(async () => {
    function findElement(e, all = false) {
        if (all){
			for (const c of e) {
                var elements = document.querySelectorAll(c);
                //console.log(a)
                if (elements.length > 1) return elements
                //if (6 === a.length) return a
            }
		}
		else{
			for (const i of e) {
				var e = document.querySelector(i);
				//console.log(n)
				if (e) return e
			}
		}
                
        return null
    }

    async function delay(delayInms) {
		return new Promise(resolve  => {
			setTimeout(() => {
				resolve(2);
			}, delayInms);
		});
	}

    

    function Click_Checkbox() { // u()
        try {
            var e = findElement(['#checkbox']);
            if(e!=null) e.click();
        } catch (e) {}
    }
	

    function get_Question() { // s()
		let CauHoiFullText = findElement([".prompt-text"])?.innerText?.trim()
		if(CauHoiFullText != null && CauHoiFullText != undefined)
		{
			return CauHoiFullText;
		}
		return CauHoiFullText
    }

	const getBase64FromUrl = async (url) => {
		//console.log("Image URL >>>"+url);
		const data = await fetch(url);
		const blob = await data.blob();
		return new Promise((resolve) => {
			const reader = new FileReader();
			reader.readAsDataURL(blob); 
			reader.onloadend = () => {
			const base64data = reader.result;   
			resolve(base64data);
			}
		});
	}

	function mergeImages(base64Images) {
		const firstImage = new Image();
		firstImage.src = base64Images[0];
		
		firstImage.onload = function() {
			const width = firstImage.width; // Lấy chiều rộng của hình ảnh
			const height = firstImage.height; // Lấy chiều dài của hình ảnh
			alert(firstImage.width + ", " + firstImage.height);
			console.log('Width:', width);
			console.log('Height:', height);
		};
		
		const imageWidth = 128;
		const imageHeight = 128;
		console.log("imageWidth: " + imageWidth);
		// Tạo một canvas mới có kích thước phù hợp với ảnh ghép
		const canvas = document.createElement('canvas');
		canvas.width = 3 * imageWidth;
		canvas.height = 3 * imageHeight;
		const ctx = canvas.getContext('2d');
		
		// Vị trí ban đầu (x, y) của ảnh trong canvas
		let x = 0;
		let y = 0;
		
		// Lặp qua từng ảnh base64 và vẽ chúng lên canvas
		for (let i = 0; i < base64Images.length; i++) {
			const image = new Image();
			image.src = base64Images[i];
		
			// Vẽ ảnh vào canvas
			ctx.drawImage(image, x, y, imageWidth, imageHeight);
		
			// Tính toán vị trí (x, y) của ảnh tiếp theo
			x += imageWidth;
			if (x >= 3 * imageWidth) {
			x = 0;
			y += imageHeight;
			}
		}
		
		// Trả về base64 của ảnh ghép
		return canvas.toDataURL();
	}


    async function Get_img() {
		var listbase64 = [];
        let imageWrappers = findElement([".task-image > .image-wrapper > .image"], true);
		console.log("imageWrappers: "+imageWrappers.length);
		
		for (let i = 0; i < imageWrappers.length; i++) {
			if(imageWrappers[i]?.style["background-image"]){
				var bg = imageWrappers[i].style["background-image"];
				if(bg?.trim()?.match(/(?!^)".*?"/g))
				{
					bg = bg?.trim()?.match(/(?!^)".*?"/g)[0].replaceAll('"', "")
				}
				const base64data = await getBase64FromUrl(bg);
				listbase64.push(base64data.split(";base64,")[1]);
			}
		}
		//console.log("listbase64: "+listbase64.length);
		const myString = mergeImages(listbase64);
		return listbase64;
    }

    async function RunTask()
    {
    	for (;;) 
    	{
			try{
				var Settings = await BG.exec("Settings.get");
				//console.log(Settings);
				if(Settings.funcaptcha_auto_open){
					//await Click_Checkbox();
				}
				var CauHoi = get_Question();
				if(CauHoi)
				{
					console.log("CauHoi >>> " + CauHoi);
					console.log("APIKEY >>> " + API_KEY);
					var Check_Cell_IMG = findElement([".task-image"], !0);
					if(Check_Cell_IMG==null) continue;
					console.log("Check_Cell_IMG.length >>> " + Check_Cell_IMG.length);
					setTimeout(function() {
						// code to be executed after 5 seconds
					}, 5000);
					if(Check_Cell_IMG.length< 1) continue;
					var CaptchaBase64 = await Get_img();
					console.log(CaptchaBase64.length);
					if(CaptchaBase64 && CaptchaBase64 != null)
					{
						CaptchaBase64.forEach(async (base64) => {
							//console.log("=== debug 1 ===");
							var arr_post = {
								imginstructions: CauHoi,
								key: "API_KEY",
								body: base64,
								method: "base64",
								json: 0
							};
							console.log("=== arr_post ===");
							console.log(arr_post);
							var header = {"Content-Type": "application/json"}
							//console.log("BASE_API >>" + BASE_API);
							var Send_IN = await Net.fetch(BASE_API + `/hcaptcha`, {
								method: "POST",
								headers: header,
								body: JSON.stringify(arr_post)
							})

							//console.log("json post >>" + JSON.stringify(arr_post));
						

							if (Send_IN.charAt(0) === '"' && Send_IN.charAt(Send_IN.length - 1) === '"') {
								Send_IN = Send_IN.substring(1, Send_IN.length - 1);
							}
							console.log("=== Send_IN ===");
							console.log(Send_IN);
							if(Send_IN.includes("|"))
							{
								var split = Send_IN.split("|");
								var _id = split[1];
								await delay(1000);
								var ViTriClick = 0;
								if(_id.includes(",")){
									split = _id.split(",");
									ViTriClick = Number(split[1]);
								}
								else{
									ViTriClick = Number(split[1]);
								}
								
								if(document.querySelector('.right-arrow'))
								{
									for(var p=1;p<ViTriClick;p++)
									{
										if(document.querySelector('.right-arrow').click()){}
										await delay(1200);
									}
									if(document.querySelector("#root > div > div > div > button").click()){}
								}else{
									Check_Cell_IMG[ViTriClick-1].click()
								}
							}	
						});
						
						
						
					}
				}
			}
			catch(err){

			}
    		await delay(3000);
	    }
    }
    if (setInterval(() => {
            document.dispatchEvent(new Event("mousemove"))
        }, 50), window.location.pathname.startsWith("/captcha/v1") )
    {
        /*for (;;) {
            await Time.sleep(1e3);
            var t, a = await BG.exec("Settings.get");
            a && a.enabled && (t = await Location.hostname(), a.disabled_hosts.includes(t) || (a.funcaptcha_auto_open && r() ? await u() : a.funcaptcha_auto_solve && null !== s() && null !== Get_img() && await e()))
        }*/

        var Setting = await BG.exec("Settings.get");
		console.log(Setting);
        if(Setting.enabled && Setting.funcaptcha_auto_solve && Setting.funcaptcha_auto_open)
        {
        	await RunTask();
        }
    }
}
)();
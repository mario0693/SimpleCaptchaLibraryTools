(async () => {
    function findElement(e, all = false) {
        if (all){
			for (const c of e) {
                var elements = document.querySelectorAll(c);
                //console.log(a)
                if (elements.length > 1) return elements
                //if (6 === a.length) return a
            }
		}
		else{
			for (const i of e) {
				var e = document.querySelector(i);
				//console.log(n)
				if (e) return e
			}
		}
                
        return null
    }
	function getElementByXpath(path) {
		return document.evaluate(path, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
	}
    async function delay(delayInms) {
		return new Promise(resolve  => {
			setTimeout(() => {
				resolve(2);
			}, delayInms);
		});
	}

    

    function Click_Checkbox() { // u()
        try {
            var e = findElement(['#checkbox']);
            if(e!=null){
				let imageWrappers = findElement([".task-image > .image-wrapper > .image"], true);
				
                if (imageWrappers == null || imageWrappers.length==0) {
					e.click();
                    delay(3000);
                }
                else{
                    console.log("taskgrid found");
                }
				
			} 
        } catch (e) {}
    }
	

    function get_Question() { // s()
		let CauHoiFullText = findElement([".prompt-text"])?.innerText?.trim()
		if(CauHoiFullText != null && CauHoiFullText != undefined)
		{
			return CauHoiFullText;
		}
		return CauHoiFullText
    }

	const getBase64FromUrl = async (url) => {
		//console.log("Image URL >>>"+url);
		const data = await fetch(url);
		const blob = await data.blob();
		return new Promise((resolve) => {
			const reader = new FileReader();
			reader.readAsDataURL(blob); 
			reader.onloadend = () => {
			const base64data = reader.result;   
			resolve(base64data);
			}
		});
	}

	function mergeImages(base64Images) {
		const firstImage = new Image();
		firstImage.src = base64Images[0];
		
		firstImage.onload = function() {
			const width = firstImage.width; // Lấy chiều rộng của hình ảnh
			const height = firstImage.height; // Lấy chiều dài của hình ảnh
			alert(firstImage.width + ", " + firstImage.height);
			console.log('Width:', width);
			console.log('Height:', height);
		};
		
		const imageWidth = 128;
		const imageHeight = 128;
		console.log("imageWidth: " + imageWidth);
		// Tạo một canvas mới có kích thước phù hợp với ảnh ghép
		const canvas = document.createElement('canvas');
		canvas.width = 3 * imageWidth;
		canvas.height = 3 * imageHeight;
		const ctx = canvas.getContext('2d');
		
		// Vị trí ban đầu (x, y) của ảnh trong canvas
		let x = 0;
		let y = 0;
		
		// Lặp qua từng ảnh base64 và vẽ chúng lên canvas
		for (let i = 0; i < base64Images.length; i++) {
			const image = new Image();
			image.src = base64Images[i];
		
			// Vẽ ảnh vào canvas
			ctx.drawImage(image, x, y, imageWidth, imageHeight);
		
			// Tính toán vị trí (x, y) của ảnh tiếp theo
			x += imageWidth;
			if (x >= 3 * imageWidth) {
			x = 0;
			y += imageHeight;
			}
		}
		
		// Trả về base64 của ảnh ghép
		return canvas.toDataURL();
	}


    async function Get_img() {
		var listbase64 = [];
        let imageWrappers = findElement([".task-image > .image-wrapper > .image"], true);
		console.log("imageWrappers: "+imageWrappers.length);
		var listnum =[]
		listnum.push("1"); 
		listnum.push("1");
		listnum.push("1");
		listnum.push("1");
		listnum.push("1");
		listnum.push("1");
		listnum.push("1");
		listnum.push("1");
		for (let i = 0; i < imageWrappers.length; i++) {
			if(imageWrappers[i]?.style["background-image"]){
				var bg = imageWrappers[i].style["background-image"];
				if(bg?.trim()?.match(/(?!^)".*?"/g))
				{
					bg = bg?.trim()?.match(/(?!^)".*?"/g)[0].replaceAll('"', "")
				}
				const base64data = await getBase64FromUrl(bg);
				listbase64.push(base64data.split(";base64,")[1]);
			}
		}
		var new_base64 = listbase64.join(";");  // Ghép các base64 thành một chuỗi duy nhất
		var new_num = listnum.join(';');
		return new_base64;
    }
	async function simulateClickByOffset(element, offsetX, offsetY) {
		const rect = element.getBoundingClientRect();
		const clickX = rect.left + offsetX;
		const clickY = rect.top + offsetY;
	
		const event = new MouseEvent('click', {
			bubbles: true,
			cancelable: true,
			clientX: clickX,
			clientY: clickY
		});
	
		element.dispatchEvent(event);
	}
	
    async function RunTask()
    {	
		var count_get_Question = 0;
		var count_error  = 0;
    	for (;;) 
    	{
			try{
				var Settings = await BG.exec("Settings.get");
				//console.log(Settings);
				if(Settings.funcaptcha_auto_open){
					await Click_Checkbox();
				}
				
				
				var CauHoi = get_Question();
				if(CauHoi)
				{
					var Check_Cell_IMG = findElement([".task-image"], !0);
					if(Check_Cell_IMG==null) {
						console.log("Not found image");
						continue;

					}
					if(Check_Cell_IMG.length< 1) continue;
					var CaptchaBase64 = await Get_img();
					if(CaptchaBase64 && CaptchaBase64 != null)
					{
						var arr_post = {
							imginstructions: CauHoi,
							api_key: 'ENTER_YOUR_API_KEY_HERE',
							captcha_type: 'hcaptcha',
							body: CaptchaBase64,
							coordinatescaptcha: false,
							size: '3x3',
						};
						console.log("=== arr_post ===");
						console.log(arr_post);
						var header = {"Content-Type": "application/json"}
							//console.log("BASE_API >>" + BASE_API);
						var Send_IN = await Net.fetch(BASE_API + `/create-task`, {
							method: "POST",
							headers: header,
							body: JSON.stringify(arr_post)
						})
						if(Send_IN==null) {
							await delay(3000);
							continue;
						}
						var obj = JSON.parse(Send_IN);
							
						if (obj["status"] == "success") {
							Send_IN = obj["result"];
							console.log(Send_IN);
						}
						else{
							if(obj["status"] == "wrong API key"){
								alert("wrong API key!");
								return;
							}
						}
						if(Send_IN.includes("ERROR")) {
							break;
						}
						if(Send_IN== ""){
							var reload_element =  getElementByXpath("//div[@class='refresh button']");
							if(reload_element) {
								reload_element.click();
								await delay(3000);
							}
						}
						else{
							if (Send_IN.charAt(0) === '"' && Send_IN.charAt(Send_IN.length - 1) === '"') {
								Send_IN = Send_IN.substring(1, Send_IN.length - 1);
							}
							const myArray = Send_IN.split(',');
							console.log("=== Send_IN ===");
							console.log(Send_IN);
							var elements = document.querySelectorAll(".task-image");
							if(elements!=null){
								for (let i = 0; i < myArray.length; i++) {
									const intValue = parseInt(myArray[i], 10);
									elements[intValue-1].click();
								}
								var submit_element =  getElementByXpath("//div[@class='button-submit button']");
								if(submit_element) {
									submit_element.click();
									await delay(2000);
								}
							}
						}
					}
				}
				else{
					count_get_Question++;
					await delay(1000);
					if(count_get_Question>30) return;
				}
			}
			catch(err){
				count_error++;
				await delay(1000);
				if(count_error>30) return;
			}
    		await delay(3000);
	    }
    }
    if (setInterval(() => {
            document.dispatchEvent(new Event("mousemove"))
        }, 50), window.location.pathname.startsWith("/captcha/v1") )
    {
		await RunTask();
        /*for (;;) {
            await Time.sleep(1e3);
            var t, a = await BG.exec("Settings.get");
            a && a.enabled && (t = await Location.hostname(), a.disabled_hosts.includes(t) || (a.funcaptcha_auto_open && r() ? await u() : a.funcaptcha_auto_solve && null !== s() && null !== Get_img() && await e()))
        }

        var Setting = await BG.exec("Settings.get");
		console.log(Setting);
        if(Setting.enabled && Setting.funcaptcha_auto_solve && Setting.funcaptcha_auto_open)
        {
        	await RunTask();
        }*/
    }
}
)();
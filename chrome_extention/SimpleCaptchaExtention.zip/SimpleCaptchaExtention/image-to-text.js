"use strict";
(() => {
	var Re = Object.create;
	var q = Object.defineProperty;
	var Se = Object.getOwnPropertyDescriptor;
	var _e = Object.getOwnPropertyNames;
	var Ae = Object.getPrototypeOf,
		Oe = Object.prototype.hasOwnProperty;
	var V = (e, t) => () => (t || e((t = {
		exports: {}
	}).exports, t), t.exports);
	var Fe = (e, t, n, r) => {
		if (t && typeof t == "object" || typeof t == "function")
			for (let o of _e(t)) !Oe.call(e, o) && o !== n && q(e, o, {
				get: () => t[o],
				enumerable: !(r = Se(t, o)) || r.enumerable
			});
		return e
	};
	var W = (e, t, n) => (n = e != null ? Re(Ae(e)) : {}, Fe(t || !e || !e.__esModule ? q(n, "default", {
		value: e,
		enumerable: !0
	}) : n, e));
	var ne = V((vt, A) => {
		"use strict";
		var g = typeof Reflect == "object" ? Reflect : null,
			$ = g && typeof g.apply == "function" ? g.apply : function(t, n, r) {
				return Function.prototype.apply.call(t, n, r)
			},
			w;
		g && typeof g.ownKeys == "function" ? w = g.ownKeys : Object.getOwnPropertySymbols ? w = function(t) {
			return Object.getOwnPropertyNames(t).concat(Object.getOwnPropertySymbols(t))
		} : w = function(t) {
			return Object.getOwnPropertyNames(t)
		};

		function Ne(e) {
			console && console.warn && console.warn(e)
		}
		var G = Number.isNaN || function(t) {
			return t !== t
		};

		function i() {
			i.init.call(this)
		}
		A.exports = i;
		A.exports.once = Pe;
		i.EventEmitter = i;
		i.prototype._events = void 0;
		i.prototype._eventsCount = 0;
		i.prototype._maxListeners = void 0;
		var z = 10;

		function M(e) {
			if (typeof e != "function") throw new TypeError('The "listener" argument must be of type Function. Received type ' + typeof e)
		}
		Object.defineProperty(i, "defaultMaxListeners", {
			enumerable: !0,
			get: function() {
				return z
			},
			set: function(e) {
				if (typeof e != "number" || e < 0 || G(e)) throw new RangeError('The value of "defaultMaxListeners" is out of range. It must be a non-negative number. Received ' + e + ".");
				z = e
			}
		});
		i.init = function() {
			(this._events === void 0 || this._events === Object.getPrototypeOf(this)._events) && (this._events = Object.create(null), this._eventsCount = 0), this._maxListeners = this._maxListeners || void 0
		};
		i.prototype.setMaxListeners = function(t) {
			if (typeof t != "number" || t < 0 || G(t)) throw new RangeError('The value of "n" is out of range. It must be a non-negative number. Received ' + t + ".");
			return this._maxListeners = t, this
		};

		function Q(e) {
			return e._maxListeners === void 0 ? i.defaultMaxListeners : e._maxListeners
		}
		i.prototype.getMaxListeners = function() {
			return Q(this)
		};
		i.prototype.emit = function(t) {
			for (var n = [], r = 1; r < arguments.length; r++) n.push(arguments[r]);
			var o = t === "error",
				a = this._events;
			if (a !== void 0) o = o && a.error === void 0;
			else if (!o) return !1;
			if (o) {
				var s;
				if (n.length > 0 && (s = n[0]), s instanceof Error) throw s;
				var c = new Error("Unhandled error." + (s ? " (" + s.message + ")" : ""));
				throw c.context = s, c
			}
			var p = a[t];
			if (p === void 0) return !1;
			if (typeof p == "function") $(p, this, n);
			else
				for (var f = p.length, d = ee(p, f), r = 0; r < f; ++r) $(d[r], this, n);
			return !0
		};

		function X(e, t, n, r) {
			var o, a, s;
			if (M(n), a = e._events, a === void 0 ? (a = e._events = Object.create(null), e._eventsCount = 0) : (a.newListener !== void 0 && (e.emit("newListener", t, n.listener ? n.listener : n), a = e._events), s = a[t]), s === void 0) s = a[t] = n, ++e._eventsCount;
			else if (typeof s == "function" ? s = a[t] = r ? [n, s] : [s, n] : r ? s.unshift(n) : s.push(n), o = Q(e), o > 0 && s.length > o && !s.warned) {
				s.warned = !0;
				var c = new Error("Possible EventEmitter memory leak detected. " + s.length + " " + String(t) + " listeners added. Use emitter.setMaxListeners() to increase limit");
				c.name = "MaxListenersExceededWarning", c.emitter = e, c.type = t, c.count = s.length, Ne(c)
			}
			return e
		}
		i.prototype.addListener = function(t, n) {
			return X(this, t, n, !1)
		};
		i.prototype.on = i.prototype.addListener;
		i.prototype.prependListener = function(t, n) {
			return X(this, t, n, !0)
		};

		function De() {
			if (!this.fired) return this.target.removeListener(this.type, this.wrapFn), this.fired = !0, arguments.length === 0 ? this.listener.call(this.target) : this.listener.apply(this.target, arguments)
		}

		function Y(e, t, n) {
			var r = {
					fired: !1,
					wrapFn: void 0,
					target: e,
					type: t,
					listener: n
				},
				o = De.bind(r);
			return o.listener = n, r.wrapFn = o, o
		}
		i.prototype.once = function(t, n) {
			return M(n), this.on(t, Y(this, t, n)), this
		};
		i.prototype.prependOnceListener = function(t, n) {
			return M(n), this.prependListener(t, Y(this, t, n)), this
		};
		i.prototype.removeListener = function(t, n) {
			var r, o, a, s, c;
			if (M(n), o = this._events, o === void 0) return this;
			if (r = o[t], r === void 0) return this;
			if (r === n || r.listener === n) --this._eventsCount === 0 ? this._events = Object.create(null) : (delete o[t], o.removeListener && this.emit("removeListener", t, r.listener || n));
			else if (typeof r != "function") {
				for (a = -1, s = r.length - 1; s >= 0; s--)
					if (r[s] === n || r[s].listener === n) {
						c = r[s].listener, a = s;
						break
					} if (a < 0) return this;
				a === 0 ? r.shift() : He(r, a), r.length === 1 && (o[t] = r[0]), o.removeListener !== void 0 && this.emit("removeListener", t, c || n)
			}
			return this
		};
		i.prototype.off = i.prototype.removeListener;
		i.prototype.removeAllListeners = function(t) {
			var n, r, o;
			if (r = this._events, r === void 0) return this;
			if (r.removeListener === void 0) return arguments.length === 0 ? (this._events = Object.create(null), this._eventsCount = 0) : r[t] !== void 0 && (--this._eventsCount === 0 ? this._events = Object.create(null) : delete r[t]), this;
			if (arguments.length === 0) {
				var a = Object.keys(r),
					s;
				for (o = 0; o < a.length; ++o) s = a[o], s !== "removeListener" && this.removeAllListeners(s);
				return this.removeAllListeners("removeListener"), this._events = Object.create(null), this._eventsCount = 0, this
			}
			if (n = r[t], typeof n == "function") this.removeListener(t, n);
			else if (n !== void 0)
				for (o = n.length - 1; o >= 0; o--) this.removeListener(t, n[o]);
			return this
		};

		function Z(e, t, n) {
			var r = e._events;
			if (r === void 0) return [];
			var o = r[t];
			return o === void 0 ? [] : typeof o == "function" ? n ? [o.listener || o] : [o] : n ? je(o) : ee(o, o.length)
		}
		i.prototype.listeners = function(t) {
			return Z(this, t, !0)
		};
		i.prototype.rawListeners = function(t) {
			return Z(this, t, !1)
		};
		i.listenerCount = function(e, t) {
			return typeof e.listenerCount == "function" ? e.listenerCount(t) : J.call(e, t)
		};
		i.prototype.listenerCount = J;

		function J(e) {
			var t = this._events;
			if (t !== void 0) {
				var n = t[e];
				if (typeof n == "function") return 1;
				if (n !== void 0) return n.length
			}
			return 0
		}
		i.prototype.eventNames = function() {
			return this._eventsCount > 0 ? w(this._events) : []
		};

		function ee(e, t) {
			for (var n = new Array(t), r = 0; r < t; ++r) n[r] = e[r];
			return n
		}

		function He(e, t) {
			for (; t + 1 < e.length; t++) e[t] = e[t + 1];
			e.pop()
		}

		function je(e) {
			for (var t = new Array(e.length), n = 0; n < t.length; ++n) t[n] = e[n].listener || e[n];
			return t
		}

		function Pe(e, t) {
			return new Promise(function(n, r) {
				function o(s) {
					e.removeListener(t, a), r(s)
				}

				function a() {
					typeof e.removeListener == "function" && e.removeListener("error", o), n([].slice.call(arguments))
				}
				te(e, t, a, {
					once: !0
				}), t !== "error" && Be(e, o, {
					once: !0
				})
			})
		}

		function Be(e, t, n) {
			typeof e.on == "function" && te(e, "error", t, n)
		}

		function te(e, t, n, r) {
			if (typeof e.on == "function") r.once ? e.once(t, n) : e.on(t, n);
			else if (typeof e.addEventListener == "function") e.addEventListener(t, function o(a) {
				r.once && e.removeEventListener(t, o), n(a)
			});
			else throw new TypeError('The "emitter" argument must be of type EventEmitter. Received type ' + typeof e)
		}
	});
	var ie = V((Tt, l) => {
		l.exports.boot = function(e) {
			return e
		};
		l.exports.ssrMiddleware = function(e) {
			return e
		};
		l.exports.configure = function(e) {
			return e
		};
		l.exports.preFetch = function(e) {
			return e
		};
		l.exports.route = function(e) {
			return e
		};
		l.exports.store = function(e) {
			return e
		};
		l.exports.bexBackground = function(e) {
			return e
		};
		l.exports.bexContent = function(e) {
			return e
		};
		l.exports.bexDom = function(e) {
			return e
		};
		l.exports.ssrProductionExport = function(e) {
			return e
		};
		l.exports.ssrCreate = function(e) {
			return e
		};
		l.exports.ssrListen = function(e) {
			return e
		};
		l.exports.ssrClose = function(e) {
			return e
		};
		l.exports.ssrServeStaticContent = function(e) {
			return e
		};
		l.exports.ssrRenderPreloadTag = function(e) {
			return e
		}
	});
	var ae = W(ne());
	var O, L = 0,
		u = new Array(256);
	for (let e = 0; e < 256; e++) u[e] = (e + 256).toString(16).substring(1);
	var Ue = (() => {
			let e = typeof crypto != "undefined" ? crypto : typeof window != "undefined" ? window.crypto || window.msCrypto : void 0;
			if (e !== void 0) {
				if (e.randomBytes !== void 0) return e.randomBytes;
				if (e.getRandomValues !== void 0) return t => {
					let n = new Uint8Array(t);
					return e.getRandomValues(n), n
				}
			}
			return t => {
				let n = [];
				for (let r = t; r > 0; r--) n.push(Math.floor(Math.random() * 256));
				return n
			}
		})(),
		re = 4096;

	function oe() {
		(O === void 0 || L + 16 > re) && (L = 0, O = Ue(re));
		let e = Array.prototype.slice.call(O, L, L += 16);
		return e[6] = e[6] & 15 | 64, e[8] = e[8] & 63 | 128, u[e[0]] + u[e[1]] + u[e[2]] + u[e[3]] + "-" + u[e[4]] + u[e[5]] + "-" + u[e[6]] + u[e[7]] + "-" + u[e[8]] + u[e[9]] + "-" + u[e[10]] + u[e[11]] + u[e[12]] + u[e[13]] + u[e[14]] + u[e[15]]
	}
	var Ke = {
			undefined: () => 0,
			boolean: () => 4,
			number: () => 8,
			string: e => 2 * e.length,
			object: e => e ? Object.keys(e).reduce((t, n) => F(n) + F(e[n]) + t, 0) : 0
		},
		F = e => Ke[typeof e](e),
		C = class extends ae.EventEmitter {
			constructor(t) {
				super(), this.setMaxListeners(1 / 0), this.wall = t, t.listen(n => {
					Array.isArray(n) ? n.forEach(r => this._emit(r)) : this._emit(n)
				}), this._sendingQueue = [], this._sending = !1, this._maxMessageSize = 32 * 1024 * 1024
			}
			send(t, n) {
				return this._send([{
					event: t,
					payload: n
				}])
			}
			getEvents() {
				return this._events
			}
			on(t, n) {
				return super.on(t, r => {
					n({
						...r,
						respond: o => this.send(r.eventResponseKey, o)
					})
				})
			}
			_emit(t) {
				typeof t == "string" ? this.emit(t) : this.emit(t.event, t.payload)
			}
			_send(t) {
				return this._sendingQueue.push(t), this._nextSend()
			}
			_nextSend() {
				if (!this._sendingQueue.length || this._sending) return Promise.resolve();
				this._sending = !0;
				let t = this._sendingQueue.shift(),
					n = t[0],
					r = `${n.event}.${oe()}`,
					o = r + ".result";
				return new Promise((a, s) => {
					let c = [],
						p = f => {
							if (f !== void 0 && f._chunkSplit) {
								let d = f._chunkSplit;
								c = [...c, ...f.data], d.lastChunk && (this.off(o, p), a(c))
							} else this.off(o, p), a(f)
						};
					this.on(o, p);
					try {
						let f = t.map(d => ({
							...d,
							payload: {
								data: d.payload,
								eventResponseKey: o
							}
						}));
						this.wall.send(f)
					} catch (f) {
						let d = "Message length exceeded maximum allowed length.";
						if (f.message === d && Array.isArray(n.payload)) {
							let U = F(n);
							if (U > this._maxMessageSize) {
								let T = Math.ceil(U / this._maxMessageSize),
									ke = Math.ceil(n.payload.length / T),
									K = n.payload;
								for (let _ = 0; _ < T; _++) {
									let Ie = Math.min(K.length, ke);
									this.wall.send([{
										event: n.event,
										payload: {
											_chunkSplit: {
												count: T,
												lastChunk: _ === T - 1
											},
											data: K.splice(0, Ie)
										}
									}])
								}
							}
						}
					}
					this._sending = !1, setTimeout(() => this._nextSend(), 16)
				})
			}
		};
	var se = (e, t) => {
		window.addEventListener("message", n => {
			if (n.source === window && n.data.from !== void 0 && n.data.from === t) {
				let r = n.data[0],
					o = e.getEvents();
				for (let a in o) a === r.event && o[a](r.payload)
			}
		}, !1)
	};
	var we = W(ie());
	var qe = chrome.runtime.getURL("assets/config.json");
	async function Ve() {
		let e = await chrome.storage.local.get("defaultConfig");
		if (e.defaultConfig) return e.defaultConfig;
		let t = {},
			r = await (await fetch(qe)).json();
		return r && (t = r, chrome.storage.local.set({
			defaultConfig: t
		})), t
	}
	var b = {
			manualSolving: !1,
			apiKey: "",
			appId: "",
			enabledForImageToText: !0,
			enabledForRecaptchaV3: !0,
			enabledForHCaptcha: !0,
			enabledForGeetestV4: !1,
			recaptchaV3MinScore: .5,
			enabledForRecaptcha: !0,
			enabledForFunCaptcha: !0,
			enabledForDataDome: !1,
			enabledForAwsCaptcha: !0,
			useProxy: !1,
			proxyType: "http",
			hostOrIp: "",
			port: "",
			proxyLogin: "",
			proxyPassword: "",
			enabledForBlacklistControl: !1,
			blackUrlList: [],
			isInBlackList: !1,
			reCaptchaMode: "click",
			reCaptchaDelayTime: 0,
			reCaptchaCollapse: !1,
			reCaptchaRepeatTimes: 10,
			reCaptcha3Mode: "token",
			reCaptcha3DelayTime: 0,
			reCaptcha3Collapse: !1,
			reCaptcha3RepeatTimes: 10,
			hCaptchaMode: "click",
			hCaptchaDelayTime: 0,
			hCaptchaCollapse: !1,
			hCaptchaRepeatTimes: 10,
			funCaptchaMode: "click",
			funCaptchaDelayTime: 0,
			funCaptchaCollapse: !1,
			funCaptchaRepeatTimes: 10,
			geetestMode: "click",
			geetestCollapse: !1,
			geetestDelayTime: 0,
			geetestRepeatTimes: 10,
			textCaptchaMode: "click",
			textCaptchaCollapse: !1,
			textCaptchaDelayTime: 0,
			textCaptchaRepeatTimes: 10,
			enabledForCloudflare: !1,
			cloudflareMode: "click",
			cloudflareCollapse: !1,
			cloudflareDelayTime: 0,
			cloudflareRepeatTimes: 10,
			datadomeMode: "click",
			datadomeCollapse: !1,
			datadomeDelayTime: 0,
			datadomeRepeatTimes: 10,
			awsCaptchaMode: "click",
			awsCollapse: !1,
			awsDelayTime: 0,
			awsRepeatTimes: 10,
			useCapsolver: !0,
			isInit: !1,
			solvedCallback: "captchaSolvedCallback",
			textCaptchaSourceAttribute: "capsolver-image-to-text-source",
			textCaptchaResultAttribute: "capsolver-image-to-text-result"
		},
		ce = {
			proxyType: ["socks5", "http", "https", "socks4"],
			mode: ["click", "token"]
		};
	async function ue() {
		let e = await Ve(),
			t = Object.keys(e);
		for (let n of t)
			if (!(n === "proxyType" && !ce[n].includes(e[n]))) {
				{
					if (n.endsWith("Mode") && !ce.mode.includes(e[n])) continue;
					if (n === "port") {
						if (typeof e[n] != "number") continue;
						b[n] = e[n]
					}
				}
				Reflect.has(b, n) && typeof b[n] == typeof e[n] && (b[n] = e[n])
			} return b
	}
	var We = ue(),
		m = {
			default: We,
			async get(e) {
				return (await this.getAll())[e]
			},
			async getAll() {
				let e = await ue(),
					t = await chrome.storage.local.get("config");
				return m.joinConfig(e, t.config)
			},
			async set(e) {
				let t = await m.getAll(),
					n = m.joinConfig(t, e);
				return chrome.storage.local.set({
					config: n
				})
			},
			joinConfig(e, t) {
				let n = {};
				if (e)
					for (let r in e) n[r] = e[r];
				if (t)
					for (let r in t) n[r] = t[r];
				return n
			}
		};

	function le(e) {
		return new Promise((t, n) => {
			let r = new Image;
			r.src = e, r.setAttribute("crossOrigin", "anonymous"), r.onload = () => {
				let o = document.createElement("canvas");
				o.width = r.width, o.height = r.height, o.getContext("2d").drawImage(r, 0, 0, r.width, r.height);
				let s = o.toDataURL();
				t(s)
			}, r.onerror = o => {
				n(o)
			}
		})
	}

	function fe(e) {
		return new Promise(t => setTimeout(t, e))
	}

	function v(e, t) {
		var n;
		return "KeyboardEvent" in window ? n = new window.KeyboardEvent(t, {
			bubbles: !0,
			cancelable: !1
		}) : (n = e.ownerDocument.createEvent("Events"), n.initEvent(t, !0, !1), n.charCode = 0, n.keyCode = 0, n.which = 0, n.srcElement = e, n.target = e), n
	}

	function $e(e) {
		return !e || e && typeof e.click != "function" ? !1 : (e.click(), !0)
	}

	function ze(e, t) {
		if (t) {
			var n = e.value;
			e.focus(), e.value !== n && (e.value = n)
		} else e.focus()
	}

	function Ge(e) {
		var t = e.value;
		$e(e), ze(e, !1), e.dispatchEvent(v(e, "keydown")), e.dispatchEvent(v(e, "keypress")), e.dispatchEvent(v(e, "keyup")), e.value !== t && (e.value = t)
	}

	function Qe(e) {
		var t = e.value,
			n = e.ownerDocument.createEvent("HTMLEvents"),
			r = e.ownerDocument.createEvent("HTMLEvents");
		e.dispatchEvent(v(e, "keydown")), e.dispatchEvent(v(e, "keypress")), e.dispatchEvent(v(e, "keyup")), r.initEvent("input", !0, !0), e.dispatchEvent(r), n.initEvent("change", !0, !0), e.dispatchEvent(n), e.blur(), e.value !== t && (e.value = t)
	}
	async function N(e, t) {
		e.value = t, Ge(e), Qe(e)
	}
	var E = "capsolver-image-to-text-source",
		y = "capsolver-image-to-text-result",
		k = [],
		pe = 0;

	function I(e) {
		let t = "",
			n = "",
			r = [];
		e.style.backgroundImage ? n = e.style.backgroundImage : e.style.background && (n = e.style.background), r = n.split(",");
		let o = r.find(a => a.startsWith("url("));
		return o ? (t = o.slice(5, o.length - 2), t.startsWith("blob:") ? t.slice(5) : t) : ""
	}

	function Ye() {
		let e = "[" + E + "]",
			t = document.querySelectorAll(e),
			n = [];
		return Array.from(t).forEach(r => {
			let o = r.tagName,
				a = "";
			o === "IMG" ? a = r.getAttribute("src") : a = I(r), a && n.push(r)
		}), n
	}

	function Ze() {
		let e = "input[" + y + "]";
		return Array.from(document.querySelectorAll(e))
	}

	function Je(e) {
		let t = e.naturalWidth,
			n = e.naturalHeight,
			r = document.createElement("canvas");
		return Object.assign(r, {
			width: t,
			height: n
		}), r.getContext("2d").drawImage(e, 0, 0, t, n, 0, 0, t, n), r.toDataURL("image/jpeg")
	}
	async function et(e) {
		if (e.tagName === "IMG") return Je(e);
		{
			let n = I(e);
			return await le(n)
		}
	}

	function tt(e, t) {
		let n = [];
		return t.forEach(r => {
			let o = r.getAttribute(y),
				a = e.find(s => s.getAttribute(E) === o);
			a && n.push({
				image: a,
				result: r,
				id: o
			})
		}), n
	}
	async function nt(e, t) {
		let n = await et(e.image),
			r = {
				body: n.slice(n.indexOf(";base64,") + 8),
				id: e.id
			},
			o = {
				action: "solver",
				captchaType: "textCaptcha",
				params: r
			};
		chrome.runtime.sendMessage(o).then(a => {
			var s;
			if (!(a != null && a.response) || ((s = a == null ? void 0 : a.response) == null ? void 0 : s.error)) {
				pe++, pe <= t && k.splice(k.indexOf(e.id), 1);
				return
			}
			it(a.response)
		})
	}
	var rt = [{
			value: "mul",
			label: "\xD7"
		}, {
			value: "add",
			label: "+"
		}, {
			value: "subtract",
			label: "-"
		}],
		ot = new Map([
			["add", "+"],
			["subtract", "-"],
			["mul", "\xD7"]
		]);

	function at(e, t) {
		let r = e.slice(0, e.length - 1).split(ot.get(t));
		if (isNaN(Number(r[0])) || isNaN(Number(r[1]))) return NaN;
		let o;
		switch (t) {
			case "add": {
				o = Number(r[0]) + Number(r[1]);
				break
			}
			case "subtract": {
				o = Number(r[0]) - Number(r[1]);
				break
			}
			case "mul": {
				o = Number(r[0]) * Number(r[1]);
				break
			}
		}
		return o
	}

	function st(e) {
		return e[e.length - 1] !== "=" ? !1 : rt.find(n => e.indexOf(n.label) !== -1).value
	}

	function it(e) {
		var a;
		let t = (a = e.response) == null ? void 0 : a.solution,
			n = e.id,
			r = document.querySelector(`input[${y}="${n}"]`);
		if (!r) return;
		let o = st(t.text);
		if (!o) N(r, t.text);
		else {
			let s = at(t.text, o);
			N(r, isNaN(s) ? t.text : s)
		}
		chrome.runtime.sendMessage({
			action: "solved"
		})
	}

	function de(e) {
		E = e.textCaptchaSourceAttribute || E, y = e.textCaptchaResultAttribute || y;
		let t = Ye();
		if (t.length <= 0) return !1;
		let n = Ze();
		if (n.length <= 0) return !1;
		let r = tt(t, n);
		return r.length <= 0 ? !1 : r
	}

	function me(e, t) {
		let n = e.length;
		for (let r = 0; r < n; r++) k.includes(e[r].id) || (nt(e[r], t), k.push(e[r].id))
	}
	var j, h, x, D = 0,
		H = 0;

	function he() {
		document.addEventListener("contextmenu", e => {
			h = null, x = null;
			let t = e.target,
				n = t.tagName,
				r = "";
			n === "IMG" ? r = t.getAttribute("src") : r = I(t), r ? h = t : x = t
		})
	}

	function P() {
		let e = window.location;
		return e.protocol + "//" + e.hostname + e.pathname
	}

	function ge(e) {
		let t = "",
			n = e.tagName.toLowerCase(),
			r = e.id;
		if (r) t = `${n}#${r}`;
		else {
			let o = Array.from(e.attributes),
				a = "";
			for (let s = 0; s < o.length; s++) {
				let c = o[s];
				["id", "class", "onclick"].includes(c.name) || (a += "[" + c.name + '="' + c.value + '"]')
			}
			t = `${n}${a}`
		}
		return t
	}
	async function R(e) {
		let t = await m.getAll();
		if (e === "source") return t.textCaptchaSourceAttribute || "capsolver-image-to-text-source";
		if (e === "result") return t.textCaptchaResultAttribute || "capsolver-image-to-text-result"
	}
	async function ct(e) {
		var c;
		let t = ge(e),
			n = P(),
			r = await chrome.storage.local.get("imageUrls"),
			o = (c = r == null ? void 0 : r.imageUrls) != null ? c : {},
			a = o.hasOwnProperty(n) ? o[n] : {},
			s = Object.assign({}, a, {
				image: t
			});
		o.hasOwnProperty(n) ? Object.assign(o[n], s) : o[n] = s, chrome.storage.local.set({
			imageUrls: o
		})
	}
	async function ut(e) {
		let t = ge(e),
			n = P(),
			o = (await chrome.storage.local.get("imageUrls")).imageUrls,
			a = o[n],
			s = Object.assign({}, a, {
				input: t
			});
		o[n] = s, chrome.storage.local.set({
			imageUrls: o
		})
	}

	function ve(e) {
		let t = e.indexOf("[");
		return t === -1 ? "id" : e.indexOf("#") > t ? "attr" : "id"
	}
	async function lt(e) {
		if (!e) return;
		let t, n = await R("source");
		ve(e) === "attr" ? t = document.querySelector(e) : t = document.getElementById(e.slice(e.indexOf("#") + 1)), t == null || t.setAttribute(n, String(D))
	}
	async function ft(e) {
		if (!e) return;
		let t, n = await R("result");
		ve(e) === "attr" ? t = document.querySelector(e) : t = document.getElementById(e.slice(e.indexOf("#") + 1)), t == null || t.setAttribute(n, String(H))
	}

	function pt(e) {
		let t = e.image,
			n = e.input;
		lt(t), ft(n)
	}

	function Ce() {
		return !h
	}

	function be() {
		return !!j
	}
	async function ye() {
		let e = await R("source");
		!h || (h.setAttribute(e, String(D)), j = h, D++, chrome.runtime.sendMessage({
			action: "updateMenu"
		}), ct(h))
	}
	async function xe() {
		let e = await R("result");
		!x || (x.setAttribute(e, String(H)), j = null, H++, chrome.runtime.sendMessage({
			action: "updateMenu"
		}), ut(x))
	}
	async function Te() {
		let e = P(),
			t = await chrome.storage.local.get("imageUrls");
		if (!t) return;
		let n = t == null ? void 0 : t.imageUrls;
		if (!n) return;
		let r = n[e];
		!r || pt(r)
	}
	async function dt(e) {
		!e.useCapsolver || !e.enabledForImageToText || !e.apiKey || e.enabledForBlacklistControl && e.isInBlackList || (await fe(e.textCaptchaDelayTime), setInterval(async () => {
			let t = de(e);
			!t || me(t, e.textCaptchaRepeatTimes)
		}, 1e3))
	}
	var S = null;
	S && window.clearInterval(S);
	S = window.setInterval(async () => {
		let e = await m.getAll();
		!e.isInit || (dt(e), window.clearInterval(S))
	}, 100);
	he();
	chrome.runtime.onMessage.addListener((e, t, n) => {
		let {
			command: r
		} = e;
		switch (r) {
			case "image2Text:canMarkImage":
				let o = Ce();
				n(o);
				break;
			case "image2Text:canMarkInput":
				let a = be();
				n(a);
				break;
			case "image2Text:markedImage":
				ye(), n(null);
				break;
			case "image2Text:markedResult":
				xe(), n(null);
				break
		}
		return !1
	});
	var mt = setInterval(function() {
			document.readyState === "complete" && (Te(), clearInterval(mt))
		}, 1e3),
		Me = (0, we.bexContent)(e => {});
	var B = chrome.runtime.connect({
			name: "contentScript"
		}),
		Le = !1;
	B.onDisconnect.addListener(() => {
		Le = !0
	});
	var Ee = new C({
		listen(e) {
			B.onMessage.addListener(e)
		},
		send(e) {
			Le || (B.postMessage(e), window.postMessage({
				...e,
				from: "bex-content-script"
			}, "*"))
		}
	});

	function ht(e) {
		let t = document.createElement("script");
		t.src = e, t.onload = function() {
			this.remove()
		}, (document.head || document.documentElement).appendChild(t)
	}
	document instanceof HTMLDocument && ht(chrome.runtime.getURL("dom.js"));
	se(Ee, "bex-dom");
	Me(Ee);
})();
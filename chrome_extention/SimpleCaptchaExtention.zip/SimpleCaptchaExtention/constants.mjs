const API_KEY = 'Hello World';
module.exports = API_KEY;
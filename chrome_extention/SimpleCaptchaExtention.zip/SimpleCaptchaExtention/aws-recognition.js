"use strict";
(() => {
	var he = Object.create;
	var O = Object.defineProperty;
	var ge = Object.getOwnPropertyDescriptor;
	var ve = Object.getOwnPropertyNames;
	var ye = Object.getPrototypeOf,
		Ce = Object.prototype.hasOwnProperty;
	var B = (e, t) => () => (t || e((t = {
		exports: {}
	}).exports, t), t.exports);
	var be = (e, t, n, o) => {
		if (t && typeof t == "object" || typeof t == "function")
			for (let r of ve(t)) !Ce.call(e, r) && r !== n && O(e, r, {
				get: () => t[r],
				enumerable: !(o = ge(t, r)) || o.enumerable
			});
		return e
	};
	var A = (e, t, n) => (n = e != null ? he(ye(e)) : {}, be(t || !e || !e.__esModule ? O(n, "default", {
		value: e,
		enumerable: !0
	}) : n, e));
	var Y = B((Ue, _) => {
		"use strict";
		var h = typeof Reflect == "object" ? Reflect : null,
			j = h && typeof h.apply == "function" ? h.apply : function(t, n, o) {
				return Function.prototype.apply.call(t, n, o)
			},
			x;
		h && typeof h.ownKeys == "function" ? x = h.ownKeys : Object.getOwnPropertySymbols ? x = function(t) {
			return Object.getOwnPropertyNames(t).concat(Object.getOwnPropertySymbols(t))
		} : x = function(t) {
			return Object.getOwnPropertyNames(t)
		};

		function xe(e) {
			console && console.warn && console.warn(e)
		}
		var H = Number.isNaN || function(t) {
			return t !== t
		};

		function a() {
			a.init.call(this)
		}
		_.exports = a;
		_.exports.once = Te;
		a.EventEmitter = a;
		a.prototype._events = void 0;
		a.prototype._eventsCount = 0;
		a.prototype._maxListeners = void 0;
		var N = 10;

		function w(e) {
			if (typeof e != "function") throw new TypeError('The "listener" argument must be of type Function. Received type ' + typeof e)
		}
		Object.defineProperty(a, "defaultMaxListeners", {
			enumerable: !0,
			get: function() {
				return N
			},
			set: function(e) {
				if (typeof e != "number" || e < 0 || H(e)) throw new RangeError('The value of "defaultMaxListeners" is out of range. It must be a non-negative number. Received ' + e + ".");
				N = e
			}
		});
		a.init = function() {
			(this._events === void 0 || this._events === Object.getPrototypeOf(this)._events) && (this._events = Object.create(null), this._eventsCount = 0), this._maxListeners = this._maxListeners || void 0
		};
		a.prototype.setMaxListeners = function(t) {
			if (typeof t != "number" || t < 0 || H(t)) throw new RangeError('The value of "n" is out of range. It must be a non-negative number. Received ' + t + ".");
			return this._maxListeners = t, this
		};

		function q(e) {
			return e._maxListeners === void 0 ? a.defaultMaxListeners : e._maxListeners
		}
		a.prototype.getMaxListeners = function() {
			return q(this)
		};
		a.prototype.emit = function(t) {
			for (var n = [], o = 1; o < arguments.length; o++) n.push(arguments[o]);
			var r = t === "error",
				s = this._events;
			if (s !== void 0) r = r && s.error === void 0;
			else if (!r) return !1;
			if (r) {
				var i;
				if (n.length > 0 && (i = n[0]), i instanceof Error) throw i;
				var c = new Error("Unhandled error." + (i ? " (" + i.message + ")" : ""));
				throw c.context = i, c
			}
			var l = s[t];
			if (l === void 0) return !1;
			if (typeof l == "function") j(l, this, n);
			else
				for (var p = l.length, d = W(l, p), o = 0; o < p; ++o) j(d[o], this, n);
			return !0
		};

		function K(e, t, n, o) {
			var r, s, i;
			if (w(n), s = e._events, s === void 0 ? (s = e._events = Object.create(null), e._eventsCount = 0) : (s.newListener !== void 0 && (e.emit("newListener", t, n.listener ? n.listener : n), s = e._events), i = s[t]), i === void 0) i = s[t] = n, ++e._eventsCount;
			else if (typeof i == "function" ? i = s[t] = o ? [n, i] : [i, n] : o ? i.unshift(n) : i.push(n), r = q(e), r > 0 && i.length > r && !i.warned) {
				i.warned = !0;
				var c = new Error("Possible EventEmitter memory leak detected. " + i.length + " " + String(t) + " listeners added. Use emitter.setMaxListeners() to increase limit");
				c.name = "MaxListenersExceededWarning", c.emitter = e, c.type = t, c.count = i.length, xe(c)
			}
			return e
		}
		a.prototype.addListener = function(t, n) {
			return K(this, t, n, !1)
		};
		a.prototype.on = a.prototype.addListener;
		a.prototype.prependListener = function(t, n) {
			return K(this, t, n, !0)
		};

		function we() {
			if (!this.fired) return this.target.removeListener(this.type, this.wrapFn), this.fired = !0, arguments.length === 0 ? this.listener.call(this.target) : this.listener.apply(this.target, arguments)
		}

		function U(e, t, n) {
			var o = {
					fired: !1,
					wrapFn: void 0,
					target: e,
					type: t,
					listener: n
				},
				r = we.bind(o);
			return r.listener = n, o.wrapFn = r, r
		}
		a.prototype.once = function(t, n) {
			return w(n), this.on(t, U(this, t, n)), this
		};
		a.prototype.prependOnceListener = function(t, n) {
			return w(n), this.prependListener(t, U(this, t, n)), this
		};
		a.prototype.removeListener = function(t, n) {
			var o, r, s, i, c;
			if (w(n), r = this._events, r === void 0) return this;
			if (o = r[t], o === void 0) return this;
			if (o === n || o.listener === n) --this._eventsCount === 0 ? this._events = Object.create(null) : (delete r[t], r.removeListener && this.emit("removeListener", t, o.listener || n));
			else if (typeof o != "function") {
				for (s = -1, i = o.length - 1; i >= 0; i--)
					if (o[i] === n || o[i].listener === n) {
						c = o[i].listener, s = i;
						break
					} if (s < 0) return this;
				s === 0 ? o.shift() : Me(o, s), o.length === 1 && (r[t] = o[0]), r.removeListener !== void 0 && this.emit("removeListener", t, c || n)
			}
			return this
		};
		a.prototype.off = a.prototype.removeListener;
		a.prototype.removeAllListeners = function(t) {
			var n, o, r;
			if (o = this._events, o === void 0) return this;
			if (o.removeListener === void 0) return arguments.length === 0 ? (this._events = Object.create(null), this._eventsCount = 0) : o[t] !== void 0 && (--this._eventsCount === 0 ? this._events = Object.create(null) : delete o[t]), this;
			if (arguments.length === 0) {
				var s = Object.keys(o),
					i;
				for (r = 0; r < s.length; ++r) i = s[r], i !== "removeListener" && this.removeAllListeners(i);
				return this.removeAllListeners("removeListener"), this._events = Object.create(null), this._eventsCount = 0, this
			}
			if (n = o[t], typeof n == "function") this.removeListener(t, n);
			else if (n !== void 0)
				for (r = n.length - 1; r >= 0; r--) this.removeListener(t, n[r]);
			return this
		};

		function z(e, t, n) {
			var o = e._events;
			if (o === void 0) return [];
			var r = o[t];
			return r === void 0 ? [] : typeof r == "function" ? n ? [r.listener || r] : [r] : n ? Le(r) : W(r, r.length)
		}
		a.prototype.listeners = function(t) {
			return z(this, t, !0)
		};
		a.prototype.rawListeners = function(t) {
			return z(this, t, !1)
		};
		a.listenerCount = function(e, t) {
			return typeof e.listenerCount == "function" ? e.listenerCount(t) : V.call(e, t)
		};
		a.prototype.listenerCount = V;

		function V(e) {
			var t = this._events;
			if (t !== void 0) {
				var n = t[e];
				if (typeof n == "function") return 1;
				if (n !== void 0) return n.length
			}
			return 0
		}
		a.prototype.eventNames = function() {
			return this._eventsCount > 0 ? x(this._events) : []
		};

		function W(e, t) {
			for (var n = new Array(t), o = 0; o < t; ++o) n[o] = e[o];
			return n
		}

		function Me(e, t) {
			for (; t + 1 < e.length; t++) e[t] = e[t + 1];
			e.pop()
		}

		function Le(e) {
			for (var t = new Array(e.length), n = 0; n < t.length; ++n) t[n] = e[n].listener || e[n];
			return t
		}

		function Te(e, t) {
			return new Promise(function(n, o) {
				function r(i) {
					e.removeListener(t, s), o(i)
				}

				function s() {
					typeof e.removeListener == "function" && e.removeListener("error", r), n([].slice.call(arguments))
				}
				X(e, t, s, {
					once: !0
				}), t !== "error" && Ee(e, r, {
					once: !0
				})
			})
		}

		function Ee(e, t, n) {
			typeof e.on == "function" && X(e, "error", t, n)
		}

		function X(e, t, n, o) {
			if (typeof e.on == "function") o.once ? e.once(t, n) : e.on(t, n);
			else if (typeof e.addEventListener == "function") e.addEventListener(t, function r(s) {
				o.once && e.removeEventListener(t, r), n(s)
			});
			else throw new TypeError('The "emitter" argument must be of type EventEmitter. Received type ' + typeof e)
		}
	});
	var Z = B((Ye, f) => {
		f.exports.boot = function(e) {
			return e
		};
		f.exports.ssrMiddleware = function(e) {
			return e
		};
		f.exports.configure = function(e) {
			return e
		};
		f.exports.preFetch = function(e) {
			return e
		};
		f.exports.route = function(e) {
			return e
		};
		f.exports.store = function(e) {
			return e
		};
		f.exports.bexBackground = function(e) {
			return e
		};
		f.exports.bexContent = function(e) {
			return e
		};
		f.exports.bexDom = function(e) {
			return e
		};
		f.exports.ssrProductionExport = function(e) {
			return e
		};
		f.exports.ssrCreate = function(e) {
			return e
		};
		f.exports.ssrListen = function(e) {
			return e
		};
		f.exports.ssrClose = function(e) {
			return e
		};
		f.exports.ssrServeStaticContent = function(e) {
			return e
		};
		f.exports.ssrRenderPreloadTag = function(e) {
			return e
		}
	});
	var J = A(Y());
	var R, M = 0,
		u = new Array(256);
	for (let e = 0; e < 256; e++) u[e] = (e + 256).toString(16).substring(1);
	var _e = (() => {
			let e = typeof crypto != "undefined" ? crypto : typeof window != "undefined" ? window.crypto || window.msCrypto : void 0;
			if (e !== void 0) {
				if (e.randomBytes !== void 0) return e.randomBytes;
				if (e.getRandomValues !== void 0) return t => {
					let n = new Uint8Array(t);
					return e.getRandomValues(n), n
				}
			}
			return t => {
				let n = [];
				for (let o = t; o > 0; o--) n.push(Math.floor(Math.random() * 256));
				return n
			}
		})(),
		Q = 4096;

	function G() {
		(R === void 0 || M + 16 > Q) && (M = 0, R = _e(Q));
		let e = Array.prototype.slice.call(R, M, M += 16);
		return e[6] = e[6] & 15 | 64, e[8] = e[8] & 63 | 128, u[e[0]] + u[e[1]] + u[e[2]] + u[e[3]] + "-" + u[e[4]] + u[e[5]] + "-" + u[e[6]] + u[e[7]] + "-" + u[e[8]] + u[e[9]] + "-" + u[e[10]] + u[e[11]] + u[e[12]] + u[e[13]] + u[e[14]] + u[e[15]]
	}
	var Re = {
			undefined: () => 0,
			boolean: () => 4,
			number: () => 8,
			string: e => 2 * e.length,
			object: e => e ? Object.keys(e).reduce((t, n) => k(n) + k(e[n]) + t, 0) : 0
		},
		k = e => Re[typeof e](e),
		g = class extends J.EventEmitter {
			constructor(t) {
				super(), this.setMaxListeners(1 / 0), this.wall = t, t.listen(n => {
					Array.isArray(n) ? n.forEach(o => this._emit(o)) : this._emit(n)
				}), this._sendingQueue = [], this._sending = !1, this._maxMessageSize = 32 * 1024 * 1024
			}
			send(t, n) {
				return this._send([{
					event: t,
					payload: n
				}])
			}
			getEvents() {
				return this._events
			}
			on(t, n) {
				return super.on(t, o => {
					n({
						...o,
						respond: r => this.send(o.eventResponseKey, r)
					})
				})
			}
			_emit(t) {
				typeof t == "string" ? this.emit(t) : this.emit(t.event, t.payload)
			}
			_send(t) {
				return this._sendingQueue.push(t), this._nextSend()
			}
			_nextSend() {
				if (!this._sendingQueue.length || this._sending) return Promise.resolve();
				this._sending = !0;
				let t = this._sendingQueue.shift(),
					n = t[0],
					o = `${n.event}.${G()}`,
					r = o + ".result";
				return new Promise((s, i) => {
					let c = [],
						l = p => {
							if (p !== void 0 && p._chunkSplit) {
								let d = p._chunkSplit;
								c = [...c, ...p.data], d.lastChunk && (this.off(r, l), s(c))
							} else this.off(r, l), s(p)
						};
					this.on(r, l);
					try {
						let p = t.map(d => ({
							...d,
							payload: {
								data: d.payload,
								eventResponseKey: r
							}
						}));
						this.wall.send(p)
					} catch (p) {
						let d = "Message length exceeded maximum allowed length.";
						if (p.message === d && Array.isArray(n.payload)) {
							let F = k(n);
							if (F > this._maxMessageSize) {
								let b = Math.ceil(F / this._maxMessageSize),
									de = Math.ceil(n.payload.length / b),
									D = n.payload;
								for (let E = 0; E < b; E++) {
									let me = Math.min(D.length, de);
									this.wall.send([{
										event: n.event,
										payload: {
											_chunkSplit: {
												count: b,
												lastChunk: E === b - 1
											},
											data: D.splice(0, me)
										}
									}])
								}
							}
						}
					}
					this._sending = !1, setTimeout(() => this._nextSend(), 16)
				})
			}
		};
	var $ = (e, t) => {
		window.addEventListener("message", n => {
			if (n.source === window && n.data.from !== void 0 && n.data.from === t) {
				let o = n.data[0],
					r = e.getEvents();
				for (let s in r) s === o.event && r[s](o.payload)
			}
		}, !1)
	};
	var ae = A(Z());
	var ke = chrome.runtime.getURL("assets/config.json");
	async function Se() {
		let e = await chrome.storage.local.get("defaultConfig");
		if (e.defaultConfig) return e.defaultConfig;
		let t = {},
			o = await (await fetch(ke)).json();
		return o && (t = o, chrome.storage.local.set({
			defaultConfig: t
		})), t
	}
	var v = {
			manualSolving: !1,
			apiKey: "",
			appId: "",
			enabledForImageToText: !0,
			enabledForRecaptchaV3: !0,
			enabledForHCaptcha: !0,
			enabledForGeetestV4: !1,
			recaptchaV3MinScore: .5,
			enabledForRecaptcha: !0,
			enabledForFunCaptcha: !0,
			enabledForDataDome: !1,
			enabledForAwsCaptcha: !0,
			useProxy: !1,
			proxyType: "http",
			hostOrIp: "",
			port: "",
			proxyLogin: "",
			proxyPassword: "",
			enabledForBlacklistControl: !1,
			blackUrlList: [],
			isInBlackList: !1,
			reCaptchaMode: "click",
			reCaptchaDelayTime: 0,
			reCaptchaCollapse: !1,
			reCaptchaRepeatTimes: 10,
			reCaptcha3Mode: "token",
			reCaptcha3DelayTime: 0,
			reCaptcha3Collapse: !1,
			reCaptcha3RepeatTimes: 10,
			hCaptchaMode: "click",
			hCaptchaDelayTime: 0,
			hCaptchaCollapse: !1,
			hCaptchaRepeatTimes: 10,
			funCaptchaMode: "click",
			funCaptchaDelayTime: 0,
			funCaptchaCollapse: !1,
			funCaptchaRepeatTimes: 10,
			geetestMode: "click",
			geetestCollapse: !1,
			geetestDelayTime: 0,
			geetestRepeatTimes: 10,
			textCaptchaMode: "click",
			textCaptchaCollapse: !1,
			textCaptchaDelayTime: 0,
			textCaptchaRepeatTimes: 10,
			enabledForCloudflare: !1,
			cloudflareMode: "click",
			cloudflareCollapse: !1,
			cloudflareDelayTime: 0,
			cloudflareRepeatTimes: 10,
			datadomeMode: "click",
			datadomeCollapse: !1,
			datadomeDelayTime: 0,
			datadomeRepeatTimes: 10,
			awsCaptchaMode: "click",
			awsCollapse: !1,
			awsDelayTime: 0,
			awsRepeatTimes: 10,
			useCapsolver: !0,
			isInit: !1,
			solvedCallback: "captchaSolvedCallback",
			textCaptchaSourceAttribute: "capsolver-image-to-text-source",
			textCaptchaResultAttribute: "capsolver-image-to-text-result"
		},
		ee = {
			proxyType: ["socks5", "http", "https", "socks4"],
			mode: ["click", "token"]
		};
	async function te() {
		let e = await Se(),
			t = Object.keys(e);
		for (let n of t)
			if (!(n === "proxyType" && !ee[n].includes(e[n]))) {
				{
					if (n.endsWith("Mode") && !ee.mode.includes(e[n])) continue;
					if (n === "port") {
						if (typeof e[n] != "number") continue;
						v[n] = e[n]
					}
				}
				Reflect.has(v, n) && typeof v[n] == typeof e[n] && (v[n] = e[n])
			} return v
	}
	var Pe = te(),
		y = {
			default: Pe,
			async get(e) {
				return (await this.getAll())[e]
			},
			async getAll() {
				let e = await te(),
					t = await chrome.storage.local.get("config");
				return y.joinConfig(e, t.config)
			},
			async set(e) {
				let t = await y.getAll(),
					n = y.joinConfig(t, e);
				return chrome.storage.local.set({
					config: n
				})
			},
			joinConfig(e, t) {
				let n = {};
				if (e)
					for (let o in e) n[o] = e[o];
				if (t)
					for (let o in t) n[o] = t[o];
				return n
			}
		};

	function C(e) {
		return new Promise(t => setTimeout(t, e))
	}

	function ne(e, t) {
		function n(o, r, s) {
			let i = ["mouseover", "mousedown", "mouseup", "click"],
				c = {
					clientX: r,
					clientY: s,
					bubbles: !0
				};
			for (let l = 0; l < i.length; l++) {
				let p = new MouseEvent(i[l], c);
				o.dispatchEvent(p)
			}
		}
		e.forEach(o => {
			n(t, o.x, o.y)
		})
	}
	var L = "",
		m = "",
		S = 0,
		oe = 0;

	function Ie() {
		return {
			image: L,
			question: m === "toycarcity" ? "aws:toycarcity:carcity" : m
		}
	}
	async function Fe(e) {
		var c;
		let t = (c = e == null ? void 0 : e.box) != null ? c : [],
			n = 0,
			o = 0,
			r = [],
			s = document.querySelector("canvas"),
			i = s.getBoundingClientRect();
		for (let l = 0; l < t.length; l++) l % 2 === 0 ? n = t[l] + i.left : (o = t[l] + i.top, r.push({
			x: n,
			y: o
		}));
		ne(r, s), await C(500), De()
	}

	function De() {
		let e = document.querySelector("#amzn-btn-verify-internal");
		e == null || e.click()
	}

	function Oe() {
		return document.querySelector("#captcha-container") && document.querySelector("#amzn-captcha-verify-button")
	}

	function Be() {
		document.querySelector("#amzn-captcha-verify-button").click()
	}

	function Ae() {
		let e = document.querySelector("#amzn-btn-verify-internal");
		return !(!e || e.style.display === "none")
	}
	async function je() {
		if (oe < S || !m) return;
		let e = Ie(),
			t = {
				action: "solver",
				captchaType: "awsCaptcha",
				params: e
			};
		chrome.runtime.sendMessage(t).then(n => {
			var o, r;
			if (!(n != null && n.response) || ((o = n == null ? void 0 : n.response) == null ? void 0 : o.error)) {
				L = "", m = "", S++, P();
				return
			}
			Fe((r = n.response.response) == null ? void 0 : r.solution)
		})
	}

	function re() {
		m !== "toycarcity" && (m = "", document.querySelector("#amzn-btn-refresh-internal").click());
		let e = setInterval(async () => {
			Ae() && (clearInterval(e), await je())
		}, 1e3)
	}
	async function ie(e) {
		try {
			let t = JSON.parse(e);
			if (!(t != null && t.problem_type)) return;
			L = t.assets.image, m = t.problem_type, re()
		} catch (t) {
			console.error(t)
		}
	}
	async function se(e) {
		var t;
		try {
			let n = JSON.parse(e);
			if (n.token) return;
			if (n.success) {
				chrome.runtime.sendMessage({
					action: "solved"
				});
				return
			}
			if (!((t = n == null ? void 0 : n.problem) != null && t.problem_type)) return;
			L = n.problem.assets.image, m = n.problem.problem_type, S++, re()
		} catch (n) {
			console.error(n)
		}
	}

	function P(e) {
		e && (oe = e.awsRepeatTimes);
		let t = setInterval(() => {
			Oe() && (Be(), clearInterval(t))
		}, 1e3)
	}
	var ce = document.createElement("script");
	ce.src = chrome.runtime.getURL("assets/inject/injected.js");
	var Ne = document.head || document.documentElement;
	Ne.appendChild(ce);

	function le(e) {
		window.addEventListener("message", function(t) {
			var n, o;
			if (((n = t == null ? void 0 : t.data) == null ? void 0 : n.type) === "xhr" || ((o = t == null ? void 0 : t.data) == null ? void 0 : o.type) === "fetch") {
				let r = t.data.url;
				r.includes("/problem") && ie(t.data.data), r.includes("/verify") && se(t.data.data)
			}
		}), P(e)
	}
	async function He(e) {
		!e.useCapsolver || !e.enabledForAwsCaptcha || !e.apiKey || e.enabledForBlacklistControl && e.isInBlackList || e.awsCaptchaMode !== "click" || (await C(e.awsDelayTime), le(e))
	}
	var T = null;
	T && window.clearInterval(T);
	T = window.setInterval(async () => {
		let e = await y.getAll();
		!e.isInit || (e.manualSolving ? chrome.runtime.onMessage.addListener(t => {
			t.command === "execute" && le(e)
		}) : He(e), window.clearInterval(T))
	}, 100);
	var ue = (0, ae.bexContent)(e => {});
	var I = chrome.runtime.connect({
			name: "contentScript"
		}),
		fe = !1;
	I.onDisconnect.addListener(() => {
		fe = !0
	});
	var pe = new g({
		listen(e) {
			I.onMessage.addListener(e)
		},
		send(e) {
			fe || (I.postMessage(e), window.postMessage({
				...e,
				from: "bex-content-script"
			}, "*"))
		}
	});

	function qe(e) {
		let t = document.createElement("script");
		t.src = e, t.onload = function() {
			this.remove()
		}, (document.head || document.documentElement).appendChild(t)
	}
	document instanceof HTMLDocument && qe(chrome.runtime.getURL("dom.js"));
	$(pe, "bex-dom");
	ue(pe);
})();
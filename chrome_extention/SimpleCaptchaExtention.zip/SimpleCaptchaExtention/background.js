class API {
    static endpoints = {};
    static register(t, e) {
        var a = t.name + "." + e;
        const s = t[e];
        this.endpoints[a] = function() {
            return s.apply(t, [{
                tab_id: arguments[0].tab_id,
                frame_id: arguments[0].frame_id,
                ...arguments[0].data
            }])
        }
    }
}
class Net {
    static async fetch({
        url: t,
        options: e
    } = {
        options: {}
    }) {
        try {
            return await (await fetch(t, e)).text()
        } catch (t) {
            return null
        }
    }
    static {
        API.register(this, "fetch")
    }
}

"use strict";
(() => {
	var le = Object.create;
	var P = Object.defineProperty;
	var pe = Object.getOwnPropertyDescriptor;
	var fe = Object.getOwnPropertyNames;
	var de = Object.getPrototypeOf,
		he = Object.prototype.hasOwnProperty;
	var me = (e, t, n) => t in e ? P(e, t, {
		enumerable: !0,
		configurable: !0,
		writable: !0,
		value: n
	}) : e[t] = n;
	var O = (e, t) => () => (t || e((t = {
		exports: {}
	}).exports, t), t.exports);
	var ge = (e, t, n, a) => {
		if (t && typeof t == "object" || typeof t == "function")
			for (let o of fe(t)) !he.call(e, o) && o !== n && P(e, o, {
				get: () => t[o],
				enumerable: !(a = pe(t, o)) || a.enumerable
			});
		return e
	};
	var K = (e, t, n) => (n = e != null ? le(de(e)) : {}, ge(t || !e || !e.__esModule ? P(n, "default", {
		value: e,
		enumerable: !0
	}) : n, e));
	var C = (e, t, n) => (me(e, typeof t != "symbol" ? t + "" : t, n), n);
	var Q = O((Xe, S) => {
		"use strict";
		var y = typeof Reflect == "object" ? Reflect : null,
			D = y && typeof y.apply == "function" ? y.apply : function(t, n, a) {
				return Function.prototype.apply.call(t, n, a)
			},
			x;
		y && typeof y.ownKeys == "function" ? x = y.ownKeys : Object.getOwnPropertySymbols ? x = function(t) {
			return Object.getOwnPropertyNames(t).concat(Object.getOwnPropertySymbols(t))
		} : x = function(t) {
			return Object.getOwnPropertyNames(t)
		};

		function ye(e) {
			console && console.warn && console.warn(e)
		}
		var j = Number.isNaN || function(t) {
			return t !== t
		};

		function i() {
			i.init.call(this)
		}
		S.exports = i;
		S.exports.once = ke;
		i.EventEmitter = i;
		i.prototype._events = void 0;
		i.prototype._eventsCount = 0;
		i.prototype._maxListeners = void 0;
		var B = 10;

		function T(e) {
			if (typeof e != "function") throw new TypeError('The "listener" argument must be of type Function. Received type ' + typeof e)
		}
		Object.defineProperty(i, "defaultMaxListeners", {
			enumerable: !0,
			get: function() {
				return B
			},
			set: function(e) {
				if (typeof e != "number" || e < 0 || j(e)) throw new RangeError('The value of "defaultMaxListeners" is out of range. It must be a non-negative number. Received ' + e + ".");
				B = e
			}
		});
		i.init = function() {
			(this._events === void 0 || this._events === Object.getPrototypeOf(this)._events) && (this._events = Object.create(null), this._eventsCount = 0), this._maxListeners = this._maxListeners || void 0
		};
		i.prototype.setMaxListeners = function(t) {
			if (typeof t != "number" || t < 0 || j(t)) throw new RangeError('The value of "n" is out of range. It must be a non-negative number. Received ' + t + ".");
			return this._maxListeners = t, this
		};

		function H(e) {
			return e._maxListeners === void 0 ? i.defaultMaxListeners : e._maxListeners
		}
		i.prototype.getMaxListeners = function() {
			return H(this)
		};
		i.prototype.emit = function(t) {
			for (var n = [], a = 1; a < arguments.length; a++) n.push(arguments[a]);
			var o = t === "error",
				r = this._events;
			if (r !== void 0) o = o && r.error === void 0;
			else if (!o) return !1;
			if (o) {
				var s;
				if (n.length > 0 && (s = n[0]), s instanceof Error) throw s;
				var c = new Error("Unhandled error." + (s ? " (" + s.message + ")" : ""));
				throw c.context = s, c
			}
			var h = r[t];
			if (h === void 0) return !1;
			if (typeof h == "function") D(h, this, n);
			else
				for (var u = h.length, m = W(h, u), a = 0; a < u; ++a) D(m[a], this, n);
			return !0
		};

		function U(e, t, n, a) {
			var o, r, s;
			if (T(n), r = e._events, r === void 0 ? (r = e._events = Object.create(null), e._eventsCount = 0) : (r.newListener !== void 0 && (e.emit("newListener", t, n.listener ? n.listener : n), r = e._events), s = r[t]), s === void 0) s = r[t] = n, ++e._eventsCount;
			else if (typeof s == "function" ? s = r[t] = a ? [n, s] : [s, n] : a ? s.unshift(n) : s.push(n), o = H(e), o > 0 && s.length > o && !s.warned) {
				s.warned = !0;
				var c = new Error("Possible EventEmitter memory leak detected. " + s.length + " " + String(t) + " listeners added. Use emitter.setMaxListeners() to increase limit");
				c.name = "MaxListenersExceededWarning", c.emitter = e, c.type = t, c.count = s.length, ye(c)
			}
			return e
		}
		i.prototype.addListener = function(t, n) {
			return U(this, t, n, !1)
		};
		i.prototype.on = i.prototype.addListener;
		i.prototype.prependListener = function(t, n) {
			return U(this, t, n, !0)
		};

		function Ce() {
			if (!this.fired) return this.target.removeListener(this.type, this.wrapFn), this.fired = !0, arguments.length === 0 ? this.listener.call(this.target) : this.listener.apply(this.target, arguments)
		}

		function N(e, t, n) {
			var a = {
					fired: !1,
					wrapFn: void 0,
					target: e,
					type: t,
					listener: n
				},
				o = Ce.bind(a);
			return o.listener = n, a.wrapFn = o, o
		}
		i.prototype.once = function(t, n) {
			return T(n), this.on(t, N(this, t, n)), this
		};
		i.prototype.prependOnceListener = function(t, n) {
			return T(n), this.prependListener(t, N(this, t, n)), this
		};
		i.prototype.removeListener = function(t, n) {
			var a, o, r, s, c;
			if (T(n), o = this._events, o === void 0) return this;
			if (a = o[t], a === void 0) return this;
			if (a === n || a.listener === n) --this._eventsCount === 0 ? this._events = Object.create(null) : (delete o[t], o.removeListener && this.emit("removeListener", t, a.listener || n));
			else if (typeof a != "function") {
				for (r = -1, s = a.length - 1; s >= 0; s--)
					if (a[s] === n || a[s].listener === n) {
						c = a[s].listener, r = s;
						break
					} if (r < 0) return this;
				r === 0 ? a.shift() : be(a, r), a.length === 1 && (o[t] = a[0]), o.removeListener !== void 0 && this.emit("removeListener", t, c || n)
			}
			return this
		};
		i.prototype.off = i.prototype.removeListener;
		i.prototype.removeAllListeners = function(t) {
			var n, a, o;
			if (a = this._events, a === void 0) return this;
			if (a.removeListener === void 0) return arguments.length === 0 ? (this._events = Object.create(null), this._eventsCount = 0) : a[t] !== void 0 && (--this._eventsCount === 0 ? this._events = Object.create(null) : delete a[t]), this;
			if (arguments.length === 0) {
				var r = Object.keys(a),
					s;
				for (o = 0; o < r.length; ++o) s = r[o], s !== "removeListener" && this.removeAllListeners(s);
				return this.removeAllListeners("removeListener"), this._events = Object.create(null), this._eventsCount = 0, this
			}
			if (n = a[t], typeof n == "function") this.removeListener(t, n);
			else if (n !== void 0)
				for (o = n.length - 1; o >= 0; o--) this.removeListener(t, n[o]);
			return this
		};

		function q(e, t, n) {
			var a = e._events;
			if (a === void 0) return [];
			var o = a[t];
			return o === void 0 ? [] : typeof o == "function" ? n ? [o.listener || o] : [o] : n ? ve(o) : W(o, o.length)
		}
		i.prototype.listeners = function(t) {
			return q(this, t, !0)
		};
		i.prototype.rawListeners = function(t) {
			return q(this, t, !1)
		};
		i.listenerCount = function(e, t) {
			return typeof e.listenerCount == "function" ? e.listenerCount(t) : V.call(e, t)
		};
		i.prototype.listenerCount = V;

		function V(e) {
			var t = this._events;
			if (t !== void 0) {
				var n = t[e];
				if (typeof n == "function") return 1;
				if (n !== void 0) return n.length
			}
			return 0
		}
		i.prototype.eventNames = function() {
			return this._eventsCount > 0 ? x(this._events) : []
		};

		function W(e, t) {
			for (var n = new Array(t), a = 0; a < t; ++a) n[a] = e[a];
			return n
		}

		function be(e, t) {
			for (; t + 1 < e.length; t++) e[t] = e[t + 1];
			e.pop()
		}

		function ve(e) {
			for (var t = new Array(e.length), n = 0; n < t.length; ++n) t[n] = e[n].listener || e[n];
			return t
		}

		function ke(e, t) {
			return new Promise(function(n, a) {
				function o(s) {
					e.removeListener(t, r), a(s)
				}

				function r() {
					typeof e.removeListener == "function" && e.removeListener("error", o), n([].slice.call(arguments))
				}
				z(e, t, r, {
					once: !0
				}), t !== "error" && we(e, o, {
					once: !0
				})
			})
		}

		function we(e, t, n) {
			typeof e.on == "function" && z(e, "error", t, n)
		}

		function z(e, t, n, a) {
			if (typeof e.on == "function") a.once ? e.once(t, n) : e.on(t, n);
			else if (typeof e.addEventListener == "function") e.addEventListener(t, function o(r) {
				a.once && e.removeEventListener(t, o), n(r)
			});
			else throw new TypeError('The "emitter" argument must be of type EventEmitter. Received type ' + typeof e)
		}
	});
	var X = O((tt, p) => {
		p.exports.boot = function(e) {
			return e
		};
		p.exports.ssrMiddleware = function(e) {
			return e
		};
		p.exports.configure = function(e) {
			return e
		};
		p.exports.preFetch = function(e) {
			return e
		};
		p.exports.route = function(e) {
			return e
		};
		p.exports.store = function(e) {
			return e
		};
		p.exports.bexBackground = function(e) {
			return e
		};
		p.exports.bexContent = function(e) {
			return e
		};
		p.exports.bexDom = function(e) {
			return e
		};
		p.exports.ssrProductionExport = function(e) {
			return e
		};
		p.exports.ssrCreate = function(e) {
			return e
		};
		p.exports.ssrListen = function(e) {
			return e
		};
		p.exports.ssrClose = function(e) {
			return e
		};
		p.exports.ssrServeStaticContent = function(e) {
			return e
		};
		p.exports.ssrRenderPreloadTag = function(e) {
			return e
		}
	});
	var J = K(Q());
	var _, R = 0,
		l = new Array(256);
	for (let e = 0; e < 256; e++) l[e] = (e + 256).toString(16).substring(1);
	var xe = (() => {
			let e = typeof crypto != "undefined" ? crypto : typeof window != "undefined" ? window.crypto || window.msCrypto : void 0;
			if (e !== void 0) {
				if (e.randomBytes !== void 0) return e.randomBytes;
				if (e.getRandomValues !== void 0) return t => {
					let n = new Uint8Array(t);
					return e.getRandomValues(n), n
				}
			}
			return t => {
				let n = [];
				for (let a = t; a > 0; a--) n.push(Math.floor(Math.random() * 256));
				return n
			}
		})(),
		$ = 4096;

	function G() {
		(_ === void 0 || R + 16 > $) && (R = 0, _ = xe($));
		let e = Array.prototype.slice.call(_, R, R += 16);
		return e[6] = e[6] & 15 | 64, e[8] = e[8] & 63 | 128, l[e[0]] + l[e[1]] + l[e[2]] + l[e[3]] + "-" + l[e[4]] + l[e[5]] + "-" + l[e[6]] + l[e[7]] + "-" + l[e[8]] + l[e[9]] + "-" + l[e[10]] + l[e[11]] + l[e[12]] + l[e[13]] + l[e[14]] + l[e[15]]
	}
	var Te = {
			undefined: () => 0,
			boolean: () => 4,
			number: () => 8,
			string: e => 2 * e.length,
			object: e => e ? Object.keys(e).reduce((t, n) => A(n) + A(e[n]) + t, 0) : 0
		},
		A = e => Te[typeof e](e),
		b = class extends J.EventEmitter {
			constructor(t) {
				super(), this.setMaxListeners(1 / 0), this.wall = t, t.listen(n => {
					Array.isArray(n) ? n.forEach(a => this._emit(a)) : this._emit(n)
				}), this._sendingQueue = [], this._sending = !1, this._maxMessageSize = 32 * 1024 * 1024
			}
			send(t, n) {
				return this._send([{
					event: t,
					payload: n
				}])
			}
			getEvents() {
				return this._events
			}
			on(t, n) {
				return super.on(t, a => {
					n({
						...a,
						respond: o => this.send(a.eventResponseKey, o)
					})
				})
			}
			_emit(t) {
				typeof t == "string" ? this.emit(t) : this.emit(t.event, t.payload)
			}
			_send(t) {
				return this._sendingQueue.push(t), this._nextSend()
			}
			_nextSend() {
				if (!this._sendingQueue.length || this._sending) return Promise.resolve();
				this._sending = !0;
				let t = this._sendingQueue.shift(),
					n = t[0],
					a = `${n.event}.${G()}`,
					o = a + ".result";
				return new Promise((r, s) => {
					let c = [],
						h = u => {
							if (u !== void 0 && u._chunkSplit) {
								let m = u._chunkSplit;
								c = [...c, ...u.data], m.lastChunk && (this.off(o, h), r(c))
							} else this.off(o, h), r(u)
						};
					this.on(o, h);
					try {
						let u = t.map(m => ({
							...m,
							payload: {
								data: m.payload,
								eventResponseKey: o
							}
						}));
						this.wall.send(u)
					} catch (u) {
						let m = "Message length exceeded maximum allowed length.";
						if (u.message === m && Array.isArray(n.payload)) {
							let E = A(n);
							if (E > this._maxMessageSize) {
								let w = Math.ceil(E / this._maxMessageSize),
									ce = Math.ceil(n.payload.length / w),
									F = n.payload;
								for (let I = 0; I < w; I++) {
									let ue = Math.min(F.length, ce);
									this.wall.send([{
										event: n.event,
										payload: {
											_chunkSplit: {
												count: w,
												lastChunk: I === w - 1
											},
											data: F.splice(0, ue)
										}
									}])
								}
							}
						}
					}
					this._sending = !1, setTimeout(() => this._nextSend(), 16)
				})
			}
		};
	var se = K(X());
	var Re = chrome.runtime.getURL("assets/config.json");
	async function Le() {
		let e = await chrome.storage.local.get("defaultConfig");
		if (e.defaultConfig) return e.defaultConfig;
		let t = {},
			a = await (await fetch(Re)).json();
		return a && (t = a, chrome.storage.local.set({
			defaultConfig: t
		})), t
	}
	var v = {
			manualSolving: !1,
			apiKey: "",
			appId: "",
			enabledForImageToText: !0,
			enabledForRecaptchaV3: !0,
			enabledForHCaptcha: !0,
			enabledForGeetestV4: !1,
			recaptchaV3MinScore: .5,
			enabledForRecaptcha: !0,
			enabledForFunCaptcha: !0,
			enabledForDataDome: !1,
			enabledForAwsCaptcha: !0,
			useProxy: !1,
			proxyType: "http",
			hostOrIp: "",
			port: "",
			proxyLogin: "",
			proxyPassword: "",
			enabledForBlacklistControl: !1,
			blackUrlList: [],
			isInBlackList: !1,
			reCaptchaMode: "click",
			reCaptchaDelayTime: 0,
			reCaptchaCollapse: !1,
			reCaptchaRepeatTimes: 10,
			reCaptcha3Mode: "token",
			reCaptcha3DelayTime: 0,
			reCaptcha3Collapse: !1,
			reCaptcha3RepeatTimes: 10,
			hCaptchaMode: "click",
			hCaptchaDelayTime: 0,
			hCaptchaCollapse: !1,
			hCaptchaRepeatTimes: 10,
			funCaptchaMode: "click",
			funCaptchaDelayTime: 0,
			funCaptchaCollapse: !1,
			funCaptchaRepeatTimes: 10,
			geetestMode: "click",
			geetestCollapse: !1,
			geetestDelayTime: 0,
			geetestRepeatTimes: 10,
			textCaptchaMode: "click",
			textCaptchaCollapse: !1,
			textCaptchaDelayTime: 0,
			textCaptchaRepeatTimes: 10,
			enabledForCloudflare: !1,
			cloudflareMode: "click",
			cloudflareCollapse: !1,
			cloudflareDelayTime: 0,
			cloudflareRepeatTimes: 10,
			datadomeMode: "click",
			datadomeCollapse: !1,
			datadomeDelayTime: 0,
			datadomeRepeatTimes: 10,
			awsCaptchaMode: "click",
			awsCollapse: !1,
			awsDelayTime: 0,
			awsRepeatTimes: 10,
			useCapsolver: !0,
			isInit: !1,
			solvedCallback: "captchaSolvedCallback",
			textCaptchaSourceAttribute: "capsolver-image-to-text-source",
			textCaptchaResultAttribute: "capsolver-image-to-text-result"
		},
		Z = {
			proxyType: ["socks5", "http", "https", "socks4"],
			mode: ["click", "token"]
		};
	async function Y() {
		let e = await Le(),
			t = Object.keys(e);
		for (let n of t)
			if (!(n === "proxyType" && !Z[n].includes(e[n]))) {
				{
					if (n.endsWith("Mode") && !Z.mode.includes(e[n])) continue;
					if (n === "port") {
						if (typeof e[n] != "number") continue;
						v[n] = e[n]
					}
				}
				Reflect.has(v, n) && typeof v[n] == typeof e[n] && (v[n] = e[n])
			} return v
	}
	var Me = Y(),
		d = {
			default: Me,
			async get(e) {
				return (await this.getAll())[e]
			},
			async getAll() {
				let e = await Y(),
					t = await chrome.storage.local.get("config");
				return d.joinConfig(e, t.config)
			},
			async set(e) {
				let t = await d.getAll(),
					n = d.joinConfig(t, e);
				return chrome.storage.local.set({
					config: n
				})
			},
			joinConfig(e, t) {
				let n = {};
				if (e)
					for (let a in e) n[a] = e[a];
				if (t)
					for (let a in t) n[a] = t[a];
				return n
			}
		};

	function ee(e) {
		e.on("storage.get", ({
			data: t,
			respond: n
		}) => {
			let {
				key: a
			} = t;
			a === null ? chrome.storage.local.get(null, o => {
				n(Object.values(o))
			}) : chrome.storage.local.get([a], o => {
				n(o[a])
			})
		}), e.on("storage.set", ({
			data: t,
			respond: n
		}) => {
			chrome.storage.local.set({
				[t.key]: t.value
			}, () => {
				n()
			})
		}), e.on("storage.remove", ({
			data: t,
			respond: n
		}) => {
			chrome.storage.local.remove(t.key, () => {
				n()
			})
		}), e.on("config", async ({
			respond: t
		}) => {
			let n = await d.getAll();
			t(n).then()
		})
	}

	function te(e) {
		e.on("log", ({
			data: t,
			respond: n
		}) => {
			console.log(`[BEX] ${t.message}`, ...t.data || []), n()
		})
	}
	var L = class {
		constructor(t) {
			C(this, "baseURL");
			this.baseURL = t
		}
		async post(t, n, a) {
			let o = await fetch(this.getURL(t), {
				method: "POST",
				body: JSON.stringify(n),
				headers: {
					"Content-Type": "application/json"
				},
				...a
			});
			return {
				status: o.status,
				statusText: o.statusText,
				data: await o.json(),
				headers: o.headers
			}
		}
		getURL(t) {
			return this.baseURL + t
		}
	};
	var f = class {
		constructor(t) {
			C(this, "options", {
				apiKey: "",
				service: "https://api.simplecaptcha.org",
				defaultTimeout: 120,
				pollingInterval: 5,
				recaptchaTimeout: 600
			});
			C(this, "http");
			for (let n in this.options) this.options[n] = t[n] === void 0 ? this.options[n] : t[n];
			this.http = new L(this.options.service)
		}
		static async API(t) {
			let n = await d.getAll();
			if (!(t != null && t.apiKey) && !(n != null && n.apiKey)) throw new Error("Capsover: No API Kye set up yet!");
			return new f({
				apiKey: n.apiKey,
				...t
			})
		}
		async getProxyParams(t) {
			let n = await d.getAll();
			return {
				proxyType: n.proxyType,
				proxyAddress: n.hostOrIp,
				proxyPort: n.port,
				proxyLogin: n.proxyLogin,
				proxyPassword: n.proxyPassword,
				type: t.type.replace("ProxyLess", "")
			}
		}
		async getBalance() {
			var n, a, o;
			let t = await this.http.post("/getBalance", {
				clientKey: this.options.apiKey
			});
			if (t.status !== 200 || ((n = t.data) == null ? void 0 : n.errorCode) || ((a = t.data) == null ? void 0 : a.errorId)) throw new Error(((o = t.data) == null ? void 0 : o.errorDescription) || "createTask fail\uFF01");
			return t.data
		}
		async createTaskResult(t, n) {
			n || (n = {
				timeout: this.options.defaultTimeout,
				pollingInterval: this.options.pollingInterval
			});
			let a = await d.getAll();
			if (a.appId && (t.appId = a.appId), a.useProxy) {
				let u = await this.getProxyParams(t.task);
				Object.assign(t.task, u)
			}
			let o = await this.createTask(t),
				{
					taskId: r
				} = o,
				s = this.getTime(),
				c = n.timeout === void 0 ? this.options.defaultTimeout : n.timeout,
				h = n.pollingInterval === void 0 ? this.options.pollingInterval : n.pollingInterval;
			for (; !(this.getTime() - s > c);) {
				await new Promise(m => setTimeout(m, h * 1e3));
				let u = await this.getTaskSolution({
					taskId: r
				});
				if (u.status === "ready") return u
			}
			throw new Error("Timeout " + c + " seconds reached")
		}
		async createTask(t) {
			var a, o, r;
			let n = await this.http.post("/createTask", {
				clientKey: this.options.apiKey,
				...t
			});
			if (n.status !== 200 || ((a = n.data) == null ? void 0 : a.errorCode) || ((o = n.data) == null ? void 0 : o.errorId)) throw new Error(((r = n.data) == null ? void 0 : r.errorCode) || "createTask fail\uFF01");
			if (!n.data.taskId) throw new Error("taskIs is empty!");
			return n.data
		}
		async getTaskSolution({
			taskId: t
		}) {
			var a, o, r;
			let n = await this.http.post("/getTaskResult", {
				clientKey: this.options.apiKey,
				taskId: t
			});
			if (n.status !== 200 || ((a = n.data) == null ? void 0 : a.errorCode) || ((o = n.data) == null ? void 0 : o.errorId)) throw new Error(((r = n.data) == null ? void 0 : r.errorCode) || "getTaskResult fail\uFF01");
			return n.data
		}
		async createRecognitionTask(t) {
			console.log("createRecognitionTask");
			var o, r, s;
			let n = await d.getAll();
			n.appId && (t.appId = n.appId);
			let a = await this.http.post("/createTask", {
				api_key: this.options.apiKey,
				...t
			});
			if (a.status !== 200 ||((o = a.data.result) == null)) {throw new Error(((s = a.data) == null ? void 0 : s.errorDescription) || "createTask fail！");}
			//if (a.status !== 200 || ((o = a.data) == null ? void 0 : o.errorCode) || ((r = a.data) == null ? void 0 : r.errorId) !== 0) throw new Error(((s = a.data) == null ? void 0 : s.errorDescription) || "createTask fail\uFF01");
			// if (!a.data.taskId) throw new Error("taskIs is empty!");
			return a.data
		}
		getTime() {
			return parseInt(String(Date.now() / 1e3))
		}
	};

	function Ie(e) {
		chrome.contextMenus.update("capsolver-mark-image", {
			enabled: e
		})
	}

	function Pe(e) {
		chrome.contextMenus.update("capsolver-mark-result", {
			enabled: e
		})
	}

	function M(e, t) {
		return new Promise(n => {
			chrome.tabs.query({
				active: !0,
				currentWindow: !0
			}).then(a => {
				let o = a.find(s => s.id === e),
					r = o == null ? void 0 : o.url;
				r || n(!1), r && chrome.tabs.sendMessage(e, {
					command: t
				}, s => {
					n(s)
				})
			})
		})
	}
	async function Se(e) {
		return await M(e, "image2Text:canMarkImage")
	}
	async function _e(e) {
		return await M(e, "image2Text:canMarkInput")
	}
	async function ne(e) {
		M(e, "image2Text:markedImage")
	}
	async function ae(e) {
		M(e, "image2Text:markedResult")
	}
	async function k(e) {
		let t = await Se(e),
			n = await _e(e);
		Ie(t), Pe(n)
	}

	function re(e, t, n) {
		let {
			action: a
		} = e;
		return d.getAll().then(o => {
			switch (a) {
				case "solver":
					o[`${e.captchaType}Mode`] === "click" ? Fe(e).then(r => {
						n({
							response: r
						})
					}) : Ee(e, o).then(r => {
						n({
							response: r
						})
					});
					break;
				case "execute":
					oe({
						command: "execute"
					});
					break;
				case "solved":
					oe({
						response: {
							action: "solved"
						}
					});
					break;
				case "callback":
					Ae(o);
					break;
				case "updateMenu":
					k(t.tab.id);
					break
			}
		}), a === "solver"
	}
	async function oe(e) {
		let t = await chrome.tabs.query({
			currentWindow: !0,
			active: !0
		});
		for (let n of t) chrome.tabs.sendMessage(n.id, e)
	}
	async function Ae(e) {
		let t = await chrome.tabs.query({
			currentWindow: !0,
			active: !0
		});
		for (let n of t) chrome.scripting.executeScript({
			args: [e],
			target: {
				tabId: n.id
			},
			world: "MAIN",
			func: a => {
				window[a.solvedCallback] && window[a.solvedCallback]()
			}
		})
	}
	async function Ee(e, t) {
		let {
			captchaType: n,
			widgetId: a,
			params: o,
			action: r
		} = e, s = {
			action: r,
			request: {
				captchaType: n,
				widgetId: a
			}
		};
		if (!o) return s.error = "params is error!", s;
		try {
			s.response = await Oe(n, o, t)
		} catch (c) {
			s.error = String(c)
		}
		return s
	}
	async function Fe(e) {
		let {
			captchaType: t,
			params: n,
			action: a
		} = e, o = {
			action: a,
			request: {
				captchaType: t
			}
		};
		if (!n) return o.error = "params is error!", o;
		n.hasOwnProperty("index") && (o.index = n.index), n.hasOwnProperty("id") && (o.id = n.id);
		try {
			o.response = await Ke(t, n)
		} catch (r) {
			o.error = String(r)
		}
		return o
	}
	async function Oe(e, t, n) {
		let a = {
			code: "",
			status: "processing"
		};
		switch (e) {
			case "hCaptcha": {
				let o = await De(t);
				a.code = o.solution.gRecaptchaResponse, a.status = o.status;
				break
			}
			case "reCaptcha": {
				let o = await Be(t);
				a.code = o.solution.gRecaptchaResponse, a.status = o.status;
				break
			}
			case "funCaptcha": {
				let o = await He(t);
				a.code = o.solution.token, a.status = o.status;
				break
			}
			case "reCaptcha3": {
				let o = await je(t);
				a.code = o.solution.gRecaptchaResponse, a.status = o.status;
				break
			}
			case "cloudflare": {
				let o = await Ue(t);
				a.code = o.solution.token, a.status = o.status;
				break
			}
			default:
				throw new Error("do not support captchaType: " + e)
		}
		return a
	}
	async function Ke(e, t) {
		console.log("Ke");
		let n = {
			status: "processing"
		};
		switch (e) {
			case "funCaptcha": {
				let a = await Ne(t);
				n.status = a.status, n.solution = a.result;
				// n.status = a.status, n.solution = a.solution;
				break
			}
			case "hCaptcha": {
				let a = await qe(t);
				n.status = a.status, n.solution = a.result;
				// n.status = a.status, n.solution = a.solution;
				break
			}
			case "reCaptcha": {
				let a = await Ve(t);
				n.status = a.status, n.solution = a.result;
				// n.status = a.status, n.solution = a.solution;
				break
			}
			case "textCaptcha": {
				let a = await We(t);
				n.status = a.status, n.solution = a.result;
				// n.status = a.status, n.solution = a.solution;
				break
			}
			case "awsCaptcha": {
				let a = await ze(t);
				n.status = a.status, n.solution = a.result;
				// n.status = a.status, n.solution = a.solution;
				break
			}
			default:
				throw new Error("do not support captchaType: " + e)
		}
		return n
	}
	async function De(e) {
		return await (await f.API()).createTaskResult({
			task: {
				type: "HCaptchaTaskProxyLess",
				websiteURL: e.url,
				websiteKey: e.sitekey
			}
		})
	}
	async function Be(e) {
		return await (await f.API()).createTaskResult({
			task: {
				type: "ReCaptchaV2TaskProxyLess",
				websiteURL: e.url,
				websiteKey: e.sitekey,
				invisible: e.invisible,
				enterprisePayload: {
					s: e.s
				}
			}
		})
	}
	async function je(e) {
		return await (await f.API()).createTaskResult({
			task: {
				type: "ReCaptchaV3TaskProxyLess",
				websiteURL: e.url,
				websiteKey: e.sitekey,
				pageAction: e.action,
				enterprisePayload: {
					s: e.s
				}
			}
		})
	}
	async function He(e) {
		return await (await f.API()).createTaskResult({
			task: {
				type: "FunCaptchaTaskProxyLess",
				websiteURL: e.websiteURL,
				websitePublicKey: e.websitePublicKey
			}
		})
	}
	async function Ue(e) {
		return await (await f.API()).createTaskResult({
			task: {
				type: "",
				websiteURL: e.websiteURL,
				websitePublicKey: e.websiteKey,
				metaData: {
					type: e.type
				}
			}
		})
	}
	async function Ne(e) {
		return await (await f.API()).createRecognitionTask({
			captcha_type: "funcaptcha",
			body: e.image,
			imginstructions: e.question,
			imginstructions2: e.question2,
			size: e.size
			// task: {
			// 	type: "FunCaptchaClassification",
			// 	images: [e.image],
			// 	question: e.question
			// }
		})
	}
	async function qe(e) {
		return await (await f.API()).createRecognitionTask({
			captcha_type: "hcaptcha",
			queries: e.queries,
			imginstructions: e.question,
			size: e.size
			// task: {
			// 	type: "HCaptchaClassification",
			// 	queries: e.queries,
			// 	question: e.question
			// }
		})
	}
	async function Ve(e) {
		return await (await f.API()).createRecognitionTask({
			captcha_type: "recaptcha",
			body: e.image,
			imginstructions: e.question,
			size: e.size
			// task: {
			// 	type: "ReCaptchaV2Classification",
			// 	image: e.image,
			// 	question: e.question
			// }
		})
	}
	async function We(e) {
		return await (await f.API()).createRecognitionTask({
			captcha_type: "captchatext",
			body: e.body
			// task: {
			// 	type: "ImageToTextTask",
			// 	body: e.body
			// }
		})
	}
	async function ze(e) {
		return await (await f.API()).createRecognitionTask({
			captcha_type: "awswaf",
			body: e.image,
			imginstructions: e.question
			// task: {
			// 	type: "AwsWafClassification",
			// 	images: [e.image],
			// 	question: e.question
			// }
		})
	}
	chrome.runtime.onConnect.addListener(() => {
		console.log("CapSolver is connect")
	});
	chrome.runtime.onMessage.addListener(re);

	function Qe() {
		chrome.contextMenus.removeAll(() => {
			chrome.contextMenus.create({
				title: "capsolver mark image as captcha",
				contexts: ["all"],
				id: "capsolver-mark-image",
				enabled: !0
			}), chrome.contextMenus.create({
				title: "select an input for the captcha result",
				contexts: ["editable"],
				id: "capsolver-mark-result",
				enabled: !1
			})
		})
	}
	chrome.tabs.onActivated.addListener(({
		tabId: e
	}) => {
		k(e)
	});
	chrome.tabs.onUpdated.addListener((e, t) => {
		t.status === "complete" && k(e)
	});
	chrome.contextMenus.onClicked.addListener((e, t) => {
		switch (e.menuItemId) {
			case "capsolver-mark-image":
				ne(t.id);
				break;
			case "capsolver-mark-result":
				ae(t.id);
				break
		}
	});
	Qe();
	var ie = (0, se.bexBackground)(e => {
		te(e), ee(e)
	});
	var g = {},
		$e = e => {
			let t = e.sender.tab,
				n;
			if (e.name.indexOf(":") > -1) {
				let o = e.name.split(":");
				n = o[1], e.name = o[0]
			}
			t !== void 0 && (n = t.id);
			let a = g[n];
			return a || (a = g[n] = {}), a[e.name] = {
				port: e,
				connected: !0,
				listening: !1
			}, a[e.name]
		};
	chrome.runtime.onConnect.addListener(e => {
		let t = $e(e);
		t.port.onDisconnect.addListener(() => {
			t.connected = !1
		});
		let n = new b({
			listen(a) {
				for (let o in g) {
					let r = g[o];
					r.app && !r.app.listening && (r.app.listening = !0, r.app.port.onMessage.addListener(a)), r.contentScript && !r.contentScript.listening && (r.contentScript.port.onMessage.addListener(a), r.contentScript.listening = !0)
				}
			},
			send(a) {
				for (let o in g) {
					let r = g[o];
					r.app && r.app.connected && r.app.port.postMessage(a), r.contentScript && r.contentScript.connected && r.contentScript.port.postMessage(a)
				}
			}
		});
		ie(n, g);
		for (let a in g) {
			let o = g[a];
			o.app && o.contentScript && Ge(o.app, o.contentScript)
		}
	});

	function Ge(e, t) {
		e.port.onMessage.addListener(n => {
			t.connected && t.port.postMessage(n)
		}), t.port.onMessage.addListener(n => {
			e.connected && e.port.postMessage(n)
		})
	}
})();
(async () => {
	function findElement(e, all = false) {
        if (all){
			for (const c of e) {
                var elements = document.querySelectorAll(c);
                //console.log(a)
                if (elements.length > 1) return elements
                //if (6 === a.length) return a
            }
		}
		else{
			for (const i of e) {
				var e = document.querySelector(i);
				//console.log(n)
				if (e) return e
			}
		}
                
        return null
    }
	// Hàm loadImage không thay đổi
	function loadImage(src) {
		return new Promise((resolve, reject) => {
		const img = new Image();
		img.onload = () => resolve(img);
		img.onerror = reject;
		img.src = src;
		});
	}
	
	// Hàm drawImages cần biến ctx để vẽ lên canvas
	async function drawImages(ctx, imageBase64List, columns, imageWidth, imageHeight) {
		const promises = imageBase64List.map(loadImage);
		const images = await Promise.all(promises);
	
		for (let i = 0; i < images.length; i++) {
			ctx.drawImage(images[i], i % columns * imageWidth, Math.floor(i / columns) * imageHeight);
		}
	}
	async function mergeImages(imageBase64List, columns, rows) {
		// Check if the list of images is not empty.
		if (imageBase64List.length === 0) {
			throw new Error("The list of images is empty.");
		}
		
		// Check if the number of columns and rows is valid.
		if (columns <= 0 || rows <= 0) {
			throw new Error("The number of columns and rows must be greater than 0.");
		}
		
		// Get the width and height of each image.

		var img = document.createElement("img");
		img.setAttribute("src", imageBase64List[0]);
		img.onload = function() {
			const imageWidth = img.width;
			const imageHeight = img.height;
			console.log(imageWidth, imageHeight);
			// Calculate the width and height of the new image.
			const newImageWidth = columns * imageWidth;
			const newImageHeight = rows * imageHeight;
			
			const canvas = document.createElement('canvas');
			canvas.width = newImageWidth;
			canvas.height = newImageHeight;
			const ctx = canvas.getContext('2d');

			drawImages(ctx, imageBase64List, columns, imageWidth, imageHeight);
			// Get the base64 string of the new image.
			const newImageBase64 = canvas.toDataURL();
			console.log(newImageBase64);
			// Return the base64 string of the new image.
			return newImageBase64;
		};
		
		
	}

	

	const getBase64FromUrl = async (url) => {
		console.log("Image URL >>>"+url);
		const data = await fetch(url);
		const blob = await data.blob();
		return new Promise((resolve) => {
			const reader = new FileReader();
			reader.readAsDataURL(blob); 
			reader.onloadend = () => {
			const base64data = reader.result;   
			resolve(base64data);
			}
		});
	}

	async function Get_img() {
		
		let e = findElement([".rc-image-tile-44", ".rc-image-tile-33"]);
		try{
			if (e!=null){
				var src = e.getAttribute("src");
				e = await getBase64FromUrl(src).then(function(base64data) {
					return base64data.split(";base64,")[1];
				});
			} 
			
		}catch(err){return null}
		return e;
		
       
        return null;
    }
	async function delay(delayInms) {
		return new Promise(resolve  => {
			setTimeout(() => {
				resolve(2);
			}, delayInms);
		});
	}
	async function Get_size(){
		var taskGridElement = document.querySelector('.rc-image-tile-44');
		if(taskGridElement!=null) return "4x4";
		taskGridElement = document.querySelectorAll('.rc-image-tile-11');
		if(taskGridElement!=null && taskGridElement.length>0) return taskGridElement.length+"x1";
		taskGridElement = document.querySelector('.rc-image-tile-33');
		if(taskGridElement!=null) return "3x3";
	}

	async function SolverCaptcha(captcha_type, question, size){
		var arr_post = {
			imginstructions: question,
			api_key: 'ENTER_YOUR_API_KEY_HERE',
			captcha_type: captcha_type,
			body: CaptchaBase64,
			coordinatescaptcha: false,
			size: size,
		};
		console.log("=== arr_post ===");
		console.log(arr_post);
		var header = {"Content-Type": "application/json"}
		console.log("BASE_API >>" + BASE_API);
		var Send_IN = await Net.fetch(BASE_API + `/create-task`, {
			method: "POST",
			headers: header,
			body: JSON.stringify(arr_post)
		})
		//console.log("json post >>" + JSON.stringify(arr_post));
		
		//console.log(BASE_API + `/api/v1/create-task`);
		if (Send_IN.charAt(0) === '"' && Send_IN.charAt(Send_IN.length - 1) === '"') {
			Send_IN = Send_IN.substring(1, Send_IN.length - 1);
			Send_IN = Send_IN.replace(/\\"/g, '"');
		}
		return Send_IN;
	}


	



    var e = IS_DEVELOPMENT;
    const o = "lazy";
    
    window.SimpleCaptcha = [];
    var a = {};
    var n = window.addEventListener ? "addEventListener" : "attachEvent";
    for (window[n]("attachEvent" == n ? "onmessage" : "message", async e => {
            e = e[e.message ? "message" : "data"];
            e && !0 === e.SimpleCaptcha && ("append" === e.action ? window.SimpleCaptcha.push(e.data) : "clear" === e.action ? window.CaptCha69 = [] : "reload" === e.action && (window.parent.postMessage({
                SimpleCaptcha: !0,
                action: "reload"
            }, "*"), window.location.reload(!0)))
        }, !1);;) {
        await Time.sleep(1e3);
		console.log("recaptcha.js")
        try {
            var taskGridElement = document.querySelector('.rc-image-tile-44');
			var size = await Get_size();
			let CauHoiFullText = findElement([".rc-imageselect-desc > strong", ".rc-imageselect-desc-no-canonical > strong"])?.innerText?.trim()
			let checked_base64 =[]
			if(CauHoiFullText != null && CauHoiFullText != undefined){
				let CauHoi2 = findElement([".rc-imageselect-desc > span", ".rc-imageselect-desc-no-canonical > span"])?.innerText?.trim();
				var count_no_result = 0;
				var isNoneLeft = false;
				if (CauHoi2 != null && CauHoi2 != undefined && CauHoi2.includes("none left")) {
					count_no_result = 2;
					isNoneLeft = true;
				}
				console.log(CauHoiFullText +" size: "+size)
				do {
					var verify_button_element = document.querySelector("#recaptcha-verify-button");
					var list_1x1_elements = document.querySelectorAll('.rc-image-tile-11');
					if(list_1x1_elements!=null && list_1x1_elements.length>0){
						var have_result = false;
						for(let i=0 ;i<list_1x1_elements.length; i++){
							var src = list_1x1_elements[i].getAttribute("src");
							var base64 = await getBase64FromUrl(src).then(function(base64data) {
								return base64data;
							});
							if(checked_base64.includes(base64)==false){
								var Send_IN = await SolverCaptcha("recaptcha", CauHoiFullText, "1x1");
								var obj = JSON.parse(Send_IN);
								if (obj["status"] == "success") {
									Send_IN = obj["result"];
								}
								if(Send_IN!= ""){
									list_1x1_elements[i].click();
									have_result = true;
								}
								checked_base64.push(base64);
							}
						}
						if(have_result == false) count_no_result--;
						else{
							await delay(3000);
						}
						if(count_no_result==0){
							if(isNoneLeft == false) document.querySelector("#recaptcha-verify-button")?.click();
							else findElement(["#recaptcha-reload-button"])?.click();
						}
						else{
							count_no_result = count_no_result -1;
							await delay(3000);
						}
					}
					else{
						var CaptchaBase64 = await Get_img();
						if(CaptchaBase64 && CaptchaBase64 != null)
						{
							//console.log("=== debug 1 ===");
							var Send_IN = await SolverCaptcha("recaptcha", CauHoiFullText, size);

							var obj = JSON.parse(Send_IN);
							
							if (obj["status"] == "success") {
								Send_IN = obj["result"];
							}
							else{
								if(obj["status"] == "wrong API key"){
									alert("wrong API key!");
									return;
								}
							}
							console.log(Send_IN);
							if(Send_IN.includes("ERROR")) {
								break;
							}
							if(Send_IN== ""){
								if(isNoneLeft == false){
									var e = findElement(["#recaptcha-reload-button"]);
									if(e!=null){ e.click();}
									await delay(3000);
									break;
								}
								else{
									console.log("isNoneLeft "+count_no_result);
									if(count_no_result==0){
										if(isNoneLeft == false) document.querySelector("#recaptcha-verify-button")?.click();
										else findElement(["#recaptcha-reload-button"])?.click();
									}
									else{
										count_no_result = count_no_result -1;
										await delay(3000);
									}
								}
							}
							else
							{
								if (Send_IN.charAt(0) === '"' && Send_IN.charAt(Send_IN.length - 1) === '"') {
									Send_IN = Send_IN.substring(1, Send_IN.length - 1);
								}
								const myArray = Send_IN.split(',');
								var elements = document.querySelectorAll("tbody > tr > td");
								if(elements!=null){
									for (let i = 0; i < myArray.length; i++) {
										const intValue = parseInt(myArray[i], 10);
										elements[intValue-1].click();
									}
								}
								if(isNoneLeft == false){
									verify_button_element.click();
								}
								else{
									await delay(5000);
								}
							}	
						}
					}
				} while (count_no_result >0 );
			}

            //Check Block connection
            "block" === document.querySelector("#timeout_widget")?.style?.display && (window.parent.postMessage({
                SimpleCaptcha: !0,
                action: "reload"
            }, "*"), window.location.reload(!0));
            var r = document.querySelectorAll("#game_children_challenge ul > li > a");
            for (const l in r) {
                var d = r[l];
                l in a && d.removeEventListener("click", a[l]), a[l] = t.bind(this, parseInt(l)), d.addEventListener("click", a[l])
            }
        } catch (e) {}
    }
})();
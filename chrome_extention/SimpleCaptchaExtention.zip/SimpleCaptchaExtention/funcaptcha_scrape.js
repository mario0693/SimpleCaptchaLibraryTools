(async () => {
    var e = IS_DEVELOPMENT;
    const o = "lazy";
    window.CaptCha69 = [];
    var a = {};
    var n = window.addEventListener ? "addEventListener" : "attachEvent";
    for (window[n]("attachEvent" == n ? "onmessage" : "message", async e => {
            e = e[e.message ? "message" : "data"];
            e && !0 === e.CaptCha69 && ("append" === e.action ? window.CaptCha69.push(e.data) : "clear" === e.action ? window.CaptCha69 = [] : "reload" === e.action && (window.parent.postMessage({
                CaptCha69: !0,
                action: "reload"
            }, "*"), window.location.reload(!0)))
        }, !1);;) {
        await Time.sleep(1e3);
        try {
            
            if (document.querySelector("body.victory")) {
            }
            if(document.querySelector('#root > div > div > button'))
            {
                console.log("fun_screape 2")
                if(document.querySelector('#root > div > div > button').innerText.toLowerCase()==='try again')
                {
                    console.log("fun_screape 3")
                    if(document.querySelector('#root > div > div > button').click()){console.log("fun_screape click 0.1")}
                }
            }
            if(document.querySelector('#home_children_button')){
                console.log("home children");
                if(document.querySelector('#home_children_button').click()){
                    //console.log("home children");
                }
            }
            "block" === document.querySelector("#timeout_widget")?.style?.display && (window.parent.postMessage({
                CaptCha69: !0,
                action: "reload"
            }, "*"), window.location.reload(!0));
            
            var r = document.querySelectorAll("#game_children_challenge ul > li > a");
            for (const l in r) {
                var d = r[l];
                l in a && d.removeEventListener("click", a[l]), a[l] = t.bind(this, parseInt(l)), d.addEventListener("click", a[l])
            }
        } catch (e) {}
    }
})();
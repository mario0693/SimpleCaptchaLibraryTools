(async () => {
    function findElement(e, all = false) {
        if (all){
			for (const c of e) {
                var elements = document.querySelectorAll(c);
                //console.log(a)
                if (elements.length > 1) return elements
                //if (6 === a.length) return a
            }
		}
		else{
			for (const i of e) {
				var e = document.querySelector(i);
				//console.log(n)
				if (e) return e
			}
		}
                
        return null
    }

    async function delay(delayInms) {
		return new Promise(resolve  => {
			setTimeout(() => {
				resolve(2);
			}, delayInms);
		});
	}

    function Check_Button_Next() { //r()
        return null !== findElement(['button[aria-describedby="descriptionVerify"]', 'button[data-theme="home.verifyButton"]', "#wrong_children_button", "#wrongTimeout_children_button", ".error > .button", 'button[id="verifyButton"]'])
    }

    function Click_Button_Very() { // u()
        try {
            var e = findElement(['button[aria-describedby="descriptionVerify"]', 'button[data-theme="home.verifyButton"]', '#home_children_buttonContainer']),
                t = (e && (window.parent.postMessage({
                    CaptCha69: !0,
                    action: "clear"
                }, "*"), e.click()), document.querySelector("#wrong_children_button")),
                a = (t && (window.parent.postMessage({
                    CaptCha69: !0,
                    action: "clear"
                }, "*"), t.click()), document.querySelector("#wrongTimeout_children_button"));
            a && (window.parent.postMessage({
                CaptCha69: !0,
                action: "clear"
            }, "*"), a.click())
        } catch (e) {}
    }
	
	
	function convert_Question(CauHoiFullText)
	{
		if(CauHoiFullText.includes('connect')){return 'icon_connect';}
		else if(CauHoiFullText.includes("use the arrows to rotate the animal to face in the direction of the hand")){return "finger_direction";}
		else if(CauHoiFullText.includes('spot indicated by the cross')){return 'indicated_cross';}
		else if(CauHoiFullText.includes('hopscotch')){return 'hopscotch';}
		else if(CauHoiFullText.includes("pick one square that shows two identical objects")){return "two identical objects";}
			else if(CauHoiFullText.includes("square icon similar")){return "ident";}
			else if(CauHoiFullText.includes("numericalmatch")){return "mask_match";}
			else if(CauHoiFullText.includes("3d rollball animals alt")){return "finger_direction";}
			else if(CauHoiFullText.includes("galaxy")){return "spiral_galaxy";}
			else if(CauHoiFullText.includes("dice pair")){return "same_dice_pair";}
			else if(CauHoiFullText.includes("dice 7 revised")){return "dicesum7";}
			else if(CauHoiFullText.includes("dice 8 revised")){return "dicesum8";}
			else if(CauHoiFullText.includes("dice 14 revised")){return "dicesum14";}
			else if(CauHoiFullText.includes("dice slow 6 revised")){return "dicesum6";}
			else if(CauHoiFullText.includes("dice slow 7 revised")){return "dicesum7";}
			else if(CauHoiFullText.includes("dice slow 8 revised")){return "dicesum8";}
			else if(CauHoiFullText.includes("dice slow 14 revised")){return "dicesum14";}
			else if(CauHoiFullText.includes("pick the animal looking at the shape that matches the shape it's standing on")){return "animal_look_standing";}
			else if(CauHoiFullText.includes("pick the image that is the correct way up")){return "rotated";}
			else if(CauHoiFullText.includes("pick the shadow with a different object silhouette")){return "shadow_puppets";}
			else if(CauHoiFullText.includes("pick the penguin")){return "penguins";}
			else if(CauHoiFullText.includes("pick the card pair with matching numbers and symbols")){return "card";}
			else if(CauHoiFullText.includes("pick the mouse that can't reach the cheese")){return "mouse_maze";}
			else if(CauHoiFullText.includes("pick the dice pair whose top sides add up to 6")){return "dicesum6";}
			else if(CauHoiFullText.includes("pick the dice pair whose top sides add up to 7")){return "dicesum7";}
			else if(CauHoiFullText.includes("pick the dice pair whose top sides add up to 8")){return "dicesum8";}
			else if(CauHoiFullText.includes("pick the dice pair whose top sides add up to 14")){return "dicesum14";}
			else if(CauHoiFullText.includes("pick the dice pair with the same icon facing up")){return "same_dice_pair";}
			else if(CauHoiFullText.includes("pick the matching cards")){return "card";}
			else if(CauHoiFullText.includes("pick the spiral galaxy")){return "spiral_galaxy";}
			else if(CauHoiFullText.includes("pick the wrong shadow")){return "wrong_shadow";}
			else if(CauHoiFullText.includes("pick the butterfly")){return "butterfly";}
			else if(CauHoiFullText.includes("pick the parrot")){return "parrot";}
			else if(CauHoiFullText.includes("pick the dinosaur")){return "dinosaur";}
			else if(CauHoiFullText.includes("pick the pig")){return "pig";}
			else if(CauHoiFullText.includes("pick the bee")){return "bee";}
			else if(CauHoiFullText.includes("pick the monkey")){return "monkey";}
			else if(CauHoiFullText.includes("pick the snake")){return "snake";}
			else if(CauHoiFullText.includes("pick the chicken")){return "chicken";}
			else if(CauHoiFullText.includes("pick the ladybug")){return "ladybug";}
			else if(CauHoiFullText.includes("pick the bread")){return "bread";}
			else if(CauHoiFullText.includes("pick the octopus")){return "octopus";}
			else if(CauHoiFullText.includes("pick the deer")){return "deer";}
			else if(CauHoiFullText.includes("pick the cow")){return "cow";}
			else if(CauHoiFullText.includes("pick the lobster")){return "lobster";}
			else if(CauHoiFullText.includes("pick the apple")){return "apple";}
			else if(CauHoiFullText.includes("pick the seal")){return "seal";}
			else if(CauHoiFullText.includes("pick the camel")){return "camel";}
			else if(CauHoiFullText.includes("pick the bear")){return "bear";}
			else if(CauHoiFullText.includes("pick the crab")){return "crab";}
			else if(CauHoiFullText.includes("pick the cat")){return "cat";}
			else if(CauHoiFullText.includes("pick the pig")){return "pig";}
			else if(CauHoiFullText.includes("pick the pineapple")){return "pineapple";}
			else if(CauHoiFullText.includes("pick the ant")){return "ant";}
			else if(CauHoiFullText.includes("pick the parrot")){return "parrot";}
			else if(CauHoiFullText.includes("pick the owl")){return "owl";}
			else if(CauHoiFullText.includes("pick the turtle")){return "turtle";}
			else if(CauHoiFullText.includes("pick the donut")){return "donut";}
			else if(CauHoiFullText.includes("pick the rabbit")){return "rabbit";}
			else if(CauHoiFullText.includes("pick the banana")){return "banana";}
			else if(CauHoiFullText.includes("pick the snail")){return "snail";}
			else if(CauHoiFullText.includes("pick the pizza")){return "pizza";}
			else if(CauHoiFullText.includes("pick the koala")){return "koala";}
			else if(CauHoiFullText.includes("pick the duck")){return "duck";}
			else if(CauHoiFullText.includes("pick the zebra")){return "zebra";}
			else if(CauHoiFullText.includes("pick the sheep")){return "sheep";}
			else if(CauHoiFullText.includes("pick the kangaroo")){return "kangaroo";}
			else if(CauHoiFullText.includes("pick the dog")){return "dog";}
			else if(CauHoiFullText.includes("pick the ice cream")){return "ice_cream";}
			else if(CauHoiFullText.includes("pick the starfish")){return "starfish";}
			else if(CauHoiFullText.includes("pick the dinosaur")){return "dinosaur";}
			else if(CauHoiFullText.includes("pick the elephant")){return "elephant";}
			else if(CauHoiFullText.includes("pick the shark")){return "shark";}
			else if(CauHoiFullText.includes("pick the lion")){return "lion";}
			else if(CauHoiFullText.includes("pick the grapes")){return "grapes";}
			else if(CauHoiFullText.includes("pick the giraffe")){return "giraffe";}
			else if(CauHoiFullText.includes("pick the bat")){return "bat";}
			else if(CauHoiFullText.includes("pick the frog")){return "frog";}
			else if(CauHoiFullText.includes("pick the goat")){return "goat";}
			else if(CauHoiFullText.includes("pick the mouse")){return "mouse";}
			else if(CauHoiFullText.includes("pick the dolphin")){return "dolphin";}
			else if(CauHoiFullText.includes("pick the rhino")){return "rhino";}
			else if(CauHoiFullText.includes("use the arrows to change the number of objects until it matches the left image")){return "mask_match";}
			else if(CauHoiFullText.includes("pick the mouse that can reach all the cheese in the maze")){return "mouse_multicheese_maze";}
			else if(CauHoiFullText.includes("pick the shadow that matches the icons at the top of the image")){return "shadow_icons_top";}
			else if(CauHoiFullText.includes("select the animal with the wrong head")){return "frankenhead";}
			else if(CauHoiFullText.includes("pick the image of 2 checkered shapes")){return "two_checkered_shapes";}
			else if(CauHoiFullText.includes("pick the image where all animals are walking in the same direction as the arrow")){return "animal_walk_arrow";}
			else if(CauHoiFullText.includes("pick the image of the brick cone and the checkered cube")){return "mat_brickcone_checkercube";}
			else if(CauHoiFullText.includes("pick the image of the brick cone and the checkered sphere")){return "mat_brickcone_checkersphere";}
			else if(CauHoiFullText.includes("pick the image of the brick cone and the striped cone")){return "mat_brickcone_stripecone";}
			else if(CauHoiFullText.includes("pick the image of the brick cube and the striped heart")){return "mat_brickcube_stripeheart";}
			else if(CauHoiFullText.includes("pick the image of the brick cube and the striped sphere")){return "mat_brickcube_stripesphere";}
			else if(CauHoiFullText.includes("pick the image of the brick heart and the striped heart")){return "mat_brickheart_stripeheart";}
			else if(CauHoiFullText.includes("pick the image of the brick sphere and the checkered heart")){return "mat_bricksphere_checkerheart";}
			else if(CauHoiFullText.includes("pick the image of the checkered cone and the checkered sphere")){return "mat_checkercone_checkersphere";}
			else if(CauHoiFullText.includes("pick the image of the fuzzy cone and the brick sphere")){return "mat_fuzzcone_bricksphere";}
			else if(CauHoiFullText.includes("pick the image of the fuzzy cube and the checkered cube")){return "mat_fuzzcube_checkercube";}
			else if(CauHoiFullText.includes("pick the image of the fuzzy cube and the striped cube")){return "mat_fuzzcube_stripecube";}
			else if(CauHoiFullText.includes("pick the image of the fuzzy heart and the brick heart")){return "mat_fuzzheart_brickheart";}
			else if(CauHoiFullText.includes("pick the image of the fuzzy heart and the striped heart")){return "mat_fuzzheart_stripeheart";}
			else if(CauHoiFullText.includes("pick the image of the fuzzy sphere and the striped cone")){return "mat_fuzzsphere_stripecone";}
			else if(CauHoiFullText.includes("pick the image of the fuzzy sphere and the striped cube")){return "mat_fuzzsphere_stripecube";}
			else if(CauHoiFullText.includes("pick the image of the striped cone and the checkered cube")){return "mat_stripecone_checkercube";}
			else if(CauHoiFullText.includes("pick the image of the striped cube and the checkered cube")){return "mat_stripecube_checkercube";}
			else if(CauHoiFullText.includes("pick the image of the striped cube and the checkered heart")){return "mat_stripecube_checkerheart";}
			else if(CauHoiFullText.includes("pick the image of the striped cube and the checkered sphere")){return "mat_stripecube_checkersphere";}
			else if(CauHoiFullText.includes("pick the image of the striped heart and the checkered cube")){return "mat_stripeheart_checkercube";}
			else if(CauHoiFullText.includes("pick the image where the darts add up to 6")){return "darts6";}
			else if(CauHoiFullText.includes("pick the image where the darts add up to 8")){return "darts8";}
			else if(CauHoiFullText.includes("pick the image where the darts add up to 10")){return "darts10";}
			else if(CauHoiFullText.includes("pick the image where the darts add up to 12")){return "darts12";}
			else if(CauHoiFullText.includes("mat stripeshape checkershape")){return "mat_stripeshape_checkershape";}
			else if(CauHoiFullText.includes("pick the image where the darts add up to 9")){return "darts9";}
			else if(CauHoiFullText.includes("pick the image where the darts add up to 14")){return "darts14";}
			else if(CauHoiFullText.includes("pick the image where the darts add up to 17")){return "darts17";}
			else if(CauHoiFullText.includes("pick the image where the darts add up to 15")){return "darts15";}
			else if(CauHoiFullText.includes("pick the image where the darts add up to 13")){return "darts13";}
			else if(CauHoiFullText.includes("pick the alien")){return "alien";}
			else if(CauHoiFullText.includes("pick the anchor")){return "anchor";}
			else if(CauHoiFullText.includes("pick the aquarium")){return "aquarium";}
			else if(CauHoiFullText.includes("pick the ball")){return "ball";}
			else if(CauHoiFullText.includes("pick the bicycle")){return "bicycle";}
			else if(CauHoiFullText.includes("pick the boat")){return "boat";}
			else if(CauHoiFullText.includes("pick the calculator")){return "calculator";}
			else if(CauHoiFullText.includes("pick the camera")){return "camera";}
			else if(CauHoiFullText.includes("pick the car")){return "car";}
			else if(CauHoiFullText.includes("pick the cheese")){return "cheese";}
			else if(CauHoiFullText.includes("pick the computer")){return "computer";}
			else if(CauHoiFullText.includes("pick the couch")){return "couch";}
			else if(CauHoiFullText.includes("pick the crown")){return "crown";}
			else if(CauHoiFullText.includes("pick the fan")){return "fan";}
			else if(CauHoiFullText.includes("pick the fence")){return "fence";}
			else if(CauHoiFullText.includes("pick the fire")){return "fire";}
			else if(CauHoiFullText.includes("pick the flower")){return "flower";}
			else if(CauHoiFullText.includes("pick the glasses")){return "glasses";}
			else if(CauHoiFullText.includes("pick the helmet")){return "helmet";}
			else if(CauHoiFullText.includes("pick the hotdog")){return "hotdog";}
			else if(CauHoiFullText.includes("pick the key")){return "key";}
			else if(CauHoiFullText.includes("pick the lamp")){return "lamp";}
			else if(CauHoiFullText.includes("pick the money")){return "money";}
			else if(CauHoiFullText.includes("pick the mushroom")){return "mushroom";}
			else if(CauHoiFullText.includes("pick the pants")){return "pants";}
			else if(CauHoiFullText.includes("pick the pencil")){return "pencil";}
			else if(CauHoiFullText.includes("pick the printer")){return "printer";}
			else if(CauHoiFullText.includes("pick the refrigerator")){return "refrigerator";}
			else if(CauHoiFullText.includes("pick the ring")){return "ring";}
			else if(CauHoiFullText.includes("pick the scissors")){return "scissors";}
			else if(CauHoiFullText.includes("pick the shoe")){return "shoe";}
			else if(CauHoiFullText.includes("pick the sock")){return "sock";}
			else if(CauHoiFullText.includes("pick the spaceship")){return "spaceship";}
			else if(CauHoiFullText.includes("pick the trophy")){return "trophy";}
			else if(CauHoiFullText.includes("pick the watermelon")){return "watermelon";}
			else if(CauHoiFullText.includes("pick the wristwatch")){return "wristwatch";}
			else if(CauHoiFullText.includes("numericalmatch")){return "mask_match";}
			else if(CauHoiFullText.includes("pick the dice pair whose top sides add up to 5")){return "dicesum5";}
			else if(CauHoiFullText.includes("pick the dice pair whose top sides add up to 9")){return "dicesum9";}
			else if(CauHoiFullText.includes("use the arrows to move the person to the spot indicated by the cross")){return "hopscotch";}
			else if(CauHoiFullText.includes("using the arrows, connect the same two icons with the dotted line as shown on the left")){return "icon_connect";}
		else if(CauHoiFullText.includes('arrows')){return 'hopscotch';}
		else if(CauHoiFullText.includes('identical')){return 'ident';}
		else if(CauHoiFullText.includes('looking')){return 'animal_look_standing';}
		else if(CauHoiFullText.includes('correct')){return 'rotated';}
		else if(CauHoiFullText.includes('different')){return 'shadow_puppets';}
		else if(CauHoiFullText.includes('penguin')){return 'penguins';}
		else if(CauHoiFullText.includes('card')){return 'card';}
		else if(CauHoiFullText.includes('maze')){return 'mouse_multicheese_maze';}
		else if(CauHoiFullText.includes('cheese')){return 'mouse_maze';}
		else if(CauHoiFullText.includes('mouse')){return 'mouse';}
		else if(CauHoiFullText.includes('up to 6')){return 'dicesum6';}
		else if(CauHoiFullText.includes('up to 7')){return 'dicesum7';}
		else if(CauHoiFullText.includes('up to 8')){return 'dicesum8';}
		else if(CauHoiFullText.includes('up to 14')){return 'dicesum14';}
		else if(CauHoiFullText.includes('facing')){return 'same_dice_pair';}
		else if(CauHoiFullText.includes('galaxy')){return 'spiral_galaxy';}
		else if(CauHoiFullText.includes('wrong shadow')){return 'wrong_shadow';}
		else if(CauHoiFullText.includes('butterfly')){return 'butterfly';}
		else if(CauHoiFullText.includes('parrot')){return 'parrot';}
		else if(CauHoiFullText.includes('dinosaur')){return 'dinosaur';}
		else if(CauHoiFullText.includes('pig')){return 'pig';}
		else if(CauHoiFullText.includes('bee')){return 'bee';}
		else if(CauHoiFullText.includes('monkey')){return 'monkey';}
		else if(CauHoiFullText.includes('snake')){return 'snake';}
		else if(CauHoiFullText.includes('chicken')){return 'chicken';}
		else if(CauHoiFullText.includes('ladybug')){return 'ladybug';}
		else if(CauHoiFullText.includes('bread')){return 'bread';}
		else if(CauHoiFullText.includes('octopus')){return 'octopus';}
		else if(CauHoiFullText.includes('deer')){return 'deer';}
		else if(CauHoiFullText.includes('cow')){return 'cow';}
		else if(CauHoiFullText.includes('lobster')){return 'lobster';}
		else if(CauHoiFullText.includes('apple')){return 'apple';}
		else if(CauHoiFullText.includes('seal')){return 'seal';}
		else if(CauHoiFullText.includes('camel')){return 'camel';}
		else if(CauHoiFullText.includes('bear')){return 'bear';}
		else if(CauHoiFullText.includes('crab')){return 'crab';}
		else if(CauHoiFullText.includes('cat')){return 'cat';}
		else if(CauHoiFullText.includes('pineapple')){return 'pineapple';}
		else if(CauHoiFullText.includes('ant')){return 'ant';}
		else if(CauHoiFullText.includes('owl')){return 'owl';}
		else if(CauHoiFullText.includes('turtle')){return 'turtle';}
		else if(CauHoiFullText.includes('donut')){return 'donut';}
		else if(CauHoiFullText.includes('rabbit')){return 'rabbit';}
		else if(CauHoiFullText.includes('banana')){return 'banana';}
		else if(CauHoiFullText.includes('snail')){return 'snail';}
		else if(CauHoiFullText.includes('pizza')){return 'pizza';}
		else if(CauHoiFullText.includes('koala')){return 'koala';}
		else if(CauHoiFullText.includes('duck')){return 'duck';}
		else if(CauHoiFullText.includes('zebra')){return 'zebra';}
		else if(CauHoiFullText.includes('sheep')){return 'sheep';}
		else if(CauHoiFullText.includes('kangaroo')){return 'kangaroo';}
		else if(CauHoiFullText.includes('dog')){return 'dog';}
		else if(CauHoiFullText.includes('ice cream')){return 'ice_cream';}
		else if(CauHoiFullText.includes('starfish')){return 'starfish';}
		else if(CauHoiFullText.includes('elephant')){return 'elephant';}
		else if(CauHoiFullText.includes('shark')){return 'shark';}
		else if(CauHoiFullText.includes('lion')){return 'lion';}
		else if(CauHoiFullText.includes('grapes')){return 'grapes';}
		else if(CauHoiFullText.includes('giraffe')){return 'giraffe';}
		else if(CauHoiFullText.includes('bat')){return 'bat';}
		else if(CauHoiFullText.includes('frog')){return 'frog';}
		else if(CauHoiFullText.includes('goat')){return 'goat';}
		else if(CauHoiFullText.includes('dolphin')){return 'dolphin';}
		else if(CauHoiFullText.includes('rhino')){return 'rhino';}
		else if(CauHoiFullText.includes('matches the left image')){return 'mask_match';}
		else if(CauHoiFullText.includes('matche')){return 'mask_match';}
		else if(CauHoiFullText.includes('hand')){return 'finger_direction';}
		else if(CauHoiFullText.includes('shadow that matches')){return 'shadow_icons_top';}
		else if(CauHoiFullText.includes('wrong head')){return 'frankenhead';}
		else if(CauHoiFullText.includes('shapes')){return 'two_checkered_shapes';}
		else if(CauHoiFullText.includes('walking')){return 'animal_walk_arrow';}
		else if(CauHoiFullText.includes('brick cone and the checkered cube')){return 'mat_brickcone_checkercube';}
		else if(CauHoiFullText.includes('brick cone and the checkered sphere')){return 'mat_brickcone_checkersphere';}
		else if(CauHoiFullText.includes('brick cone and the striped cone')){return 'mat_brickcone_stripecone';}
		else if(CauHoiFullText.includes('brick cube and the striped heart')){return 'mat_brickcube_stripeheart';}
		else if(CauHoiFullText.includes('brick cube and the striped sphere')){return 'mat_brickcube_stripesphere';}
		else if(CauHoiFullText.includes('brick heart and the striped heart')){return 'mat_brickheart_stripeheart';}
		else if(CauHoiFullText.includes('brick sphere and the checkered heart')){return 'mat_bricksphere_checkerheart';}
		else if(CauHoiFullText.includes('checkered cone and the checkered sphere')){return 'mat_checkercone_checkersphere';}
		else if(CauHoiFullText.includes('fuzzy cone and the brick sphere')){return 'mat_fuzzcone_bricksphere';}
		else if(CauHoiFullText.includes('fuzzy cube and the checkered cube')){return 'mat_fuzzcube_checkercube';}
		else if(CauHoiFullText.includes('fuzzy cube and the striped cube')){return 'mat_fuzzcube_stripecube';}
		else if(CauHoiFullText.includes('fuzzy heart and the brick heart')){return 'mat_fuzzheart_brickheart';}
		else if(CauHoiFullText.includes('fuzzy heart and the striped heart')){return 'mat_fuzzheart_stripeheart';}
		else if(CauHoiFullText.includes('fuzzy sphere and the striped cone')){return 'mat_fuzzsphere_stripecone';}
		else if(CauHoiFullText.includes('fuzzy sphere and the striped cube')){return 'mat_fuzzsphere_stripecube';}
		else if(CauHoiFullText.includes('striped cone and the checkered cube')){return 'mat_stripecone_checkercube';}
		else if(CauHoiFullText.includes('striped cube and the checkered cube')){return 'mat_stripecube_checkercube';}
		else if(CauHoiFullText.includes('striped cube and the checkered heart')){return 'mat_stripecube_checkerheart';}
		else if(CauHoiFullText.includes('striped cube and the checkered sphere')){return 'mat_stripecube_checkersphere';}
		else {return 'mat_stripeheart_checkercube';}
	}
    function get_Question() { // s()
		let CauHoiFullText = findElement(["#game_children_text > h2", ".challenge-instructions-container > h2", ".match-game > div > h2"])?.innerText?.trim()
		if(CauHoiFullText != null && CauHoiFullText != undefined)
		{
			return CauHoiFullText;
			//return convert_Question(CauHoiFullText)
		}else{
			//funcaptcha v2
			var e =  document.getElementById("game_children_text");
			CauHoiFullText = e?.innerText?.trim();
			if(CauHoiFullText != null && CauHoiFullText != undefined)
			{
				return CauHoiFullText;
			}
		}
		return CauHoiFullText
    }

    const getBase64FromUrl = async (url) => {
		//console.log("Image URL >>>"+url);
		const data = await fetch(url);
		const blob = await data.blob();
		return new Promise((resolve) => {
			const reader = new FileReader();
			reader.readAsDataURL(blob); 
			reader.onloadend = () => {
			const base64data = reader.result;   
			resolve(base64data);
			}
		});
	}

    async function Get_img() {
        let e = findElement(["img#game_challengeItem_image"]);
        var t;
        var t2;
        e = e ? e.src?.split(";base64,")[1] : (t = (e = findElement([".challenge-container button"]))?.style["background-image"]?.trim()?.match(/(?!^)".*?"/g)) && 0 !== t.length ? t[0].replaceAll('"', "") : null
        if(e == null)
        {
        	e = findElement([".match-game > div > .box > .answer-frame > div > img"]);
        	if(e)
        	{
        		if(e?.style["background-image"])
        		{
        			e = e.style["background-image"];
        			if(e?.trim()?.match(/(?!^)".*?"/g))
        			{
        				e = e?.trim()?.match(/(?!^)".*?"/g)[0].replaceAll('"', "")
        			}
        		}
        	}
        }
        try{
	        if(e!=null)
	        {
				
	        	if(e.includes("blob"))
	        	{
	        		e = await getBase64FromUrl(e).then(function(base64data) {
						return base64data.split(";base64,")[1];
					});
	        	}
	        }
	    }catch(err){return null}
        return e
    }
	async function Check_Cell_IMG(){
		var cells = findElement(["#game_children_challenge ul > li > a", ".challenge-container button",'.pip'], !0);
		return cells
	}
	async function Get_size(){
		try{
			var Check_Cell_IMG = findElement(["#game_children_challenge ul > li > a", ".challenge-container button",'.pip'], !0);

			let e = findElement([".match-game > div > .box > .answer-frame > div > img"]); //game core
			if(e!=null){
				return Check_Cell_IMG.length.toString()+"x2";
			}
			else{
				return (Check_Cell_IMG.length/2).toString()+"x2";
			}
		}catch(err){return "0x0"}
		return "0x0"
	}

    async function RunTask()
    {
		for(;;){
			try{
				//var Settings = await BG.exec("Settings.get");
				//console.log(Settings);
				//if(Settings.funcaptcha_auto_open){
					//await Check_Button_Next();
					//await Click_Button_Very();
				//}
				console.log("Find question");
				await Check_Button_Next();
				await Click_Button_Very();
				
				var CauHoi = get_Question();
				if(CauHoi)
				{
					console.log("CauHoi >>> " + CauHoi);
					var Check_Cell_IMG = findElement(["#game_children_challenge ul > li > a", ".challenge-container button",'.pip'], !0);
					//if(Check_Cell_IMG==null) continue;
					//console.log("Check_Cell_IMG.length >>> " + Check_Cell_IMG.length);
					//console.log(Check_Cell_IMG);
					if(Check_Cell_IMG.length< 1) continue;
					var CaptchaBase64 = await Get_img();
					var imgsize = await Get_size();
					if(imgsize==undefined) imgsize = "0x0";
					console.log("ImageSize >>> " + imgsize);
					if(CaptchaBase64 && CaptchaBase64 != null)
					{
						//console.log("=== debug 1 ===");
						var arr_post = {
							imginstructions: CauHoi,
							api_key: 'ENTER_YOUR_API_KEY_HERE',
							captcha_type: 'funcaptcha',
							body: CaptchaBase64,
							coordinatescaptcha: false,
							size: imgsize,
						};
						console.log("=== arr_post ===");
						console.log(arr_post);
						var header = {"Content-Type": "application/json"}
						console.log("BASE_API >>" + BASE_API);
						var Send_IN = await Net.fetch(BASE_API + `/create-task`, {
							method: "POST",
							headers: header,
							body: JSON.stringify(arr_post)
						})
						//console.log("json post >>" + JSON.stringify(arr_post));
						
						//console.log(BASE_API + `/api/v1/create-task`);
						if (Send_IN.charAt(0) === '"' && Send_IN.charAt(Send_IN.length - 1) === '"') {
							Send_IN = Send_IN.substring(1, Send_IN.length - 1);
							Send_IN = Send_IN.replace(/\\"/g, '"');
						}
						console.log(Send_IN)
						var obj = JSON.parse(Send_IN);

						if (obj["status"] == "success") {
							Send_IN = obj["result"];
						}
						else{
							if(obj["status"] == "wrong API key"){
								alert("wrong API key!");
								return;
							}
							
						}
						console.log(Send_IN);
						if(Send_IN.includes("ERROR")) {
							continue;
						}
						if(Send_IN== ""){
							var e = findElement(["#root > div > div > div > button"]);
							if(e!=null){ e.click();}
							else{
								Check_Cell_IMG[1].click()
							}
							await delay(3000);
							continue;
						}
						else
						{
							if (Send_IN.charAt(0) === '"' && Send_IN.charAt(Send_IN.length - 1) === '"') {
								Send_IN = Send_IN.substring(1, Send_IN.length - 1);
							}
							var _id = Send_IN;
							await delay(1000);
							var ViTriClick = 0;
							if(_id.includes(",")){
								split = _id.split(",");
								ViTriClick = Number(split[1]);
							}
							else{
								ViTriClick = Number(Send_IN);
							}
							
							if(document.querySelector('.right-arrow'))
							{
								for(var p=1;p<ViTriClick;p++)
								{
									if(document.querySelector('.right-arrow').click()){}
									await delay(1200);
								}
								if(document.querySelector("#root > div > div > div > button").click()){}
							}else{
								Check_Cell_IMG[ViTriClick-1].click()
							}
						}	
						
					}
				}
				
			}
			catch(err){
				console.log("Error >>>"+err);
			}
			await delay(3000);
		}
		

    	//for (;;) 
    	//{
			
    		
			
    		
    		//await delay(3000);
	    //}
    }

	console.log("funcaptcha.js");
	console.log(window.location.pathname)
    if (setInterval(() => {
            document.dispatchEvent(new Event("mousemove"))
        }, 50), window.location.pathname.startsWith("/fc/assets/tile-game-ui/") || window.location.pathname.startsWith("/fc/assets/ec-game-core/") ||  window.location.pathname.startsWith("/fc/gc"))
    {
        /*for (;;) {
            await Time.sleep(1e3);
            var t, a = await BG.exec("Settings.get");
            a && a.enabled && (t = await Location.hostname(), a.disabled_hosts.includes(t) || (a.funcaptcha_auto_open && r() ? await u() : a.funcaptcha_auto_solve && null !== s() && null !== Get_img() && await e()))
        }*/
		try{
			/*var Setting = await BG.exec("Settings.get");
			if(Setting == undefined) console.log("Setting undefined");
			
			if(Setting != undefined && Setting.enabled && Setting.funcaptcha_auto_solve && Setting.funcaptcha_auto_open)
			{
				await RunTask();
			}*/
			await RunTask();
		}
		catch(err){
			console.log("Error >>>"+err);
		}
        
    }
}
)();
"use strict";
(() => {
	var Te = Object.create;
	var X = Object.defineProperty;
	var Ee = Object.getOwnPropertyDescriptor;
	var _e = Object.getOwnPropertyNames;
	var Se = Object.getPrototypeOf,
		ke = Object.prototype.hasOwnProperty;
	var Y = (e, t) => () => (t || e((t = {
		exports: {}
	}).exports, t), t.exports);
	var Re = (e, t, n, o) => {
		if (t && typeof t == "object" || typeof t == "function")
			for (let r of _e(t)) !ke.call(e, r) && r !== n && X(e, r, {
				get: () => t[r],
				enumerable: !(o = Ee(t, r)) || o.enumerable
			});
		return e
	};
	var G = (e, t, n) => (n = e != null ? Te(Se(e)) : {}, Re(t || !e || !e.__esModule ? X(n, "default", {
		value: e,
		enumerable: !0
	}) : n, e));
	var se = Y((st, A) => {
		"use strict";
		var C = typeof Reflect == "object" ? Reflect : null,
			$ = C && typeof C.apply == "function" ? C.apply : function(t, n, o) {
				return Function.prototype.apply.call(t, n, o)
			},
			_;
		C && typeof C.ownKeys == "function" ? _ = C.ownKeys : Object.getOwnPropertySymbols ? _ = function(t) {
			return Object.getOwnPropertyNames(t).concat(Object.getOwnPropertySymbols(t))
		} : _ = function(t) {
			return Object.getOwnPropertyNames(t)
		};

		function Ie(e) {
			console && console.warn && console.warn(e)
		}
		var Z = Number.isNaN || function(t) {
			return t !== t
		};

		function s() {
			s.init.call(this)
		}
		A.exports = s;
		A.exports.once = Oe;
		s.EventEmitter = s;
		s.prototype._events = void 0;
		s.prototype._eventsCount = 0;
		s.prototype._maxListeners = void 0;
		var J = 10;

		function S(e) {
			if (typeof e != "function") throw new TypeError('The "listener" argument must be of type Function. Received type ' + typeof e)
		}
		Object.defineProperty(s, "defaultMaxListeners", {
			enumerable: !0,
			get: function() {
				return J
			},
			set: function(e) {
				if (typeof e != "number" || e < 0 || Z(e)) throw new RangeError('The value of "defaultMaxListeners" is out of range. It must be a non-negative number. Received ' + e + ".");
				J = e
			}
		});
		s.init = function() {
			(this._events === void 0 || this._events === Object.getPrototypeOf(this)._events) && (this._events = Object.create(null), this._eventsCount = 0), this._maxListeners = this._maxListeners || void 0
		};
		s.prototype.setMaxListeners = function(t) {
			if (typeof t != "number" || t < 0 || Z(t)) throw new RangeError('The value of "n" is out of range. It must be a non-negative number. Received ' + t + ".");
			return this._maxListeners = t, this
		};

		function ee(e) {
			return e._maxListeners === void 0 ? s.defaultMaxListeners : e._maxListeners
		}
		s.prototype.getMaxListeners = function() {
			return ee(this)
		};
		s.prototype.emit = function(t) {
			for (var n = [], o = 1; o < arguments.length; o++) n.push(arguments[o]);
			var r = t === "error",
				a = this._events;
			if (a !== void 0) r = r && a.error === void 0;
			else if (!r) return !1;
			if (r) {
				var i;
				if (n.length > 0 && (i = n[0]), i instanceof Error) throw i;
				var c = new Error("Unhandled error." + (i ? " (" + i.message + ")" : ""));
				throw c.context = i, c
			}
			var d = a[t];
			if (d === void 0) return !1;
			if (typeof d == "function") $(d, this, n);
			else
				for (var l = d.length, m = ae(d, l), o = 0; o < l; ++o) $(m[o], this, n);
			return !0
		};

		function te(e, t, n, o) {
			var r, a, i;
			if (S(n), a = e._events, a === void 0 ? (a = e._events = Object.create(null), e._eventsCount = 0) : (a.newListener !== void 0 && (e.emit("newListener", t, n.listener ? n.listener : n), a = e._events), i = a[t]), i === void 0) i = a[t] = n, ++e._eventsCount;
			else if (typeof i == "function" ? i = a[t] = o ? [n, i] : [i, n] : o ? i.unshift(n) : i.push(n), r = ee(e), r > 0 && i.length > r && !i.warned) {
				i.warned = !0;
				var c = new Error("Possible EventEmitter memory leak detected. " + i.length + " " + String(t) + " listeners added. Use emitter.setMaxListeners() to increase limit");
				c.name = "MaxListenersExceededWarning", c.emitter = e, c.type = t, c.count = i.length, Ie(c)
			}
			return e
		}
		s.prototype.addListener = function(t, n) {
			return te(this, t, n, !1)
		};
		s.prototype.on = s.prototype.addListener;
		s.prototype.prependListener = function(t, n) {
			return te(this, t, n, !0)
		};

		function Fe() {
			if (!this.fired) return this.target.removeListener(this.type, this.wrapFn), this.fired = !0, arguments.length === 0 ? this.listener.call(this.target) : this.listener.apply(this.target, arguments)
		}

		function ne(e, t, n) {
			var o = {
					fired: !1,
					wrapFn: void 0,
					target: e,
					type: t,
					listener: n
				},
				r = Fe.bind(o);
			return r.listener = n, o.wrapFn = r, r
		}
		s.prototype.once = function(t, n) {
			return S(n), this.on(t, ne(this, t, n)), this
		};
		s.prototype.prependOnceListener = function(t, n) {
			return S(n), this.prependListener(t, ne(this, t, n)), this
		};
		s.prototype.removeListener = function(t, n) {
			var o, r, a, i, c;
			if (S(n), r = this._events, r === void 0) return this;
			if (o = r[t], o === void 0) return this;
			if (o === n || o.listener === n) --this._eventsCount === 0 ? this._events = Object.create(null) : (delete r[t], r.removeListener && this.emit("removeListener", t, o.listener || n));
			else if (typeof o != "function") {
				for (a = -1, i = o.length - 1; i >= 0; i--)
					if (o[i] === n || o[i].listener === n) {
						c = o[i].listener, a = i;
						break
					} if (a < 0) return this;
				a === 0 ? o.shift() : Pe(o, a), o.length === 1 && (r[t] = o[0]), r.removeListener !== void 0 && this.emit("removeListener", t, c || n)
			}
			return this
		};
		s.prototype.off = s.prototype.removeListener;
		s.prototype.removeAllListeners = function(t) {
			var n, o, r;
			if (o = this._events, o === void 0) return this;
			if (o.removeListener === void 0) return arguments.length === 0 ? (this._events = Object.create(null), this._eventsCount = 0) : o[t] !== void 0 && (--this._eventsCount === 0 ? this._events = Object.create(null) : delete o[t]), this;
			if (arguments.length === 0) {
				var a = Object.keys(o),
					i;
				for (r = 0; r < a.length; ++r) i = a[r], i !== "removeListener" && this.removeAllListeners(i);
				return this.removeAllListeners("removeListener"), this._events = Object.create(null), this._eventsCount = 0, this
			}
			if (n = o[t], typeof n == "function") this.removeListener(t, n);
			else if (n !== void 0)
				for (r = n.length - 1; r >= 0; r--) this.removeListener(t, n[r]);
			return this
		};

		function oe(e, t, n) {
			var o = e._events;
			if (o === void 0) return [];
			var r = o[t];
			return r === void 0 ? [] : typeof r == "function" ? n ? [r.listener || r] : [r] : n ? qe(r) : ae(r, r.length)
		}
		s.prototype.listeners = function(t) {
			return oe(this, t, !0)
		};
		s.prototype.rawListeners = function(t) {
			return oe(this, t, !1)
		};
		s.listenerCount = function(e, t) {
			return typeof e.listenerCount == "function" ? e.listenerCount(t) : re.call(e, t)
		};
		s.prototype.listenerCount = re;

		function re(e) {
			var t = this._events;
			if (t !== void 0) {
				var n = t[e];
				if (typeof n == "function") return 1;
				if (n !== void 0) return n.length
			}
			return 0
		}
		s.prototype.eventNames = function() {
			return this._eventsCount > 0 ? _(this._events) : []
		};

		function ae(e, t) {
			for (var n = new Array(t), o = 0; o < t; ++o) n[o] = e[o];
			return n
		}

		function Pe(e, t) {
			for (; t + 1 < e.length; t++) e[t] = e[t + 1];
			e.pop()
		}

		function qe(e) {
			for (var t = new Array(e.length), n = 0; n < t.length; ++n) t[n] = e[n].listener || e[n];
			return t
		}

		function Oe(e, t) {
			return new Promise(function(n, o) {
				function r(i) {
					e.removeListener(t, a), o(i)
				}

				function a() {
					typeof e.removeListener == "function" && e.removeListener("error", r), n([].slice.call(arguments))
				}
				ie(e, t, a, {
					once: !0
				}), t !== "error" && Ae(e, r, {
					once: !0
				})
			})
		}

		function Ae(e, t, n) {
			typeof e.on == "function" && ie(e, "error", t, n)
		}

		function ie(e, t, n, o) {
			if (typeof e.on == "function") o.once ? e.once(t, n) : e.on(t, n);
			else if (typeof e.addEventListener == "function") e.addEventListener(t, function r(a) {
				o.once && e.removeEventListener(t, r), n(a)
			});
			else throw new TypeError('The "emitter" argument must be of type EventEmitter. Received type ' + typeof e)
		}
	});
	var pe = Y((pt, f) => {
		f.exports.boot = function(e) {
			return e
		};
		f.exports.ssrMiddleware = function(e) {
			return e
		};
		f.exports.configure = function(e) {
			return e
		};
		f.exports.preFetch = function(e) {
			return e
		};
		f.exports.route = function(e) {
			return e
		};
		f.exports.store = function(e) {
			return e
		};
		f.exports.bexBackground = function(e) {
			return e
		};
		f.exports.bexContent = function(e) {
			return e
		};
		f.exports.bexDom = function(e) {
			return e
		};
		f.exports.ssrProductionExport = function(e) {
			return e
		};
		f.exports.ssrCreate = function(e) {
			return e
		};
		f.exports.ssrListen = function(e) {
			return e
		};
		f.exports.ssrClose = function(e) {
			return e
		};
		f.exports.ssrServeStaticContent = function(e) {
			return e
		};
		f.exports.ssrRenderPreloadTag = function(e) {
			return e
		}
	});
	var le = G(se());
	var D, k = 0,
		u = new Array(256);
	for (let e = 0; e < 256; e++) u[e] = (e + 256).toString(16).substring(1);
	var De = (() => {
			let e = typeof crypto != "undefined" ? crypto : typeof window != "undefined" ? window.crypto || window.msCrypto : void 0;
			if (e !== void 0) {
				if (e.randomBytes !== void 0) return e.randomBytes;
				if (e.getRandomValues !== void 0) return t => {
					let n = new Uint8Array(t);
					return e.getRandomValues(n), n
				}
			}
			return t => {
				let n = [];
				for (let o = t; o > 0; o--) n.push(Math.floor(Math.random() * 256));
				return n
			}
		})(),
		ce = 4096;

	function ue() {
		(D === void 0 || k + 16 > ce) && (k = 0, D = De(ce));
		let e = Array.prototype.slice.call(D, k, k += 16);
		return e[6] = e[6] & 15 | 64, e[8] = e[8] & 63 | 128, u[e[0]] + u[e[1]] + u[e[2]] + u[e[3]] + "-" + u[e[4]] + u[e[5]] + "-" + u[e[6]] + u[e[7]] + "-" + u[e[8]] + u[e[9]] + "-" + u[e[10]] + u[e[11]] + u[e[12]] + u[e[13]] + u[e[14]] + u[e[15]]
	}
	var je = {
			undefined: () => 0,
			boolean: () => 4,
			number: () => 8,
			string: e => 2 * e.length,
			object: e => e ? Object.keys(e).reduce((t, n) => j(n) + j(e[n]) + t, 0) : 0
		},
		j = e => je[typeof e](e),
		v = class extends le.EventEmitter {
			constructor(t) {
				super(), this.setMaxListeners(1 / 0), this.wall = t, t.listen(n => {
					Array.isArray(n) ? n.forEach(o => this._emit(o)) : this._emit(n)
				}), this._sendingQueue = [], this._sending = !1, this._maxMessageSize = 32 * 1024 * 1024
			}
			send(t, n) {
				return this._send([{
					event: t,
					payload: n
				}])
			}
			getEvents() {
				return this._events
			}
			on(t, n) {
				return super.on(t, o => {
					n({
						...o,
						respond: r => this.send(o.eventResponseKey, r)
					})
				})
			}
			_emit(t) {
				typeof t == "string" ? this.emit(t) : this.emit(t.event, t.payload)
			}
			_send(t) {
				return this._sendingQueue.push(t), this._nextSend()
			}
			_nextSend() {
				if (!this._sendingQueue.length || this._sending) return Promise.resolve();
				this._sending = !0;
				let t = this._sendingQueue.shift(),
					n = t[0],
					o = `${n.event}.${ue()}`,
					r = o + ".result";
				return new Promise((a, i) => {
					let c = [],
						d = l => {
							if (l !== void 0 && l._chunkSplit) {
								let m = l._chunkSplit;
								c = [...c, ...l.data], m.lastChunk && (this.off(r, d), a(c))
							} else this.off(r, d), a(l)
						};
					this.on(r, d);
					try {
						let l = t.map(m => ({
							...m,
							payload: {
								data: m.payload,
								eventResponseKey: r
							}
						}));
						this.wall.send(l)
					} catch (l) {
						let m = "Message length exceeded maximum allowed length.";
						if (l.message === m && Array.isArray(n.payload)) {
							let h = j(n);
							if (h > this._maxMessageSize) {
								let g = Math.ceil(h / this._maxMessageSize),
									b = Math.ceil(n.payload.length / g),
									E = n.payload;
								for (let O = 0; O < g; O++) {
									let Le = Math.min(E.length, b);
									this.wall.send([{
										event: n.event,
										payload: {
											_chunkSplit: {
												count: g,
												lastChunk: O === g - 1
											},
											data: E.splice(0, Le)
										}
									}])
								}
							}
						}
					}
					this._sending = !1, setTimeout(() => this._nextSend(), 16)
				})
			}
		};
	var fe = (e, t) => {
		window.addEventListener("message", n => {
			if (n.source === window && n.data.from !== void 0 && n.data.from === t) {
				let o = n.data[0],
					r = e.getEvents();
				for (let a in r) a === o.event && r[a](o.payload)
			}
		}, !1)
	};
	var be = G(pe());
	var Be = chrome.runtime.getURL("assets/config.json");
	async function He() {
		let e = await chrome.storage.local.get("defaultConfig");
		if (e.defaultConfig) return e.defaultConfig;
		let t = {},
			o = await (await fetch(Be)).json();
		return o && (t = o, chrome.storage.local.set({
			defaultConfig: t
		})), t
	}
	var x = {
			manualSolving: !1,
			apiKey: "",
			appId: "",
			enabledForImageToText: !0,
			enabledForRecaptchaV3: !0,
			enabledForHCaptcha: !0,
			enabledForGeetestV4: !1,
			recaptchaV3MinScore: .5,
			enabledForRecaptcha: !0,
			enabledForFunCaptcha: !0,
			enabledForDataDome: !1,
			enabledForAwsCaptcha: !0,
			useProxy: !1,
			proxyType: "http",
			hostOrIp: "",
			port: "",
			proxyLogin: "",
			proxyPassword: "",
			enabledForBlacklistControl: !1,
			blackUrlList: [],
			isInBlackList: !1,
			reCaptchaMode: "click",
			reCaptchaDelayTime: 0,
			reCaptchaCollapse: !1,
			reCaptchaRepeatTimes: 10,
			reCaptcha3Mode: "token",
			reCaptcha3DelayTime: 0,
			reCaptcha3Collapse: !1,
			reCaptcha3RepeatTimes: 10,
			hCaptchaMode: "click",
			hCaptchaDelayTime: 0,
			hCaptchaCollapse: !1,
			hCaptchaRepeatTimes: 10,
			funCaptchaMode: "click",
			funCaptchaDelayTime: 0,
			funCaptchaCollapse: !1,
			funCaptchaRepeatTimes: 10,
			geetestMode: "click",
			geetestCollapse: !1,
			geetestDelayTime: 0,
			geetestRepeatTimes: 10,
			textCaptchaMode: "click",
			textCaptchaCollapse: !1,
			textCaptchaDelayTime: 0,
			textCaptchaRepeatTimes: 10,
			enabledForCloudflare: !1,
			cloudflareMode: "click",
			cloudflareCollapse: !1,
			cloudflareDelayTime: 0,
			cloudflareRepeatTimes: 10,
			datadomeMode: "click",
			datadomeCollapse: !1,
			datadomeDelayTime: 0,
			datadomeRepeatTimes: 10,
			awsCaptchaMode: "click",
			awsCollapse: !1,
			awsDelayTime: 0,
			awsRepeatTimes: 10,
			useCapsolver: !0,
			isInit: !1,
			solvedCallback: "captchaSolvedCallback",
			textCaptchaSourceAttribute: "capsolver-image-to-text-source",
			textCaptchaResultAttribute: "capsolver-image-to-text-result"
		},
		de = {
			proxyType: ["socks5", "http", "https", "socks4"],
			mode: ["click", "token"]
		};
	async function me() {
		let e = await He(),
			t = Object.keys(e);
		for (let n of t)
			if (!(n === "proxyType" && !de[n].includes(e[n]))) {
				{
					if (n.endsWith("Mode") && !de.mode.includes(e[n])) continue;
					if (n === "port") {
						if (typeof e[n] != "number") continue;
						x[n] = e[n]
					}
				}
				Reflect.has(x, n) && typeof x[n] == typeof e[n] && (x[n] = e[n])
			} return x
	}
	var Ne = me(),
		w = {
			default: Ne,
			async get(e) {
				return (await this.getAll())[e]
			},
			async getAll() {
				let e = await me(),
					t = await chrome.storage.local.get("config");
				return w.joinConfig(e, t.config)
			},
			async set(e) {
				let t = await w.getAll(),
					n = w.joinConfig(t, e);
				return chrome.storage.local.set({
					config: n
				})
			},
			joinConfig(e, t) {
				let n = {};
				if (e)
					for (let o in e) n[o] = e[o];
				if (t)
					for (let o in t) n[o] = t[o];
				return n
			}
		};

	function Sleep(e) {
		return new Promise(t => setTimeout(t, e))
	}

	function p(e, t) {
		let n = t - e + 1;
		return Math.floor(Math.random() * n + e)
	}

	function B(e) {
		let t = e == null ? void 0 : e.getBoundingClientRect();
		return t ? {
			x: t.top + window.scrollY - document.documentElement.clientTop + p(-5, 5),
			y: t.left + window.scrollX - document.documentElement.clientLeft + p(-5, 5)
		} : {
			x: 0,
			y: 0
		}
	}

	function Ke(e, t, n, o, r) {
		let [a, i] = t, [c, d] = r, [l, m] = n, [h, g] = o, b = a * (1 - e) * (1 - e) * (1 - e) + 3 * l * e * (1 - e) * (1 - e) + 3 * h * e * e * (1 - e) + c * e * e * e, E = i * (1 - e) * (1 - e) * (1 - e) + 3 * m * e * (1 - e) * (1 - e) + 3 * g * e * e * (1 - e) + d * e * e * e;
		return [b, E]
	}

	function Ue(e, t, n = 30) {
		let o = [],
			r = 0,
			a = 1;
		for (let h = 0; h < n; ++h) o.push(r), h < n * 1 / 10 ? a += p(60, 100) : h >= n * 9 / 10 && (a -= p(60, 100), a = Math.max(20, a)), r += a;
		let i = [],
			c = [e.x, e.y],
			d = [(e.x + t.x) / 2 + p(30, 100) * 1, (e.y + t.y) / 2 + p(30, 100) * 1],
			l = [(e.x + t.x) / 2 + p(30, 100) * 1, (e.y + t.y) / 2 + p(30, 100) * 1],
			m = [t.x, t.y];
		for (let h of o) {
			let [g, b] = Ke(h / r, c, d, l, m);
			i.push({
				x: g,
				y: b
			})
		}
		return i
	}

	function Ve(e, t) {
		let n = Ue(e, t, p(15, 30));
		for (let o = 0; o < n.length; o++) document.body.dispatchEvent(new MouseEvent("mousemove", {
			bubbles: !0,
			clientX: n[o].x,
			clientY: n[o].y
		}))
	}

	function ze({
		x: e,
		y: t
	}) {
		document.body.dispatchEvent(new MouseEvent("mousedown", {
			bubbles: !0,
			clientX: e,
			clientY: t
		}))
	}

	function Qe({
		x: e,
		y: t
	}) {
		document.body.dispatchEvent(new MouseEvent("mouseup", {
			bubbles: !0,
			clientX: e,
			clientY: t
		}))
	}

	var I = "",
		ge = "",
		M = !1,
		Count_Do = 0,
		H = !1;

	function FindFail() {
		return document.querySelector(".match-game-fail") !== null || document.querySelector("#wrong")
	}

	async function findElement(e, all = false) {
        if (all == true){
			for (const c of e) {
                var elements = document.querySelectorAll(c);
                //console.log(a)
                if (elements.length >= 1) return elements
                //if (6 === a.length) return a
            }
		}
		else{
			for (const i of e) {
				var e = document.querySelector(i);
				//console.log(n)
				if (e) return e
			}
		}
                
        return null
    }

	function FindVerifyButton() {
		return document.querySelector(".geetest_radar_tip") !== null
	}
	function FindGeetest_box() {
		var gee_box = document.querySelector(".geetest_captcha");
		if(gee_box!=null){
			var styleValue = gee_box.getAttribute("style");
			if(styleValue == "display: block;") return true;
			else return false;
		}

		//return document.querySelector(".geetest_box") !== null
	}
	function FindGeetest_Slide(){
		return document.querySelector(".geetest_absolute") !== null
	}
	function FindGeetest_Radar_Ready(){
		return document.querySelector(".geetest_radar_click_ready") !== null
	}
	async function ClickAnchorButton(e) {
		console.log("ClickAnchorButton");
		let t = FindFail();
		
		//t && (M = !1, Count_Do++), !M && Count_Do <= e && (FindContainer() ? document.querySelector(".container .box button.button").click() : FindHomeChallenge() && (t ? document.querySelector("#wrong_children_button").click() : document.querySelector("#home_children_button").click()), M = !0, H = !1)
		if (t && !M) {
			M = false;
			Count_Do++;
		}
		else if (!M && Count_Do <= e) 
		{
			if (FindVerifyButton()) {
			  	document.querySelector(".geetest_radar_tip").click();
				
			} else if (FindHomeChallenge()) {
			  if (t) {
				document.querySelector("#wrong_children_button").click();
			  } else {
				document.querySelector("#home_children_button").click();
			  }
			  M = true;
			  H = false;
			}
		  }
	}
	async function GetImageCanvas() {
		let e = document.querySelector("canvas");
		if (!e) return null;
		let [t, n] = [e.width, e.height], r = e.getContext("2d", {
			willReadFrequently: !0
		}).getImageData(0, 0, t, n);
		if (Array.from(r.data).every((Ie, Oe) => Oe % 4 === 3 || Ie === 0)) return console.log("The original canvas has no valid content"), null;
		let s = parseInt(e.style.width, 10),
			i = parseInt(e.style.height, 10);
		if (s <= 0 || i <= 0) return console.log("Desired width and height should be positive numbers"), null;
		let c = Math.min(s / t, i / n),
			[u, f] = [t * c, n * c],
			p = document.querySelector(".bounding-box-example"),
			g = p == null ? void 0 : p.style.top.replace("px", ""),
			C = p == null ? void 0 : p.style.height.replace("px", ""),
			v = Number(g) + Number(C),
			b = document.createElement("canvas");
		Object.assign(b, {
			width: u,
			height: f
		}), b.getContext("2d").drawImage(e, 0, v, t, n - v, 0, 0, u, f - v);
		let ne = b.toDataURL("image/jpeg", .4);
		return ne.slice(ne.indexOf(";base64,") + 8)
	}
	function getBase64FromUrl(e) {
		return new Promise((t, n) => {
			let o = new Image;
			o.src = e, o.setAttribute("crossOrigin", "anonymous"), o.onload = () => {
				let r = document.createElement("canvas");
				r.width = o.width, r.height = o.height, r.getContext("2d").drawImage(o, 0, 0, o.width, o.height);
				let s = r.toDataURL();
				t(s)
			}, o.onerror = r => {
				n(r)
			}
		})
	}

	async function SolverBox() {
		console.log("SolverBox");
		let CauHoiFullTexts = await findElement([".geetest_text_tips"], !0)
		var main_q = "";
		if(CauHoiFullTexts!=null){
			main_q = CauHoiFullTexts[0].innerText?.trim();
		}
		var base64 = "";
		let imageElements = await findElement([".geetest_bg"], !0)
		if(imageElements!=null){
			var bg = imageElements[0].style.backgroundImage;
			let imageUrl = bg.slice(bg.indexOf('("')+2, bg.indexOf('")'));
			console.log(imageUrl);
			base64 = await getBase64FromUrl(imageUrl)
		}
		let e = {
			image: base64,
			question: main_q
		},
		t = {
			action: "solver",
			captchaType: "geetest",
			params: e
		};
		console.log(e);
		chrome.runtime.sendMessage(t).then(n => {
			var o, r;
			if (!(n != null && n.response) || ((o = n == null ? void 0 : n.response) == null ? void 0 : o.error)) {
				I = "", Count_Do++;
				return
			}
			
			ClickCaptchaCanvas((r = n.response.response) == null ? void 0 : r.solution)
		})
	}

	async function SolverCanvasSlide() {
		let e = await GetQuestionImage(),
			t = {
				action: "solver",
				captchaType: "geetest",
				params: e
			};
		console.log(e);
		chrome.runtime.sendMessage(t).then(n => {
			var o, r;
			if (!(n != null && n.response) || ((o = n == null ? void 0 : n.response) == null ? void 0 : o.error)) {
				I = "", Count_Do++;
				return
			}
			
			ClickCaptchaCanvas((r = n.response.response) == null ? void 0 : r.solution)
		})
	}
	async function ClickCaptchaCanvas(e) {
		console.log("ClickCaptcha");
	}

	var ve = document.createElement("script");
	ve.src = chrome.runtime.getURL("assets/inject/injected.js");
	var nt = document.head || document.documentElement;
	nt.appendChild(ve);
	window.addEventListener("message", function(e) {
		var t, n;
		(((t = e == null ? void 0 : e.data) == null ? void 0 : t.type) === "xhr" || ((n = e == null ? void 0 : e.data) == null ? void 0 : n.type) === "fetch") && Ce(e.data.data)
	});
	async function ot(e) {
		!e.useCapsolver || !e.enabledForGeetestV4 || !e.apiKey || e.enabledForBlacklistControl && e.isInBlackList || e.geetestMode !== "click" || (await Sleep(e.geetestDelayTime), setInterval(async () => {
			
			if (FindGeetest_box()){
				await SolverBox()
			}
			else if(FindGeetest_Slide()){
				await SolverCanvasSlide()
			}
			else if(FindGeetest_Radar_Ready()){

			}
			else if (FindVerifyButton()){
				if(await ClickAnchorButton(e.geetestRepeatTimes)){
					U()
				}
			}	
		}, 1e3))
	}
	async function rt(e) {
		setInterval(async () => {
			if (FindVerifyButton() && await ClickAnchorButton(e.geetestRepeatTimes), U()) {
				if (!await FindImage() || !await z(e.geetestRepeatTimes)) return;
				await SolverCanvasSlide()
			}
		}, 1e3)
	}
	var q = null;
	q && window.clearInterval(q);
	q = window.setInterval(async () => {
		let e = await w.getAll();
		!e.isInit || (e.manualSolving ? chrome.runtime.onMessage.addListener(t => {
			t.command === "execute" && rt(e)
		}) : ot(e), window.clearInterval(q))
	}, 100);
	var xe = (0, be.bexContent)(e => {});
	var W = chrome.runtime.connect({
			name: "contentScript"
		}),
		we = !1;
	W.onDisconnect.addListener(() => {
		we = !0
	});
	var Me = new v({
		listen(e) {
			W.onMessage.addListener(e)
		},
		send(e) {
			we || (W.postMessage(e), window.postMessage({
				...e,
				from: "bex-content-script"
			}, "*"))
		}
	});

	function at(e) {
		let t = document.createElement("script");
		t.src = e, t.onload = function() {
			this.remove()
		}, (document.head || document.documentElement).appendChild(t)
	}
	document instanceof HTMLDocument && at(chrome.runtime.getURL("dom.js"));
	fe(Me, "bex-dom");
	xe(Me);
})();
(async () => {
    window.addEventListener("load", () => {
        var t = document.body.appendChild(document.createElement("style")).sheet;
        t.insertRule("* {transition-duration: 0s !important}", 0), t.insertRule("li > a::after {border: 8px solid rgba(0, 255, 0, 0.6) !important}", 1), t.insertRule("#interstitial {backdrop-filter: none !important}", 2), t.insertRule("#interstitial {background-color: transparent !important}", 3), t.insertRule("#interstitial_wrapper {background-color: transparent !important}", 4)
    })
})();
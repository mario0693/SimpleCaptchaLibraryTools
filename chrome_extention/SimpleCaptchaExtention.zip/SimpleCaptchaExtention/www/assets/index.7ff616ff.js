var e = Object.defineProperty,
	t = (t, n, o) => (((t, n, o) => {
		n in t ? e(t, n, {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: o
		}) : t[n] = o
	})(t, "symbol" != typeof n ? n + "" : n, o), o);
const n = function() {
		const e = document.createElement("link").relList;
		return e && e.supports && e.supports("modulepreload") ? "modulepreload" : "preload"
	}(),
	o = {},
	l = function(e, t) {
		return t && 0 !== t.length ? Promise.all(t.map((e => {
			if ((e = `${e}`) in o) return;
			o[e] = !0;
			const t = e.endsWith(".css"),
				l = t ? '[rel="stylesheet"]' : "";
			if (document.querySelector(`link[href="${e}"]${l}`)) return;
			const a = document.createElement("link");
			return a.rel = t ? "stylesheet" : n, t || (a.as = "script", a.crossOrigin = ""), a.href = e, document.head.appendChild(a), t ? new Promise(((t, n) => {
				a.addEventListener("load", t), a.addEventListener("error", (() => n(new Error(`Unable to preload CSS for ${e}`))))
			})) : void 0
		}))).then((() => e())) : e()
	};

function a(e, t) {
	const n = Object.create(null),
		o = e.split(",");
	for (let l = 0; l < o.length; l++) n[o[l]] = !0;
	return t ? e => !!n[e.toLowerCase()] : e => !!n[e]
}

function r(e) {
	if (q(e)) {
		const t = {};
		for (let n = 0; n < e.length; n++) {
			const o = e[n],
				l = O(o) ? c(o) : r(o);
			if (l)
				for (const e in l) t[e] = l[e]
		}
		return t
	}
	return O(e) || P(e) ? e : void 0
}
const i = /;(?![^(]*\))/g,
	s = /:([^]+)/,
	u = /\/\*.*?\*\//gs;

function c(e) {
	const t = {};
	return e.replace(u, "").split(i).forEach((e => {
		if (e) {
			const n = e.split(s);
			n.length > 1 && (t[n[0].trim()] = n[1].trim())
		}
	})), t
}

function d(e) {
	let t = "";
	if (O(e)) t = e;
	else if (q(e))
		for (let n = 0; n < e.length; n++) {
			const o = d(e[n]);
			o && (t += o + " ")
		} else if (P(e))
			for (const n in e) e[n] && (t += n + " ");
	return t.trim()
}
const p = a("itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly");

function f(e) {
	return !!e || "" === e
}
const v = e => O(e) ? e : null == e ? "" : q(e) || P(e) && (e.toString === V || !R(e.toString)) ? JSON.stringify(e, h, 2) : String(e),
	h = (e, t) => t && t.__v_isRef ? h(e, t.value) : L(t) ? {
		[`Map(${t.size})`]: [...t.entries()].reduce(((e, [t, n]) => (e[`${t} =>`] = n, e)), {})
	} : F(t) ? {
		[`Set(${t.size})`]: [...t.values()]
	} : !P(t) || q(t) || B(t) ? t : String(t),
	m = {},
	g = [],
	b = () => {},
	y = () => !1,
	_ = /^on[^a-z]/,
	w = e => _.test(e),
	k = e => e.startsWith("onUpdate:"),
	S = Object.assign,
	x = (e, t) => {
		const n = e.indexOf(t);
		n > -1 && e.splice(n, 1)
	},
	C = Object.prototype.hasOwnProperty,
	E = (e, t) => C.call(e, t),
	q = Array.isArray,
	L = e => "[object Map]" === M(e),
	F = e => "[object Set]" === M(e),
	R = e => "function" == typeof e,
	O = e => "string" == typeof e,
	T = e => "symbol" == typeof e,
	P = e => null !== e && "object" == typeof e,
	A = e => P(e) && R(e.then) && R(e.catch),
	V = Object.prototype.toString,
	M = e => V.call(e),
	B = e => "[object Object]" === M(e),
	I = e => O(e) && "NaN" !== e && "-" !== e[0] && "" + parseInt(e, 10) === e,
	$ = a(",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"),
	z = e => {
		const t = Object.create(null);
		return n => t[n] || (t[n] = e(n))
	},
	N = /-(\w)/g,
	j = z((e => e.replace(N, ((e, t) => t ? t.toUpperCase() : "")))),
	D = /\B([A-Z])/g,
	U = z((e => e.replace(D, "-$1").toLowerCase())),
	H = z((e => e.charAt(0).toUpperCase() + e.slice(1))),
	W = z((e => e ? `on${H(e)}` : "")),
	K = (e, t) => !Object.is(e, t),
	Q = (e, t) => {
		for (let n = 0; n < e.length; n++) e[n](t)
	},
	G = (e, t, n) => {
		Object.defineProperty(e, t, {
			configurable: !0,
			enumerable: !1,
			value: n
		})
	},
	Z = e => {
		const t = parseFloat(e);
		return isNaN(t) ? e : t
	};
let J;
let X;
class Y {
	constructor(e = !1) {
		this.detached = e, this.active = !0, this.effects = [], this.cleanups = [], this.parent = X, !e && X && (this.index = (X.scopes || (X.scopes = [])).push(this) - 1)
	}
	run(e) {
		if (this.active) {
			const t = X;
			try {
				return X = this, e()
			} finally {
				X = t
			}
		}
	}
	on() {
		X = this
	}
	off() {
		X = this.parent
	}
	stop(e) {
		if (this.active) {
			let t, n;
			for (t = 0, n = this.effects.length; t < n; t++) this.effects[t].stop();
			for (t = 0, n = this.cleanups.length; t < n; t++) this.cleanups[t]();
			if (this.scopes)
				for (t = 0, n = this.scopes.length; t < n; t++) this.scopes[t].stop(!0);
			if (!this.detached && this.parent && !e) {
				const e = this.parent.scopes.pop();
				e && e !== this && (this.parent.scopes[this.index] = e, e.index = this.index)
			}
			this.parent = void 0, this.active = !1
		}
	}
}

function ee(e) {
	return new Y(e)
}
const te = e => {
		const t = new Set(e);
		return t.w = 0, t.n = 0, t
	},
	ne = e => (e.w & re) > 0,
	oe = e => (e.n & re) > 0,
	le = new WeakMap;
let ae = 0,
	re = 1;
let ie;
const se = Symbol(""),
	ue = Symbol("");
class ce {
	constructor(e, t = null, n) {
		this.fn = e, this.scheduler = t, this.active = !0, this.deps = [], this.parent = void 0,
			function(e, t = X) {
				t && t.active && t.effects.push(e)
			}(this, n)
	}
	run() {
		if (!this.active) return this.fn();
		let e = ie,
			t = pe;
		for (; e;) {
			if (e === this) return;
			e = e.parent
		}
		try {
			return this.parent = ie, ie = this, pe = !0, re = 1 << ++ae, ae <= 30 ? (({
				deps: e
			}) => {
				if (e.length)
					for (let t = 0; t < e.length; t++) e[t].w |= re
			})(this) : de(this), this.fn()
		} finally {
			ae <= 30 && (e => {
				const {
					deps: t
				} = e;
				if (t.length) {
					let n = 0;
					for (let o = 0; o < t.length; o++) {
						const l = t[o];
						ne(l) && !oe(l) ? l.delete(e) : t[n++] = l, l.w &= ~re, l.n &= ~re
					}
					t.length = n
				}
			})(this), re = 1 << --ae, ie = this.parent, pe = t, this.parent = void 0, this.deferStop && this.stop()
		}
	}
	stop() {
		ie === this ? this.deferStop = !0 : this.active && (de(this), this.onStop && this.onStop(), this.active = !1)
	}
}

function de(e) {
	const {
		deps: t
	} = e;
	if (t.length) {
		for (let n = 0; n < t.length; n++) t[n].delete(e);
		t.length = 0
	}
}
let pe = !0;
const fe = [];

function ve() {
	fe.push(pe), pe = !1
}

function he() {
	const e = fe.pop();
	pe = void 0 === e || e
}

function me(e, t, n) {
	if (pe && ie) {
		let t = le.get(e);
		t || le.set(e, t = new Map);
		let o = t.get(n);
		o || t.set(n, o = te()), ge(o)
	}
}

function ge(e, t) {
	let n = !1;
	ae <= 30 ? oe(e) || (e.n |= re, n = !ne(e)) : n = !e.has(ie), n && (e.add(ie), ie.deps.push(e))
}

function be(e, t, n, o, l, a) {
	const r = le.get(e);
	if (!r) return;
	let i = [];
	if ("clear" === t) i = [...r.values()];
	else if ("length" === n && q(e)) {
		const e = Z(o);
		r.forEach(((t, n) => {
			("length" === n || n >= e) && i.push(t)
		}))
	} else switch (void 0 !== n && i.push(r.get(n)), t) {
		case "add":
			q(e) ? I(n) && i.push(r.get("length")) : (i.push(r.get(se)), L(e) && i.push(r.get(ue)));
			break;
		case "delete":
			q(e) || (i.push(r.get(se)), L(e) && i.push(r.get(ue)));
			break;
		case "set":
			L(e) && i.push(r.get(se))
	}
	if (1 === i.length) i[0] && ye(i[0]);
	else {
		const e = [];
		for (const t of i) t && e.push(...t);
		ye(te(e))
	}
}

function ye(e, t) {
	const n = q(e) ? e : [...e];
	for (const o of n) o.computed && _e(o);
	for (const o of n) o.computed || _e(o)
}

function _e(e, t) {
	(e !== ie || e.allowRecurse) && (e.scheduler ? e.scheduler() : e.run())
}
const we = a("__proto__,__v_isRef,__isVue"),
	ke = new Set(Object.getOwnPropertyNames(Symbol).filter((e => "arguments" !== e && "caller" !== e)).map((e => Symbol[e])).filter(T)),
	Se = Le(),
	xe = Le(!1, !0),
	Ce = Le(!0),
	Ee = qe();

function qe() {
	const e = {};
	return ["includes", "indexOf", "lastIndexOf"].forEach((t => {
		e[t] = function(...e) {
			const n = pt(this);
			for (let t = 0, l = this.length; t < l; t++) me(n, 0, t + "");
			const o = n[t](...e);
			return -1 === o || !1 === o ? n[t](...e.map(pt)) : o
		}
	})), ["push", "pop", "shift", "unshift", "splice"].forEach((t => {
		e[t] = function(...e) {
			ve();
			const n = pt(this)[t].apply(this, e);
			return he(), n
		}
	})), e
}

function Le(e = !1, t = !1) {
	return function(n, o, l) {
		if ("__v_isReactive" === o) return !e;
		if ("__v_isReadonly" === o) return e;
		if ("__v_isShallow" === o) return t;
		if ("__v_raw" === o && l === (e ? t ? ot : nt : t ? tt : et).get(n)) return n;
		const a = q(n);
		if (!e && a && E(Ee, o)) return Reflect.get(Ee, o, l);
		const r = Reflect.get(n, o, l);
		return (T(o) ? ke.has(o) : we(o)) ? r : (e || me(n, 0, o), t ? r : bt(r) ? a && I(o) ? r : r.value : P(r) ? e ? rt(r) : at(r) : r)
	}
}

function Fe(e = !1) {
	return function(t, n, o, l) {
		let a = t[n];
		if (ut(a) && bt(a) && !bt(o)) return !1;
		if (!e && (ct(o) || ut(o) || (a = pt(a), o = pt(o)), !q(t) && bt(a) && !bt(o))) return a.value = o, !0;
		const r = q(t) && I(n) ? Number(n) < t.length : E(t, n),
			i = Reflect.set(t, n, o, l);
		return t === pt(l) && (r ? K(o, a) && be(t, "set", n, o) : be(t, "add", n, o)), i
	}
}
const Re = {
		get: Se,
		set: Fe(),
		deleteProperty: function(e, t) {
			const n = E(e, t);
			e[t];
			const o = Reflect.deleteProperty(e, t);
			return o && n && be(e, "delete", t, void 0), o
		},
		has: function(e, t) {
			const n = Reflect.has(e, t);
			return T(t) && ke.has(t) || me(e, 0, t), n
		},
		ownKeys: function(e) {
			return me(e, 0, q(e) ? "length" : se), Reflect.ownKeys(e)
		}
	},
	Oe = {
		get: Ce,
		set: (e, t) => !0,
		deleteProperty: (e, t) => !0
	},
	Te = S({}, Re, {
		get: xe,
		set: Fe(!0)
	}),
	Pe = e => e,
	Ae = e => Reflect.getPrototypeOf(e);

function Ve(e, t, n = !1, o = !1) {
	const l = pt(e = e.__v_raw),
		a = pt(t);
	n || (t !== a && me(l, 0, t), me(l, 0, a));
	const {
		has: r
	} = Ae(l), i = o ? Pe : n ? ht : vt;
	return r.call(l, t) ? i(e.get(t)) : r.call(l, a) ? i(e.get(a)) : void(e !== l && e.get(t))
}

function Me(e, t = !1) {
	const n = this.__v_raw,
		o = pt(n),
		l = pt(e);
	return t || (e !== l && me(o, 0, e), me(o, 0, l)), e === l ? n.has(e) : n.has(e) || n.has(l)
}

function Be(e, t = !1) {
	return e = e.__v_raw, !t && me(pt(e), 0, se), Reflect.get(e, "size", e)
}

function Ie(e) {
	e = pt(e);
	const t = pt(this);
	return Ae(t).has.call(t, e) || (t.add(e), be(t, "add", e, e)), this
}

function $e(e, t) {
	t = pt(t);
	const n = pt(this),
		{
			has: o,
			get: l
		} = Ae(n);
	let a = o.call(n, e);
	a || (e = pt(e), a = o.call(n, e));
	const r = l.call(n, e);
	return n.set(e, t), a ? K(t, r) && be(n, "set", e, t) : be(n, "add", e, t), this
}

function ze(e) {
	const t = pt(this),
		{
			has: n,
			get: o
		} = Ae(t);
	let l = n.call(t, e);
	l || (e = pt(e), l = n.call(t, e)), o && o.call(t, e);
	const a = t.delete(e);
	return l && be(t, "delete", e, void 0), a
}

function Ne() {
	const e = pt(this),
		t = 0 !== e.size,
		n = e.clear();
	return t && be(e, "clear", void 0, void 0), n
}

function je(e, t) {
	return function(n, o) {
		const l = this,
			a = l.__v_raw,
			r = pt(a),
			i = t ? Pe : e ? ht : vt;
		return !e && me(r, 0, se), a.forEach(((e, t) => n.call(o, i(e), i(t), l)))
	}
}

function De(e, t, n) {
	return function(...o) {
		const l = this.__v_raw,
			a = pt(l),
			r = L(a),
			i = "entries" === e || e === Symbol.iterator && r,
			s = "keys" === e && r,
			u = l[e](...o),
			c = n ? Pe : t ? ht : vt;
		return !t && me(a, 0, s ? ue : se), {
			next() {
				const {
					value: e,
					done: t
				} = u.next();
				return t ? {
					value: e,
					done: t
				} : {
					value: i ? [c(e[0]), c(e[1])] : c(e),
					done: t
				}
			},
			[Symbol.iterator]() {
				return this
			}
		}
	}
}

function Ue(e) {
	return function(...t) {
		return "delete" !== e && this
	}
}

function He() {
	const e = {
			get(e) {
				return Ve(this, e)
			},
			get size() {
				return Be(this)
			},
			has: Me,
			add: Ie,
			set: $e,
			delete: ze,
			clear: Ne,
			forEach: je(!1, !1)
		},
		t = {
			get(e) {
				return Ve(this, e, !1, !0)
			},
			get size() {
				return Be(this)
			},
			has: Me,
			add: Ie,
			set: $e,
			delete: ze,
			clear: Ne,
			forEach: je(!1, !0)
		},
		n = {
			get(e) {
				return Ve(this, e, !0)
			},
			get size() {
				return Be(this, !0)
			},
			has(e) {
				return Me.call(this, e, !0)
			},
			add: Ue("add"),
			set: Ue("set"),
			delete: Ue("delete"),
			clear: Ue("clear"),
			forEach: je(!0, !1)
		},
		o = {
			get(e) {
				return Ve(this, e, !0, !0)
			},
			get size() {
				return Be(this, !0)
			},
			has(e) {
				return Me.call(this, e, !0)
			},
			add: Ue("add"),
			set: Ue("set"),
			delete: Ue("delete"),
			clear: Ue("clear"),
			forEach: je(!0, !0)
		};
	return ["keys", "values", "entries", Symbol.iterator].forEach((l => {
		e[l] = De(l, !1, !1), n[l] = De(l, !0, !1), t[l] = De(l, !1, !0), o[l] = De(l, !0, !0)
	})), [e, n, t, o]
}
const [We, Ke, Qe, Ge] = He();

function Ze(e, t) {
	const n = t ? e ? Ge : Qe : e ? Ke : We;
	return (t, o, l) => "__v_isReactive" === o ? !e : "__v_isReadonly" === o ? e : "__v_raw" === o ? t : Reflect.get(E(n, o) && o in t ? n : t, o, l)
}
const Je = {
		get: Ze(!1, !1)
	},
	Xe = {
		get: Ze(!1, !0)
	},
	Ye = {
		get: Ze(!0, !1)
	},
	et = new WeakMap,
	tt = new WeakMap,
	nt = new WeakMap,
	ot = new WeakMap;

function lt(e) {
	return e.__v_skip || !Object.isExtensible(e) ? 0 : function(e) {
		switch (e) {
			case "Object":
			case "Array":
				return 1;
			case "Map":
			case "Set":
			case "WeakMap":
			case "WeakSet":
				return 2;
			default:
				return 0
		}
	}((e => M(e).slice(8, -1))(e))
}

function at(e) {
	return ut(e) ? e : it(e, !1, Re, Je, et)
}

function rt(e) {
	return it(e, !0, Oe, Ye, nt)
}

function it(e, t, n, o, l) {
	if (!P(e)) return e;
	if (e.__v_raw && (!t || !e.__v_isReactive)) return e;
	const a = l.get(e);
	if (a) return a;
	const r = lt(e);
	if (0 === r) return e;
	const i = new Proxy(e, 2 === r ? o : n);
	return l.set(e, i), i
}

function st(e) {
	return ut(e) ? st(e.__v_raw) : !(!e || !e.__v_isReactive)
}

function ut(e) {
	return !(!e || !e.__v_isReadonly)
}

function ct(e) {
	return !(!e || !e.__v_isShallow)
}

function dt(e) {
	return st(e) || ut(e)
}

function pt(e) {
	const t = e && e.__v_raw;
	return t ? pt(t) : e
}

function ft(e) {
	return G(e, "__v_skip", !0), e
}
const vt = e => P(e) ? at(e) : e,
	ht = e => P(e) ? rt(e) : e;

function mt(e) {
	pe && ie && ge((e = pt(e)).dep || (e.dep = te()))
}

function gt(e, t) {
	(e = pt(e)).dep && ye(e.dep)
}

function bt(e) {
	return !(!e || !0 !== e.__v_isRef)
}

function yt(e) {
	return _t(e, !1)
}

function _t(e, t) {
	return bt(e) ? e : new wt(e, t)
}
class wt {
	constructor(e, t) {
		this.__v_isShallow = t, this.dep = void 0, this.__v_isRef = !0, this._rawValue = t ? e : pt(e), this._value = t ? e : vt(e)
	}
	get value() {
		return mt(this), this._value
	}
	set value(e) {
		const t = this.__v_isShallow || ct(e) || ut(e);
		e = t ? e : pt(e), K(e, this._rawValue) && (this._rawValue = e, this._value = t ? e : vt(e), gt(this))
	}
}

function kt(e) {
	return bt(e) ? e.value : e
}
const St = {
	get: (e, t, n) => kt(Reflect.get(e, t, n)),
	set: (e, t, n, o) => {
		const l = e[t];
		return bt(l) && !bt(n) ? (l.value = n, !0) : Reflect.set(e, t, n, o)
	}
};

function xt(e) {
	return st(e) ? e : new Proxy(e, St)
}
var Ct;
class Et {
	constructor(e, t, n, o) {
		this._setter = t, this.dep = void 0, this.__v_isRef = !0, this[Ct] = !1, this._dirty = !0, this.effect = new ce(e, (() => {
			this._dirty || (this._dirty = !0, gt(this))
		})), this.effect.computed = this, this.effect.active = this._cacheable = !o, this.__v_isReadonly = n
	}
	get value() {
		const e = pt(this);
		return mt(e), !e._dirty && e._cacheable || (e._dirty = !1, e._value = e.effect.run()), e._value
	}
	set value(e) {
		this._setter(e)
	}
}

function qt(e, t, n, o) {
	let l;
	try {
		l = o ? e(...o) : e()
	} catch (a) {
		Ft(a, t, n)
	}
	return l
}

function Lt(e, t, n, o) {
	if (R(e)) {
		const l = qt(e, t, n, o);
		return l && A(l) && l.catch((e => {
			Ft(e, t, n)
		})), l
	}
	const l = [];
	for (let a = 0; a < e.length; a++) l.push(Lt(e[a], t, n, o));
	return l
}

function Ft(e, t, n, o = !0) {
	t && t.vnode;
	if (t) {
		let o = t.parent;
		const l = t.proxy,
			a = n;
		for (; o;) {
			const t = o.ec;
			if (t)
				for (let n = 0; n < t.length; n++)
					if (!1 === t[n](e, l, a)) return;
			o = o.parent
		}
		const r = t.appContext.config.errorHandler;
		if (r) return void qt(r, null, 10, [e, l, a])
	}! function(e, t, n, o = !0) {
		console.error(e)
	}(e, 0, 0, o)
}
Ct = "__v_isReadonly";
let Rt = !1,
	Ot = !1;
const Tt = [];
let Pt = 0;
const At = [];
let Vt = null,
	Mt = 0;
const Bt = Promise.resolve();
let It = null;

function $t(e) {
	const t = It || Bt;
	return e ? t.then(this ? e.bind(this) : e) : t
}

function zt(e) {
	Tt.length && Tt.includes(e, Rt && e.allowRecurse ? Pt + 1 : Pt) || (null == e.id ? Tt.push(e) : Tt.splice(function(e) {
		let t = Pt + 1,
			n = Tt.length;
		for (; t < n;) {
			const o = t + n >>> 1;
			Ht(Tt[o]) < e ? t = o + 1 : n = o
		}
		return t
	}(e.id), 0, e), Nt())
}

function Nt() {
	Rt || Ot || (Ot = !0, It = Bt.then(Kt))
}

function jt(e) {
	q(e) ? At.push(...e) : Vt && Vt.includes(e, e.allowRecurse ? Mt + 1 : Mt) || At.push(e), Nt()
}

function Dt(e, t = (Rt ? Pt + 1 : 0)) {
	for (; t < Tt.length; t++) {
		const e = Tt[t];
		e && e.pre && (Tt.splice(t, 1), t--, e())
	}
}

function Ut(e) {
	if (At.length) {
		const e = [...new Set(At)];
		if (At.length = 0, Vt) return void Vt.push(...e);
		for (Vt = e, Vt.sort(((e, t) => Ht(e) - Ht(t))), Mt = 0; Mt < Vt.length; Mt++) Vt[Mt]();
		Vt = null, Mt = 0
	}
}
const Ht = e => null == e.id ? 1 / 0 : e.id,
	Wt = (e, t) => {
		const n = Ht(e) - Ht(t);
		if (0 === n) {
			if (e.pre && !t.pre) return -1;
			if (t.pre && !e.pre) return 1
		}
		return n
	};

function Kt(e) {
	Ot = !1, Rt = !0, Tt.sort(Wt);
	try {
		for (Pt = 0; Pt < Tt.length; Pt++) {
			const e = Tt[Pt];
			e && !1 !== e.active && qt(e, null, 14)
		}
	} finally {
		Pt = 0, Tt.length = 0, Ut(), Rt = !1, It = null, (Tt.length || At.length) && Kt()
	}
}

function Qt(e, t, ...n) {
	if (e.isUnmounted) return;
	const o = e.vnode.props || m;
	let l = n;
	const a = t.startsWith("update:"),
		r = a && t.slice(7);
	if (r && r in o) {
		const e = `${"modelValue"===r?"model":r}Modifiers`,
			{
				number: t,
				trim: a
			} = o[e] || m;
		a && (l = n.map((e => O(e) ? e.trim() : e))), t && (l = n.map(Z))
	}
	let i, s = o[i = W(t)] || o[i = W(j(t))];
	!s && a && (s = o[i = W(U(t))]), s && Lt(s, e, 6, l);
	const u = o[i + "Once"];
	if (u) {
		if (e.emitted) {
			if (e.emitted[i]) return
		} else e.emitted = {};
		e.emitted[i] = !0, Lt(u, e, 6, l)
	}
}

function Gt(e, t, n = !1) {
	const o = t.emitsCache,
		l = o.get(e);
	if (void 0 !== l) return l;
	const a = e.emits;
	let r = {},
		i = !1;
	if (!R(e)) {
		const o = e => {
			const n = Gt(e, t, !0);
			n && (i = !0, S(r, n))
		};
		!n && t.mixins.length && t.mixins.forEach(o), e.extends && o(e.extends), e.mixins && e.mixins.forEach(o)
	}
	return a || i ? (q(a) ? a.forEach((e => r[e] = null)) : S(r, a), P(e) && o.set(e, r), r) : (P(e) && o.set(e, null), null)
}

function Zt(e, t) {
	return !(!e || !w(t)) && (t = t.slice(2).replace(/Once$/, ""), E(e, t[0].toLowerCase() + t.slice(1)) || E(e, U(t)) || E(e, t))
}
let Jt = null,
	Xt = null;

function Yt(e) {
	const t = Jt;
	return Jt = e, Xt = e && e.type.__scopeId || null, t
}

function en(e) {
	Xt = e
}

function tn() {
	Xt = null
}

function nn(e, t = Jt, n) {
	if (!t) return e;
	if (e._n) return e;
	const o = (...n) => {
		o._d && tl(-1);
		const l = Yt(t);
		let a;
		try {
			a = e(...n)
		} finally {
			Yt(l), o._d && tl(1)
		}
		return a
	};
	return o._n = !0, o._c = !0, o._d = !0, o
}

function on(e) {
	const {
		type: t,
		vnode: n,
		proxy: o,
		withProxy: l,
		props: a,
		propsOptions: [r],
		slots: i,
		attrs: s,
		emit: u,
		render: c,
		renderCache: d,
		data: p,
		setupState: f,
		ctx: v,
		inheritAttrs: h
	} = e;
	let m, g;
	const b = Yt(e);
	try {
		if (4 & n.shapeFlag) {
			const e = l || o;
			m = hl(c.call(e, e, d, a, f, p, v)), g = s
		} else {
			const e = t;
			0, m = hl(e.length > 1 ? e(a, {
				attrs: s,
				slots: i,
				emit: u
			}) : e(a, null)), g = t.props ? s : ln(s)
		}
	} catch (_) {
		Zo.length = 0, Ft(_, e, 1), m = dl(Qo)
	}
	let y = m;
	if (g && !1 !== h) {
		const e = Object.keys(g),
			{
				shapeFlag: t
			} = y;
		e.length && 7 & t && (r && e.some(k) && (g = an(g, r)), y = pl(y, g))
	}
	return n.dirs && (y = pl(y), y.dirs = y.dirs ? y.dirs.concat(n.dirs) : n.dirs), n.transition && (y.transition = n.transition), m = y, Yt(b), m
}
const ln = e => {
		let t;
		for (const n in e)("class" === n || "style" === n || w(n)) && ((t || (t = {}))[n] = e[n]);
		return t
	},
	an = (e, t) => {
		const n = {};
		for (const o in e) k(o) && o.slice(9) in t || (n[o] = e[o]);
		return n
	};

function rn(e, t, n) {
	const o = Object.keys(t);
	if (o.length !== Object.keys(e).length) return !0;
	for (let l = 0; l < o.length; l++) {
		const a = o[l];
		if (t[a] !== e[a] && !Zt(n, a)) return !0
	}
	return !1
}

function sn({
	vnode: e,
	parent: t
}, n) {
	for (; t && t.subTree === e;)(e = t.vnode).el = n, t = t.parent
}
const un = {
	name: "Suspense",
	__isSuspense: !0,
	process(e, t, n, o, l, a, r, i, s, u) {
		null == e ? function(e, t, n, o, l, a, r, i, s) {
			const {
				p: u,
				o: {
					createElement: c
				}
			} = s, d = c("div"), p = e.suspense = dn(e, l, o, t, d, n, a, r, i, s);
			u(null, p.pendingBranch = e.ssContent, d, null, o, p, a, r), p.deps > 0 ? (cn(e, "onPending"), cn(e, "onFallback"), u(null, e.ssFallback, t, n, o, null, a, r), fn(p, e.ssFallback)) : p.resolve()
		}(t, n, o, l, a, r, i, s, u) : function(e, t, n, o, l, a, r, i, {
			p: s,
			um: u,
			o: {
				createElement: c
			}
		}) {
			const d = t.suspense = e.suspense;
			d.vnode = t, t.el = e.el;
			const p = t.ssContent,
				f = t.ssFallback,
				{
					activeBranch: v,
					pendingBranch: h,
					isInFallback: m,
					isHydrating: g
				} = d;
			if (h) d.pendingBranch = p, rl(p, h) ? (s(h, p, d.hiddenContainer, null, l, d, a, r, i), d.deps <= 0 ? d.resolve() : m && (s(v, f, n, o, l, null, a, r, i), fn(d, f))) : (d.pendingId++, g ? (d.isHydrating = !1, d.activeBranch = h) : u(h, l, d), d.deps = 0, d.effects.length = 0, d.hiddenContainer = c("div"), m ? (s(null, p, d.hiddenContainer, null, l, d, a, r, i), d.deps <= 0 ? d.resolve() : (s(v, f, n, o, l, null, a, r, i), fn(d, f))) : v && rl(p, v) ? (s(v, p, n, o, l, d, a, r, i), d.resolve(!0)) : (s(null, p, d.hiddenContainer, null, l, d, a, r, i), d.deps <= 0 && d.resolve()));
			else if (v && rl(p, v)) s(v, p, n, o, l, d, a, r, i), fn(d, p);
			else if (cn(t, "onPending"), d.pendingBranch = p, d.pendingId++, s(null, p, d.hiddenContainer, null, l, d, a, r, i), d.deps <= 0) d.resolve();
			else {
				const {
					timeout: e,
					pendingId: t
				} = d;
				e > 0 ? setTimeout((() => {
					d.pendingId === t && d.fallback(f)
				}), e) : 0 === e && d.fallback(f)
			}
		}(e, t, n, o, l, r, i, s, u)
	},
	hydrate: function(e, t, n, o, l, a, r, i, s) {
		const u = t.suspense = dn(t, o, n, e.parentNode, document.createElement("div"), null, l, a, r, i, !0),
			c = s(e, u.pendingBranch = t.ssContent, n, u, a, r);
		0 === u.deps && u.resolve();
		return c
	},
	create: dn,
	normalize: function(e) {
		const {
			shapeFlag: t,
			children: n
		} = e, o = 32 & t;
		e.ssContent = pn(o ? n.default : n), e.ssFallback = o ? pn(n.fallback) : dl(Qo)
	}
};

function cn(e, t) {
	const n = e.props && e.props[t];
	R(n) && n()
}

function dn(e, t, n, o, l, a, r, i, s, u, c = !1) {
	const {
		p: d,
		m: p,
		um: f,
		n: v,
		o: {
			parentNode: h,
			remove: m
		}
	} = u, g = Z(e.props && e.props.timeout), b = {
		vnode: e,
		parent: t,
		parentComponent: n,
		isSVG: r,
		container: o,
		hiddenContainer: l,
		anchor: a,
		deps: 0,
		pendingId: 0,
		timeout: "number" == typeof g ? g : -1,
		activeBranch: null,
		pendingBranch: null,
		isInFallback: !0,
		isHydrating: c,
		isUnmounted: !1,
		effects: [],
		resolve(e = !1) {
			const {
				vnode: t,
				activeBranch: n,
				pendingBranch: o,
				pendingId: l,
				effects: a,
				parentComponent: r,
				container: i
			} = b;
			if (b.isHydrating) b.isHydrating = !1;
			else if (!e) {
				const e = n && o.transition && "out-in" === o.transition.mode;
				e && (n.transition.afterLeave = () => {
					l === b.pendingId && p(o, i, t, 0)
				});
				let {
					anchor: t
				} = b;
				n && (t = v(n), f(n, r, b, !0)), e || p(o, i, t, 0)
			}
			fn(b, o), b.pendingBranch = null, b.isInFallback = !1;
			let s = b.parent,
				u = !1;
			for (; s;) {
				if (s.pendingBranch) {
					s.effects.push(...a), u = !0;
					break
				}
				s = s.parent
			}
			u || jt(a), b.effects = [], cn(t, "onResolve")
		},
		fallback(e) {
			if (!b.pendingBranch) return;
			const {
				vnode: t,
				activeBranch: n,
				parentComponent: o,
				container: l,
				isSVG: a
			} = b;
			cn(t, "onFallback");
			const r = v(n),
				u = () => {
					b.isInFallback && (d(null, e, l, r, o, null, a, i, s), fn(b, e))
				},
				c = e.transition && "out-in" === e.transition.mode;
			c && (n.transition.afterLeave = u), b.isInFallback = !0, f(n, o, null, !0), c || u()
		},
		move(e, t, n) {
			b.activeBranch && p(b.activeBranch, e, t, n), b.container = e
		},
		next: () => b.activeBranch && v(b.activeBranch),
		registerDep(e, t) {
			const n = !!b.pendingBranch;
			n && b.deps++;
			const o = e.vnode.el;
			e.asyncDep.catch((t => {
				Ft(t, e, 0)
			})).then((l => {
				if (e.isUnmounted || b.isUnmounted || b.pendingId !== e.suspenseId) return;
				e.asyncResolved = !0;
				const {
					vnode: a
				} = e;
				Ll(e, l, !1), o && (a.el = o);
				const i = !o && e.subTree.el;
				t(e, a, h(o || e.subTree.el), o ? null : v(e.subTree), b, r, s), i && m(i), sn(e, a.el), n && 0 == --b.deps && b.resolve()
			}))
		},
		unmount(e, t) {
			b.isUnmounted = !0, b.activeBranch && f(b.activeBranch, n, e, t), b.pendingBranch && f(b.pendingBranch, n, e, t)
		}
	};
	return b
}

function pn(e) {
	let t;
	if (R(e)) {
		const n = el && e._c;
		n && (e._d = !1, Xo()), e = e(), n && (e._d = !0, t = Jo, Yo())
	}
	if (q(e)) {
		const t = function(e) {
			let t;
			for (let n = 0; n < e.length; n++) {
				const o = e[n];
				if (!al(o)) return;
				if (o.type !== Qo || "v-if" === o.children) {
					if (t) return;
					t = o
				}
			}
			return t
		}(e);
		e = t
	}
	return e = hl(e), t && !e.dynamicChildren && (e.dynamicChildren = t.filter((t => t !== e))), e
}

function fn(e, t) {
	e.activeBranch = t;
	const {
		vnode: n,
		parentComponent: o
	} = e, l = n.el = t.el;
	o && o.subTree === n && (o.vnode.el = l, sn(o, l))
}

function vn(e, t) {
	if (kl) {
		let n = kl.provides;
		const o = kl.parent && kl.parent.provides;
		o === n && (n = kl.provides = Object.create(o)), n[e] = t
	} else;
}

function hn(e, t, n = !1) {
	const o = kl || Jt;
	if (o) {
		const l = null == o.parent ? o.vnode.appContext && o.vnode.appContext.provides : o.parent.provides;
		if (l && e in l) return l[e];
		if (arguments.length > 1) return n && R(t) ? t.call(o.proxy) : t
	}
}
const mn = {};

function gn(e, t, n) {
	return bn(e, t, n)
}

function bn(e, t, {
	immediate: n,
	deep: o,
	flush: l,
	onTrack: a,
	onTrigger: r
} = m) {
	const i = kl;
	let s, u, c = !1,
		d = !1;
	if (bt(e) ? (s = () => e.value, c = ct(e)) : st(e) ? (s = () => e, o = !0) : q(e) ? (d = !0, c = e.some((e => st(e) || ct(e))), s = () => e.map((e => bt(e) ? e.value : st(e) ? wn(e) : R(e) ? qt(e, i, 2) : void 0))) : s = R(e) ? t ? () => qt(e, i, 2) : () => {
			if (!i || !i.isUnmounted) return u && u(), Lt(e, i, 3, [f])
		} : b, t && o) {
		const e = s;
		s = () => wn(e())
	}
	let p, f = e => {
		u = y.onStop = () => {
			qt(e, i, 4)
		}
	};
	if (ql) {
		if (f = b, t ? n && Lt(t, i, 3, [s(), d ? [] : void 0, f]) : s(), "sync" !== l) return b;
		{
			const e = Al();
			p = e.__watcherHandles || (e.__watcherHandles = [])
		}
	}
	let v = d ? new Array(e.length).fill(mn) : mn;
	const h = () => {
		if (y.active)
			if (t) {
				const e = y.run();
				(o || c || (d ? e.some(((e, t) => K(e, v[t]))) : K(e, v))) && (u && u(), Lt(t, i, 3, [e, v === mn ? void 0 : d && v[0] === mn ? [] : v, f]), v = e)
			} else y.run()
	};
	let g;
	h.allowRecurse = !!t, "sync" === l ? g = h : "post" === l ? g = () => Mo(h, i && i.suspense) : (h.pre = !0, i && (h.id = i.uid), g = () => zt(h));
	const y = new ce(s, g);
	t ? n ? h() : v = y.run() : "post" === l ? Mo(y.run.bind(y), i && i.suspense) : y.run();
	const _ = () => {
		y.stop(), i && i.scope && x(i.scope.effects, y)
	};
	return p && p.push(_), _
}

function yn(e, t, n) {
	const o = this.proxy,
		l = O(e) ? e.includes(".") ? _n(o, e) : () => o[e] : e.bind(o, o);
	let a;
	R(t) ? a = t : (a = t.handler, n = t);
	const r = kl;
	xl(this);
	const i = bn(l, a.bind(o), n);
	return r ? xl(r) : Cl(), i
}

function _n(e, t) {
	const n = t.split(".");
	return () => {
		let t = e;
		for (let e = 0; e < n.length && t; e++) t = t[n[e]];
		return t
	}
}

function wn(e, t) {
	if (!P(e) || e.__v_skip) return e;
	if ((t = t || new Set).has(e)) return e;
	if (t.add(e), bt(e)) wn(e.value, t);
	else if (q(e))
		for (let n = 0; n < e.length; n++) wn(e[n], t);
	else if (F(e) || L(e)) e.forEach((e => {
		wn(e, t)
	}));
	else if (B(e))
		for (const n in e) wn(e[n], t);
	return e
}
const kn = [Function, Array],
	Sn = {
		name: "BaseTransition",
		props: {
			mode: String,
			appear: Boolean,
			persisted: Boolean,
			onBeforeEnter: kn,
			onEnter: kn,
			onAfterEnter: kn,
			onEnterCancelled: kn,
			onBeforeLeave: kn,
			onLeave: kn,
			onAfterLeave: kn,
			onLeaveCancelled: kn,
			onBeforeAppear: kn,
			onAppear: kn,
			onAfterAppear: kn,
			onAppearCancelled: kn
		},
		setup(e, {
			slots: t
		}) {
			const n = Sl(),
				o = function() {
					const e = {
						isMounted: !1,
						isLeaving: !1,
						isUnmounting: !1,
						leavingVNodes: new Map
					};
					return zn((() => {
						e.isMounted = !0
					})), Dn((() => {
						e.isUnmounting = !0
					})), e
				}();
			let l;
			return () => {
				const a = t.default && Fn(t.default(), !0);
				if (!a || !a.length) return;
				let r = a[0];
				if (a.length > 1)
					for (const e of a)
						if (e.type !== Qo) {
							r = e;
							break
						} const i = pt(e),
					{
						mode: s
					} = i;
				if (o.isLeaving) return En(r);
				const u = qn(r);
				if (!u) return En(r);
				const c = Cn(u, i, o, n);
				Ln(u, c);
				const d = n.subTree,
					p = d && qn(d);
				let f = !1;
				const {
					getTransitionKey: v
				} = u.type;
				if (v) {
					const e = v();
					void 0 === l ? l = e : e !== l && (l = e, f = !0)
				}
				if (p && p.type !== Qo && (!rl(u, p) || f)) {
					const e = Cn(p, i, o, n);
					if (Ln(p, e), "out-in" === s) return o.isLeaving = !0, e.afterLeave = () => {
						o.isLeaving = !1, !1 !== n.update.active && n.update()
					}, En(r);
					"in-out" === s && u.type !== Qo && (e.delayLeave = (e, t, n) => {
						xn(o, p)[String(p.key)] = p, e._leaveCb = () => {
							t(), e._leaveCb = void 0, delete c.delayedLeave
						}, c.delayedLeave = n
					})
				}
				return r
			}
		}
	};

function xn(e, t) {
	const {
		leavingVNodes: n
	} = e;
	let o = n.get(t.type);
	return o || (o = Object.create(null), n.set(t.type, o)), o
}

function Cn(e, t, n, o) {
	const {
		appear: l,
		mode: a,
		persisted: r = !1,
		onBeforeEnter: i,
		onEnter: s,
		onAfterEnter: u,
		onEnterCancelled: c,
		onBeforeLeave: d,
		onLeave: p,
		onAfterLeave: f,
		onLeaveCancelled: v,
		onBeforeAppear: h,
		onAppear: m,
		onAfterAppear: g,
		onAppearCancelled: b
	} = t, y = String(e.key), _ = xn(n, e), w = (e, t) => {
		e && Lt(e, o, 9, t)
	}, k = (e, t) => {
		const n = t[1];
		w(e, t), q(e) ? e.every((e => e.length <= 1)) && n() : e.length <= 1 && n()
	}, S = {
		mode: a,
		persisted: r,
		beforeEnter(t) {
			let o = i;
			if (!n.isMounted) {
				if (!l) return;
				o = h || i
			}
			t._leaveCb && t._leaveCb(!0);
			const a = _[y];
			a && rl(e, a) && a.el._leaveCb && a.el._leaveCb(), w(o, [t])
		},
		enter(e) {
			let t = s,
				o = u,
				a = c;
			if (!n.isMounted) {
				if (!l) return;
				t = m || s, o = g || u, a = b || c
			}
			let r = !1;
			const i = e._enterCb = t => {
				r || (r = !0, w(t ? a : o, [e]), S.delayedLeave && S.delayedLeave(), e._enterCb = void 0)
			};
			t ? k(t, [e, i]) : i()
		},
		leave(t, o) {
			const l = String(e.key);
			if (t._enterCb && t._enterCb(!0), n.isUnmounting) return o();
			w(d, [t]);
			let a = !1;
			const r = t._leaveCb = n => {
				a || (a = !0, o(), w(n ? v : f, [t]), t._leaveCb = void 0, _[l] === e && delete _[l])
			};
			_[l] = e, p ? k(p, [t, r]) : r()
		},
		clone: e => Cn(e, t, n, o)
	};
	return S
}

function En(e) {
	if (Tn(e)) return (e = pl(e)).children = null, e
}

function qn(e) {
	return Tn(e) ? e.children ? e.children[0] : void 0 : e
}

function Ln(e, t) {
	6 & e.shapeFlag && e.component ? Ln(e.component.subTree, t) : 128 & e.shapeFlag ? (e.ssContent.transition = t.clone(e.ssContent), e.ssFallback.transition = t.clone(e.ssFallback)) : e.transition = t
}

function Fn(e, t = !1, n) {
	let o = [],
		l = 0;
	for (let a = 0; a < e.length; a++) {
		let r = e[a];
		const i = null == n ? r.key : String(n) + String(null != r.key ? r.key : a);
		r.type === Wo ? (128 & r.patchFlag && l++, o = o.concat(Fn(r.children, t, i))) : (t || r.type !== Qo) && o.push(null != i ? pl(r, {
			key: i
		}) : r)
	}
	if (l > 1)
		for (let a = 0; a < o.length; a++) o[a].patchFlag = -2;
	return o
}

function Rn(e) {
	return R(e) ? {
		setup: e,
		name: e.name
	} : e
}
const On = e => !!e.type.__asyncLoader,
	Tn = e => e.type.__isKeepAlive;

function Pn(e, t) {
	Vn(e, "a", t)
}

function An(e, t) {
	Vn(e, "da", t)
}

function Vn(e, t, n = kl) {
	const o = e.__wdc || (e.__wdc = () => {
		let t = n;
		for (; t;) {
			if (t.isDeactivated) return;
			t = t.parent
		}
		return e()
	});
	if (Bn(t, o, n), n) {
		let e = n.parent;
		for (; e && e.parent;) Tn(e.parent.vnode) && Mn(o, t, n, e), e = e.parent
	}
}

function Mn(e, t, n, o) {
	const l = Bn(t, e, o, !0);
	Un((() => {
		x(o[t], l)
	}), n)
}

function Bn(e, t, n = kl, o = !1) {
	if (n) {
		const l = n[e] || (n[e] = []),
			a = t.__weh || (t.__weh = (...o) => {
				if (n.isUnmounted) return;
				ve(), xl(n);
				const l = Lt(t, n, e, o);
				return Cl(), he(), l
			});
		return o ? l.unshift(a) : l.push(a), a
	}
}
const In = e => (t, n = kl) => (!ql || "sp" === e) && Bn(e, ((...e) => t(...e)), n),
	$n = In("bm"),
	zn = In("m"),
	Nn = In("bu"),
	jn = In("u"),
	Dn = In("bum"),
	Un = In("um"),
	Hn = In("sp"),
	Wn = In("rtg"),
	Kn = In("rtc");

function Qn(e, t = kl) {
	Bn("ec", e, t)
}

function Gn(e, t) {
	const n = Jt;
	if (null === n) return e;
	const o = Rl(n) || n.proxy,
		l = e.dirs || (e.dirs = []);
	for (let a = 0; a < t.length; a++) {
		let [e, n, r, i = m] = t[a];
		e && (R(e) && (e = {
			mounted: e,
			updated: e
		}), e.deep && wn(n), l.push({
			dir: e,
			instance: o,
			value: n,
			oldValue: void 0,
			arg: r,
			modifiers: i
		}))
	}
	return e
}

function Zn(e, t, n, o) {
	const l = e.dirs,
		a = t && t.dirs;
	for (let r = 0; r < l.length; r++) {
		const i = l[r];
		a && (i.oldValue = a[r].value);
		let s = i.dir[o];
		s && (ve(), Lt(s, n, 8, [e.el, i, e, t]), he())
	}
}

function Jn(e, t) {
	return function(e, t, n = !0, o = !1) {
		const l = Jt || kl;
		if (l) {
			const n = l.type;
			if ("components" === e) {
				const e = function(e, t = !0) {
					return R(e) ? e.displayName || e.name : e.name || t && e.__name
				}(n, !1);
				if (e && (e === t || e === j(t) || e === H(j(t)))) return n
			}
			const a = Yn(l[e] || n[e], t) || Yn(l.appContext[e], t);
			return !a && o ? n : a
		}
	}("components", e, !0, t) || e
}
const Xn = Symbol();

function Yn(e, t) {
	return e && (e[t] || e[j(t)] || e[H(j(t))])
}

function eo(e, t, n, o) {
	let l;
	const a = n && n[o];
	if (q(e) || O(e)) {
		l = new Array(e.length);
		for (let n = 0, o = e.length; n < o; n++) l[n] = t(e[n], n, void 0, a && a[n])
	} else if ("number" == typeof e) {
		l = new Array(e);
		for (let n = 0; n < e; n++) l[n] = t(n + 1, n, void 0, a && a[n])
	} else if (P(e))
		if (e[Symbol.iterator]) l = Array.from(e, ((e, n) => t(e, n, void 0, a && a[n])));
		else {
			const n = Object.keys(e);
			l = new Array(n.length);
			for (let o = 0, r = n.length; o < r; o++) {
				const r = n[o];
				l[o] = t(e[r], r, o, a && a[o])
			}
		}
	else l = [];
	return n && (n[o] = l), l
}

function to(e, t, n = {}, o, l) {
	if (Jt.isCE || Jt.parent && On(Jt.parent) && Jt.parent.isCE) return "default" !== t && (n.name = t), dl("slot", n, o && o());
	let a = e[t];
	a && a._c && (a._d = !1), Xo();
	const r = a && no(a(n)),
		i = ll(Wo, {
			key: n.key || r && r.key || `_${t}`
		}, r || (o ? o() : []), r && 1 === e._ ? 64 : -2);
	return !l && i.scopeId && (i.slotScopeIds = [i.scopeId + "-s"]), a && a._c && (a._d = !0), i
}

function no(e) {
	return e.some((e => !al(e) || e.type !== Qo && !(e.type === Wo && !no(e.children)))) ? e : null
}
const oo = e => e ? El(e) ? Rl(e) || e.proxy : oo(e.parent) : null,
	lo = S(Object.create(null), {
		$: e => e,
		$el: e => e.vnode.el,
		$data: e => e.data,
		$props: e => e.props,
		$attrs: e => e.attrs,
		$slots: e => e.slots,
		$refs: e => e.refs,
		$parent: e => oo(e.parent),
		$root: e => oo(e.root),
		$emit: e => e.emit,
		$options: e => po(e),
		$forceUpdate: e => e.f || (e.f = () => zt(e.update)),
		$nextTick: e => e.n || (e.n = $t.bind(e.proxy)),
		$watch: e => yn.bind(e)
	}),
	ao = (e, t) => e !== m && !e.__isScriptSetup && E(e, t),
	ro = {
		get({
			_: e
		}, t) {
			const {
				ctx: n,
				setupState: o,
				data: l,
				props: a,
				accessCache: r,
				type: i,
				appContext: s
			} = e;
			let u;
			if ("$" !== t[0]) {
				const i = r[t];
				if (void 0 !== i) switch (i) {
					case 1:
						return o[t];
					case 2:
						return l[t];
					case 4:
						return n[t];
					case 3:
						return a[t]
				} else {
					if (ao(o, t)) return r[t] = 1, o[t];
					if (l !== m && E(l, t)) return r[t] = 2, l[t];
					if ((u = e.propsOptions[0]) && E(u, t)) return r[t] = 3, a[t];
					if (n !== m && E(n, t)) return r[t] = 4, n[t];
					io && (r[t] = 0)
				}
			}
			const c = lo[t];
			let d, p;
			return c ? ("$attrs" === t && me(e, 0, t), c(e)) : (d = i.__cssModules) && (d = d[t]) ? d : n !== m && E(n, t) ? (r[t] = 4, n[t]) : (p = s.config.globalProperties, E(p, t) ? p[t] : void 0)
		},
		set({
			_: e
		}, t, n) {
			const {
				data: o,
				setupState: l,
				ctx: a
			} = e;
			return ao(l, t) ? (l[t] = n, !0) : o !== m && E(o, t) ? (o[t] = n, !0) : !E(e.props, t) && (("$" !== t[0] || !(t.slice(1) in e)) && (a[t] = n, !0))
		},
		has({
			_: {
				data: e,
				setupState: t,
				accessCache: n,
				ctx: o,
				appContext: l,
				propsOptions: a
			}
		}, r) {
			let i;
			return !!n[r] || e !== m && E(e, r) || ao(t, r) || (i = a[0]) && E(i, r) || E(o, r) || E(lo, r) || E(l.config.globalProperties, r)
		},
		defineProperty(e, t, n) {
			return null != n.get ? e._.accessCache[t] = 0 : E(n, "value") && this.set(e, t, n.value, null), Reflect.defineProperty(e, t, n)
		}
	};
let io = !0;

function so(e) {
	const t = po(e),
		n = e.proxy,
		o = e.ctx;
	io = !1, t.beforeCreate && uo(t.beforeCreate, e, "bc");
	const {
		data: l,
		computed: a,
		methods: r,
		watch: i,
		provide: s,
		inject: u,
		created: c,
		beforeMount: d,
		mounted: p,
		beforeUpdate: f,
		updated: v,
		activated: h,
		deactivated: m,
		beforeDestroy: g,
		beforeUnmount: y,
		destroyed: _,
		unmounted: w,
		render: k,
		renderTracked: S,
		renderTriggered: x,
		errorCaptured: C,
		serverPrefetch: E,
		expose: L,
		inheritAttrs: F,
		components: O,
		directives: T,
		filters: A
	} = t;
	if (u && function(e, t, n = b, o = !1) {
			q(e) && (e = mo(e));
			for (const l in e) {
				const n = e[l];
				let a;
				a = P(n) ? "default" in n ? hn(n.from || l, n.default, !0) : hn(n.from || l) : hn(n), bt(a) && o ? Object.defineProperty(t, l, {
					enumerable: !0,
					configurable: !0,
					get: () => a.value,
					set: e => a.value = e
				}) : t[l] = a
			}
		}(u, o, null, e.appContext.config.unwrapInjectedRef), r)
		for (const b in r) {
			const e = r[b];
			R(e) && (o[b] = e.bind(n))
		}
	if (l) {
		const t = l.call(n, n);
		P(t) && (e.data = at(t))
	}
	if (io = !0, a)
		for (const q in a) {
			const e = a[q],
				t = R(e) ? e.bind(n, n) : R(e.get) ? e.get.bind(n, n) : b,
				l = !R(e) && R(e.set) ? e.set.bind(n) : b,
				r = Ol({
					get: t,
					set: l
				});
			Object.defineProperty(o, q, {
				enumerable: !0,
				configurable: !0,
				get: () => r.value,
				set: e => r.value = e
			})
		}
	if (i)
		for (const b in i) co(i[b], o, n, b);
	if (s) {
		const e = R(s) ? s.call(n) : s;
		Reflect.ownKeys(e).forEach((t => {
			vn(t, e[t])
		}))
	}

	function V(e, t) {
		q(t) ? t.forEach((t => e(t.bind(n)))) : t && e(t.bind(n))
	}
	if (c && uo(c, e, "c"), V($n, d), V(zn, p), V(Nn, f), V(jn, v), V(Pn, h), V(An, m), V(Qn, C), V(Kn, S), V(Wn, x), V(Dn, y), V(Un, w), V(Hn, E), q(L))
		if (L.length) {
			const t = e.exposed || (e.exposed = {});
			L.forEach((e => {
				Object.defineProperty(t, e, {
					get: () => n[e],
					set: t => n[e] = t
				})
			}))
		} else e.exposed || (e.exposed = {});
	k && e.render === b && (e.render = k), null != F && (e.inheritAttrs = F), O && (e.components = O), T && (e.directives = T)
}

function uo(e, t, n) {
	Lt(q(e) ? e.map((e => e.bind(t.proxy))) : e.bind(t.proxy), t, n)
}

function co(e, t, n, o) {
	const l = o.includes(".") ? _n(n, o) : () => n[o];
	if (O(e)) {
		const n = t[e];
		R(n) && gn(l, n)
	} else if (R(e)) gn(l, e.bind(n));
	else if (P(e))
		if (q(e)) e.forEach((e => co(e, t, n, o)));
		else {
			const o = R(e.handler) ? e.handler.bind(n) : t[e.handler];
			R(o) && gn(l, o, e)
		}
}

function po(e) {
	const t = e.type,
		{
			mixins: n,
			extends: o
		} = t,
		{
			mixins: l,
			optionsCache: a,
			config: {
				optionMergeStrategies: r
			}
		} = e.appContext,
		i = a.get(t);
	let s;
	return i ? s = i : l.length || n || o ? (s = {}, l.length && l.forEach((e => fo(s, e, r, !0))), fo(s, t, r)) : s = t, P(t) && a.set(t, s), s
}

function fo(e, t, n, o = !1) {
	const {
		mixins: l,
		extends: a
	} = t;
	a && fo(e, a, n, !0), l && l.forEach((t => fo(e, t, n, !0)));
	for (const r in t)
		if (o && "expose" === r);
		else {
			const o = vo[r] || n && n[r];
			e[r] = o ? o(e[r], t[r]) : t[r]
		} return e
}
const vo = {
	data: ho,
	props: bo,
	emits: bo,
	methods: bo,
	computed: bo,
	beforeCreate: go,
	created: go,
	beforeMount: go,
	mounted: go,
	beforeUpdate: go,
	updated: go,
	beforeDestroy: go,
	beforeUnmount: go,
	destroyed: go,
	unmounted: go,
	activated: go,
	deactivated: go,
	errorCaptured: go,
	serverPrefetch: go,
	components: bo,
	directives: bo,
	watch: function(e, t) {
		if (!e) return t;
		if (!t) return e;
		const n = S(Object.create(null), e);
		for (const o in t) n[o] = go(e[o], t[o]);
		return n
	},
	provide: ho,
	inject: function(e, t) {
		return bo(mo(e), mo(t))
	}
};

function ho(e, t) {
	return t ? e ? function() {
		return S(R(e) ? e.call(this, this) : e, R(t) ? t.call(this, this) : t)
	} : t : e
}

function mo(e) {
	if (q(e)) {
		const t = {};
		for (let n = 0; n < e.length; n++) t[e[n]] = e[n];
		return t
	}
	return e
}

function go(e, t) {
	return e ? [...new Set([].concat(e, t))] : t
}

function bo(e, t) {
	return e ? S(S(Object.create(null), e), t) : t
}

function yo(e, t, n, o = !1) {
	const l = {},
		a = {};
	G(a, il, 1), e.propsDefaults = Object.create(null), _o(e, t, l, a);
	for (const r in e.propsOptions[0]) r in l || (l[r] = void 0);
	n ? e.props = o ? l : it(l, !1, Te, Xe, tt) : e.type.props ? e.props = l : e.props = a, e.attrs = a
}

function _o(e, t, n, o) {
	const [l, a] = e.propsOptions;
	let r, i = !1;
	if (t)
		for (let s in t) {
			if ($(s)) continue;
			const u = t[s];
			let c;
			l && E(l, c = j(s)) ? a && a.includes(c) ? (r || (r = {}))[c] = u : n[c] = u : Zt(e.emitsOptions, s) || s in o && u === o[s] || (o[s] = u, i = !0)
		}
	if (a) {
		const t = pt(n),
			o = r || m;
		for (let r = 0; r < a.length; r++) {
			const i = a[r];
			n[i] = wo(l, t, i, o[i], e, !E(o, i))
		}
	}
	return i
}

function wo(e, t, n, o, l, a) {
	const r = e[n];
	if (null != r) {
		const e = E(r, "default");
		if (e && void 0 === o) {
			const e = r.default;
			if (r.type !== Function && R(e)) {
				const {
					propsDefaults: a
				} = l;
				n in a ? o = a[n] : (xl(l), o = a[n] = e.call(null, t), Cl())
			} else o = e
		}
		r[0] && (a && !e ? o = !1 : !r[1] || "" !== o && o !== U(n) || (o = !0))
	}
	return o
}

function ko(e, t, n = !1) {
	const o = t.propsCache,
		l = o.get(e);
	if (l) return l;
	const a = e.props,
		r = {},
		i = [];
	let s = !1;
	if (!R(e)) {
		const o = e => {
			s = !0;
			const [n, o] = ko(e, t, !0);
			S(r, n), o && i.push(...o)
		};
		!n && t.mixins.length && t.mixins.forEach(o), e.extends && o(e.extends), e.mixins && e.mixins.forEach(o)
	}
	if (!a && !s) return P(e) && o.set(e, g), g;
	if (q(a))
		for (let c = 0; c < a.length; c++) {
			const e = j(a[c]);
			So(e) && (r[e] = m)
		} else if (a)
			for (const c in a) {
				const e = j(c);
				if (So(e)) {
					const t = a[c],
						n = r[e] = q(t) || R(t) ? {
							type: t
						} : Object.assign({}, t);
					if (n) {
						const t = Eo(Boolean, n.type),
							o = Eo(String, n.type);
						n[0] = t > -1, n[1] = o < 0 || t < o, (t > -1 || E(n, "default")) && i.push(e)
					}
				}
			}
	const u = [r, i];
	return P(e) && o.set(e, u), u
}

function So(e) {
	return "$" !== e[0]
}

function xo(e) {
	const t = e && e.toString().match(/^\s*function (\w+)/);
	return t ? t[1] : null === e ? "null" : ""
}

function Co(e, t) {
	return xo(e) === xo(t)
}

function Eo(e, t) {
	return q(t) ? t.findIndex((t => Co(t, e))) : R(t) && Co(t, e) ? 0 : -1
}
const qo = e => "_" === e[0] || "$stable" === e,
	Lo = e => q(e) ? e.map(hl) : [hl(e)],
	Fo = (e, t, n) => {
		if (t._n) return t;
		const o = nn(((...e) => Lo(t(...e))), n);
		return o._c = !1, o
	},
	Ro = (e, t, n) => {
		const o = e._ctx;
		for (const l in e) {
			if (qo(l)) continue;
			const n = e[l];
			if (R(n)) t[l] = Fo(0, n, o);
			else if (null != n) {
				const e = Lo(n);
				t[l] = () => e
			}
		}
	},
	Oo = (e, t) => {
		const n = Lo(t);
		e.slots.default = () => n
	};

function To() {
	return {
		app: null,
		config: {
			isNativeTag: y,
			performance: !1,
			globalProperties: {},
			optionMergeStrategies: {},
			errorHandler: void 0,
			warnHandler: void 0,
			compilerOptions: {}
		},
		mixins: [],
		components: {},
		directives: {},
		provides: Object.create(null),
		optionsCache: new WeakMap,
		propsCache: new WeakMap,
		emitsCache: new WeakMap
	}
}
let Po = 0;

function Ao(e, t) {
	return function(n, o = null) {
		R(n) || (n = Object.assign({}, n)), null == o || P(o) || (o = null);
		const l = To(),
			a = new Set;
		let r = !1;
		const i = l.app = {
			_uid: Po++,
			_component: n,
			_props: o,
			_container: null,
			_context: l,
			_instance: null,
			version: Vl,
			get config() {
				return l.config
			},
			set config(e) {},
			use: (e, ...t) => (a.has(e) || (e && R(e.install) ? (a.add(e), e.install(i, ...t)) : R(e) && (a.add(e), e(i, ...t))), i),
			mixin: e => (l.mixins.includes(e) || l.mixins.push(e), i),
			component: (e, t) => t ? (l.components[e] = t, i) : l.components[e],
			directive: (e, t) => t ? (l.directives[e] = t, i) : l.directives[e],
			mount(a, s, u) {
				if (!r) {
					const c = dl(n, o);
					return c.appContext = l, s && t ? t(c, a) : e(c, a, u), r = !0, i._container = a, a.__vue_app__ = i, Rl(c.component) || c.component.proxy
				}
			},
			unmount() {
				r && (e(null, i._container), delete i._container.__vue_app__)
			},
			provide: (e, t) => (l.provides[e] = t, i)
		};
		return i
	}
}

function Vo(e, t, n, o, l = !1) {
	if (q(e)) return void e.forEach(((e, a) => Vo(e, t && (q(t) ? t[a] : t), n, o, l)));
	if (On(o) && !l) return;
	const a = 4 & o.shapeFlag ? Rl(o.component) || o.component.proxy : o.el,
		r = l ? null : a,
		{
			i: i,
			r: s
		} = e,
		u = t && t.r,
		c = i.refs === m ? i.refs = {} : i.refs,
		d = i.setupState;
	if (null != u && u !== s && (O(u) ? (c[u] = null, E(d, u) && (d[u] = null)) : bt(u) && (u.value = null)), R(s)) qt(s, i, 12, [r, c]);
	else {
		const t = O(s),
			o = bt(s);
		if (t || o) {
			const i = () => {
				if (e.f) {
					const n = t ? E(d, s) ? d[s] : c[s] : s.value;
					l ? q(n) && x(n, a) : q(n) ? n.includes(a) || n.push(a) : t ? (c[s] = [a], E(d, s) && (d[s] = c[s])) : (s.value = [a], e.k && (c[e.k] = s.value))
				} else t ? (c[s] = r, E(d, s) && (d[s] = r)) : o && (s.value = r, e.k && (c[e.k] = r))
			};
			r ? (i.id = -1, Mo(i, n)) : i()
		}
	}
}
const Mo = function(e, t) {
	t && t.pendingBranch ? q(e) ? t.effects.push(...e) : t.effects.push(e) : jt(e)
};

function Bo(e) {
	return function(e, t) {
		(J || (J = "undefined" != typeof globalThis ? globalThis : "undefined" != typeof self ? self : "undefined" != typeof window ? window : "undefined" != typeof global ? global : {})).__VUE__ = !0;
		const {
			insert: n,
			remove: o,
			patchProp: l,
			createElement: a,
			createText: r,
			createComment: i,
			setText: s,
			setElementText: u,
			parentNode: c,
			nextSibling: d,
			setScopeId: p = b,
			insertStaticContent: f
		} = e, v = (e, t, n, o = null, l = null, a = null, r = !1, i = null, s = !!t.dynamicChildren) => {
			if (e === t) return;
			e && !rl(e, t) && (o = te(e), W(e, l, a, !0), e = null), -2 === t.patchFlag && (s = !1, t.dynamicChildren = null);
			const {
				type: u,
				ref: c,
				shapeFlag: d
			} = t;
			switch (u) {
				case Ko:
					h(e, t, n, o);
					break;
				case Qo:
					y(e, t, n, o);
					break;
				case Go:
					null == e && _(t, n, o, r);
					break;
				case Wo:
					T(e, t, n, o, l, a, r, i, s);
					break;
				default:
					1 & d ? x(e, t, n, o, l, a, r, i, s) : 6 & d ? P(e, t, n, o, l, a, r, i, s) : (64 & d || 128 & d) && u.process(e, t, n, o, l, a, r, i, s, oe)
			}
			null != c && l && Vo(c, e && e.ref, a, t || e, !t)
		}, h = (e, t, o, l) => {
			if (null == e) n(t.el = r(t.children), o, l);
			else {
				const n = t.el = e.el;
				t.children !== e.children && s(n, t.children)
			}
		}, y = (e, t, o, l) => {
			null == e ? n(t.el = i(t.children || ""), o, l) : t.el = e.el
		}, _ = (e, t, n, o) => {
			[e.el, e.anchor] = f(e.children, t, n, o, e.el, e.anchor)
		}, w = ({
			el: e,
			anchor: t
		}, o, l) => {
			let a;
			for (; e && e !== t;) a = d(e), n(e, o, l), e = a;
			n(t, o, l)
		}, k = ({
			el: e,
			anchor: t
		}) => {
			let n;
			for (; e && e !== t;) n = d(e), o(e), e = n;
			o(t)
		}, x = (e, t, n, o, l, a, r, i, s) => {
			r = r || "svg" === t.type, null == e ? C(t, n, o, l, a, r, i, s) : F(e, t, l, a, r, i, s)
		}, C = (e, t, o, r, i, s, c, d) => {
			let p, f;
			const {
				type: v,
				props: h,
				shapeFlag: m,
				transition: g,
				dirs: b
			} = e;
			if (p = e.el = a(e.type, s, h && h.is, h), 8 & m ? u(p, e.children) : 16 & m && L(e.children, p, null, r, i, s && "foreignObject" !== v, c, d), b && Zn(e, null, r, "created"), h) {
				for (const t in h) "value" === t || $(t) || l(p, t, null, h[t], s, e.children, r, i, ee);
				"value" in h && l(p, "value", null, h.value), (f = h.onVnodeBeforeMount) && yl(f, r, e)
			}
			q(p, e, e.scopeId, c, r), b && Zn(e, null, r, "beforeMount");
			const y = (!i || i && !i.pendingBranch) && g && !g.persisted;
			y && g.beforeEnter(p), n(p, t, o), ((f = h && h.onVnodeMounted) || y || b) && Mo((() => {
				f && yl(f, r, e), y && g.enter(p), b && Zn(e, null, r, "mounted")
			}), i)
		}, q = (e, t, n, o, l) => {
			if (n && p(e, n), o)
				for (let a = 0; a < o.length; a++) p(e, o[a]);
			if (l) {
				if (t === l.subTree) {
					const t = l.vnode;
					q(e, t, t.scopeId, t.slotScopeIds, l.parent)
				}
			}
		}, L = (e, t, n, o, l, a, r, i, s = 0) => {
			for (let u = s; u < e.length; u++) {
				const s = e[u] = i ? ml(e[u]) : hl(e[u]);
				v(null, s, t, n, o, l, a, r, i)
			}
		}, F = (e, t, n, o, a, r, i) => {
			const s = t.el = e.el;
			let {
				patchFlag: c,
				dynamicChildren: d,
				dirs: p
			} = t;
			c |= 16 & e.patchFlag;
			const f = e.props || m,
				v = t.props || m;
			let h;
			n && Io(n, !1), (h = v.onVnodeBeforeUpdate) && yl(h, n, t, e), p && Zn(t, e, n, "beforeUpdate"), n && Io(n, !0);
			const g = a && "foreignObject" !== t.type;
			if (d ? R(e.dynamicChildren, d, s, n, o, g, r) : i || z(e, t, s, null, n, o, g, r, !1), c > 0) {
				if (16 & c) O(s, t, f, v, n, o, a);
				else if (2 & c && f.class !== v.class && l(s, "class", null, v.class, a), 4 & c && l(s, "style", f.style, v.style, a), 8 & c) {
					const r = t.dynamicProps;
					for (let t = 0; t < r.length; t++) {
						const i = r[t],
							u = f[i],
							c = v[i];
						c === u && "value" !== i || l(s, i, u, c, a, e.children, n, o, ee)
					}
				}
				1 & c && e.children !== t.children && u(s, t.children)
			} else i || null != d || O(s, t, f, v, n, o, a);
			((h = v.onVnodeUpdated) || p) && Mo((() => {
				h && yl(h, n, t, e), p && Zn(t, e, n, "updated")
			}), o)
		}, R = (e, t, n, o, l, a, r) => {
			for (let i = 0; i < t.length; i++) {
				const s = e[i],
					u = t[i],
					d = s.el && (s.type === Wo || !rl(s, u) || 70 & s.shapeFlag) ? c(s.el) : n;
				v(s, u, d, null, o, l, a, r, !0)
			}
		}, O = (e, t, n, o, a, r, i) => {
			if (n !== o) {
				if (n !== m)
					for (const s in n) $(s) || s in o || l(e, s, n[s], null, i, t.children, a, r, ee);
				for (const s in o) {
					if ($(s)) continue;
					const u = o[s],
						c = n[s];
					u !== c && "value" !== s && l(e, s, c, u, i, t.children, a, r, ee)
				}
				"value" in o && l(e, "value", n.value, o.value)
			}
		}, T = (e, t, o, l, a, i, s, u, c) => {
			const d = t.el = e ? e.el : r(""),
				p = t.anchor = e ? e.anchor : r("");
			let {
				patchFlag: f,
				dynamicChildren: v,
				slotScopeIds: h
			} = t;
			h && (u = u ? u.concat(h) : h), null == e ? (n(d, o, l), n(p, o, l), L(t.children, o, p, a, i, s, u, c)) : f > 0 && 64 & f && v && e.dynamicChildren ? (R(e.dynamicChildren, v, o, a, i, s, u), (null != t.key || a && t === a.subTree) && $o(e, t, !0)) : z(e, t, o, p, a, i, s, u, c)
		}, P = (e, t, n, o, l, a, r, i, s) => {
			t.slotScopeIds = i, null == e ? 512 & t.shapeFlag ? l.ctx.activate(t, n, o, r, s) : V(t, n, o, l, a, r, s) : M(e, t, s)
		}, V = (e, t, n, o, l, a, r) => {
			const i = e.component = function(e, t, n) {
				const o = e.type,
					l = (t ? t.appContext : e.appContext) || _l,
					a = {
						uid: wl++,
						vnode: e,
						type: o,
						parent: t,
						appContext: l,
						root: null,
						next: null,
						subTree: null,
						effect: null,
						update: null,
						scope: new Y(!0),
						render: null,
						proxy: null,
						exposed: null,
						exposeProxy: null,
						withProxy: null,
						provides: t ? t.provides : Object.create(l.provides),
						accessCache: null,
						renderCache: [],
						components: null,
						directives: null,
						propsOptions: ko(o, l),
						emitsOptions: Gt(o, l),
						emit: null,
						emitted: null,
						propsDefaults: m,
						inheritAttrs: o.inheritAttrs,
						ctx: m,
						data: m,
						props: m,
						attrs: m,
						slots: m,
						refs: m,
						setupState: m,
						setupContext: null,
						suspense: n,
						suspenseId: n ? n.pendingId : 0,
						asyncDep: null,
						asyncResolved: !1,
						isMounted: !1,
						isUnmounted: !1,
						isDeactivated: !1,
						bc: null,
						c: null,
						bm: null,
						m: null,
						bu: null,
						u: null,
						um: null,
						bum: null,
						da: null,
						a: null,
						rtg: null,
						rtc: null,
						ec: null,
						sp: null
					};
				a.ctx = {
					_: a
				}, a.root = t ? t.root : a, a.emit = Qt.bind(null, a), e.ce && e.ce(a);
				return a
			}(e, o, l);
			if (Tn(e) && (i.ctx.renderer = oe), function(e, t = !1) {
					ql = t;
					const {
						props: n,
						children: o
					} = e.vnode, l = El(e);
					yo(e, n, l, t), ((e, t) => {
						if (32 & e.vnode.shapeFlag) {
							const n = t._;
							n ? (e.slots = pt(t), G(t, "_", n)) : Ro(t, e.slots = {})
						} else e.slots = {}, t && Oo(e, t);
						G(e.slots, il, 1)
					})(e, o);
					const a = l ? function(e, t) {
						const n = e.type;
						e.accessCache = Object.create(null), e.proxy = ft(new Proxy(e.ctx, ro));
						const {
							setup: o
						} = n;
						if (o) {
							const n = e.setupContext = o.length > 1 ? function(e) {
								const t = t => {
									e.exposed = t || {}
								};
								let n;
								return {
									get attrs() {
										return n || (n = function(e) {
											return new Proxy(e.attrs, {
												get: (t, n) => (me(e, 0, "$attrs"), t[n])
											})
										}(e))
									},
									slots: e.slots,
									emit: e.emit,
									expose: t
								}
							}(e) : null;
							xl(e), ve();
							const l = qt(o, e, 0, [e.props, n]);
							if (he(), Cl(), A(l)) {
								if (l.then(Cl, Cl), t) return l.then((n => {
									Ll(e, n, t)
								})).catch((t => {
									Ft(t, e, 0)
								}));
								e.asyncDep = l
							} else Ll(e, l, t)
						} else Fl(e, t)
					}(e, t) : void 0;
					ql = !1
				}(i), i.asyncDep) {
				if (l && l.registerDep(i, B), !e.el) {
					const e = i.subTree = dl(Qo);
					y(null, e, t, n)
				}
			} else B(i, e, t, n, l, a, r)
		}, M = (e, t, n) => {
			const o = t.component = e.component;
			if (function(e, t, n) {
					const {
						props: o,
						children: l,
						component: a
					} = e, {
						props: r,
						children: i,
						patchFlag: s
					} = t, u = a.emitsOptions;
					if (t.dirs || t.transition) return !0;
					if (!(n && s >= 0)) return !(!l && !i || i && i.$stable) || o !== r && (o ? !r || rn(o, r, u) : !!r);
					if (1024 & s) return !0;
					if (16 & s) return o ? rn(o, r, u) : !!r;
					if (8 & s) {
						const e = t.dynamicProps;
						for (let t = 0; t < e.length; t++) {
							const n = e[t];
							if (r[n] !== o[n] && !Zt(u, n)) return !0
						}
					}
					return !1
				}(e, t, n)) {
				if (o.asyncDep && !o.asyncResolved) return void I(o, t, n);
				o.next = t,
					function(e) {
						const t = Tt.indexOf(e);
						t > Pt && Tt.splice(t, 1)
					}(o.update), o.update()
			} else t.el = e.el, o.vnode = t
		}, B = (e, t, n, o, l, a, r) => {
			const i = () => {
					if (e.isMounted) {
						let t, {
								next: n,
								bu: o,
								u: i,
								parent: s,
								vnode: u
							} = e,
							d = n;
						Io(e, !1), n ? (n.el = u.el, I(e, n, r)) : n = u, o && Q(o), (t = n.props && n.props.onVnodeBeforeUpdate) && yl(t, s, n, u), Io(e, !0);
						const p = on(e),
							f = e.subTree;
						e.subTree = p, v(f, p, c(f.el), te(f), e, l, a), n.el = p.el, null === d && sn(e, p.el), i && Mo(i, l), (t = n.props && n.props.onVnodeUpdated) && Mo((() => yl(t, s, n, u)), l)
					} else {
						let r;
						const {
							el: i,
							props: s
						} = t, {
							bm: u,
							m: c,
							parent: d
						} = e, p = On(t);
						if (Io(e, !1), u && Q(u), !p && (r = s && s.onVnodeBeforeMount) && yl(r, d, t), Io(e, !0), i && ae) {
							const n = () => {
								e.subTree = on(e), ae(i, e.subTree, e, l, null)
							};
							p ? t.type.__asyncLoader().then((() => !e.isUnmounted && n())) : n()
						} else {
							const r = e.subTree = on(e);
							v(null, r, n, o, e, l, a), t.el = r.el
						}
						if (c && Mo(c, l), !p && (r = s && s.onVnodeMounted)) {
							const e = t;
							Mo((() => yl(r, d, e)), l)
						}(256 & t.shapeFlag || d && On(d.vnode) && 256 & d.vnode.shapeFlag) && e.a && Mo(e.a, l), e.isMounted = !0, t = n = o = null
					}
				},
				s = e.effect = new ce(i, (() => zt(u)), e.scope),
				u = e.update = () => s.run();
			u.id = e.uid, Io(e, !0), u()
		}, I = (e, t, n) => {
			t.component = e;
			const o = e.vnode.props;
			e.vnode = t, e.next = null,
				function(e, t, n, o) {
					const {
						props: l,
						attrs: a,
						vnode: {
							patchFlag: r
						}
					} = e, i = pt(l), [s] = e.propsOptions;
					let u = !1;
					if (!(o || r > 0) || 16 & r) {
						let o;
						_o(e, t, l, a) && (u = !0);
						for (const a in i) t && (E(t, a) || (o = U(a)) !== a && E(t, o)) || (s ? !n || void 0 === n[a] && void 0 === n[o] || (l[a] = wo(s, i, a, void 0, e, !0)) : delete l[a]);
						if (a !== i)
							for (const e in a) t && E(t, e) || (delete a[e], u = !0)
					} else if (8 & r) {
						const n = e.vnode.dynamicProps;
						for (let o = 0; o < n.length; o++) {
							let r = n[o];
							if (Zt(e.emitsOptions, r)) continue;
							const c = t[r];
							if (s)
								if (E(a, r)) c !== a[r] && (a[r] = c, u = !0);
								else {
									const t = j(r);
									l[t] = wo(s, i, t, c, e, !1)
								}
							else c !== a[r] && (a[r] = c, u = !0)
						}
					}
					u && be(e, "set", "$attrs")
				}(e, t.props, o, n), ((e, t, n) => {
					const {
						vnode: o,
						slots: l
					} = e;
					let a = !0,
						r = m;
					if (32 & o.shapeFlag) {
						const e = t._;
						e ? n && 1 === e ? a = !1 : (S(l, t), n || 1 !== e || delete l._) : (a = !t.$stable, Ro(t, l)), r = t
					} else t && (Oo(e, t), r = {
						default: 1
					});
					if (a)
						for (const i in l) qo(i) || i in r || delete l[i]
				})(e, t.children, n), ve(), Dt(), he()
		}, z = (e, t, n, o, l, a, r, i, s = !1) => {
			const c = e && e.children,
				d = e ? e.shapeFlag : 0,
				p = t.children,
				{
					patchFlag: f,
					shapeFlag: v
				} = t;
			if (f > 0) {
				if (128 & f) return void D(c, p, n, o, l, a, r, i, s);
				if (256 & f) return void N(c, p, n, o, l, a, r, i, s)
			}
			8 & v ? (16 & d && ee(c, l, a), p !== c && u(n, p)) : 16 & d ? 16 & v ? D(c, p, n, o, l, a, r, i, s) : ee(c, l, a, !0) : (8 & d && u(n, ""), 16 & v && L(p, n, o, l, a, r, i, s))
		}, N = (e, t, n, o, l, a, r, i, s) => {
			t = t || g;
			const u = (e = e || g).length,
				c = t.length,
				d = Math.min(u, c);
			let p;
			for (p = 0; p < d; p++) {
				const o = t[p] = s ? ml(t[p]) : hl(t[p]);
				v(e[p], o, n, null, l, a, r, i, s)
			}
			u > c ? ee(e, l, a, !0, !1, d) : L(t, n, o, l, a, r, i, s, d)
		}, D = (e, t, n, o, l, a, r, i, s) => {
			let u = 0;
			const c = t.length;
			let d = e.length - 1,
				p = c - 1;
			for (; u <= d && u <= p;) {
				const o = e[u],
					c = t[u] = s ? ml(t[u]) : hl(t[u]);
				if (!rl(o, c)) break;
				v(o, c, n, null, l, a, r, i, s), u++
			}
			for (; u <= d && u <= p;) {
				const o = e[d],
					u = t[p] = s ? ml(t[p]) : hl(t[p]);
				if (!rl(o, u)) break;
				v(o, u, n, null, l, a, r, i, s), d--, p--
			}
			if (u > d) {
				if (u <= p) {
					const e = p + 1,
						d = e < c ? t[e].el : o;
					for (; u <= p;) v(null, t[u] = s ? ml(t[u]) : hl(t[u]), n, d, l, a, r, i, s), u++
				}
			} else if (u > p)
				for (; u <= d;) W(e[u], l, a, !0), u++;
			else {
				const f = u,
					h = u,
					m = new Map;
				for (u = h; u <= p; u++) {
					const e = t[u] = s ? ml(t[u]) : hl(t[u]);
					null != e.key && m.set(e.key, u)
				}
				let b, y = 0;
				const _ = p - h + 1;
				let w = !1,
					k = 0;
				const S = new Array(_);
				for (u = 0; u < _; u++) S[u] = 0;
				for (u = f; u <= d; u++) {
					const o = e[u];
					if (y >= _) {
						W(o, l, a, !0);
						continue
					}
					let c;
					if (null != o.key) c = m.get(o.key);
					else
						for (b = h; b <= p; b++)
							if (0 === S[b - h] && rl(o, t[b])) {
								c = b;
								break
							} void 0 === c ? W(o, l, a, !0) : (S[c - h] = u + 1, c >= k ? k = c : w = !0, v(o, t[c], n, null, l, a, r, i, s), y++)
				}
				const x = w ? function(e) {
					const t = e.slice(),
						n = [0];
					let o, l, a, r, i;
					const s = e.length;
					for (o = 0; o < s; o++) {
						const s = e[o];
						if (0 !== s) {
							if (l = n[n.length - 1], e[l] < s) {
								t[o] = l, n.push(o);
								continue
							}
							for (a = 0, r = n.length - 1; a < r;) i = a + r >> 1, e[n[i]] < s ? a = i + 1 : r = i;
							s < e[n[a]] && (a > 0 && (t[o] = n[a - 1]), n[a] = o)
						}
					}
					a = n.length, r = n[a - 1];
					for (; a-- > 0;) n[a] = r, r = t[r];
					return n
				}(S) : g;
				for (b = x.length - 1, u = _ - 1; u >= 0; u--) {
					const e = h + u,
						d = t[e],
						p = e + 1 < c ? t[e + 1].el : o;
					0 === S[u] ? v(null, d, n, p, l, a, r, i, s) : w && (b < 0 || u !== x[b] ? H(d, n, p, 2) : b--)
				}
			}
		}, H = (e, t, o, l, a = null) => {
			const {
				el: r,
				type: i,
				transition: s,
				children: u,
				shapeFlag: c
			} = e;
			if (6 & c) return void H(e.component.subTree, t, o, l);
			if (128 & c) return void e.suspense.move(t, o, l);
			if (64 & c) return void i.move(e, t, o, oe);
			if (i === Wo) {
				n(r, t, o);
				for (let e = 0; e < u.length; e++) H(u[e], t, o, l);
				return void n(e.anchor, t, o)
			}
			if (i === Go) return void w(e, t, o);
			if (2 !== l && 1 & c && s)
				if (0 === l) s.beforeEnter(r), n(r, t, o), Mo((() => s.enter(r)), a);
				else {
					const {
						leave: e,
						delayLeave: l,
						afterLeave: a
					} = s, i = () => n(r, t, o), u = () => {
						e(r, (() => {
							i(), a && a()
						}))
					};
					l ? l(r, i, u) : u()
				}
			else n(r, t, o)
		}, W = (e, t, n, o = !1, l = !1) => {
			const {
				type: a,
				props: r,
				ref: i,
				children: s,
				dynamicChildren: u,
				shapeFlag: c,
				patchFlag: d,
				dirs: p
			} = e;
			if (null != i && Vo(i, null, n, e, !0), 256 & c) return void t.ctx.deactivate(e);
			const f = 1 & c && p,
				v = !On(e);
			let h;
			if (v && (h = r && r.onVnodeBeforeUnmount) && yl(h, t, e), 6 & c) X(e.component, n, o);
			else {
				if (128 & c) return void e.suspense.unmount(n, o);
				f && Zn(e, null, t, "beforeUnmount"), 64 & c ? e.type.remove(e, t, n, l, oe, o) : u && (a !== Wo || d > 0 && 64 & d) ? ee(u, t, n, !1, !0) : (a === Wo && 384 & d || !l && 16 & c) && ee(s, t, n), o && K(e)
			}(v && (h = r && r.onVnodeUnmounted) || f) && Mo((() => {
				h && yl(h, t, e), f && Zn(e, null, t, "unmounted")
			}), n)
		}, K = e => {
			const {
				type: t,
				el: n,
				anchor: l,
				transition: a
			} = e;
			if (t === Wo) return void Z(n, l);
			if (t === Go) return void k(e);
			const r = () => {
				o(n), a && !a.persisted && a.afterLeave && a.afterLeave()
			};
			if (1 & e.shapeFlag && a && !a.persisted) {
				const {
					leave: t,
					delayLeave: o
				} = a, l = () => t(n, r);
				o ? o(e.el, r, l) : l()
			} else r()
		}, Z = (e, t) => {
			let n;
			for (; e !== t;) n = d(e), o(e), e = n;
			o(t)
		}, X = (e, t, n) => {
			const {
				bum: o,
				scope: l,
				update: a,
				subTree: r,
				um: i
			} = e;
			o && Q(o), l.stop(), a && (a.active = !1, W(r, e, t, n)), i && Mo(i, t), Mo((() => {
				e.isUnmounted = !0
			}), t), t && t.pendingBranch && !t.isUnmounted && e.asyncDep && !e.asyncResolved && e.suspenseId === t.pendingId && (t.deps--, 0 === t.deps && t.resolve())
		}, ee = (e, t, n, o = !1, l = !1, a = 0) => {
			for (let r = a; r < e.length; r++) W(e[r], t, n, o, l)
		}, te = e => 6 & e.shapeFlag ? te(e.component.subTree) : 128 & e.shapeFlag ? e.suspense.next() : d(e.anchor || e.el), ne = (e, t, n) => {
			null == e ? t._vnode && W(t._vnode, null, null, !0) : v(t._vnode || null, e, t, null, null, null, n), Dt(), Ut(), t._vnode = e
		}, oe = {
			p: v,
			um: W,
			m: H,
			r: K,
			mt: V,
			mc: L,
			pc: z,
			pbc: R,
			n: te,
			o: e
		};
		let le, ae;
		t && ([le, ae] = t(oe));
		return {
			render: ne,
			hydrate: le,
			createApp: Ao(ne, le)
		}
	}(e)
}

function Io({
	effect: e,
	update: t
}, n) {
	e.allowRecurse = t.allowRecurse = n
}

function $o(e, t, n = !1) {
	const o = e.children,
		l = t.children;
	if (q(o) && q(l))
		for (let a = 0; a < o.length; a++) {
			const e = o[a];
			let t = l[a];
			1 & t.shapeFlag && !t.dynamicChildren && ((t.patchFlag <= 0 || 32 === t.patchFlag) && (t = l[a] = ml(l[a]), t.el = e.el), n || $o(e, t)), t.type === Ko && (t.el = e.el)
		}
}
const zo = e => e && (e.disabled || "" === e.disabled),
	No = e => "undefined" != typeof SVGElement && e instanceof SVGElement,
	jo = (e, t) => {
		const n = e && e.to;
		if (O(n)) {
			if (t) {
				return t(n)
			}
			return null
		}
		return n
	};

function Do(e, t, n, {
	o: {
		insert: o
	},
	m: l
}, a = 2) {
	0 === a && o(e.targetAnchor, t, n);
	const {
		el: r,
		anchor: i,
		shapeFlag: s,
		children: u,
		props: c
	} = e, d = 2 === a;
	if (d && o(r, t, n), (!d || zo(c)) && 16 & s)
		for (let p = 0; p < u.length; p++) l(u[p], t, n, 2);
	d && o(i, t, n)
}
const Uo = {
	__isTeleport: !0,
	process(e, t, n, o, l, a, r, i, s, u) {
		const {
			mc: c,
			pc: d,
			pbc: p,
			o: {
				insert: f,
				querySelector: v,
				createText: h,
				createComment: m
			}
		} = u, g = zo(t.props);
		let {
			shapeFlag: b,
			children: y,
			dynamicChildren: _
		} = t;
		if (null == e) {
			const e = t.el = h(""),
				u = t.anchor = h("");
			f(e, n, o), f(u, n, o);
			const d = t.target = jo(t.props, v),
				p = t.targetAnchor = h("");
			d && (f(p, d), r = r || No(d));
			const m = (e, t) => {
				16 & b && c(y, e, t, l, a, r, i, s)
			};
			g ? m(n, u) : d && m(d, p)
		} else {
			t.el = e.el;
			const o = t.anchor = e.anchor,
				c = t.target = e.target,
				f = t.targetAnchor = e.targetAnchor,
				h = zo(e.props),
				m = h ? n : c,
				b = h ? o : f;
			if (r = r || No(c), _ ? (p(e.dynamicChildren, _, m, l, a, r, i), $o(e, t, !0)) : s || d(e, t, m, b, l, a, r, i, !1), g) h || Do(t, n, o, u, 1);
			else if ((t.props && t.props.to) !== (e.props && e.props.to)) {
				const e = t.target = jo(t.props, v);
				e && Do(t, e, null, u, 0)
			} else h && Do(t, c, f, u, 1)
		}
		Ho(t)
	},
	remove(e, t, n, o, {
		um: l,
		o: {
			remove: a
		}
	}, r) {
		const {
			shapeFlag: i,
			children: s,
			anchor: u,
			targetAnchor: c,
			target: d,
			props: p
		} = e;
		if (d && a(c), (r || !zo(p)) && (a(u), 16 & i))
			for (let f = 0; f < s.length; f++) {
				const e = s[f];
				l(e, t, n, !0, !!e.dynamicChildren)
			}
	},
	move: Do,
	hydrate: function(e, t, n, o, l, a, {
		o: {
			nextSibling: r,
			parentNode: i,
			querySelector: s
		}
	}, u) {
		const c = t.target = jo(t.props, s);
		if (c) {
			const s = c._lpa || c.firstChild;
			if (16 & t.shapeFlag)
				if (zo(t.props)) t.anchor = u(r(e), t, i(e), n, o, l, a), t.targetAnchor = s;
				else {
					t.anchor = r(e);
					let i = s;
					for (; i;)
						if (i = r(i), i && 8 === i.nodeType && "teleport anchor" === i.data) {
							t.targetAnchor = i, c._lpa = t.targetAnchor && r(t.targetAnchor);
							break
						} u(s, t, c, n, o, l, a)
				} Ho(t)
		}
		return t.anchor && r(t.anchor)
	}
};

function Ho(e) {
	const t = e.ctx;
	if (t && t.ut) {
		let n = e.children[0].el;
		for (; n !== e.targetAnchor;) 1 === n.nodeType && n.setAttribute("data-v-owner", t.uid), n = n.nextSibling;
		t.ut()
	}
}
const Wo = Symbol(void 0),
	Ko = Symbol(void 0),
	Qo = Symbol(void 0),
	Go = Symbol(void 0),
	Zo = [];
let Jo = null;

function Xo(e = !1) {
	Zo.push(Jo = e ? null : [])
}

function Yo() {
	Zo.pop(), Jo = Zo[Zo.length - 1] || null
}
let el = 1;

function tl(e) {
	el += e
}

function nl(e) {
	return e.dynamicChildren = el > 0 ? Jo || g : null, Yo(), el > 0 && Jo && Jo.push(e), e
}

function ol(e, t, n, o, l, a) {
	return nl(cl(e, t, n, o, l, a, !0))
}

function ll(e, t, n, o, l) {
	return nl(dl(e, t, n, o, l, !0))
}

function al(e) {
	return !!e && !0 === e.__v_isVNode
}

function rl(e, t) {
	return e.type === t.type && e.key === t.key
}
const il = "__vInternal",
	sl = ({
		key: e
	}) => null != e ? e : null,
	ul = ({
		ref: e,
		ref_key: t,
		ref_for: n
	}) => null != e ? O(e) || bt(e) || R(e) ? {
		i: Jt,
		r: e,
		k: t,
		f: !!n
	} : e : null;

function cl(e, t = null, n = null, o = 0, l = null, a = (e === Wo ? 0 : 1), r = !1, i = !1) {
	const s = {
		__v_isVNode: !0,
		__v_skip: !0,
		type: e,
		props: t,
		key: t && sl(t),
		ref: t && ul(t),
		scopeId: Xt,
		slotScopeIds: null,
		children: n,
		component: null,
		suspense: null,
		ssContent: null,
		ssFallback: null,
		dirs: null,
		transition: null,
		el: null,
		anchor: null,
		target: null,
		targetAnchor: null,
		staticCount: 0,
		shapeFlag: a,
		patchFlag: o,
		dynamicProps: l,
		dynamicChildren: null,
		appContext: null,
		ctx: Jt
	};
	return i ? (gl(s, n), 128 & a && e.normalize(s)) : n && (s.shapeFlag |= O(n) ? 8 : 16), el > 0 && !r && Jo && (s.patchFlag > 0 || 6 & a) && 32 !== s.patchFlag && Jo.push(s), s
}
const dl = function(e, t = null, n = null, o = 0, l = null, a = !1) {
	e && e !== Xn || (e = Qo);
	if (al(e)) {
		const o = pl(e, t, !0);
		return n && gl(o, n), el > 0 && !a && Jo && (6 & o.shapeFlag ? Jo[Jo.indexOf(e)] = o : Jo.push(o)), o.patchFlag |= -2, o
	}
	i = e, R(i) && "__vccOpts" in i && (e = e.__vccOpts);
	var i;
	if (t) {
		t = function(e) {
			return e ? dt(e) || il in e ? S({}, e) : e : null
		}(t);
		let {
			class: e,
			style: n
		} = t;
		e && !O(e) && (t.class = d(e)), P(n) && (dt(n) && !q(n) && (n = S({}, n)), t.style = r(n))
	}
	const s = O(e) ? 1 : (e => e.__isSuspense)(e) ? 128 : (e => e.__isTeleport)(e) ? 64 : P(e) ? 4 : R(e) ? 2 : 0;
	return cl(e, t, n, o, l, s, a, !0)
};

function pl(e, t, n = !1) {
	const {
		props: o,
		ref: l,
		patchFlag: a,
		children: r
	} = e, i = t ? bl(o || {}, t) : o;
	return {
		__v_isVNode: !0,
		__v_skip: !0,
		type: e.type,
		props: i,
		key: i && sl(i),
		ref: t && t.ref ? n && l ? q(l) ? l.concat(ul(t)) : [l, ul(t)] : ul(t) : l,
		scopeId: e.scopeId,
		slotScopeIds: e.slotScopeIds,
		children: r,
		target: e.target,
		targetAnchor: e.targetAnchor,
		staticCount: e.staticCount,
		shapeFlag: e.shapeFlag,
		patchFlag: t && e.type !== Wo ? -1 === a ? 16 : 16 | a : a,
		dynamicProps: e.dynamicProps,
		dynamicChildren: e.dynamicChildren,
		appContext: e.appContext,
		dirs: e.dirs,
		transition: e.transition,
		component: e.component,
		suspense: e.suspense,
		ssContent: e.ssContent && pl(e.ssContent),
		ssFallback: e.ssFallback && pl(e.ssFallback),
		el: e.el,
		anchor: e.anchor,
		ctx: e.ctx
	}
}

function fl(e = " ", t = 0) {
	return dl(Ko, null, e, t)
}

function vl(e = "", t = !1) {
	return t ? (Xo(), ll(Qo, null, e)) : dl(Qo, null, e)
}

function hl(e) {
	return null == e || "boolean" == typeof e ? dl(Qo) : q(e) ? dl(Wo, null, e.slice()) : "object" == typeof e ? ml(e) : dl(Ko, null, String(e))
}

function ml(e) {
	return null === e.el && -1 !== e.patchFlag || e.memo ? e : pl(e)
}

function gl(e, t) {
	let n = 0;
	const {
		shapeFlag: o
	} = e;
	if (null == t) t = null;
	else if (q(t)) n = 16;
	else if ("object" == typeof t) {
		if (65 & o) {
			const n = t.default;
			return void(n && (n._c && (n._d = !1), gl(e, n()), n._c && (n._d = !0)))
		} {
			n = 32;
			const o = t._;
			o || il in t ? 3 === o && Jt && (1 === Jt.slots._ ? t._ = 1 : (t._ = 2, e.patchFlag |= 1024)) : t._ctx = Jt
		}
	} else R(t) ? (t = {
		default: t,
		_ctx: Jt
	}, n = 32) : (t = String(t), 64 & o ? (n = 16, t = [fl(t)]) : n = 8);
	e.children = t, e.shapeFlag |= n
}

function bl(...e) {
	const t = {};
	for (let n = 0; n < e.length; n++) {
		const o = e[n];
		for (const e in o)
			if ("class" === e) t.class !== o.class && (t.class = d([t.class, o.class]));
			else if ("style" === e) t.style = r([t.style, o.style]);
		else if (w(e)) {
			const n = t[e],
				l = o[e];
			!l || n === l || q(n) && n.includes(l) || (t[e] = n ? [].concat(n, l) : l)
		} else "" !== e && (t[e] = o[e])
	}
	return t
}

function yl(e, t, n, o = null) {
	Lt(e, t, 7, [n, o])
}
const _l = To();
let wl = 0;
let kl = null;
const Sl = () => kl || Jt,
	xl = e => {
		kl = e, e.scope.on()
	},
	Cl = () => {
		kl && kl.scope.off(), kl = null
	};

function El(e) {
	return 4 & e.vnode.shapeFlag
}
let ql = !1;

function Ll(e, t, n) {
	R(t) ? e.type.__ssrInlineRender ? e.ssrRender = t : e.render = t : P(t) && (e.setupState = xt(t)), Fl(e, n)
}

function Fl(e, t, n) {
	const o = e.type;
	e.render || (e.render = o.render || b), xl(e), ve(), so(e), he(), Cl()
}

function Rl(e) {
	if (e.exposed) return e.exposeProxy || (e.exposeProxy = new Proxy(xt(ft(e.exposed)), {
		get: (t, n) => n in t ? t[n] : n in lo ? lo[n](e) : void 0,
		has: (e, t) => t in e || t in lo
	}))
}
const Ol = (e, t) => function(e, t, n = !1) {
	let o, l;
	const a = R(e);
	return a ? (o = e, l = b) : (o = e.get, l = e.set), new Et(o, l, a || !l, n)
}(e, 0, ql);

function Tl(e, t, n) {
	const o = arguments.length;
	return 2 === o ? P(t) && !q(t) ? al(t) ? dl(e, null, [t]) : dl(e, t) : dl(e, null, t) : (o > 3 ? n = Array.prototype.slice.call(arguments, 2) : 3 === o && al(n) && (n = [n]), dl(e, t, n))
}
const Pl = Symbol(""),
	Al = () => hn(Pl),
	Vl = "3.2.45",
	Ml = "undefined" != typeof document ? document : null,
	Bl = Ml && Ml.createElement("template"),
	Il = {
		insert: (e, t, n) => {
			t.insertBefore(e, n || null)
		},
		remove: e => {
			const t = e.parentNode;
			t && t.removeChild(e)
		},
		createElement: (e, t, n, o) => {
			const l = t ? Ml.createElementNS("http://www.w3.org/2000/svg", e) : Ml.createElement(e, n ? {
				is: n
			} : void 0);
			return "select" === e && o && null != o.multiple && l.setAttribute("multiple", o.multiple), l
		},
		createText: e => Ml.createTextNode(e),
		createComment: e => Ml.createComment(e),
		setText: (e, t) => {
			e.nodeValue = t
		},
		setElementText: (e, t) => {
			e.textContent = t
		},
		parentNode: e => e.parentNode,
		nextSibling: e => e.nextSibling,
		querySelector: e => Ml.querySelector(e),
		setScopeId(e, t) {
			e.setAttribute(t, "")
		},
		insertStaticContent(e, t, n, o, l, a) {
			const r = n ? n.previousSibling : t.lastChild;
			if (l && (l === a || l.nextSibling))
				for (; t.insertBefore(l.cloneNode(!0), n), l !== a && (l = l.nextSibling););
			else {
				Bl.innerHTML = o ? `<svg>${e}</svg>` : e;
				const l = Bl.content;
				if (o) {
					const e = l.firstChild;
					for (; e.firstChild;) l.appendChild(e.firstChild);
					l.removeChild(e)
				}
				t.insertBefore(l, n)
			}
			return [r ? r.nextSibling : t.firstChild, n ? n.previousSibling : t.lastChild]
		}
	};
const $l = /\s*!important$/;

function zl(e, t, n) {
	if (q(n)) n.forEach((n => zl(e, t, n)));
	else if (null == n && (n = ""), t.startsWith("--")) e.setProperty(t, n);
	else {
		const o = function(e, t) {
			const n = jl[t];
			if (n) return n;
			let o = j(t);
			if ("filter" !== o && o in e) return jl[t] = o;
			o = H(o);
			for (let l = 0; l < Nl.length; l++) {
				const n = Nl[l] + o;
				if (n in e) return jl[t] = n
			}
			return t
		}(e, t);
		$l.test(n) ? e.setProperty(U(o), n.replace($l, ""), "important") : e[o] = n
	}
}
const Nl = ["Webkit", "Moz", "ms"],
	jl = {};
const Dl = "http://www.w3.org/1999/xlink";

function Ul(e, t, n, o, l = null) {
	const a = e._vei || (e._vei = {}),
		r = a[t];
	if (o && r) r.value = o;
	else {
		const [n, i] = function(e) {
			let t;
			if (Hl.test(e)) {
				let n;
				for (t = {}; n = e.match(Hl);) e = e.slice(0, e.length - n[0].length), t[n[0].toLowerCase()] = !0
			}
			return [":" === e[2] ? e.slice(3) : U(e.slice(2)), t]
		}(t);
		if (o) {
			const r = a[t] = function(e, t) {
				const n = e => {
					if (e._vts) {
						if (e._vts <= n.attached) return
					} else e._vts = Date.now();
					Lt(function(e, t) {
						if (q(t)) {
							const n = e.stopImmediatePropagation;
							return e.stopImmediatePropagation = () => {
								n.call(e), e._stopped = !0
							}, t.map((e => t => !t._stopped && e && e(t)))
						}
						return t
					}(e, n.value), t, 5, [e])
				};
				return n.value = e, n.attached = (() => Wl || (Kl.then((() => Wl = 0)), Wl = Date.now()))(), n
			}(o, l);
			! function(e, t, n, o) {
				e.addEventListener(t, n, o)
			}(e, n, r, i)
		} else r && (! function(e, t, n, o) {
			e.removeEventListener(t, n, o)
		}(e, n, r, i), a[t] = void 0)
	}
}
const Hl = /(?:Once|Passive|Capture)$/;
let Wl = 0;
const Kl = Promise.resolve();
const Ql = /^on[a-z]/;
const Gl = "transition",
	Zl = (e, {
		slots: t
	}) => Tl(Sn, function(e) {
		const t = {};
		for (const S in e) S in Jl || (t[S] = e[S]);
		if (!1 === e.css) return t;
		const {
			name: n = "v",
			type: o,
			duration: l,
			enterFromClass: a = `${n}-enter-from`,
			enterActiveClass: r = `${n}-enter-active`,
			enterToClass: i = `${n}-enter-to`,
			appearFromClass: s = a,
			appearActiveClass: u = r,
			appearToClass: c = i,
			leaveFromClass: d = `${n}-leave-from`,
			leaveActiveClass: p = `${n}-leave-active`,
			leaveToClass: f = `${n}-leave-to`
		} = e, v = function(e) {
			if (null == e) return null;
			if (P(e)) return [ea(e.enter), ea(e.leave)];
			{
				const t = ea(e);
				return [t, t]
			}
		}(l), h = v && v[0], m = v && v[1], {
			onBeforeEnter: g,
			onEnter: b,
			onEnterCancelled: y,
			onLeave: _,
			onLeaveCancelled: w,
			onBeforeAppear: k = g,
			onAppear: x = b,
			onAppearCancelled: C = y
		} = t, E = (e, t, n) => {
			na(e, t ? c : i), na(e, t ? u : r), n && n()
		}, q = (e, t) => {
			e._isLeaving = !1, na(e, d), na(e, f), na(e, p), t && t()
		}, L = e => (t, n) => {
			const l = e ? x : b,
				r = () => E(t, e, n);
			Xl(l, [t, r]), oa((() => {
				na(t, e ? s : a), ta(t, e ? c : i), Yl(l) || aa(t, o, h, r)
			}))
		};
		return S(t, {
			onBeforeEnter(e) {
				Xl(g, [e]), ta(e, a), ta(e, r)
			},
			onBeforeAppear(e) {
				Xl(k, [e]), ta(e, s), ta(e, u)
			},
			onEnter: L(!1),
			onAppear: L(!0),
			onLeave(e, t) {
				e._isLeaving = !0;
				const n = () => q(e, t);
				ta(e, d), document.body.offsetHeight, ta(e, p), oa((() => {
					e._isLeaving && (na(e, d), ta(e, f), Yl(_) || aa(e, o, m, n))
				})), Xl(_, [e, n])
			},
			onEnterCancelled(e) {
				E(e, !1), Xl(y, [e])
			},
			onAppearCancelled(e) {
				E(e, !0), Xl(C, [e])
			},
			onLeaveCancelled(e) {
				q(e), Xl(w, [e])
			}
		})
	}(e), t);
Zl.displayName = "Transition";
const Jl = {
	name: String,
	type: String,
	css: {
		type: Boolean,
		default: !0
	},
	duration: [String, Number, Object],
	enterFromClass: String,
	enterActiveClass: String,
	enterToClass: String,
	appearFromClass: String,
	appearActiveClass: String,
	appearToClass: String,
	leaveFromClass: String,
	leaveActiveClass: String,
	leaveToClass: String
};
Zl.props = S({}, Sn.props, Jl);
const Xl = (e, t = []) => {
		q(e) ? e.forEach((e => e(...t))) : e && e(...t)
	},
	Yl = e => !!e && (q(e) ? e.some((e => e.length > 1)) : e.length > 1);

function ea(e) {
	return Z(e)
}

function ta(e, t) {
	t.split(/\s+/).forEach((t => t && e.classList.add(t))), (e._vtc || (e._vtc = new Set)).add(t)
}

function na(e, t) {
	t.split(/\s+/).forEach((t => t && e.classList.remove(t)));
	const {
		_vtc: n
	} = e;
	n && (n.delete(t), n.size || (e._vtc = void 0))
}

function oa(e) {
	requestAnimationFrame((() => {
		requestAnimationFrame(e)
	}))
}
let la = 0;

function aa(e, t, n, o) {
	const l = e._endId = ++la,
		a = () => {
			l === e._endId && o()
		};
	if (n) return setTimeout(a, n);
	const {
		type: r,
		timeout: i,
		propCount: s
	} = function(e, t) {
		const n = window.getComputedStyle(e),
			o = e => (n[e] || "").split(", "),
			l = o("transitionDelay"),
			a = o("transitionDuration"),
			r = ra(l, a),
			i = o("animationDelay"),
			s = o("animationDuration"),
			u = ra(i, s);
		let c = null,
			d = 0,
			p = 0;
		t === Gl ? r > 0 && (c = Gl, d = r, p = a.length) : "animation" === t ? u > 0 && (c = "animation", d = u, p = s.length) : (d = Math.max(r, u), c = d > 0 ? r > u ? Gl : "animation" : null, p = c ? c === Gl ? a.length : s.length : 0);
		const f = c === Gl && /\b(transform|all)(,|$)/.test(o("transitionProperty").toString());
		return {
			type: c,
			timeout: d,
			propCount: p,
			hasTransform: f
		}
	}(e, t);
	if (!r) return o();
	const u = r + "end";
	let c = 0;
	const d = () => {
			e.removeEventListener(u, p), a()
		},
		p = t => {
			t.target === e && ++c >= s && d()
		};
	setTimeout((() => {
		c < s && d()
	}), i + 1), e.addEventListener(u, p)
}

function ra(e, t) {
	for (; e.length < t.length;) e = e.concat(e);
	return Math.max(...t.map(((t, n) => ia(t) + ia(e[n]))))
}

function ia(e) {
	return 1e3 * Number(e.slice(0, -1).replace(",", "."))
}
const sa = ["ctrl", "shift", "alt", "meta"],
	ua = {
		stop: e => e.stopPropagation(),
		prevent: e => e.preventDefault(),
		self: e => e.target !== e.currentTarget,
		ctrl: e => !e.ctrlKey,
		shift: e => !e.shiftKey,
		alt: e => !e.altKey,
		meta: e => !e.metaKey,
		left: e => "button" in e && 0 !== e.button,
		middle: e => "button" in e && 1 !== e.button,
		right: e => "button" in e && 2 !== e.button,
		exact: (e, t) => sa.some((n => e[`${n}Key`] && !t.includes(n)))
	},
	ca = {
		beforeMount(e, {
			value: t
		}, {
			transition: n
		}) {
			e._vod = "none" === e.style.display ? "" : e.style.display, n && t ? n.beforeEnter(e) : da(e, t)
		},
		mounted(e, {
			value: t
		}, {
			transition: n
		}) {
			n && t && n.enter(e)
		},
		updated(e, {
			value: t,
			oldValue: n
		}, {
			transition: o
		}) {
			!t != !n && (o ? t ? (o.beforeEnter(e), da(e, !0), o.enter(e)) : o.leave(e, (() => {
				da(e, !1)
			})) : da(e, t))
		},
		beforeUnmount(e, {
			value: t
		}) {
			da(e, t)
		}
	};

function da(e, t) {
	e.style.display = t ? e._vod : "none"
}
const pa = S({
	patchProp: (e, t, n, o, l = !1, a, r, i, s) => {
		"class" === t ? function(e, t, n) {
			const o = e._vtc;
			o && (t = (t ? [t, ...o] : [...o]).join(" ")), null == t ? e.removeAttribute("class") : n ? e.setAttribute("class", t) : e.className = t
		}(e, o, l) : "style" === t ? function(e, t, n) {
			const o = e.style,
				l = O(n);
			if (n && !l) {
				for (const e in n) zl(o, e, n[e]);
				if (t && !O(t))
					for (const e in t) null == n[e] && zl(o, e, "")
			} else {
				const a = o.display;
				l ? t !== n && (o.cssText = n) : t && e.removeAttribute("style"), "_vod" in e && (o.display = a)
			}
		}(e, n, o) : w(t) ? k(t) || Ul(e, t, 0, o, r) : ("." === t[0] ? (t = t.slice(1), 1) : "^" === t[0] ? (t = t.slice(1), 0) : function(e, t, n, o) {
			if (o) return "innerHTML" === t || "textContent" === t || !!(t in e && Ql.test(t) && R(n));
			if ("spellcheck" === t || "draggable" === t || "translate" === t) return !1;
			if ("form" === t) return !1;
			if ("list" === t && "INPUT" === e.tagName) return !1;
			if ("type" === t && "TEXTAREA" === e.tagName) return !1;
			if (Ql.test(t) && O(n)) return !1;
			return t in e
		}(e, t, o, l)) ? function(e, t, n, o, l, a, r) {
			if ("innerHTML" === t || "textContent" === t) return o && r(o, l, a), void(e[t] = null == n ? "" : n);
			if ("value" === t && "PROGRESS" !== e.tagName && !e.tagName.includes("-")) {
				e._value = n;
				const o = null == n ? "" : n;
				return e.value === o && "OPTION" !== e.tagName || (e.value = o), void(null == n && e.removeAttribute(t))
			}
			let i = !1;
			if ("" === n || null == n) {
				const o = typeof e[t];
				"boolean" === o ? n = f(n) : null == n && "string" === o ? (n = "", i = !0) : "number" === o && (n = 0, i = !0)
			}
			try {
				e[t] = n
			} catch (s) {}
			i && e.removeAttribute(t)
		}(e, t, o, a, r, i, s) : ("true-value" === t ? e._trueValue = o : "false-value" === t && (e._falseValue = o), function(e, t, n, o, l) {
			if (o && t.startsWith("xlink:")) null == n ? e.removeAttributeNS(Dl, t.slice(6, t.length)) : e.setAttributeNS(Dl, t, n);
			else {
				const o = p(t);
				null == n || o && !f(n) ? e.removeAttribute(t) : e.setAttribute(t, o ? "" : n)
			}
		}(e, t, o, l))
	}
}, Il);
let fa;

function va() {
	return fa || (fa = Bo(pa))
}
let ha, ma = 0;
const ga = new Array(256);
for (let lg = 0; lg < 256; lg++) ga[lg] = (lg + 256).toString(16).substring(1);
const ba = (() => {
	const e = "undefined" != typeof crypto ? crypto : "undefined" != typeof window ? window.crypto || window.msCrypto : void 0;
	if (void 0 !== e) {
		if (void 0 !== e.randomBytes) return e.randomBytes;
		if (void 0 !== e.getRandomValues) return t => {
			const n = new Uint8Array(t);
			return e.getRandomValues(n), n
		}
	}
	return e => {
		const t = [];
		for (let n = e; n > 0; n--) t.push(Math.floor(256 * Math.random()));
		return t
	}
})();

function ya() {
	(void 0 === ha || ma + 16 > 4096) && (ma = 0, ha = ba(4096));
	const e = Array.prototype.slice.call(ha, ma, ma += 16);
	return e[6] = 15 & e[6] | 64, e[8] = 63 & e[8] | 128, ga[e[0]] + ga[e[1]] + ga[e[2]] + ga[e[3]] + "-" + ga[e[4]] + ga[e[5]] + "-" + ga[e[6]] + ga[e[7]] + "-" + ga[e[8]] + ga[e[9]] + "-" + ga[e[10]] + ga[e[11]] + ga[e[12]] + ga[e[13]] + ga[e[14]] + ga[e[15]]
}
var _a, wa = "undefined" != typeof globalThis ? globalThis : "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
	ka = {
		exports: {}
	},
	Sa = "object" == typeof Reflect ? Reflect : null,
	xa = Sa && "function" == typeof Sa.apply ? Sa.apply : function(e, t, n) {
		return Function.prototype.apply.call(e, t, n)
	};
_a = Sa && "function" == typeof Sa.ownKeys ? Sa.ownKeys : Object.getOwnPropertySymbols ? function(e) {
	return Object.getOwnPropertyNames(e).concat(Object.getOwnPropertySymbols(e))
} : function(e) {
	return Object.getOwnPropertyNames(e)
};
var Ca = Number.isNaN || function(e) {
	return e != e
};

function Ea() {
	Ea.init.call(this)
}
ka.exports = Ea, ka.exports.once = function(e, t) {
	return new Promise((function(n, o) {
		function l(n) {
			e.removeListener(t, a), o(n)
		}

		function a() {
			"function" == typeof e.removeListener && e.removeListener("error", l), n([].slice.call(arguments))
		}
		Ma(e, t, a, {
			once: !0
		}), "error" !== t && function(e, t, n) {
			"function" == typeof e.on && Ma(e, "error", t, n)
		}(e, l, {
			once: !0
		})
	}))
}, Ea.EventEmitter = Ea, Ea.prototype._events = void 0, Ea.prototype._eventsCount = 0, Ea.prototype._maxListeners = void 0;
var qa = 10;

function La(e) {
	if ("function" != typeof e) throw new TypeError('The "listener" argument must be of type Function. Received type ' + typeof e)
}

function Fa(e) {
	return void 0 === e._maxListeners ? Ea.defaultMaxListeners : e._maxListeners
}

function Ra(e, t, n, o) {
	var l, a, r, i;
	if (La(n), void 0 === (a = e._events) ? (a = e._events = Object.create(null), e._eventsCount = 0) : (void 0 !== a.newListener && (e.emit("newListener", t, n.listener ? n.listener : n), a = e._events), r = a[t]), void 0 === r) r = a[t] = n, ++e._eventsCount;
	else if ("function" == typeof r ? r = a[t] = o ? [n, r] : [r, n] : o ? r.unshift(n) : r.push(n), (l = Fa(e)) > 0 && r.length > l && !r.warned) {
		r.warned = !0;
		var s = new Error("Possible EventEmitter memory leak detected. " + r.length + " " + String(t) + " listeners added. Use emitter.setMaxListeners() to increase limit");
		s.name = "MaxListenersExceededWarning", s.emitter = e, s.type = t, s.count = r.length, i = s, console && console.warn && console.warn(i)
	}
	return e
}

function Oa() {
	if (!this.fired) return this.target.removeListener(this.type, this.wrapFn), this.fired = !0, 0 === arguments.length ? this.listener.call(this.target) : this.listener.apply(this.target, arguments)
}

function Ta(e, t, n) {
	var o = {
			fired: !1,
			wrapFn: void 0,
			target: e,
			type: t,
			listener: n
		},
		l = Oa.bind(o);
	return l.listener = n, o.wrapFn = l, l
}

function Pa(e, t, n) {
	var o = e._events;
	if (void 0 === o) return [];
	var l = o[t];
	return void 0 === l ? [] : "function" == typeof l ? n ? [l.listener || l] : [l] : n ? function(e) {
		for (var t = new Array(e.length), n = 0; n < t.length; ++n) t[n] = e[n].listener || e[n];
		return t
	}(l) : Va(l, l.length)
}

function Aa(e) {
	var t = this._events;
	if (void 0 !== t) {
		var n = t[e];
		if ("function" == typeof n) return 1;
		if (void 0 !== n) return n.length
	}
	return 0
}

function Va(e, t) {
	for (var n = new Array(t), o = 0; o < t; ++o) n[o] = e[o];
	return n
}

function Ma(e, t, n, o) {
	if ("function" == typeof e.on) o.once ? e.once(t, n) : e.on(t, n);
	else {
		if ("function" != typeof e.addEventListener) throw new TypeError('The "emitter" argument must be of type EventEmitter. Received type ' + typeof e);
		e.addEventListener(t, (function l(a) {
			o.once && e.removeEventListener(t, l), n(a)
		}))
	}
}
Object.defineProperty(Ea, "defaultMaxListeners", {
	enumerable: !0,
	get: function() {
		return qa
	},
	set: function(e) {
		if ("number" != typeof e || e < 0 || Ca(e)) throw new RangeError('The value of "defaultMaxListeners" is out of range. It must be a non-negative number. Received ' + e + ".");
		qa = e
	}
}), Ea.init = function() {
	void 0 !== this._events && this._events !== Object.getPrototypeOf(this)._events || (this._events = Object.create(null), this._eventsCount = 0), this._maxListeners = this._maxListeners || void 0
}, Ea.prototype.setMaxListeners = function(e) {
	if ("number" != typeof e || e < 0 || Ca(e)) throw new RangeError('The value of "n" is out of range. It must be a non-negative number. Received ' + e + ".");
	return this._maxListeners = e, this
}, Ea.prototype.getMaxListeners = function() {
	return Fa(this)
}, Ea.prototype.emit = function(e) {
	for (var t = [], n = 1; n < arguments.length; n++) t.push(arguments[n]);
	var o = "error" === e,
		l = this._events;
	if (void 0 !== l) o = o && void 0 === l.error;
	else if (!o) return !1;
	if (o) {
		var a;
		if (t.length > 0 && (a = t[0]), a instanceof Error) throw a;
		var r = new Error("Unhandled error." + (a ? " (" + a.message + ")" : ""));
		throw r.context = a, r
	}
	var i = l[e];
	if (void 0 === i) return !1;
	if ("function" == typeof i) xa(i, this, t);
	else {
		var s = i.length,
			u = Va(i, s);
		for (n = 0; n < s; ++n) xa(u[n], this, t)
	}
	return !0
}, Ea.prototype.addListener = function(e, t) {
	return Ra(this, e, t, !1)
}, Ea.prototype.on = Ea.prototype.addListener, Ea.prototype.prependListener = function(e, t) {
	return Ra(this, e, t, !0)
}, Ea.prototype.once = function(e, t) {
	return La(t), this.on(e, Ta(this, e, t)), this
}, Ea.prototype.prependOnceListener = function(e, t) {
	return La(t), this.prependListener(e, Ta(this, e, t)), this
}, Ea.prototype.removeListener = function(e, t) {
	var n, o, l, a, r;
	if (La(t), void 0 === (o = this._events)) return this;
	if (void 0 === (n = o[e])) return this;
	if (n === t || n.listener === t) 0 == --this._eventsCount ? this._events = Object.create(null) : (delete o[e], o.removeListener && this.emit("removeListener", e, n.listener || t));
	else if ("function" != typeof n) {
		for (l = -1, a = n.length - 1; a >= 0; a--)
			if (n[a] === t || n[a].listener === t) {
				r = n[a].listener, l = a;
				break
			} if (l < 0) return this;
		0 === l ? n.shift() : function(e, t) {
			for (; t + 1 < e.length; t++) e[t] = e[t + 1];
			e.pop()
		}(n, l), 1 === n.length && (o[e] = n[0]), void 0 !== o.removeListener && this.emit("removeListener", e, r || t)
	}
	return this
}, Ea.prototype.off = Ea.prototype.removeListener, Ea.prototype.removeAllListeners = function(e) {
	var t, n, o;
	if (void 0 === (n = this._events)) return this;
	if (void 0 === n.removeListener) return 0 === arguments.length ? (this._events = Object.create(null), this._eventsCount = 0) : void 0 !== n[e] && (0 == --this._eventsCount ? this._events = Object.create(null) : delete n[e]), this;
	if (0 === arguments.length) {
		var l, a = Object.keys(n);
		for (o = 0; o < a.length; ++o) "removeListener" !== (l = a[o]) && this.removeAllListeners(l);
		return this.removeAllListeners("removeListener"), this._events = Object.create(null), this._eventsCount = 0, this
	}
	if ("function" == typeof(t = n[e])) this.removeListener(e, t);
	else if (void 0 !== t)
		for (o = t.length - 1; o >= 0; o--) this.removeListener(e, t[o]);
	return this
}, Ea.prototype.listeners = function(e) {
	return Pa(this, e, !0)
}, Ea.prototype.rawListeners = function(e) {
	return Pa(this, e, !1)
}, Ea.listenerCount = function(e, t) {
	return "function" == typeof e.listenerCount ? e.listenerCount(t) : Aa.call(e, t)
}, Ea.prototype.listenerCount = Aa, Ea.prototype.eventNames = function() {
	return this._eventsCount > 0 ? _a(this._events) : []
};
const Ba = {
		undefined: () => 0,
		boolean: () => 4,
		number: () => 8,
		string: e => 2 * e.length,
		object: e => e ? Object.keys(e).reduce(((t, n) => Ia(n) + Ia(e[n]) + t), 0) : 0
	},
	Ia = e => Ba[typeof e](e);
class $a extends ka.exports.EventEmitter {
	constructor(e) {
		super(), this.setMaxListeners(1 / 0), this.wall = e, e.listen((e => {
			Array.isArray(e) ? e.forEach((e => this._emit(e))) : this._emit(e)
		})), this._sendingQueue = [], this._sending = !1, this._maxMessageSize = 33554432
	}
	send(e, t) {
		return this._send([{
			event: e,
			payload: t
		}])
	}
	getEvents() {
		return this._events
	}
	on(e, t) {
		return super.on(e, (e => {
			t({
				...e,
				respond: t => this.send(e.eventResponseKey, t)
			})
		}))
	}
	_emit(e) {
		"string" == typeof e ? this.emit(e) : this.emit(e.event, e.payload)
	}
	_send(e) {
		return this._sendingQueue.push(e), this._nextSend()
	}
	_nextSend() {
		if (!this._sendingQueue.length || this._sending) return Promise.resolve();
		this._sending = !0;
		const e = this._sendingQueue.shift(),
			t = e[0],
			n = `${t.event}.${ya()}` + ".result";
		return new Promise(((o, l) => {
			let a = [];
			const r = e => {
				if (void 0 !== e && e._chunkSplit) {
					const t = e._chunkSplit;
					a = [...a, ...e.data], t.lastChunk && (this.off(n, r), o(a))
				} else this.off(n, r), o(e)
			};
			this.on(n, r);
			try {
				const t = e.map((e => ({
					...e,
					payload: {
						data: e.payload,
						eventResponseKey: n
					}
				})));
				this.wall.send(t)
			} catch (i) {
				const e = "Message length exceeded maximum allowed length.";
				if (i.message === e)
					if (Array.isArray(t.payload)) {
						const e = Ia(t);
						if (e > this._maxMessageSize) {
							const n = Math.ceil(e / this._maxMessageSize),
								o = Math.ceil(t.payload.length / n);
							let l = t.payload;
							for (let e = 0; e < n; e++) {
								let a = Math.min(l.length, o);
								this.wall.send([{
									event: t.event,
									payload: {
										_chunkSplit: {
											count: n,
											lastChunk: e === n - 1
										},
										data: l.splice(0, a)
									}
								}])
							}
						}
					} else;
			}
			this._sending = !1, setTimeout((() => this._nextSend()), 16)
		}))
	}
}

function za(e, t, n, o) {
	return Object.defineProperty(e, t, {
		get: n,
		set: o,
		enumerable: !0
	}), e
}
const Na = yt(!1);
let ja;
const Da = "ontouchstart" in window || window.navigator.maxTouchPoints > 0;
const Ua = navigator.userAgent || navigator.vendor || window.opera,
	Ha = {
		has: {
			touch: !1,
			webStorage: !1
		},
		within: {
			iframe: !1
		}
	},
	Wa = {
		userAgent: Ua,
		is: function(e) {
			const t = e.toLowerCase(),
				n = function(e) {
					return /(ipad)/.exec(e) || /(ipod)/.exec(e) || /(windows phone)/.exec(e) || /(iphone)/.exec(e) || /(kindle)/.exec(e) || /(silk)/.exec(e) || /(android)/.exec(e) || /(win)/.exec(e) || /(mac)/.exec(e) || /(linux)/.exec(e) || /(cros)/.exec(e) || /(playbook)/.exec(e) || /(bb)/.exec(e) || /(blackberry)/.exec(e) || []
				}(t),
				o = function(e, t) {
					const n = /(edg|edge|edga|edgios)\/([\w.]+)/.exec(e) || /(opr)[\/]([\w.]+)/.exec(e) || /(vivaldi)[\/]([\w.]+)/.exec(e) || /(chrome|crios)[\/]([\w.]+)/.exec(e) || /(version)(applewebkit)[\/]([\w.]+).*(safari)[\/]([\w.]+)/.exec(e) || /(webkit)[\/]([\w.]+).*(version)[\/]([\w.]+).*(safari)[\/]([\w.]+)/.exec(e) || /(firefox|fxios)[\/]([\w.]+)/.exec(e) || /(webkit)[\/]([\w.]+)/.exec(e) || /(opera)(?:.*version|)[\/]([\w.]+)/.exec(e) || [];
					return {
						browser: n[5] || n[3] || n[1] || "",
						version: n[2] || n[4] || "0",
						versionNumber: n[4] || n[2] || "0",
						platform: t[0] || ""
					}
				}(t, n),
				l = {};
			o.browser && (l[o.browser] = !0, l.version = o.version, l.versionNumber = parseInt(o.versionNumber, 10)), o.platform && (l[o.platform] = !0);
			const a = l.android || l.ios || l.bb || l.blackberry || l.ipad || l.iphone || l.ipod || l.kindle || l.playbook || l.silk || l["windows phone"];
			return !0 === a || t.indexOf("mobile") > -1 ? (l.mobile = !0, l.edga || l.edgios ? (l.edge = !0, o.browser = "edge") : l.crios ? (l.chrome = !0, o.browser = "chrome") : l.fxios && (l.firefox = !0, o.browser = "firefox")) : l.desktop = !0, (l.ipod || l.ipad || l.iphone) && (l.ios = !0), l["windows phone"] && (l.winphone = !0, delete l["windows phone"]), (l.chrome || l.opr || l.safari || l.vivaldi || !0 === l.mobile && !0 !== l.ios && !0 !== a) && (l.webkit = !0), l.edg && (o.browser = "edgechromium", l.edgeChromium = !0), (l.safari && l.blackberry || l.bb) && (o.browser = "blackberry", l.blackberry = !0), l.safari && l.playbook && (o.browser = "playbook", l.playbook = !0), l.opr && (o.browser = "opera", l.opera = !0), l.safari && l.android && (o.browser = "android", l.android = !0), l.safari && l.kindle && (o.browser = "kindle", l.kindle = !0), l.safari && l.silk && (o.browser = "silk", l.silk = !0), l.vivaldi && (o.browser = "vivaldi", l.vivaldi = !0), l.name = o.browser, l.platform = o.platform, t.indexOf("electron") > -1 ? l.electron = !0 : document.location.href.indexOf("-extension://") > -1 ? l.bex = !0 : (void 0 !== window.Capacitor ? (l.capacitor = !0, l.nativeMobile = !0, l.nativeMobileWrapper = "capacitor") : void 0 === window._cordovaNative && void 0 === window.cordova || (l.cordova = !0, l.nativeMobile = !0, l.nativeMobileWrapper = "cordova"), !0 === Da && !0 === l.mac && (!0 === l.desktop && !0 === l.safari || !0 === l.nativeMobile && !0 !== l.android && !0 !== l.ios && !0 !== l.ipad) && function(e) {
				ja = {
					is: {
						...e
					}
				}, delete e.mac, delete e.desktop;
				const t = Math.min(window.innerHeight, window.innerWidth) > 414 ? "ipad" : "iphone";
				Object.assign(e, {
					mobile: !0,
					ios: !0,
					platform: t,
					[t]: !0
				})
			}(l)), l
		}(Ua),
		has: {
			touch: Da
		},
		within: {
			iframe: window.self !== window.top
		}
	},
	Ka = {
		install(e) {
			const {
				$q: t
			} = e;
			!0 === Na.value ? (e.onSSRHydrated.push((() => {
				Object.assign(t.platform, Wa), Na.value = !1, ja = void 0
			})), t.platform = at(this)) : t.platform = this
		}
	};
{
	let e;
	za(Wa.has, "webStorage", (() => {
		if (void 0 !== e) return e;
		try {
			if (window.localStorage) return e = !0, !0
		} catch (t) {}
		return e = !1, !1
	})), !0 === Wa.is.ios && window.navigator.vendor.toLowerCase().indexOf("apple"), !0 === Na.value ? Object.assign(Ka, Wa, ja, Ha) : Object.assign(Ka, Wa)
}
var Qa = (e, t) => {
	const n = at(e);
	for (const o in e) za(t, o, (() => n[o]), (e => {
		n[o] = e
	}));
	return t
};
const Ga = {
	hasPassive: !1,
	passiveCapture: !0,
	notPassiveCapture: !0
};
try {
	const e = Object.defineProperty({}, "passive", {
		get() {
			Object.assign(Ga, {
				hasPassive: !0,
				passive: {
					passive: !0
				},
				notPassive: {
					passive: !1
				},
				passiveCapture: {
					passive: !0,
					capture: !0
				},
				notPassiveCapture: {
					passive: !1,
					capture: !0
				}
			})
		}
	});
	window.addEventListener("qtest", null, e), window.removeEventListener("qtest", null, e)
} catch (og) {}

function Za() {}

function Ja(e) {
	return e.touches && e.touches[0] ? e = e.touches[0] : e.changedTouches && e.changedTouches[0] ? e = e.changedTouches[0] : e.targetTouches && e.targetTouches[0] && (e = e.targetTouches[0]), {
		top: e.clientY,
		left: e.clientX
	}
}

function Xa(e) {
	e.stopPropagation()
}

function Ya(e) {
	!1 !== e.cancelable && e.preventDefault()
}

function er(e) {
	!1 !== e.cancelable && e.preventDefault(), e.stopPropagation()
}

function tr(e, t, n) {
	const o = `__q_${t}_evt`;
	e[o] = void 0 !== e[o] ? e[o].concat(n) : n, n.forEach((t => {
		t[0].addEventListener(t[1], e[t[2]], Ga[t[3]])
	}))
}

function nr(e, t) {
	const n = `__q_${t}_evt`;
	void 0 !== e[n] && (e[n].forEach((t => {
		t[0].removeEventListener(t[1], e[t[2]], Ga[t[3]])
	})), e[n] = void 0)
}

function or(e, t = 250, n) {
	let o = null;

	function l() {
		const l = arguments,
			a = () => {
				o = null, !0 !== n && e.apply(this, l)
			};
		null !== o ? clearTimeout(o) : !0 === n && e.apply(this, l), o = setTimeout(a, t)
	}
	return l.cancel = () => {
		null !== o && clearTimeout(o)
	}, l
}
const lr = ["sm", "md", "lg", "xl"],
	{
		passive: ar
	} = Ga;
var rr = Qa({
	width: 0,
	height: 0,
	name: "xs",
	sizes: {
		sm: 600,
		md: 1024,
		lg: 1440,
		xl: 1920
	},
	lt: {
		sm: !0,
		md: !0,
		lg: !0,
		xl: !0
	},
	gt: {
		xs: !1,
		sm: !1,
		md: !1,
		lg: !1
	},
	xs: !0,
	sm: !1,
	md: !1,
	lg: !1,
	xl: !1
}, {
	setSizes: Za,
	setDebounce: Za,
	install({
		$q: e,
		onSSRHydrated: t
	}) {
		if (e.screen = this, !0 === this.__installed) return void(void 0 !== e.config.screen && (!1 === e.config.screen.bodyClasses ? document.body.classList.remove(`screen--${this.name}`) : this.__update(!0)));
		const {
			visualViewport: n
		} = window, o = n || window, l = document.scrollingElement || document.documentElement, a = void 0 === n || !0 === Wa.is.mobile ? () => [Math.max(window.innerWidth, l.clientWidth), Math.max(window.innerHeight, l.clientHeight)] : () => [n.width * n.scale + window.innerWidth - l.clientWidth, n.height * n.scale + window.innerHeight - l.clientHeight], r = void 0 !== e.config.screen && !0 === e.config.screen.bodyClasses;
		this.__update = e => {
			const [t, n] = a();
			if (n !== this.height && (this.height = n), t !== this.width) this.width = t;
			else if (!0 !== e) return;
			let o = this.sizes;
			this.gt.xs = t >= o.sm, this.gt.sm = t >= o.md, this.gt.md = t >= o.lg, this.gt.lg = t >= o.xl, this.lt.sm = t < o.sm, this.lt.md = t < o.md, this.lt.lg = t < o.lg, this.lt.xl = t < o.xl, this.xs = this.lt.sm, this.sm = !0 === this.gt.xs && !0 === this.lt.md, this.md = !0 === this.gt.sm && !0 === this.lt.lg, this.lg = !0 === this.gt.md && !0 === this.lt.xl, this.xl = this.gt.lg, o = (!0 === this.xs ? "xs" : !0 === this.sm && "sm") || !0 === this.md && "md" || !0 === this.lg && "lg" || "xl", o !== this.name && (!0 === r && (document.body.classList.remove(`screen--${this.name}`), document.body.classList.add(`screen--${o}`)), this.name = o)
		};
		let i, s = {},
			u = 16;
		this.setSizes = e => {
			lr.forEach((t => {
				void 0 !== e[t] && (s[t] = e[t])
			}))
		}, this.setDebounce = e => {
			u = e
		};
		const c = () => {
			const e = getComputedStyle(document.body);
			e.getPropertyValue("--q-size-sm") && lr.forEach((t => {
				this.sizes[t] = parseInt(e.getPropertyValue(`--q-size-${t}`), 10)
			})), this.setSizes = e => {
				lr.forEach((t => {
					e[t] && (this.sizes[t] = e[t])
				})), this.__update(!0)
			}, this.setDebounce = e => {
				void 0 !== i && o.removeEventListener("resize", i, ar), i = e > 0 ? or(this.__update, e) : this.__update, o.addEventListener("resize", i, ar)
			}, this.setDebounce(u), Object.keys(s).length > 0 ? (this.setSizes(s), s = void 0) : this.__update(), !0 === r && "xs" === this.name && document.body.classList.add("screen--xs")
		};
		!0 === Na.value ? t.push(c) : c()
	}
});
const ir = Qa({
		isActive: !1,
		mode: !1
	}, {
		__media: void 0,
		set(e) {
			ir.mode = e, "auto" === e ? (void 0 === ir.__media && (ir.__media = window.matchMedia("(prefers-color-scheme: dark)"), ir.__updateMedia = () => {
				ir.set("auto")
			}, ir.__media.addListener(ir.__updateMedia)), e = ir.__media.matches) : void 0 !== ir.__media && (ir.__media.removeListener(ir.__updateMedia), ir.__media = void 0), ir.isActive = !0 === e, document.body.classList.remove("body--" + (!0 === e ? "light" : "dark")), document.body.classList.add("body--" + (!0 === e ? "dark" : "light"))
		},
		toggle() {
			ir.set(!1 === ir.isActive)
		},
		install({
			$q: e,
			onSSRHydrated: t,
			ssrContext: n
		}) {
			const {
				dark: o
			} = e.config;
			if (e.dark = this, !0 === this.__installed && void 0 === o) return;
			this.isActive = !0 === o;
			const l = void 0 !== o && o;
			if (!0 === Na.value) {
				const e = e => {
						this.__fromSSR = e
					},
					n = this.set;
				this.set = e, e(l), t.push((() => {
					this.set = n, this.set(this.__fromSSR)
				}))
			} else this.set(l)
		}
	}),
	sr = () => !0;

function ur(e) {
	return "string" == typeof e && "" !== e && "/" !== e && "#/" !== e
}

function cr(e) {
	return !0 === e.startsWith("#") && (e = e.substring(1)), !1 === e.startsWith("/") && (e = "/" + e), !0 === e.endsWith("/") && (e = e.substring(0, e.length - 1)), "#" + e
}
var dr = {
		__history: [],
		add: Za,
		remove: Za,
		install({
			$q: e
		}) {
			if (!0 === this.__installed) return;
			const {
				cordova: t,
				capacitor: n
			} = Wa.is;
			if (!0 !== t && !0 !== n) return;
			const o = e.config[!0 === t ? "cordova" : "capacitor"];
			if (void 0 !== o && !1 === o.backButton) return;
			if (!0 === n && (void 0 === window.Capacitor || void 0 === window.Capacitor.Plugins.App)) return;
			this.add = e => {
				void 0 === e.condition && (e.condition = sr), this.__history.push(e)
			}, this.remove = e => {
				const t = this.__history.indexOf(e);
				t >= 0 && this.__history.splice(t, 1)
			};
			const l = function(e) {
					if (!1 === e.backButtonExit) return () => !1;
					if ("*" === e.backButtonExit) return sr;
					const t = ["#/"];
					return !0 === Array.isArray(e.backButtonExit) && t.push(...e.backButtonExit.filter(ur).map(cr)), () => t.includes(window.location.hash)
				}(Object.assign({
					backButtonExit: !0
				}, o)),
				a = () => {
					if (this.__history.length) {
						const e = this.__history[this.__history.length - 1];
						!0 === e.condition() && (this.__history.pop(), e.handler())
					} else !0 === l() ? navigator.app.exitApp() : window.history.back()
				};
			!0 === t ? document.addEventListener("deviceready", (() => {
				document.addEventListener("backbutton", a, !1)
			})) : window.Capacitor.Plugins.App.addListener("backButton", a)
		}
	},
	pr = {
		isoName: "en-US",
		nativeName: "English (US)",
		label: {
			clear: "Clear",
			ok: "OK",
			cancel: "Cancel",
			close: "Close",
			set: "Set",
			select: "Select",
			reset: "Reset",
			remove: "Remove",
			update: "Update",
			create: "Create",
			search: "Search",
			filter: "Filter",
			refresh: "Refresh",
			expand: e => e ? `Expand "${e}"` : "Expand",
			collapse: e => e ? `Collapse "${e}"` : "Collapse"
		},
		date: {
			days: "Sunday_Monday_Tuesday_Wednesday_Thursday_Friday_Saturday".split("_"),
			daysShort: "Sun_Mon_Tue_Wed_Thu_Fri_Sat".split("_"),
			months: "January_February_March_April_May_June_July_August_September_October_November_December".split("_"),
			monthsShort: "Jan_Feb_Mar_Apr_May_Jun_Jul_Aug_Sep_Oct_Nov_Dec".split("_"),
			firstDayOfWeek: 0,
			format24h: !1,
			pluralDay: "days"
		},
		table: {
			noData: "No data available",
			noResults: "No matching records found",
			loading: "Loading...",
			selectedRecords: e => 1 === e ? "1 record selected." : (0 === e ? "No" : e) + " records selected.",
			recordsPerPage: "Records per page:",
			allRows: "All",
			pagination: (e, t, n) => e + "-" + t + " of " + n,
			columns: "Columns"
		},
		editor: {
			url: "URL",
			bold: "Bold",
			italic: "Italic",
			strikethrough: "Strikethrough",
			underline: "Underline",
			unorderedList: "Unordered List",
			orderedList: "Ordered List",
			subscript: "Subscript",
			superscript: "Superscript",
			hyperlink: "Hyperlink",
			toggleFullscreen: "Toggle Fullscreen",
			quote: "Quote",
			left: "Left align",
			center: "Center align",
			right: "Right align",
			justify: "Justify align",
			print: "Print",
			outdent: "Decrease indentation",
			indent: "Increase indentation",
			removeFormat: "Remove formatting",
			formatting: "Formatting",
			fontSize: "Font Size",
			align: "Align",
			hr: "Insert Horizontal Rule",
			undo: "Undo",
			redo: "Redo",
			heading1: "Heading 1",
			heading2: "Heading 2",
			heading3: "Heading 3",
			heading4: "Heading 4",
			heading5: "Heading 5",
			heading6: "Heading 6",
			paragraph: "Paragraph",
			code: "Code",
			size1: "Very small",
			size2: "A bit small",
			size3: "Normal",
			size4: "Medium-large",
			size5: "Big",
			size6: "Very big",
			size7: "Maximum",
			defaultFont: "Default Font",
			viewSource: "View Source"
		},
		tree: {
			noNodes: "No nodes available",
			noResults: "No matching nodes found"
		}
	};

function fr() {
	const e = !0 === Array.isArray(navigator.languages) && navigator.languages.length > 0 ? navigator.languages[0] : navigator.language;
	if ("string" == typeof e) return e.split(/[-_]/).map(((e, t) => 0 === t ? e.toLowerCase() : t > 1 || e.length < 4 ? e.toUpperCase() : e[0].toUpperCase() + e.slice(1).toLowerCase())).join("-")
}
const vr = Qa({
	__langPack: {}
}, {
	getLocale: fr,
	set(e = pr, t) {
		const n = {
			...e,
			rtl: !0 === e.rtl,
			getLocale: fr
		};
		if (n.set = vr.set, void 0 === vr.__langConfig || !0 !== vr.__langConfig.noHtmlAttrs) {
			const e = document.documentElement;
			e.setAttribute("dir", !0 === n.rtl ? "rtl" : "ltr"), e.setAttribute("lang", n.isoName)
		}
		Object.assign(vr.__langPack, n), vr.props = n, vr.isoName = n.isoName, vr.nativeName = n.nativeName
	},
	install({
		$q: e,
		lang: t,
		ssrContext: n
	}) {
		e.lang = vr.__langPack, vr.__langConfig = e.config.lang, !0 === this.__installed ? void 0 !== t && this.set(t) : this.set(t || pr)
	}
});

function hr(e, t, n = document.body) {
	if ("string" != typeof e) throw new TypeError("Expected a string as propName");
	if ("string" != typeof t) throw new TypeError("Expected a string as value");
	if (!(n instanceof Element)) throw new TypeError("Expected a DOM element");
	n.style.setProperty(`--q-${e}`, t)
}
let mr = !1;

function gr(e) {
	mr = !0 === e.isComposing
}

function br(e) {
	return !0 === mr || e !== Object(e) || !0 === e.isComposing || !0 === e.qKeyEvent
}

function yr(e, t) {
	return !0 !== br(e) && [].concat(t).includes(e.keyCode)
}

function _r(e) {
	return !0 === e.ios ? "ios" : !0 === e.android ? "android" : void 0
}
var wr = {
		install(e) {
			if (!0 !== this.__installed) {
				if (!0 === Na.value) ! function() {
					const {
						is: e
					} = Wa, t = document.body.className, n = new Set(t.replace(/ {2}/g, " ").split(" "));
					if (void 0 !== ja) n.delete("desktop"), n.add("platform-ios"), n.add("mobile");
					else if (!0 !== e.nativeMobile && !0 !== e.electron && !0 !== e.bex)
						if (!0 === e.desktop) n.delete("mobile"), n.delete("platform-ios"), n.delete("platform-android"), n.add("desktop");
						else if (!0 === e.mobile) {
						n.delete("desktop"), n.add("mobile");
						const t = _r(e);
						void 0 !== t ? (n.add(`platform-${t}`), n.delete("platform-" + ("ios" === t ? "android" : "ios"))) : (n.delete("platform-ios"), n.delete("platform-android"))
					}!0 === Wa.has.touch && (n.delete("no-touch"), n.add("touch")), !0 === Wa.within.iframe && n.add("within-iframe");
					const o = Array.from(n).join(" ");
					t !== o && (document.body.className = o)
				}();
				else {
					const {
						$q: t
					} = e;
					void 0 !== t.config.brand && function(e) {
						for (const t in e) hr(t, e[t])
					}(t.config.brand);
					const n = function({
						is: e,
						has: t,
						within: n
					}, o) {
						const l = [!0 === e.desktop ? "desktop" : "mobile", (!1 === t.touch ? "no-" : "") + "touch"];
						if (!0 === e.mobile) {
							const t = _r(e);
							void 0 !== t && l.push("platform-" + t)
						}
						if (!0 === e.nativeMobile) {
							const t = e.nativeMobileWrapper;
							l.push(t), l.push("native-mobile"), !0 !== e.ios || void 0 !== o[t] && !1 === o[t].iosStatusBarPadding || l.push("q-ios-padding")
						} else !0 === e.electron ? l.push("electron") : !0 === e.bex && l.push("bex");
						return !0 === n.iframe && l.push("within-iframe"), l
					}(Wa, t.config);
					document.body.classList.add.apply(document.body.classList, n)
				}!0 === Wa.is.ios && document.body.addEventListener("touchstart", Za), window.addEventListener("keydown", gr, !0)
			}
		}
	},
	kr = {
		name: "material-icons",
		type: {
			positive: "check_circle",
			negative: "warning",
			info: "info",
			warning: "priority_high"
		},
		arrow: {
			up: "arrow_upward",
			right: "arrow_forward",
			down: "arrow_downward",
			left: "arrow_back",
			dropdown: "arrow_drop_down"
		},
		chevron: {
			left: "chevron_left",
			right: "chevron_right"
		},
		colorPicker: {
			spectrum: "gradient",
			tune: "tune",
			palette: "style"
		},
		pullToRefresh: {
			icon: "refresh"
		},
		carousel: {
			left: "chevron_left",
			right: "chevron_right",
			up: "keyboard_arrow_up",
			down: "keyboard_arrow_down",
			navigationIcon: "lens"
		},
		chip: {
			remove: "cancel",
			selected: "check"
		},
		datetime: {
			arrowLeft: "chevron_left",
			arrowRight: "chevron_right",
			now: "access_time",
			today: "today"
		},
		editor: {
			bold: "format_bold",
			italic: "format_italic",
			strikethrough: "strikethrough_s",
			underline: "format_underlined",
			unorderedList: "format_list_bulleted",
			orderedList: "format_list_numbered",
			subscript: "vertical_align_bottom",
			superscript: "vertical_align_top",
			hyperlink: "link",
			toggleFullscreen: "fullscreen",
			quote: "format_quote",
			left: "format_align_left",
			center: "format_align_center",
			right: "format_align_right",
			justify: "format_align_justify",
			print: "print",
			outdent: "format_indent_decrease",
			indent: "format_indent_increase",
			removeFormat: "format_clear",
			formatting: "text_format",
			fontSize: "format_size",
			align: "format_align_left",
			hr: "remove",
			undo: "undo",
			redo: "redo",
			heading: "format_size",
			code: "code",
			size: "format_size",
			font: "font_download",
			viewSource: "code"
		},
		expansionItem: {
			icon: "keyboard_arrow_down",
			denseIcon: "arrow_drop_down"
		},
		fab: {
			icon: "add",
			activeIcon: "close"
		},
		field: {
			clear: "cancel",
			error: "error"
		},
		pagination: {
			first: "first_page",
			prev: "keyboard_arrow_left",
			next: "keyboard_arrow_right",
			last: "last_page"
		},
		rating: {
			icon: "grade"
		},
		stepper: {
			done: "check",
			active: "edit",
			error: "warning"
		},
		tabs: {
			left: "chevron_left",
			right: "chevron_right",
			up: "keyboard_arrow_up",
			down: "keyboard_arrow_down"
		},
		table: {
			arrowUp: "arrow_upward",
			warning: "warning",
			firstPage: "first_page",
			prevPage: "chevron_left",
			nextPage: "chevron_right",
			lastPage: "last_page"
		},
		tree: {
			icon: "play_arrow"
		},
		uploader: {
			done: "done",
			clear: "clear",
			add: "add_box",
			upload: "cloud_upload",
			removeQueue: "clear_all",
			removeUploaded: "done_all"
		}
	};
const Sr = Qa({
		iconMapFn: null,
		__icons: {}
	}, {
		set(e, t) {
			const n = {
				...e,
				rtl: !0 === e.rtl
			};
			n.set = Sr.set, Object.assign(Sr.__icons, n)
		},
		install({
			$q: e,
			iconSet: t,
			ssrContext: n
		}) {
			void 0 !== e.config.iconMapFn && (this.iconMapFn = e.config.iconMapFn), e.iconSet = this.__icons, za(e, "iconMapFn", (() => this.iconMapFn), (e => {
				this.iconMapFn = e
			})), !0 === this.__installed ? void 0 !== t && this.set(t) : this.set(t || kr)
		}
	}),
	xr = () => {},
	Cr = {};
let Er = !1;

function qr(e, t) {
	if (e === t) return !0;
	if (null !== e && null !== t && "object" == typeof e && "object" == typeof t) {
		if (e.constructor !== t.constructor) return !1;
		let n, o;
		if (e.constructor === Array) {
			if (n = e.length, n !== t.length) return !1;
			for (o = n; 0 != o--;)
				if (!0 !== qr(e[o], t[o])) return !1;
			return !0
		}
		if (e.constructor === Map) {
			if (e.size !== t.size) return !1;
			let n = e.entries();
			for (o = n.next(); !0 !== o.done;) {
				if (!0 !== t.has(o.value[0])) return !1;
				o = n.next()
			}
			for (n = e.entries(), o = n.next(); !0 !== o.done;) {
				if (!0 !== qr(o.value[1], t.get(o.value[0]))) return !1;
				o = n.next()
			}
			return !0
		}
		if (e.constructor === Set) {
			if (e.size !== t.size) return !1;
			const n = e.entries();
			for (o = n.next(); !0 !== o.done;) {
				if (!0 !== t.has(o.value[0])) return !1;
				o = n.next()
			}
			return !0
		}
		if (null != e.buffer && e.buffer.constructor === ArrayBuffer) {
			if (n = e.length, n !== t.length) return !1;
			for (o = n; 0 != o--;)
				if (e[o] !== t[o]) return !1;
			return !0
		}
		if (e.constructor === RegExp) return e.source === t.source && e.flags === t.flags;
		if (e.valueOf !== Object.prototype.valueOf) return e.valueOf() === t.valueOf();
		if (e.toString !== Object.prototype.toString) return e.toString() === t.toString();
		const l = Object.keys(e).filter((t => void 0 !== e[t]));
		if (n = l.length, n !== Object.keys(t).filter((e => void 0 !== t[e])).length) return !1;
		for (o = n; 0 != o--;) {
			const n = l[o];
			if (!0 !== qr(e[n], t[n])) return !1
		}
		return !0
	}
	return e != e && t != t
}

function Lr(e) {
	return null !== e && "object" == typeof e && !0 !== Array.isArray(e)
}

function Fr(e) {
	return "[object Date]" === Object.prototype.toString.call(e)
}

function Rr(e) {
	return "number" == typeof e && isFinite(e)
}
const Or = [Ka, wr, ir, rr, dr, vr, Sr];

function Tr(e, t) {
	t.forEach((t => {
		t.install(e), t.__installed = !0
	}))
}
var Pr = {
		version: "2.11.5",
		install: function(e, t = {}) {
			const n = {
				version: "2.11.5"
			};
			var o, l, a;
			!1 === Er ? (void 0 !== t.config && Object.assign(Cr, t.config), n.config = {
				...Cr
			}, Er = !0) : n.config = t.config || {}, o = e, l = t, a = {
				parentApp: e,
				$q: n,
				lang: t.lang,
				iconSet: t.iconSet,
				onSSRHydrated: []
			}, o.config.globalProperties.$q = a.$q, o.provide("_q_", a.$q), Tr(a, Or), void 0 !== l.components && Object.values(l.components).forEach((e => {
				!0 === Lr(e) && void 0 !== e.name && o.component(e.name, e)
			})), void 0 !== l.directives && Object.values(l.directives).forEach((e => {
				!0 === Lr(e) && void 0 !== e.name && o.directive(e.name, e)
			})), void 0 !== l.plugins && Tr(a, Object.values(l.plugins).filter((e => "function" == typeof e.install && !1 === Or.includes(e)))), !0 === Na.value && (a.$q.onSSRHydrated = () => {
				a.onSSRHydrated.forEach((e => {
					e()
				})), a.$q.onSSRHydrated = () => {}
			})
		},
		lang: vr,
		iconSet: Sr
	},
	Ar = (e, t) => {
		const n = e.__vccOpts || e;
		for (const [o, l] of t) n[o] = l;
		return n
	};
var Vr = Ar({}, [
	["render", function(e, t) {
		const n = Jn("router-view");
		return Xo(), ll(n)
	}]
]);
/*!
 * pinia v2.0.28
 * (c) 2022 Eduardo San Martin Morote
 * @license MIT
 */
const Mr = Symbol();
var Br, Ir;
(Ir = Br || (Br = {})).direct = "direct", Ir.patchObject = "patch object", Ir.patchFunction = "patch function";
var $r = () => function() {
	const e = ee(!0),
		t = e.run((() => yt({})));
	let n = [],
		o = [];
	const l = ft({
		install(e) {
			l._a = e, e.provide(Mr, l), e.config.globalProperties.$pinia = l, o.forEach((e => n.push(e))), o = []
		},
		use(e) {
			return this._a ? n.push(e) : o.push(e), this
		},
		_p: n,
		_a: null,
		_e: e,
		_s: new Map,
		state: t
	});
	return l
}();
/*!
 * vue-router v4.1.6
 * (c) 2022 Eduardo San Martin Morote
 * @license MIT
 */
const zr = "undefined" != typeof window;
const Nr = Object.assign;

function jr(e, t) {
	const n = {};
	for (const o in t) {
		const l = t[o];
		n[o] = Ur(l) ? l.map(e) : e(l)
	}
	return n
}
const Dr = () => {},
	Ur = Array.isArray,
	Hr = /\/$/;

function Wr(e, t, n = "/") {
	let o, l = {},
		a = "",
		r = "";
	const i = t.indexOf("#");
	let s = t.indexOf("?");
	return i < s && i >= 0 && (s = -1), s > -1 && (o = t.slice(0, s), a = t.slice(s + 1, i > -1 ? i : t.length), l = e(a)), i > -1 && (o = o || t.slice(0, i), r = t.slice(i, t.length)), o = function(e, t) {
		if (e.startsWith("/")) return e;
		if (!e) return t;
		const n = t.split("/"),
			o = e.split("/");
		let l, a, r = n.length - 1;
		for (l = 0; l < o.length; l++)
			if (a = o[l], "." !== a) {
				if (".." !== a) break;
				r > 1 && r--
			} return n.slice(0, r).join("/") + "/" + o.slice(l - (l === o.length ? 1 : 0)).join("/")
	}(null != o ? o : t, n), {
		fullPath: o + (a && "?") + a + r,
		path: o,
		query: l,
		hash: r
	}
}

function Kr(e, t) {
	return t && e.toLowerCase().startsWith(t.toLowerCase()) ? e.slice(t.length) || "/" : e
}

function Qr(e, t) {
	return (e.aliasOf || e) === (t.aliasOf || t)
}

function Gr(e, t) {
	if (Object.keys(e).length !== Object.keys(t).length) return !1;
	for (const n in e)
		if (!Zr(e[n], t[n])) return !1;
	return !0
}

function Zr(e, t) {
	return Ur(e) ? Jr(e, t) : Ur(t) ? Jr(t, e) : e === t
}

function Jr(e, t) {
	return Ur(t) ? e.length === t.length && e.every(((e, n) => e === t[n])) : 1 === e.length && e[0] === t
}
var Xr, Yr, ei, ti;

function ni(e) {
	if (!e)
		if (zr) {
			const t = document.querySelector("base");
			e = (e = t && t.getAttribute("href") || "/").replace(/^\w+:\/\/[^\/]+/, "")
		} else e = "/";
	return "/" !== e[0] && "#" !== e[0] && (e = "/" + e), e.replace(Hr, "")
}(Yr = Xr || (Xr = {})).pop = "pop", Yr.push = "push", (ti = ei || (ei = {})).back = "back", ti.forward = "forward", ti.unknown = "";
const oi = /^[^#]+#/;

function li(e, t) {
	return e.replace(oi, "#") + t
}
const ai = () => ({
	left: window.pageXOffset,
	top: window.pageYOffset
});

function ri(e) {
	let t;
	if ("el" in e) {
		const n = e.el,
			o = "string" == typeof n && n.startsWith("#"),
			l = "string" == typeof n ? o ? document.getElementById(n.slice(1)) : document.querySelector(n) : n;
		if (!l) return;
		t = function(e, t) {
			const n = document.documentElement.getBoundingClientRect(),
				o = e.getBoundingClientRect();
			return {
				behavior: t.behavior,
				left: o.left - n.left - (t.left || 0),
				top: o.top - n.top - (t.top || 0)
			}
		}(l, e)
	} else t = e;
	"scrollBehavior" in document.documentElement.style ? window.scrollTo(t) : window.scrollTo(null != t.left ? t.left : window.pageXOffset, null != t.top ? t.top : window.pageYOffset)
}

function ii(e, t) {
	return (history.state ? history.state.position - t : -1) + e
}
const si = new Map;

function ui(e, t) {
	const {
		pathname: n,
		search: o,
		hash: l
	} = t, a = e.indexOf("#");
	if (a > -1) {
		let t = l.includes(e.slice(a)) ? e.slice(a).length : 1,
			n = l.slice(t);
		return "/" !== n[0] && (n = "/" + n), Kr(n, "")
	}
	return Kr(n, e) + o + l
}

function ci(e, t, n, o = !1, l = !1) {
	return {
		back: e,
		current: t,
		forward: n,
		replaced: o,
		position: window.history.length,
		scroll: l ? ai() : null
	}
}

function di(e) {
	const {
		history: t,
		location: n
	} = window, o = {
		value: ui(e, n)
	}, l = {
		value: t.state
	};

	function a(o, a, r) {
		const i = e.indexOf("#"),
			s = i > -1 ? (n.host && document.querySelector("base") ? e : e.slice(i)) + o : location.protocol + "//" + location.host + e + o;
		try {
			t[r ? "replaceState" : "pushState"](a, "", s), l.value = a
		} catch (u) {
			console.error(u), n[r ? "replace" : "assign"](s)
		}
	}
	return l.value || a(o.value, {
		back: null,
		current: o.value,
		forward: null,
		position: t.length - 1,
		replaced: !0,
		scroll: null
	}, !0), {
		location: o,
		state: l,
		push: function(e, n) {
			const r = Nr({}, l.value, t.state, {
				forward: e,
				scroll: ai()
			});
			a(r.current, r, !0), a(e, Nr({}, ci(o.value, e, null), {
				position: r.position + 1
			}, n), !1), o.value = e
		},
		replace: function(e, n) {
			a(e, Nr({}, t.state, ci(l.value.back, e, l.value.forward, !0), n, {
				position: l.value.position
			}), !0), o.value = e
		}
	}
}

function pi(e) {
	const t = di(e = ni(e)),
		n = function(e, t, n, o) {
			let l = [],
				a = [],
				r = null;
			const i = ({
				state: a
			}) => {
				const i = ui(e, location),
					s = n.value,
					u = t.value;
				let c = 0;
				if (a) {
					if (n.value = i, t.value = a, r && r === s) return void(r = null);
					c = u ? a.position - u.position : 0
				} else o(i);
				l.forEach((e => {
					e(n.value, s, {
						delta: c,
						type: Xr.pop,
						direction: c ? c > 0 ? ei.forward : ei.back : ei.unknown
					})
				}))
			};

			function s() {
				const {
					history: e
				} = window;
				e.state && e.replaceState(Nr({}, e.state, {
					scroll: ai()
				}), "")
			}
			return window.addEventListener("popstate", i), window.addEventListener("beforeunload", s), {
				pauseListeners: function() {
					r = n.value
				},
				listen: function(e) {
					l.push(e);
					const t = () => {
						const t = l.indexOf(e);
						t > -1 && l.splice(t, 1)
					};
					return a.push(t), t
				},
				destroy: function() {
					for (const e of a) e();
					a = [], window.removeEventListener("popstate", i), window.removeEventListener("beforeunload", s)
				}
			}
		}(e, t.state, t.location, t.replace);
	const o = Nr({
		location: "",
		base: e,
		go: function(e, t = !0) {
			t || n.pauseListeners(), history.go(e)
		},
		createHref: li.bind(null, e)
	}, t, n);
	return Object.defineProperty(o, "location", {
		enumerable: !0,
		get: () => t.location.value
	}), Object.defineProperty(o, "state", {
		enumerable: !0,
		get: () => t.state.value
	}), o
}

function fi(e) {
	return (e = location.host ? e || location.pathname + location.search : "").includes("#") || (e += "#"), pi(e)
}

function vi(e) {
	return "string" == typeof e || "symbol" == typeof e
}
const hi = {
		path: "/",
		name: void 0,
		params: {},
		query: {},
		hash: "",
		fullPath: "/",
		matched: [],
		meta: {},
		redirectedFrom: void 0
	},
	mi = Symbol("");
var gi, bi;

function yi(e, t) {
	return Nr(new Error, {
		type: e,
		[mi]: !0
	}, t)
}

function _i(e, t) {
	return e instanceof Error && mi in e && (null == t || !!(e.type & t))
}(bi = gi || (gi = {}))[bi.aborted = 4] = "aborted", bi[bi.cancelled = 8] = "cancelled", bi[bi.duplicated = 16] = "duplicated";
const wi = {
		sensitive: !1,
		strict: !1,
		start: !0,
		end: !0
	},
	ki = /[.+*?^${}()[\]/\\]/g;

function Si(e, t) {
	let n = 0;
	for (; n < e.length && n < t.length;) {
		const o = t[n] - e[n];
		if (o) return o;
		n++
	}
	return e.length < t.length ? 1 === e.length && 80 === e[0] ? -1 : 1 : e.length > t.length ? 1 === t.length && 80 === t[0] ? 1 : -1 : 0
}

function xi(e, t) {
	let n = 0;
	const o = e.score,
		l = t.score;
	for (; n < o.length && n < l.length;) {
		const e = Si(o[n], l[n]);
		if (e) return e;
		n++
	}
	if (1 === Math.abs(l.length - o.length)) {
		if (Ci(o)) return 1;
		if (Ci(l)) return -1
	}
	return l.length - o.length
}

function Ci(e) {
	const t = e[e.length - 1];
	return e.length > 0 && t[t.length - 1] < 0
}
const Ei = {
		type: 0,
		value: ""
	},
	qi = /[a-zA-Z0-9_]/;

function Li(e, t, n) {
	const o = function(e, t) {
			const n = Nr({}, wi, t),
				o = [];
			let l = n.start ? "^" : "";
			const a = [];
			for (const s of e) {
				const e = s.length ? [] : [90];
				n.strict && !s.length && (l += "/");
				for (let t = 0; t < s.length; t++) {
					const o = s[t];
					let r = 40 + (n.sensitive ? .25 : 0);
					if (0 === o.type) t || (l += "/"), l += o.value.replace(ki, "\\$&"), r += 40;
					else if (1 === o.type) {
						const {
							value: e,
							repeatable: n,
							optional: u,
							regexp: c
						} = o;
						a.push({
							name: e,
							repeatable: n,
							optional: u
						});
						const d = c || "[^/]+?";
						if ("[^/]+?" !== d) {
							r += 10;
							try {
								new RegExp(`(${d})`)
							} catch (i) {
								throw new Error(`Invalid custom RegExp for param "${e}" (${d}): ` + i.message)
							}
						}
						let p = n ? `((?:${d})(?:/(?:${d}))*)` : `(${d})`;
						t || (p = u && s.length < 2 ? `(?:/${p})` : "/" + p), u && (p += "?"), l += p, r += 20, u && (r += -8), n && (r += -20), ".*" === d && (r += -50)
					}
					e.push(r)
				}
				o.push(e)
			}
			if (n.strict && n.end) {
				const e = o.length - 1;
				o[e][o[e].length - 1] += .7000000000000001
			}
			n.strict || (l += "/?"), n.end ? l += "$" : n.strict && (l += "(?:/|$)");
			const r = new RegExp(l, n.sensitive ? "" : "i");
			return {
				re: r,
				score: o,
				keys: a,
				parse: function(e) {
					const t = e.match(r),
						n = {};
					if (!t) return null;
					for (let o = 1; o < t.length; o++) {
						const e = t[o] || "",
							l = a[o - 1];
						n[l.name] = e && l.repeatable ? e.split("/") : e
					}
					return n
				},
				stringify: function(t) {
					let n = "",
						o = !1;
					for (const l of e) {
						o && n.endsWith("/") || (n += "/"), o = !1;
						for (const e of l)
							if (0 === e.type) n += e.value;
							else if (1 === e.type) {
							const {
								value: a,
								repeatable: r,
								optional: i
							} = e, s = a in t ? t[a] : "";
							if (Ur(s) && !r) throw new Error(`Provided param "${a}" is an array but it is not repeatable (* or + modifiers)`);
							const u = Ur(s) ? s.join("/") : s;
							if (!u) {
								if (!i) throw new Error(`Missing required param "${a}"`);
								l.length < 2 && (n.endsWith("/") ? n = n.slice(0, -1) : o = !0)
							}
							n += u
						}
					}
					return n || "/"
				}
			}
		}(function(e) {
			if (!e) return [
				[]
			];
			if ("/" === e) return [
				[Ei]
			];
			if (!e.startsWith("/")) throw new Error(`Invalid path "${e}"`);

			function t(e) {
				throw new Error(`ERR (${n})/"${u}": ${e}`)
			}
			let n = 0,
				o = n;
			const l = [];
			let a;

			function r() {
				a && l.push(a), a = []
			}
			let i, s = 0,
				u = "",
				c = "";

			function d() {
				u && (0 === n ? a.push({
					type: 0,
					value: u
				}) : 1 === n || 2 === n || 3 === n ? (a.length > 1 && ("*" === i || "+" === i) && t(`A repeatable param (${u}) must be alone in its segment. eg: '/:ids+.`), a.push({
					type: 1,
					value: u,
					regexp: c,
					repeatable: "*" === i || "+" === i,
					optional: "*" === i || "?" === i
				})) : t("Invalid state to consume buffer"), u = "")
			}

			function p() {
				u += i
			}
			for (; s < e.length;)
				if (i = e[s++], "\\" !== i || 2 === n) switch (n) {
					case 0:
						"/" === i ? (u && d(), r()) : ":" === i ? (d(), n = 1) : p();
						break;
					case 4:
						p(), n = o;
						break;
					case 1:
						"(" === i ? n = 2 : qi.test(i) ? p() : (d(), n = 0, "*" !== i && "?" !== i && "+" !== i && s--);
						break;
					case 2:
						")" === i ? "\\" == c[c.length - 1] ? c = c.slice(0, -1) + i : n = 3 : c += i;
						break;
					case 3:
						d(), n = 0, "*" !== i && "?" !== i && "+" !== i && s--, c = "";
						break;
					default:
						t("Unknown state")
				} else o = n, n = 4;
			return 2 === n && t(`Unfinished custom RegExp for param "${u}"`), d(), r(), l
		}(e.path), n),
		l = Nr(o, {
			record: e,
			parent: t,
			children: [],
			alias: []
		});
	return t && !l.record.aliasOf == !t.record.aliasOf && t.children.push(l), l
}

function Fi(e, t) {
	const n = [],
		o = new Map;

	function l(e, n, o) {
		const i = !o,
			s = function(e) {
				return {
					path: e.path,
					redirect: e.redirect,
					name: e.name,
					meta: e.meta || {},
					aliasOf: void 0,
					beforeEnter: e.beforeEnter,
					props: Oi(e),
					children: e.children || [],
					instances: {},
					leaveGuards: new Set,
					updateGuards: new Set,
					enterCallbacks: {},
					components: "components" in e ? e.components || null : e.component && {
						default: e.component
					}
				}
			}(e);
		s.aliasOf = o && o.record;
		const u = Ai(t, e),
			c = [s];
		if ("alias" in e) {
			const t = "string" == typeof e.alias ? [e.alias] : e.alias;
			for (const e of t) c.push(Nr({}, s, {
				components: o ? o.record.components : s.components,
				path: e,
				aliasOf: o ? o.record : s
			}))
		}
		let d, p;
		for (const t of c) {
			const {
				path: c
			} = t;
			if (n && "/" !== c[0]) {
				const e = n.record.path,
					o = "/" === e[e.length - 1] ? "" : "/";
				t.path = n.record.path + (c && o + c)
			}
			if (d = Li(t, n, u), o ? o.alias.push(d) : (p = p || d, p !== d && p.alias.push(d), i && e.name && !Ti(d) && a(e.name)), s.children) {
				const e = s.children;
				for (let t = 0; t < e.length; t++) l(e[t], d, o && o.children[t])
			}
			o = o || d, (d.record.components && Object.keys(d.record.components).length || d.record.name || d.record.redirect) && r(d)
		}
		return p ? () => {
			a(p)
		} : Dr
	}

	function a(e) {
		if (vi(e)) {
			const t = o.get(e);
			t && (o.delete(e), n.splice(n.indexOf(t), 1), t.children.forEach(a), t.alias.forEach(a))
		} else {
			const t = n.indexOf(e);
			t > -1 && (n.splice(t, 1), e.record.name && o.delete(e.record.name), e.children.forEach(a), e.alias.forEach(a))
		}
	}

	function r(e) {
		let t = 0;
		for (; t < n.length && xi(e, n[t]) >= 0 && (e.record.path !== n[t].record.path || !Vi(e, n[t]));) t++;
		n.splice(t, 0, e), e.record.name && !Ti(e) && o.set(e.record.name, e)
	}
	return t = Ai({
		strict: !1,
		end: !0,
		sensitive: !1
	}, t), e.forEach((e => l(e))), {
		addRoute: l,
		resolve: function(e, t) {
			let l, a, r, i = {};
			if ("name" in e && e.name) {
				if (l = o.get(e.name), !l) throw yi(1, {
					location: e
				});
				r = l.record.name, i = Nr(Ri(t.params, l.keys.filter((e => !e.optional)).map((e => e.name))), e.params && Ri(e.params, l.keys.map((e => e.name)))), a = l.stringify(i)
			} else if ("path" in e) a = e.path, l = n.find((e => e.re.test(a))), l && (i = l.parse(a), r = l.record.name);
			else {
				if (l = t.name ? o.get(t.name) : n.find((e => e.re.test(t.path))), !l) throw yi(1, {
					location: e,
					currentLocation: t
				});
				r = l.record.name, i = Nr({}, t.params, e.params), a = l.stringify(i)
			}
			const s = [];
			let u = l;
			for (; u;) s.unshift(u.record), u = u.parent;
			return {
				name: r,
				path: a,
				params: i,
				matched: s,
				meta: Pi(s)
			}
		},
		removeRoute: a,
		getRoutes: function() {
			return n
		},
		getRecordMatcher: function(e) {
			return o.get(e)
		}
	}
}

function Ri(e, t) {
	const n = {};
	for (const o of t) o in e && (n[o] = e[o]);
	return n
}

function Oi(e) {
	const t = {},
		n = e.props || !1;
	if ("component" in e) t.default = n;
	else
		for (const o in e.components) t[o] = "boolean" == typeof n ? n : n[o];
	return t
}

function Ti(e) {
	for (; e;) {
		if (e.record.aliasOf) return !0;
		e = e.parent
	}
	return !1
}

function Pi(e) {
	return e.reduce(((e, t) => Nr(e, t.meta)), {})
}

function Ai(e, t) {
	const n = {};
	for (const o in e) n[o] = o in t ? t[o] : e[o];
	return n
}

function Vi(e, t) {
	return t.children.some((t => t === e || Vi(e, t)))
}
const Mi = /#/g,
	Bi = /&/g,
	Ii = /\//g,
	$i = /=/g,
	zi = /\?/g,
	Ni = /\+/g,
	ji = /%5B/g,
	Di = /%5D/g,
	Ui = /%5E/g,
	Hi = /%60/g,
	Wi = /%7B/g,
	Ki = /%7C/g,
	Qi = /%7D/g,
	Gi = /%20/g;

function Zi(e) {
	return encodeURI("" + e).replace(Ki, "|").replace(ji, "[").replace(Di, "]")
}

function Ji(e) {
	return Zi(e).replace(Ni, "%2B").replace(Gi, "+").replace(Mi, "%23").replace(Bi, "%26").replace(Hi, "`").replace(Wi, "{").replace(Qi, "}").replace(Ui, "^")
}

function Xi(e) {
	return null == e ? "" : function(e) {
		return Zi(e).replace(Mi, "%23").replace(zi, "%3F")
	}(e).replace(Ii, "%2F")
}

function Yi(e) {
	try {
		return decodeURIComponent("" + e)
	} catch (t) {}
	return "" + e
}

function es(e) {
	const t = {};
	if ("" === e || "?" === e) return t;
	const n = ("?" === e[0] ? e.slice(1) : e).split("&");
	for (let o = 0; o < n.length; ++o) {
		const e = n[o].replace(Ni, " "),
			l = e.indexOf("="),
			a = Yi(l < 0 ? e : e.slice(0, l)),
			r = l < 0 ? null : Yi(e.slice(l + 1));
		if (a in t) {
			let e = t[a];
			Ur(e) || (e = t[a] = [e]), e.push(r)
		} else t[a] = r
	}
	return t
}

function ts(e) {
	let t = "";
	for (let n in e) {
		const o = e[n];
		if (n = Ji(n).replace($i, "%3D"), null == o) {
			void 0 !== o && (t += (t.length ? "&" : "") + n);
			continue
		}(Ur(o) ? o.map((e => e && Ji(e))) : [o && Ji(o)]).forEach((e => {
			void 0 !== e && (t += (t.length ? "&" : "") + n, null != e && (t += "=" + e))
		}))
	}
	return t
}

function ns(e) {
	const t = {};
	for (const n in e) {
		const o = e[n];
		void 0 !== o && (t[n] = Ur(o) ? o.map((e => null == e ? null : "" + e)) : null == o ? o : "" + o)
	}
	return t
}
const os = Symbol(""),
	ls = Symbol(""),
	as = Symbol(""),
	rs = Symbol(""),
	is = Symbol("");

function ss() {
	let e = [];
	return {
		add: function(t) {
			return e.push(t), () => {
				const n = e.indexOf(t);
				n > -1 && e.splice(n, 1)
			}
		},
		list: () => e,
		reset: function() {
			e = []
		}
	}
}

function us(e, t, n, o, l) {
	const a = o && (o.enterCallbacks[l] = o.enterCallbacks[l] || []);
	return () => new Promise(((r, i) => {
		const s = e => {
				var s;
				!1 === e ? i(yi(4, {
					from: n,
					to: t
				})) : e instanceof Error ? i(e) : "string" == typeof(s = e) || s && "object" == typeof s ? i(yi(2, {
					from: t,
					to: e
				})) : (a && o.enterCallbacks[l] === a && "function" == typeof e && a.push(e), r())
			},
			u = e.call(o && o.instances[l], t, n, s);
		let c = Promise.resolve(u);
		e.length < 3 && (c = c.then(s)), c.catch((e => i(e)))
	}))
}

function cs(e, t, n, o) {
	const l = [];
	for (const r of e)
		for (const e in r.components) {
			let i = r.components[e];
			if ("beforeRouteEnter" === t || r.instances[e])
				if ("object" == typeof(a = i) || "displayName" in a || "props" in a || "__vccOpts" in a) {
					const a = (i.__vccOpts || i)[t];
					a && l.push(us(a, n, o, r, e))
				} else {
					let a = i();
					l.push((() => a.then((l => {
						if (!l) return Promise.reject(new Error(`Couldn't resolve component "${e}" at "${r.path}"`));
						const a = (i = l).__esModule || "Module" === i[Symbol.toStringTag] ? l.default : l;
						var i;
						r.components[e] = a;
						const s = (a.__vccOpts || a)[t];
						return s && us(s, n, o, r, e)()
					}))))
				}
		}
	var a;
	return l
}

function ds(e) {
	const t = hn(as),
		n = hn(rs),
		o = Ol((() => t.resolve(kt(e.to)))),
		l = Ol((() => {
			const {
				matched: e
			} = o.value, {
				length: t
			} = e, l = e[t - 1], a = n.matched;
			if (!l || !a.length) return -1;
			const r = a.findIndex(Qr.bind(null, l));
			if (r > -1) return r;
			const i = fs(e[t - 2]);
			return t > 1 && fs(l) === i && a[a.length - 1].path !== i ? a.findIndex(Qr.bind(null, e[t - 2])) : r
		})),
		a = Ol((() => l.value > -1 && function(e, t) {
			for (const n in t) {
				const o = t[n],
					l = e[n];
				if ("string" == typeof o) {
					if (o !== l) return !1
				} else if (!Ur(l) || l.length !== o.length || o.some(((e, t) => e !== l[t]))) return !1
			}
			return !0
		}(n.params, o.value.params))),
		r = Ol((() => l.value > -1 && l.value === n.matched.length - 1 && Gr(n.params, o.value.params)));
	return {
		route: o,
		href: Ol((() => o.value.href)),
		isActive: a,
		isExactActive: r,
		navigate: function(n = {}) {
			return function(e) {
				if (e.metaKey || e.altKey || e.ctrlKey || e.shiftKey) return;
				if (e.defaultPrevented) return;
				if (void 0 !== e.button && 0 !== e.button) return;
				if (e.currentTarget && e.currentTarget.getAttribute) {
					const t = e.currentTarget.getAttribute("target");
					if (/\b_blank\b/i.test(t)) return
				}
				e.preventDefault && e.preventDefault();
				return !0
			}(n) ? t[kt(e.replace) ? "replace" : "push"](kt(e.to)).catch(Dr) : Promise.resolve()
		}
	}
}
const ps = Rn({
	name: "RouterLink",
	compatConfig: {
		MODE: 3
	},
	props: {
		to: {
			type: [String, Object],
			required: !0
		},
		replace: Boolean,
		activeClass: String,
		exactActiveClass: String,
		custom: Boolean,
		ariaCurrentValue: {
			type: String,
			default: "page"
		}
	},
	useLink: ds,
	setup(e, {
		slots: t
	}) {
		const n = at(ds(e)),
			{
				options: o
			} = hn(as),
			l = Ol((() => ({
				[vs(e.activeClass, o.linkActiveClass, "router-link-active")]: n.isActive,
				[vs(e.exactActiveClass, o.linkExactActiveClass, "router-link-exact-active")]: n.isExactActive
			})));
		return () => {
			const o = t.default && t.default(n);
			return e.custom ? o : Tl("a", {
				"aria-current": n.isExactActive ? e.ariaCurrentValue : null,
				href: n.href,
				onClick: n.navigate,
				class: l.value
			}, o)
		}
	}
});

function fs(e) {
	return e ? e.aliasOf ? e.aliasOf.path : e.path : ""
}
const vs = (e, t, n) => null != e ? e : null != t ? t : n;

function hs(e, t) {
	if (!e) return null;
	const n = e(t);
	return 1 === n.length ? n[0] : n
}
const ms = Rn({
	name: "RouterView",
	inheritAttrs: !1,
	props: {
		name: {
			type: String,
			default: "default"
		},
		route: Object
	},
	compatConfig: {
		MODE: 3
	},
	setup(e, {
		attrs: t,
		slots: n
	}) {
		const o = hn(is),
			l = Ol((() => e.route || o.value)),
			a = hn(ls, 0),
			r = Ol((() => {
				let e = kt(a);
				const {
					matched: t
				} = l.value;
				let n;
				for (;
					(n = t[e]) && !n.components;) e++;
				return e
			})),
			i = Ol((() => l.value.matched[r.value]));
		vn(ls, Ol((() => r.value + 1))), vn(os, i), vn(is, l);
		const s = yt();
		return gn((() => [s.value, i.value, e.name]), (([e, t, n], [o, l, a]) => {
			t && (t.instances[n] = e, l && l !== t && e && e === o && (t.leaveGuards.size || (t.leaveGuards = l.leaveGuards), t.updateGuards.size || (t.updateGuards = l.updateGuards))), !e || !t || l && Qr(t, l) && o || (t.enterCallbacks[n] || []).forEach((t => t(e)))
		}), {
			flush: "post"
		}), () => {
			const o = l.value,
				a = e.name,
				r = i.value,
				u = r && r.components[a];
			if (!u) return hs(n.default, {
				Component: u,
				route: o
			});
			const c = r.props[a],
				d = c ? !0 === c ? o.params : "function" == typeof c ? c(o) : c : null,
				p = Tl(u, Nr({}, d, t, {
					onVnodeUnmounted: e => {
						e.component.isUnmounted && (r.instances[a] = null)
					},
					ref: s
				}));
			return hs(n.default, {
				Component: p,
				route: o
			}) || p
		}
	}
});

function gs(e) {
	const t = Fi(e.routes, e),
		n = e.parseQuery || es,
		o = e.stringifyQuery || ts,
		l = e.history,
		a = ss(),
		r = ss(),
		i = ss(),
		s = _t(hi, !0);
	let u = hi;
	zr && e.scrollBehavior && "scrollRestoration" in history && (history.scrollRestoration = "manual");
	const c = jr.bind(null, (e => "" + e)),
		d = jr.bind(null, Xi),
		p = jr.bind(null, Yi);

	function f(e, a) {
		if (a = Nr({}, a || s.value), "string" == typeof e) {
			const o = Wr(n, e, a.path),
				r = t.resolve({
					path: o.path
				}, a),
				i = l.createHref(o.fullPath);
			return Nr(o, r, {
				params: p(r.params),
				hash: Yi(o.hash),
				redirectedFrom: void 0,
				href: i
			})
		}
		let r;
		if ("path" in e) r = Nr({}, e, {
			path: Wr(n, e.path, a.path).path
		});
		else {
			const t = Nr({}, e.params);
			for (const e in t) null == t[e] && delete t[e];
			r = Nr({}, e, {
				params: d(e.params)
			}), a.params = d(a.params)
		}
		const i = t.resolve(r, a),
			u = e.hash || "";
		i.params = c(p(i.params));
		const f = function(e, t) {
			const n = t.query ? e(t.query) : "";
			return t.path + (n && "?") + n + (t.hash || "")
		}(o, Nr({}, e, {
			hash: (v = u, Zi(v).replace(Wi, "{").replace(Qi, "}").replace(Ui, "^")),
			path: i.path
		}));
		var v;
		const h = l.createHref(f);
		return Nr({
			fullPath: f,
			hash: u,
			query: o === ts ? ns(e.query) : e.query || {}
		}, i, {
			redirectedFrom: void 0,
			href: h
		})
	}

	function v(e) {
		return "string" == typeof e ? Wr(n, e, s.value.path) : Nr({}, e)
	}

	function h(e, t) {
		if (u !== e) return yi(8, {
			from: t,
			to: e
		})
	}

	function m(e) {
		return b(e)
	}

	function g(e) {
		const t = e.matched[e.matched.length - 1];
		if (t && t.redirect) {
			const {
				redirect: n
			} = t;
			let o = "function" == typeof n ? n(e) : n;
			return "string" == typeof o && (o = o.includes("?") || o.includes("#") ? o = v(o) : {
				path: o
			}, o.params = {}), Nr({
				query: e.query,
				hash: e.hash,
				params: "path" in o ? {} : e.params
			}, o)
		}
	}

	function b(e, t) {
		const n = u = f(e),
			l = s.value,
			a = e.state,
			r = e.force,
			i = !0 === e.replace,
			c = g(n);
		if (c) return b(Nr(v(c), {
			state: "object" == typeof c ? Nr({}, a, c.state) : a,
			force: r,
			replace: i
		}), t || n);
		const d = n;
		let p;
		return d.redirectedFrom = t, !r && function(e, t, n) {
			const o = t.matched.length - 1,
				l = n.matched.length - 1;
			return o > -1 && o === l && Qr(t.matched[o], n.matched[l]) && Gr(t.params, n.params) && e(t.query) === e(n.query) && t.hash === n.hash
		}(o, l, n) && (p = yi(16, {
			to: d,
			from: l
		}), R(l, l, !0, !1)), (p ? Promise.resolve(p) : _(d, l)).catch((e => _i(e) ? _i(e, 2) ? e : F(e) : L(e, d, l))).then((e => {
			if (e) {
				if (_i(e, 2)) return b(Nr({
					replace: i
				}, v(e.to), {
					state: "object" == typeof e.to ? Nr({}, a, e.to.state) : a,
					force: r
				}), t || d)
			} else e = k(d, l, !0, i, a);
			return w(d, l, e), e
		}))
	}

	function y(e, t) {
		const n = h(e, t);
		return n ? Promise.reject(n) : Promise.resolve()
	}

	function _(e, t) {
		let n;
		const [o, l, i] = function(e, t) {
			const n = [],
				o = [],
				l = [],
				a = Math.max(t.matched.length, e.matched.length);
			for (let r = 0; r < a; r++) {
				const a = t.matched[r];
				a && (e.matched.find((e => Qr(e, a))) ? o.push(a) : n.push(a));
				const i = e.matched[r];
				i && (t.matched.find((e => Qr(e, i))) || l.push(i))
			}
			return [n, o, l]
		}(e, t);
		n = cs(o.reverse(), "beforeRouteLeave", e, t);
		for (const a of o) a.leaveGuards.forEach((o => {
			n.push(us(o, e, t))
		}));
		const s = y.bind(null, e, t);
		return n.push(s), bs(n).then((() => {
			n = [];
			for (const o of a.list()) n.push(us(o, e, t));
			return n.push(s), bs(n)
		})).then((() => {
			n = cs(l, "beforeRouteUpdate", e, t);
			for (const o of l) o.updateGuards.forEach((o => {
				n.push(us(o, e, t))
			}));
			return n.push(s), bs(n)
		})).then((() => {
			n = [];
			for (const o of e.matched)
				if (o.beforeEnter && !t.matched.includes(o))
					if (Ur(o.beforeEnter))
						for (const l of o.beforeEnter) n.push(us(l, e, t));
					else n.push(us(o.beforeEnter, e, t));
			return n.push(s), bs(n)
		})).then((() => (e.matched.forEach((e => e.enterCallbacks = {})), n = cs(i, "beforeRouteEnter", e, t), n.push(s), bs(n)))).then((() => {
			n = [];
			for (const o of r.list()) n.push(us(o, e, t));
			return n.push(s), bs(n)
		})).catch((e => _i(e, 8) ? e : Promise.reject(e)))
	}

	function w(e, t, n) {
		for (const o of i.list()) o(e, t, n)
	}

	function k(e, t, n, o, a) {
		const r = h(e, t);
		if (r) return r;
		const i = t === hi,
			u = zr ? history.state : {};
		n && (o || i ? l.replace(e.fullPath, Nr({
			scroll: i && u && u.scroll
		}, a)) : l.push(e.fullPath, a)), s.value = e, R(e, t, n, i), F()
	}
	let S;

	function x() {
		S || (S = l.listen(((e, t, n) => {
			if (!A.listening) return;
			const o = f(e),
				a = g(o);
			if (a) return void b(Nr(a, {
				replace: !0
			}), o).catch(Dr);
			u = o;
			const r = s.value;
			var i, c;
			zr && (i = ii(r.fullPath, n.delta), c = ai(), si.set(i, c)), _(o, r).catch((e => _i(e, 12) ? e : _i(e, 2) ? (b(e.to, o).then((e => {
				_i(e, 20) && !n.delta && n.type === Xr.pop && l.go(-1, !1)
			})).catch(Dr), Promise.reject()) : (n.delta && l.go(-n.delta, !1), L(e, o, r)))).then((e => {
				(e = e || k(o, r, !1)) && (n.delta && !_i(e, 8) ? l.go(-n.delta, !1) : n.type === Xr.pop && _i(e, 20) && l.go(-1, !1)), w(o, r, e)
			})).catch(Dr)
		})))
	}
	let C, E = ss(),
		q = ss();

	function L(e, t, n) {
		F(e);
		const o = q.list();
		return o.length ? o.forEach((o => o(e, t, n))) : console.error(e), Promise.reject(e)
	}

	function F(e) {
		return C || (C = !e, x(), E.list().forEach((([t, n]) => e ? n(e) : t())), E.reset()), e
	}

	function R(t, n, o, l) {
		const {
			scrollBehavior: a
		} = e;
		if (!zr || !a) return Promise.resolve();
		const r = !o && function(e) {
			const t = si.get(e);
			return si.delete(e), t
		}(ii(t.fullPath, 0)) || (l || !o) && history.state && history.state.scroll || null;
		return $t().then((() => a(t, n, r))).then((e => e && ri(e))).catch((e => L(e, t, n)))
	}
	const O = e => l.go(e);
	let T;
	const P = new Set,
		A = {
			currentRoute: s,
			listening: !0,
			addRoute: function(e, n) {
				let o, l;
				return vi(e) ? (o = t.getRecordMatcher(e), l = n) : l = e, t.addRoute(l, o)
			},
			removeRoute: function(e) {
				const n = t.getRecordMatcher(e);
				n && t.removeRoute(n)
			},
			hasRoute: function(e) {
				return !!t.getRecordMatcher(e)
			},
			getRoutes: function() {
				return t.getRoutes().map((e => e.record))
			},
			resolve: f,
			options: e,
			push: m,
			replace: function(e) {
				return m(Nr(v(e), {
					replace: !0
				}))
			},
			go: O,
			back: () => O(-1),
			forward: () => O(1),
			beforeEach: a.add,
			beforeResolve: r.add,
			afterEach: i.add,
			onError: q.add,
			isReady: function() {
				return C && s.value !== hi ? Promise.resolve() : new Promise(((e, t) => {
					E.add([e, t])
				}))
			},
			install(e) {
				e.component("RouterLink", ps), e.component("RouterView", ms), e.config.globalProperties.$router = this, Object.defineProperty(e.config.globalProperties, "$route", {
					enumerable: !0,
					get: () => kt(s)
				}), zr && !T && s.value === hi && (T = !0, m(l.location).catch((e => {})));
				const t = {};
				for (const o in hi) t[o] = Ol((() => s.value[o]));
				e.provide(as, this), e.provide(rs, at(t)), e.provide(is, s);
				const n = e.unmount;
				P.add(e), e.unmount = function() {
					P.delete(e), P.size < 1 && (u = hi, S && S(), S = null, s.value = hi, T = !1, C = !1), n()
				}
			}
		};
	return A
}

function bs(e) {
	return e.reduce(((e, t) => e.then((() => t()))), Promise.resolve())
}
const ys = e => ft(Rn(e)),
	_s = "undefined" != typeof ResizeObserver,
	ws = !0 === _s ? {} : {
		style: "display:block;position:absolute;top:0;left:0;right:0;bottom:0;height:100%;width:100%;overflow:hidden;pointer-events:none;z-index:-1;",
		url: "about:blank"
	};
var ks = ys({
	name: "QResizeObserver",
	props: {
		debounce: {
			type: [String, Number],
			default: 100
		}
	},
	emits: ["resize"],
	setup(e, {
		emit: t
	}) {
		let n, o = null,
			l = {
				width: -1,
				height: -1
			};

		function a(t) {
			!0 === t || 0 === e.debounce || "0" === e.debounce ? r() : null === o && (o = setTimeout(r, e.debounce))
		}

		function r() {
			if (null !== o && (clearTimeout(o), o = null), n) {
				const {
					offsetWidth: e,
					offsetHeight: o
				} = n;
				e === l.width && o === l.height || (l = {
					width: e,
					height: o
				}, t("resize", l))
			}
		}
		const {
			proxy: i
		} = Sl();
		if (!0 === _s) {
			let e;
			const t = o => {
				n = i.$el.parentNode, n ? (e = new ResizeObserver(a), e.observe(n), r()) : !0 !== o && $t((() => {
					t(!0)
				}))
			};
			return zn((() => {
				t()
			})), Dn((() => {
				null !== o && clearTimeout(o), void 0 !== e && (void 0 !== e.disconnect ? e.disconnect() : n && e.unobserve(n))
			})), Za
		} {
			let e = function() {
					null !== o && (clearTimeout(o), o = null), void 0 !== s && (void 0 !== s.removeEventListener && s.removeEventListener("resize", a, Ga.passive), s = void 0)
				},
				t = function() {
					e(), n && n.contentDocument && (s = n.contentDocument.defaultView, s.addEventListener("resize", a, Ga.passive), r())
				};
			const l = function() {
				const e = yt(!Na.value);
				return !1 === e.value && zn((() => {
					e.value = !0
				})), e
			}();
			let s;
			return zn((() => {
				$t((() => {
					n = i.$el, n && t()
				}))
			})), Dn(e), i.trigger = a, () => {
				if (!0 === l.value) return Tl("object", {
					style: ws.style,
					tabindex: -1,
					type: "text/html",
					data: ws.url,
					"aria-hidden": "true",
					onLoad: t
				})
			}
		}
	}
});

function Ss(e, t) {
	return void 0 !== e && e() || t
}

function xs(e, t) {
	if (void 0 !== e) {
		const t = e();
		if (null != t) return t.slice()
	}
	return t
}

function Cs(e, t) {
	return void 0 !== e ? t.concat(e()) : t
}
var Es = ys({
		name: "QHeader",
		props: {
			modelValue: {
				type: Boolean,
				default: !0
			},
			reveal: Boolean,
			revealOffset: {
				type: Number,
				default: 250
			},
			bordered: Boolean,
			elevated: Boolean,
			heightHint: {
				type: [String, Number],
				default: 50
			}
		},
		emits: ["reveal", "focusin"],
		setup(e, {
			slots: t,
			emit: n
		}) {
			const {
				proxy: {
					$q: o
				}
			} = Sl(), l = hn("_q_l_", xr);
			if (l === xr) return console.error("QHeader needs to be child of QLayout"), xr;
			const a = yt(parseInt(e.heightHint, 10)),
				r = yt(!0),
				i = Ol((() => !0 === e.reveal || l.view.value.indexOf("H") > -1 || o.platform.is.ios && !0 === l.isContainer.value)),
				s = Ol((() => {
					if (!0 !== e.modelValue) return 0;
					if (!0 === i.value) return !0 === r.value ? a.value : 0;
					const t = a.value - l.scroll.value.position;
					return t > 0 ? t : 0
				})),
				u = Ol((() => !0 !== e.modelValue || !0 === i.value && !0 !== r.value)),
				c = Ol((() => !0 === e.modelValue && !0 === u.value && !0 === e.reveal)),
				d = Ol((() => "q-header q-layout__section--marginal " + (!0 === i.value ? "fixed" : "absolute") + "-top" + (!0 === e.bordered ? " q-header--bordered" : "") + (!0 === u.value ? " q-header--hidden" : "") + (!0 !== e.modelValue ? " q-layout--prevent-focus" : ""))),
				p = Ol((() => {
					const e = l.rows.value.top,
						t = {};
					return "l" === e[0] && !0 === l.left.space && (t[!0 === o.lang.rtl ? "right" : "left"] = `${l.left.size}px`), "r" === e[2] && !0 === l.right.space && (t[!0 === o.lang.rtl ? "left" : "right"] = `${l.right.size}px`), t
				}));

			function f(e, t) {
				l.update("header", e, t)
			}

			function v(e, t) {
				e.value !== t && (e.value = t)
			}

			function h({
				height: e
			}) {
				v(a, e), f("size", e)
			}

			function m(e) {
				!0 === c.value && v(r, !0), n("focusin", e)
			}
			gn((() => e.modelValue), (e => {
				f("space", e), v(r, !0), l.animate()
			})), gn(s, (e => {
				f("offset", e)
			})), gn((() => e.reveal), (t => {
				!1 === t && v(r, e.modelValue)
			})), gn(r, (e => {
				l.animate(), n("reveal", e)
			})), gn(l.scroll, (t => {
				!0 === e.reveal && v(r, "up" === t.direction || t.position <= e.revealOffset || t.position - t.inflectionPoint < 100)
			}));
			const g = {};
			return l.instances.header = g, !0 === e.modelValue && f("size", a.value), f("space", e.modelValue), f("offset", s.value), Dn((() => {
				l.instances.header === g && (l.instances.header = void 0, f("size", 0), f("offset", 0), f("space", !1))
			})), () => {
				const n = xs(t.default, []);
				return !0 === e.elevated && n.push(Tl("div", {
					class: "q-layout__shadow absolute-full overflow-hidden no-pointer-events"
				})), n.push(Tl(ks, {
					debounce: 0,
					onResize: h
				})), Tl("header", {
					class: d.value,
					style: p.value,
					onFocusin: m
				}, n)
			}
		}
	}),
	qs = ys({
		name: "QPage",
		props: {
			padding: Boolean,
			styleFn: Function
		},
		setup(e, {
			slots: t
		}) {
			const {
				proxy: {
					$q: n
				}
			} = Sl(), o = hn("_q_l_", xr);
			if (o === xr) return console.error("QPage needs to be a deep child of QLayout"), xr;
			if (hn("_q_pc_", xr) === xr) return console.error("QPage needs to be child of QPageContainer"), xr;
			const l = Ol((() => {
					const t = (!0 === o.header.space ? o.header.size : 0) + (!0 === o.footer.space ? o.footer.size : 0);
					if ("function" == typeof e.styleFn) {
						const l = !0 === o.isContainer.value ? o.containerHeight.value : n.screen.height;
						return e.styleFn(t, l)
					}
					return {
						minHeight: !0 === o.isContainer.value ? o.containerHeight.value - t + "px" : 0 === n.screen.height ? 0 !== t ? `calc(100vh - ${t}px)` : "100vh" : n.screen.height - t + "px"
					}
				})),
				a = Ol((() => "q-page" + (!0 === e.padding ? " q-layout-padding" : "")));
			return () => Tl("main", {
				class: a.value,
				style: l.value
			}, Ss(t.default))
		}
	}),
	Ls = ys({
		name: "QPageContainer",
		setup(e, {
			slots: t
		}) {
			const {
				proxy: {
					$q: n
				}
			} = Sl(), o = hn("_q_l_", xr);
			if (o === xr) return console.error("QPageContainer needs to be child of QLayout"), xr;
			vn("_q_pc_", !0);
			const l = Ol((() => {
				const e = {};
				return !0 === o.header.space && (e.paddingTop = `${o.header.size}px`), !0 === o.right.space && (e["padding" + (!0 === n.lang.rtl ? "Left" : "Right")] = `${o.right.size}px`), !0 === o.footer.space && (e.paddingBottom = `${o.footer.size}px`), !0 === o.left.space && (e["padding" + (!0 === n.lang.rtl ? "Right" : "Left")] = `${o.left.size}px`), e
			}));
			return () => Tl("div", {
				class: "q-page-container",
				style: l.value
			}, Ss(t.default))
		}
	});

function Fs(e, t) {
	const n = e.style;
	for (const o in t) n[o] = t[o]
}

function Rs(e, t) {
	if (null == e || !0 === e.contains(t)) return !0;
	for (let n = e.nextElementSibling; null !== n; n = n.nextElementSibling)
		if (n.contains(t)) return !0;
	return !1
}
const Os = [null, document, document.body, document.scrollingElement, document.documentElement];

function Ts(e, t) {
	let n = function(e) {
		if (null == e) return;
		if ("string" == typeof e) try {
			return document.querySelector(e) || void 0
		} catch (n) {
			return
		}
		const t = kt(e);
		return t ? t.$el || t : void 0
	}(t);
	if (void 0 === n) {
		if (null == e) return window;
		n = e.closest(".scroll,.scroll-y,.overflow-auto")
	}
	return Os.includes(n) ? window : n
}

function Ps(e) {
	return e === window ? window.pageYOffset || window.scrollY || document.body.scrollTop || 0 : e.scrollTop
}

function As(e) {
	return e === window ? window.pageXOffset || window.scrollX || document.body.scrollLeft || 0 : e.scrollLeft
}
let Vs;

function Ms() {
	if (void 0 !== Vs) return Vs;
	const e = document.createElement("p"),
		t = document.createElement("div");
	Fs(e, {
		width: "100%",
		height: "200px"
	}), Fs(t, {
		position: "absolute",
		top: "0px",
		left: "0px",
		visibility: "hidden",
		width: "200px",
		height: "150px",
		overflow: "hidden"
	}), t.appendChild(e), document.body.appendChild(t);
	const n = e.offsetWidth;
	t.style.overflow = "scroll";
	let o = e.offsetWidth;
	return n === o && (o = t.clientWidth), t.remove(), Vs = n - o, Vs
}

function Bs(e, t = !0) {
	return !(!e || e.nodeType !== Node.ELEMENT_NODE) && (t ? e.scrollHeight > e.clientHeight && (e.classList.contains("scroll") || e.classList.contains("overflow-auto") || ["auto", "scroll"].includes(window.getComputedStyle(e)["overflow-y"])) : e.scrollWidth > e.clientWidth && (e.classList.contains("scroll") || e.classList.contains("overflow-auto") || ["auto", "scroll"].includes(window.getComputedStyle(e)["overflow-x"])))
}
const {
	passive: Is
} = Ga, $s = ["both", "horizontal", "vertical"];
var zs = ys({
		name: "QScrollObserver",
		props: {
			axis: {
				type: String,
				validator: e => $s.includes(e),
				default: "vertical"
			},
			debounce: [String, Number],
			scrollTarget: {
				default: void 0
			}
		},
		emits: ["scroll"],
		setup(e, {
			emit: t
		}) {
			const n = {
				position: {
					top: 0,
					left: 0
				},
				direction: "down",
				directionChanged: !1,
				delta: {
					top: 0,
					left: 0
				},
				inflectionPoint: {
					top: 0,
					left: 0
				}
			};
			let o, l, a = null;

			function r() {
				null !== a && a();
				const l = Math.max(0, Ps(o)),
					r = As(o),
					i = {
						top: l - n.position.top,
						left: r - n.position.left
					};
				if ("vertical" === e.axis && 0 === i.top || "horizontal" === e.axis && 0 === i.left) return;
				const s = Math.abs(i.top) >= Math.abs(i.left) ? i.top < 0 ? "up" : "down" : i.left < 0 ? "left" : "right";
				n.position = {
					top: l,
					left: r
				}, n.directionChanged = n.direction !== s, n.delta = i, !0 === n.directionChanged && (n.direction = s, n.inflectionPoint = n.position), t("scroll", {
					...n
				})
			}

			function i() {
				o = Ts(l, e.scrollTarget), o.addEventListener("scroll", u, Is), u(!0)
			}

			function s() {
				void 0 !== o && (o.removeEventListener("scroll", u, Is), o = void 0)
			}

			function u(t) {
				if (!0 === t || 0 === e.debounce || "0" === e.debounce) r();
				else if (null === a) {
					const [t, n] = e.debounce ? [setTimeout(r, e.debounce), clearTimeout] : [requestAnimationFrame(r), cancelAnimationFrame];
					a = () => {
						n(t), a = null
					}
				}
			}
			gn((() => e.scrollTarget), (() => {
				s(), i()
			}));
			const {
				proxy: c
			} = Sl();
			return gn((() => c.$q.lang.rtl), r), zn((() => {
				l = c.$el.parentNode, i()
			})), Dn((() => {
				null !== a && a(), s()
			})), Object.assign(c, {
				trigger: u,
				getPosition: () => n
			}), Za
		}
	}),
	Ns = ys({
		name: "QLayout",
		props: {
			container: Boolean,
			view: {
				type: String,
				default: "hhh lpr fff",
				validator: e => /^(h|l)h(h|r) lpr (f|l)f(f|r)$/.test(e.toLowerCase())
			},
			onScroll: Function,
			onScrollHeight: Function,
			onResize: Function
		},
		setup(e, {
			slots: t,
			emit: n
		}) {
			const {
				proxy: {
					$q: o
				}
			} = Sl(), l = yt(null), a = yt(o.screen.height), r = yt(!0 === e.container ? 0 : o.screen.width), i = yt({
				position: 0,
				direction: "down",
				inflectionPoint: 0
			}), s = yt(0), u = yt(!0 === Na.value ? 0 : Ms()), c = Ol((() => "q-layout q-layout--" + (!0 === e.container ? "containerized" : "standard"))), d = Ol((() => !1 === e.container ? {
				minHeight: o.screen.height + "px"
			} : null)), p = Ol((() => 0 !== u.value ? {
				[!0 === o.lang.rtl ? "left" : "right"]: `${u.value}px`
			} : null)), f = Ol((() => 0 !== u.value ? {
				[!0 === o.lang.rtl ? "right" : "left"]: 0,
				[!0 === o.lang.rtl ? "left" : "right"]: `-${u.value}px`,
				width: `calc(100% + ${u.value}px)`
			} : null));

			function v(t) {
				if (!0 === e.container || !0 !== document.qScrollPrevented) {
					const o = {
						position: t.position.top,
						direction: t.direction,
						directionChanged: t.directionChanged,
						inflectionPoint: t.inflectionPoint.top,
						delta: t.delta.top
					};
					i.value = o, void 0 !== e.onScroll && n("scroll", o)
				}
			}

			function h(t) {
				const {
					height: o,
					width: l
				} = t;
				let i = !1;
				a.value !== o && (i = !0, a.value = o, void 0 !== e.onScrollHeight && n("scrollHeight", o), g()), r.value !== l && (i = !0, r.value = l), !0 === i && void 0 !== e.onResize && n("resize", t)
			}

			function m({
				height: e
			}) {
				s.value !== e && (s.value = e, g())
			}

			function g() {
				if (!0 === e.container) {
					const e = a.value > s.value ? Ms() : 0;
					u.value !== e && (u.value = e)
				}
			}
			let b = null;
			const y = {
				instances: {},
				view: Ol((() => e.view)),
				isContainer: Ol((() => e.container)),
				rootRef: l,
				height: a,
				containerHeight: s,
				scrollbarWidth: u,
				totalWidth: Ol((() => r.value + u.value)),
				rows: Ol((() => {
					const t = e.view.toLowerCase().split(" ");
					return {
						top: t[0].split(""),
						middle: t[1].split(""),
						bottom: t[2].split("")
					}
				})),
				header: at({
					size: 0,
					offset: 0,
					space: !1
				}),
				right: at({
					size: 300,
					offset: 0,
					space: !1
				}),
				footer: at({
					size: 0,
					offset: 0,
					space: !1
				}),
				left: at({
					size: 300,
					offset: 0,
					space: !1
				}),
				scroll: i,
				animate() {
					null !== b ? clearTimeout(b) : document.body.classList.add("q-body--layout-animate"), b = setTimeout((() => {
						b = null, document.body.classList.remove("q-body--layout-animate")
					}), 155)
				},
				update(e, t, n) {
					y[e][t] = n
				}
			};
			if (vn("_q_l_", y), Ms() > 0) {
				let t = function() {
						a = null, r.classList.remove("hide-scrollbar")
					},
					n = function() {
						if (null === a) {
							if (r.scrollHeight > o.screen.height) return;
							r.classList.add("hide-scrollbar")
						} else clearTimeout(a);
						a = setTimeout(t, 300)
					},
					l = function(e) {
						null !== a && "remove" === e && (clearTimeout(a), t()), window[`${e}EventListener`]("resize", n)
					},
					a = null;
				const r = document.body;
				gn((() => !0 !== e.container ? "add" : "remove"), l), !0 !== e.container && l("add"), Un((() => {
					l("remove")
				}))
			}
			return () => {
				const n = Cs(t.default, [Tl(zs, {
						onScroll: v
					}), Tl(ks, {
						onResize: h
					})]),
					o = Tl("div", {
						class: c.value,
						style: d.value,
						ref: !0 === e.container ? void 0 : l,
						tabindex: -1
					}, n);
				return !0 === e.container ? Tl("div", {
					class: "q-layout-container overflow-hidden",
					ref: l
				}, [Tl(ks, {
					onResize: m
				}), Tl("div", {
					class: "absolute-full",
					style: p.value
				}, [Tl("div", {
					class: "scroll",
					style: f.value
				}, [o])])]) : o
			}
		}
	});
const js = Tl("div", {
	class: "q-space"
});
var Ds = ys({
	name: "QSpace",
	setup: () => () => js
});
const Us = {
		xs: 18,
		sm: 24,
		md: 32,
		lg: 38,
		xl: 46
	},
	Hs = {
		size: String
	};

function Ws(e, t = Us) {
	return Ol((() => void 0 !== e.size ? {
		fontSize: e.size in t ? `${t[e.size]}px` : e.size
	} : null))
}
const Ks = "0 0 24 24",
	Qs = e => e,
	Gs = e => `ionicons ${e}`,
	Zs = {
		"mdi-": e => `mdi ${e}`,
		"icon-": Qs,
		"bt-": e => `bt ${e}`,
		"eva-": e => `eva ${e}`,
		"ion-md": Gs,
		"ion-ios": Gs,
		"ion-logo": Gs,
		"iconfont ": Qs,
		"ti-": e => `themify-icon ${e}`,
		"bi-": e => `bootstrap-icons ${e}`
	},
	Js = {
		o_: "-outlined",
		r_: "-round",
		s_: "-sharp"
	},
	Xs = {
		sym_o_: "-outlined",
		sym_r_: "-rounded",
		sym_s_: "-sharp"
	},
	Ys = new RegExp("^(" + Object.keys(Zs).join("|") + ")"),
	eu = new RegExp("^(" + Object.keys(Js).join("|") + ")"),
	tu = new RegExp("^(" + Object.keys(Xs).join("|") + ")"),
	nu = /^[Mm]\s?[-+]?\.?\d/,
	ou = /^img:/,
	lu = /^svguse:/,
	au = /^ion-/,
	ru = /^(fa-(solid|regular|light|brands|duotone|thin)|[lf]a[srlbdk]?) /;
var iu = ys({
	name: "QIcon",
	props: {
		...Hs,
		tag: {
			type: String,
			default: "i"
		},
		name: String,
		color: String,
		left: Boolean,
		right: Boolean
	},
	setup(e, {
		slots: t
	}) {
		const {
			proxy: {
				$q: n
			}
		} = Sl(), o = Ws(e), l = Ol((() => "q-icon" + (!0 === e.left ? " on-left" : "") + (!0 === e.right ? " on-right" : "") + (void 0 !== e.color ? ` text-${e.color}` : ""))), a = Ol((() => {
			let t, o = e.name;
			if ("none" === o || !o) return {
				none: !0
			};
			if (null !== n.iconMapFn) {
				const e = n.iconMapFn(o);
				if (void 0 !== e) {
					if (void 0 === e.icon) return {
						cls: e.cls,
						content: void 0 !== e.content ? e.content : " "
					};
					if (o = e.icon, "none" === o || !o) return {
						none: !0
					}
				}
			}
			if (!0 === nu.test(o)) {
				const [e, t = Ks] = o.split("|");
				return {
					svg: !0,
					viewBox: t,
					nodes: e.split("&&").map((e => {
						const [t, n, o] = e.split("@@");
						return Tl("path", {
							style: n,
							d: t,
							transform: o
						})
					}))
				}
			}
			if (!0 === ou.test(o)) return {
				img: !0,
				src: o.substring(4)
			};
			if (!0 === lu.test(o)) {
				const [e, t = Ks] = o.split("|");
				return {
					svguse: !0,
					src: e.substring(7),
					viewBox: t
				}
			}
			let l = " ";
			const a = o.match(Ys);
			if (null !== a) t = Zs[a[1]](o);
			else if (!0 === ru.test(o)) t = o;
			else if (!0 === au.test(o)) t = `ionicons ion-${!0===n.platform.is.ios?"ios":"md"}${o.substring(3)}`;
			else if (!0 === tu.test(o)) {
				t = "notranslate material-symbols";
				const e = o.match(tu);
				null !== e && (o = o.substring(6), t += Xs[e[1]]), l = o
			} else {
				t = "notranslate material-icons";
				const e = o.match(eu);
				null !== e && (o = o.substring(2), t += Js[e[1]]), l = o
			}
			return {
				cls: t,
				content: l
			}
		}));
		return () => {
			const n = {
				class: l.value,
				style: o.value,
				"aria-hidden": "true",
				role: "presentation"
			};
			return !0 === a.value.none ? Tl(e.tag, n, Ss(t.default)) : !0 === a.value.img ? Tl("span", n, Cs(t.default, [Tl("img", {
				src: a.value.src
			})])) : !0 === a.value.svg ? Tl("span", n, Cs(t.default, [Tl("svg", {
				viewBox: a.value.viewBox || "0 0 24 24"
			}, a.value.nodes)])) : !0 === a.value.svguse ? Tl("span", n, Cs(t.default, [Tl("svg", {
				viewBox: a.value.viewBox
			}, [Tl("use", {
				"xlink:href": a.value.src
			})])])) : (void 0 !== a.value.cls && (n.class += " " + a.value.cls), Tl(e.tag, n, Cs(t.default, [a.value.content])))
		}
	}
});
const su = {
	dark: {
		type: Boolean,
		default: null
	}
};

function uu(e, t) {
	return Ol((() => null === e.dark ? t.dark.isActive : e.dark))
}
const cu = {
	name: String
};

function du(e) {
	return Ol((() => e.name || e.for))
}
var pu = {
	xs: 30,
	sm: 35,
	md: 40,
	lg: 50,
	xl: 60
};
const fu = {
		...su,
		...Hs,
		...cu,
		modelValue: {
			required: !0,
			default: null
		},
		val: {},
		trueValue: {
			default: !0
		},
		falseValue: {
			default: !1
		},
		indeterminateValue: {
			default: null
		},
		checkedIcon: String,
		uncheckedIcon: String,
		indeterminateIcon: String,
		toggleOrder: {
			type: String,
			validator: e => "tf" === e || "ft" === e
		},
		toggleIndeterminate: Boolean,
		label: String,
		leftLabel: Boolean,
		color: String,
		keepColor: Boolean,
		dense: Boolean,
		disable: Boolean,
		tabindex: [String, Number]
	},
	vu = ["update:modelValue"];

function hu(e, t) {
	const {
		props: n,
		slots: o,
		emit: l,
		proxy: a
	} = Sl(), {
		$q: r
	} = a, i = uu(n, r), s = yt(null), {
		refocusTargetEl: u,
		refocusTarget: c
	} = function(e, t) {
		const n = yt(null);
		return {
			refocusTargetEl: Ol((() => !0 === e.disable ? null : Tl("span", {
				ref: n,
				class: "no-outline",
				tabindex: -1
			}))),
			refocusTarget: function(e) {
				const o = t.value;
				void 0 !== e && 0 === e.type.indexOf("key") ? null !== o && document.activeElement !== o && !0 === o.contains(document.activeElement) && o.focus() : null !== n.value && (void 0 === e || null !== o && !0 === o.contains(e.target)) && n.value.focus()
			}
		}
	}(n, s), d = Ws(n, pu), p = Ol((() => void 0 !== n.val && Array.isArray(n.modelValue))), f = Ol((() => {
		const e = pt(n.val);
		return !0 === p.value ? n.modelValue.findIndex((t => pt(t) === e)) : -1
	})), v = Ol((() => !0 === p.value ? f.value > -1 : pt(n.modelValue) === pt(n.trueValue))), h = Ol((() => !0 === p.value ? -1 === f.value : pt(n.modelValue) === pt(n.falseValue))), m = Ol((() => !1 === v.value && !1 === h.value)), g = Ol((() => !0 === n.disable ? -1 : n.tabindex || 0)), b = Ol((() => `q-${e} cursor-pointer no-outline row inline no-wrap items-center` + (!0 === n.disable ? " disabled" : "") + (!0 === i.value ? ` q-${e}--dark` : "") + (!0 === n.dense ? ` q-${e}--dense` : "") + (!0 === n.leftLabel ? " reverse" : ""))), y = Ol((() => {
		const t = !0 === v.value ? "truthy" : !0 === h.value ? "falsy" : "indet",
			o = void 0 === n.color || !0 !== n.keepColor && ("toggle" === e ? !0 !== v.value : !0 === h.value) ? "" : ` text-${n.color}`;
		return `q-${e}__inner relative-position non-selectable q-${e}__inner--${t}${o}`
	})), _ = function(e = {}) {
		return (t, n, o) => {
			t[n](Tl("input", {
				class: "hidden" + (o || ""),
				...e.value
			}))
		}
	}(Ol((() => {
		const e = {
			type: "checkbox"
		};
		return void 0 !== n.name && Object.assign(e, {
			".checked": v.value,
			"^checked": !0 === v.value ? "checked" : void 0,
			name: n.name,
			value: !0 === p.value ? n.val : n.trueValue
		}), e
	}))), w = Ol((() => {
		const t = {
			tabindex: g.value,
			role: "toggle" === e ? "switch" : "checkbox",
			"aria-label": n.label,
			"aria-checked": !0 === m.value ? "mixed" : !0 === v.value ? "true" : "false"
		};
		return !0 === n.disable && (t["aria-disabled"] = "true"), t
	}));

	function k(e) {
		void 0 !== e && (er(e), c(e)), !0 !== n.disable && l("update:modelValue", function() {
			if (!0 === p.value) {
				if (!0 === v.value) {
					const e = n.modelValue.slice();
					return e.splice(f.value, 1), e
				}
				return n.modelValue.concat([n.val])
			}
			if (!0 === v.value) {
				if ("ft" !== n.toggleOrder || !1 === n.toggleIndeterminate) return n.falseValue
			} else {
				if (!0 !== h.value) return "ft" !== n.toggleOrder ? n.trueValue : n.falseValue;
				if ("ft" === n.toggleOrder || !1 === n.toggleIndeterminate) return n.trueValue
			}
			return n.indeterminateValue
		}(), e)
	}

	function S(e) {
		13 !== e.keyCode && 32 !== e.keyCode || er(e)
	}

	function x(e) {
		13 !== e.keyCode && 32 !== e.keyCode || k(e)
	}
	const C = t(v, m);
	return Object.assign(a, {
		toggle: k
	}), () => {
		const t = C();
		!0 !== n.disable && _(t, "unshift", ` q-${e}__native absolute q-ma-none q-pa-none`);
		const l = [Tl("div", {
			class: y.value,
			style: d.value,
			"aria-hidden": "true"
		}, t)];
		null !== u.value && l.push(u.value);
		const a = void 0 !== n.label ? Cs(o.default, [n.label]) : Ss(o.default);
		return void 0 !== a && l.push(Tl("div", {
			class: `q-${e}__label q-anchor--skip`
		}, a)), Tl("div", {
			ref: s,
			class: b.value,
			...w.value,
			onClick: k,
			onKeydown: S,
			onKeyup: x
		}, l)
	}
}
var mu = ys({
		name: "QToggle",
		props: {
			...fu,
			icon: String,
			iconColor: String
		},
		emits: vu,
		setup: e => hu("toggle", (function(t, n) {
			const o = Ol((() => (!0 === t.value ? e.checkedIcon : !0 === n.value ? e.indeterminateIcon : e.uncheckedIcon) || e.icon)),
				l = Ol((() => !0 === t.value ? e.iconColor : null));
			return () => [Tl("div", {
				class: "q-toggle__track"
			}), Tl("div", {
				class: "q-toggle__thumb absolute flex flex-center no-wrap"
			}, void 0 !== o.value ? [Tl(iu, {
				name: o.value,
				color: l.value
			})] : void 0)]
		}))
	}),
	gu = ys({
		name: "QToolbar",
		props: {
			inset: Boolean
		},
		setup(e, {
			slots: t
		}) {
			const n = Ol((() => "q-toolbar row no-wrap items-center" + (!0 === e.inset ? " q-toolbar--inset" : "")));
			return () => Tl("div", {
				class: n.value,
				role: "toolbar"
			}, Ss(t.default))
		}
	});
const bu = chrome.runtime.getURL("assets/config.json");
const yu = {
		manualSolving: !1,
		apiKey: "",
		appId: "",
		enabledForImageToText: !0,
		enabledForRecaptchaV3: !0,
		enabledForHCaptcha: !0,
		enabledForGeetestV4: !1,
		recaptchaV3MinScore: .5,
		enabledForRecaptcha: !0,
		enabledForFunCaptcha: !0,
		enabledForDataDome: !1,
		enabledForAwsCaptcha: !0,
		useProxy: !1,
		proxyType: "http",
		hostOrIp: "",
		port: "",
		proxyLogin: "",
		proxyPassword: "",
		enabledForBlacklistControl: !1,
		blackUrlList: [],
		isInBlackList: !1,
		reCaptchaMode: "click",
		reCaptchaDelayTime: 0,
		reCaptchaCollapse: !1,
		reCaptchaRepeatTimes: 10,
		reCaptcha3Mode: "token",
		reCaptcha3DelayTime: 0,
		reCaptcha3Collapse: !1,
		reCaptcha3RepeatTimes: 10,
		hCaptchaMode: "click",
		hCaptchaDelayTime: 0,
		hCaptchaCollapse: !1,
		hCaptchaRepeatTimes: 10,
		funCaptchaMode: "click",
		funCaptchaDelayTime: 0,
		funCaptchaCollapse: !1,
		funCaptchaRepeatTimes: 10,
		geetestMode: "click",
		geetestCollapse: !1,
		geetestDelayTime: 0,
		geetestRepeatTimes: 10,
		textCaptchaMode: "click",
		textCaptchaCollapse: !1,
		textCaptchaDelayTime: 0,
		textCaptchaRepeatTimes: 10,
		enabledForCloudflare: !1,
		cloudflareMode: "click",
		cloudflareCollapse: !1,
		cloudflareDelayTime: 0,
		cloudflareRepeatTimes: 10,
		datadomeMode: "click",
		datadomeCollapse: !1,
		datadomeDelayTime: 0,
		datadomeRepeatTimes: 10,
		awsCaptchaMode: "click",
		awsCollapse: !1,
		awsDelayTime: 0,
		awsRepeatTimes: 10,
		useCapsolver: !0,
		isInit: !1,
		solvedCallback: "captchaSolvedCallback",
		textCaptchaSourceAttribute: "capsolver-image-to-text-source",
		textCaptchaResultAttribute: "capsolver-image-to-text-result"
	},
	_u = {
		proxyType: ["socks5", "http", "https", "socks4"],
		mode: ["click", "token"]
	};
async function wu() {
	const e = await async function() {
		const e = await chrome.storage.local.get("defaultConfig");
		if (e.defaultConfig) return e.defaultConfig;
		let t = {};
		const n = await fetch(bu),
			o = await n.json();
		return o && (t = o, chrome.storage.local.set({
			defaultConfig: t
		})), t
	}(), t = Object.keys(e);
	for (let n of t)
		if (("proxyType" !== n || _u[n].includes(e[n])) && (!n.endsWith("Mode") || _u.mode.includes(e[n]))) {
			if ("port" === n) {
				if ("number" != typeof e[n]) continue;
				yu[n] = e[n]
			}
			Reflect.has(yu, n) && typeof yu[n] == typeof e[n] && (yu[n] = e[n])
		} return yu
}
const ku = wu();
let Su = {
	default: ku,
	async get(e) {
		return (await this.getAll())[e]
	},
	async getAll() {
		const e = await wu(),
			t = await chrome.storage.local.get("config");
		return Su.joinConfig(e, t.config)
	},
	async set(e) {
		const t = await Su.getAll(),
			n = Su.joinConfig(t, e);
		return chrome.storage.local.set({
			config: n
		})
	},
	joinConfig(e, t) {
		let n = {};
		if (e)
			for (let o in e) n[o] = e[o];
		if (t)
			for (let o in t) n[o] = t[o];
		return n
	}
};
var xu = ys({
		name: "QItemSection",
		props: {
			avatar: Boolean,
			thumbnail: Boolean,
			side: Boolean,
			top: Boolean,
			noWrap: Boolean
		},
		setup(e, {
			slots: t
		}) {
			const n = Ol((() => "q-item__section column q-item__section--" + (!0 === e.avatar || !0 === e.side || !0 === e.thumbnail ? "side" : "main") + (!0 === e.top ? " q-item__section--top justify-start" : " justify-center") + (!0 === e.avatar ? " q-item__section--avatar" : "") + (!0 === e.thumbnail ? " q-item__section--thumbnail" : "") + (!0 === e.noWrap ? " q-item__section--nowrap" : "")));
			return () => Tl("div", {
				class: n.value
			}, Ss(t.default))
		}
	}),
	Cu = ys({
		name: "QItemLabel",
		props: {
			overline: Boolean,
			caption: Boolean,
			header: Boolean,
			lines: [Number, String]
		},
		setup(e, {
			slots: t
		}) {
			const n = Ol((() => parseInt(e.lines, 10))),
				o = Ol((() => "q-item__label" + (!0 === e.overline ? " q-item__label--overline text-overline" : "") + (!0 === e.caption ? " q-item__label--caption text-caption" : "") + (!0 === e.header ? " q-item__label--header" : "") + (1 === n.value ? " ellipsis" : ""))),
				l = Ol((() => void 0 !== e.lines && n.value > 1 ? {
					overflow: "hidden",
					display: "-webkit-box",
					"-webkit-box-orient": "vertical",
					"-webkit-line-clamp": n.value
				} : null));
			return () => Tl("div", {
				style: l.value,
				class: o.value
			}, Ss(t.default))
		}
	});

function Eu(e) {
	if (Object(e.$parent) === e.$parent) return e.$parent;
	let {
		parent: t
	} = e.$;
	for (; Object(t) === t;) {
		if (Object(t.proxy) === t.proxy) return t.proxy;
		t = t.parent
	}
}

function qu(e) {
	return void 0 !== e.appContext.config.globalProperties.$router
}

function Lu(e) {
	return !0 === e.isUnmounted || !0 === e.isDeactivated
}

function Fu(e) {
	return e ? e.aliasOf ? e.aliasOf.path : e.path : ""
}

function Ru(e, t) {
	return (e.aliasOf || e) === (t.aliasOf || t)
}

function Ou(e, t) {
	return !0 === Array.isArray(t) ? e.length === t.length && e.every(((e, n) => e === t[n])) : 1 === e.length && e[0] === t
}

function Tu(e, t) {
	return !0 === Array.isArray(e) ? Ou(e, t) : !0 === Array.isArray(t) ? Ou(t, e) : e === t
}
const Pu = {
	to: [String, Object],
	replace: Boolean,
	exact: Boolean,
	activeClass: {
		type: String,
		default: "q-router-link--active"
	},
	exactActiveClass: {
		type: String,
		default: "q-router-link--exact-active"
	},
	href: String,
	target: String,
	disable: Boolean
};

function Au({
	fallbackTag: e,
	useDisableForRouterLinkProps: t = !0
} = {}) {
	const n = Sl(),
		{
			props: o,
			proxy: l,
			emit: a
		} = n,
		r = qu(n),
		i = Ol((() => !0 !== o.disable && void 0 !== o.href)),
		s = Ol(!0 === t ? () => !0 === r && !0 !== o.disable && !0 !== i.value && void 0 !== o.to && null !== o.to && "" !== o.to : () => !0 === r && !0 !== i.value && void 0 !== o.to && null !== o.to && "" !== o.to),
		u = Ol((() => !0 === s.value ? b(o.to) : null)),
		c = Ol((() => null !== u.value)),
		d = Ol((() => !0 === i.value || !0 === c.value)),
		p = Ol((() => "a" === o.type || !0 === d.value ? "a" : o.tag || e || "div")),
		f = Ol((() => !0 === i.value ? {
			href: o.href,
			target: o.target
		} : !0 === c.value ? {
			href: u.value.href,
			target: o.target
		} : {})),
		v = Ol((() => {
			if (!1 === c.value) return -1;
			const {
				matched: e
			} = u.value, {
				length: t
			} = e, n = e[t - 1];
			if (void 0 === n) return -1;
			const o = l.$route.matched;
			if (0 === o.length) return -1;
			const a = o.findIndex(Ru.bind(null, n));
			if (a > -1) return a;
			const r = Fu(e[t - 2]);
			return t > 1 && Fu(n) === r && o[o.length - 1].path !== r ? o.findIndex(Ru.bind(null, e[t - 2])) : a
		})),
		h = Ol((() => !0 === c.value && -1 !== v.value && function(e, t) {
			for (const n in t) {
				const o = t[n],
					l = e[n];
				if ("string" == typeof o) {
					if (o !== l) return !1
				} else if (!1 === Array.isArray(l) || l.length !== o.length || o.some(((e, t) => e !== l[t]))) return !1
			}
			return !0
		}(l.$route.params, u.value.params))),
		m = Ol((() => !0 === h.value && v.value === l.$route.matched.length - 1 && function(e, t) {
			if (Object.keys(e).length !== Object.keys(t).length) return !1;
			for (const n in e)
				if (!1 === Tu(e[n], t[n])) return !1;
			return !0
		}(l.$route.params, u.value.params))),
		g = Ol((() => !0 === c.value ? !0 === m.value ? ` ${o.exactActiveClass} ${o.activeClass}` : !0 === o.exact ? "" : !0 === h.value ? ` ${o.activeClass}` : "" : ""));

	function b(e) {
		try {
			return l.$router.resolve(e)
		} catch (t) {}
		return null
	}

	function y(e, {
		returnRouterError: t,
		to: n = o.to,
		replace: a = o.replace
	} = {}) {
		if (!0 === o.disable) return e.preventDefault(), Promise.resolve(!1);
		if (e.metaKey || e.altKey || e.ctrlKey || e.shiftKey || void 0 !== e.button && 0 !== e.button || "_blank" === o.target) return Promise.resolve(!1);
		e.preventDefault();
		const r = l.$router[!0 === a ? "replace" : "push"](n);
		return !0 === t ? r : r.then((() => {})).catch((() => {}))
	}
	return {
		hasRouterLink: c,
		hasHrefLink: i,
		hasLink: d,
		linkTag: p,
		resolvedLink: u,
		linkIsActive: h,
		linkIsExactActive: m,
		linkClass: g,
		linkAttrs: f,
		getLink: b,
		navigateToRouterLink: y,
		navigateOnClick: function(e) {
			if (!0 === c.value) {
				const t = t => y(e, t);
				a("click", e, t), !0 !== e.defaultPrevented && t()
			} else a("click", e)
		}
	}
}
var Vu = ys({
	name: "QItem",
	props: {
		...su,
		...Pu,
		tag: {
			type: String,
			default: "div"
		},
		active: {
			type: Boolean,
			default: null
		},
		clickable: Boolean,
		dense: Boolean,
		insetLevel: Number,
		tabindex: [String, Number],
		focused: Boolean,
		manualFocus: Boolean
	},
	emits: ["click", "keyup"],
	setup(e, {
		slots: t,
		emit: n
	}) {
		const {
			proxy: {
				$q: o
			}
		} = Sl(), l = uu(e, o), {
			hasLink: a,
			linkAttrs: r,
			linkClass: i,
			linkTag: s,
			navigateOnClick: u
		} = Au(), c = yt(null), d = yt(null), p = Ol((() => !0 === e.clickable || !0 === a.value || "label" === e.tag)), f = Ol((() => !0 !== e.disable && !0 === p.value)), v = Ol((() => "q-item q-item-type row no-wrap" + (!0 === e.dense ? " q-item--dense" : "") + (!0 === l.value ? " q-item--dark" : "") + (!0 === a.value && null === e.active ? i.value : !0 === e.active ? " q-item--active" + (void 0 !== e.activeClass ? ` ${e.activeClass}` : "") : "") + (!0 === e.disable ? " disabled" : "") + (!0 === f.value ? " q-item--clickable q-link cursor-pointer " + (!0 === e.manualFocus ? "q-manual-focusable" : "q-focusable q-hoverable") + (!0 === e.focused ? " q-manual-focusable--focused" : "") : ""))), h = Ol((() => {
			if (void 0 === e.insetLevel) return null;
			return {
				["padding" + (!0 === o.lang.rtl ? "Right" : "Left")]: 16 + 56 * e.insetLevel + "px"
			}
		}));

		function m(e) {
			!0 === f.value && (null !== d.value && (!0 !== e.qKeyEvent && document.activeElement === c.value ? d.value.focus() : document.activeElement === d.value && c.value.focus()), u(e))
		}

		function g(e) {
			if (!0 === f.value && !0 === yr(e, 13)) {
				er(e), e.qKeyEvent = !0;
				const t = new MouseEvent("click", e);
				t.qKeyEvent = !0, c.value.dispatchEvent(t)
			}
			n("keyup", e)
		}
		return () => {
			const n = {
				ref: c,
				class: v.value,
				style: h.value,
				role: "listitem",
				onClick: m,
				onKeyup: g
			};
			return !0 === f.value ? (n.tabindex = e.tabindex || "0", Object.assign(n, r.value)) : !0 === p.value && (n["aria-disabled"] = "true"), Tl(s.value, n, function() {
				const e = xs(t.default, []);
				return !0 === f.value && e.unshift(Tl("div", {
					class: "q-focus-helper",
					tabindex: -1,
					ref: d
				})), e
			}())
		}
	}
});
const Mu = {
	size: {
		type: [Number, String],
		default: "1em"
	},
	color: String
};

function Bu(e) {
	return {
		cSize: Ol((() => e.size in Us ? `${Us[e.size]}px` : e.size)),
		classes: Ol((() => "q-spinner" + (e.color ? ` text-${e.color}` : "")))
	}
}
var Iu = ys({
	name: "QSpinner",
	props: {
		...Mu,
		thickness: {
			type: Number,
			default: 5
		}
	},
	setup(e) {
		const {
			cSize: t,
			classes: n
		} = Bu(e);
		return () => Tl("svg", {
			class: n.value + " q-spinner-mat",
			width: t.value,
			height: t.value,
			viewBox: "25 25 50 50"
		}, [Tl("circle", {
			class: "path",
			cx: "50",
			cy: "50",
			r: "20",
			fill: "none",
			stroke: "currentColor",
			"stroke-width": e.thickness,
			"stroke-miterlimit": "10"
		})])
	}
});
const $u = /^#[0-9a-fA-F]{3}([0-9a-fA-F]{3})?$/,
	zu = /^#[0-9a-fA-F]{4}([0-9a-fA-F]{4})?$/,
	Nu = /^#([0-9a-fA-F]{3}|[0-9a-fA-F]{4}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$/,
	ju = /^rgb\(((0|[1-9][\d]?|1[\d]{0,2}|2[\d]?|2[0-4][\d]|25[0-5]),){2}(0|[1-9][\d]?|1[\d]{0,2}|2[\d]?|2[0-4][\d]|25[0-5])\)$/,
	Du = /^rgba\(((0|[1-9][\d]?|1[\d]{0,2}|2[\d]?|2[0-4][\d]|25[0-5]),){2}(0|[1-9][\d]?|1[\d]{0,2}|2[\d]?|2[0-4][\d]|25[0-5]),(0|0\.[0-9]+[1-9]|0\.[1-9]+|1)\)$/,
	Uu = {
		date: e => /^-?[\d]+\/[0-1]\d\/[0-3]\d$/.test(e),
		time: e => /^([0-1]?\d|2[0-3]):[0-5]\d$/.test(e),
		fulltime: e => /^([0-1]?\d|2[0-3]):[0-5]\d:[0-5]\d$/.test(e),
		timeOrFulltime: e => /^([0-1]?\d|2[0-3]):[0-5]\d(:[0-5]\d)?$/.test(e),
		email: e => /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(e),
		hexColor: e => $u.test(e),
		hexaColor: e => zu.test(e),
		hexOrHexaColor: e => Nu.test(e),
		rgbColor: e => ju.test(e),
		rgbaColor: e => Du.test(e),
		rgbOrRgbaColor: e => ju.test(e) || Du.test(e),
		hexOrRgbColor: e => $u.test(e) || ju.test(e),
		hexaOrRgbaColor: e => zu.test(e) || Du.test(e),
		anyColor: e => Nu.test(e) || ju.test(e) || Du.test(e)
	},
	Hu = [!0, !1, "ondemand"],
	Wu = {
		modelValue: {},
		error: {
			type: Boolean,
			default: null
		},
		errorMessage: String,
		noErrorIcon: Boolean,
		rules: Array,
		reactiveRules: Boolean,
		lazyRules: {
			type: [Boolean, String],
			validator: e => Hu.includes(e)
		}
	};

function Ku(e, t) {
	const {
		props: n,
		proxy: o
	} = Sl(), l = yt(!1), a = yt(null), r = yt(null);
	! function({
		validate: e,
		resetValidation: t,
		requiresQForm: n
	}) {
		const o = hn("_q_fo_", !1);
		if (!1 !== o) {
			const {
				props: n,
				proxy: l
			} = Sl();
			Object.assign(l, {
				validate: e,
				resetValidation: t
			}), gn((() => n.disable), (e => {
				!0 === e ? ("function" == typeof t && t(), o.unbindComponent(l)) : o.bindComponent(l)
			})), zn((() => {
				!0 !== n.disable && o.bindComponent(l)
			})), Dn((() => {
				!0 !== n.disable && o.unbindComponent(l)
			}))
		} else !0 === n && console.error("Parent QForm not found on useFormChild()!")
	}({
		validate: v,
		resetValidation: f
	});
	let i, s = 0;
	const u = Ol((() => void 0 !== n.rules && null !== n.rules && n.rules.length > 0)),
		c = Ol((() => !0 !== n.disable && !0 === u.value)),
		d = Ol((() => !0 === n.error || !0 === l.value)),
		p = Ol((() => "string" == typeof n.errorMessage && n.errorMessage.length > 0 ? n.errorMessage : a.value));

	function f() {
		s++, t.value = !1, r.value = null, l.value = !1, a.value = null, m.cancel()
	}

	function v(e = n.modelValue) {
		if (!0 !== c.value) return !0;
		const o = ++s,
			i = !0 !== t.value ? () => {
				r.value = !0
			} : () => {},
			u = (e, n) => {
				!0 === e && i(), l.value = e, a.value = n || null, t.value = !1
			},
			d = [];
		for (let t = 0; t < n.rules.length; t++) {
			const o = n.rules[t];
			let l;
			if ("function" == typeof o ? l = o(e, Uu) : "string" == typeof o && void 0 !== Uu[o] && (l = Uu[o](e)), !1 === l || "string" == typeof l) return u(!0, l), !1;
			!0 !== l && void 0 !== l && d.push(l)
		}
		return 0 === d.length ? (u(!1), !0) : (t.value = !0, Promise.all(d).then((e => {
			if (void 0 === e || !1 === Array.isArray(e) || 0 === e.length) return o === s && u(!1), !0;
			const t = e.find((e => !1 === e || "string" == typeof e));
			return o === s && u(void 0 !== t, t), void 0 === t
		}), (e => (o === s && (console.error(e), u(!0)), !1))))
	}

	function h(e) {
		!0 === c.value && "ondemand" !== n.lazyRules && (!0 === r.value || !0 !== n.lazyRules && !0 !== e) && m()
	}
	gn((() => n.modelValue), (() => {
		h()
	})), gn((() => n.reactiveRules), (e => {
		!0 === e ? void 0 === i && (i = gn((() => n.rules), (() => {
			h(!0)
		}))) : void 0 !== i && (i(), i = void 0)
	}), {
		immediate: !0
	}), gn(e, (e => {
		!0 === e ? null === r.value && (r.value = !1) : !1 === r.value && (r.value = !0, !0 === c.value && "ondemand" !== n.lazyRules && !1 === t.value && m())
	}));
	const m = or(v, 0);
	return Dn((() => {
		void 0 !== i && i(), m.cancel()
	})), Object.assign(o, {
		resetValidation: f,
		validate: v
	}), za(o, "hasError", (() => d.value)), {
		isDirtyModel: r,
		hasRules: u,
		hasError: d,
		errorMessage: p,
		validate: v,
		resetValidation: f
	}
}
const Qu = /^on[A-Z]/;

function Gu(e, t) {
	const n = {
		listeners: yt({}),
		attributes: yt({})
	};

	function o() {
		const o = {},
			l = {};
		for (const t in e) "class" !== t && "style" !== t && !1 === Qu.test(t) && (o[t] = e[t]);
		for (const e in t.props) !0 === Qu.test(e) && (l[e] = t.props[e]);
		n.attributes.value = o, n.listeners.value = l
	}
	return Nn(o), o(), n
}
let Zu = [],
	Ju = [];

function Xu(e) {
	Ju = Ju.filter((t => t !== e))
}

function Yu(e) {
	Xu(e), 0 === Ju.length && Zu.length > 0 && (Zu[Zu.length - 1](), Zu = [])
}

function ec(e) {
	0 === Ju.length ? e() : Zu.push(e)
}

function tc(e) {
	return void 0 === e ? `f_${ya()}` : e
}

function nc(e) {
	return null != e && ("" + e).length > 0
}
const oc = {
		...su,
		...Wu,
		label: String,
		stackLabel: Boolean,
		hint: String,
		hideHint: Boolean,
		prefix: String,
		suffix: String,
		labelColor: String,
		color: String,
		bgColor: String,
		filled: Boolean,
		outlined: Boolean,
		borderless: Boolean,
		standout: [Boolean, String],
		square: Boolean,
		loading: Boolean,
		labelSlot: Boolean,
		bottomSlots: Boolean,
		hideBottomSpace: Boolean,
		rounded: Boolean,
		dense: Boolean,
		itemAligned: Boolean,
		counter: Boolean,
		clearable: Boolean,
		clearIcon: String,
		disable: Boolean,
		readonly: Boolean,
		autofocus: Boolean,
		for: String,
		maxlength: [Number, String]
	},
	lc = ["update:modelValue", "clear", "focus", "blur", "popupShow", "popupHide"];

function ac() {
	const {
		props: e,
		attrs: t,
		proxy: n,
		vnode: o
	} = Sl();
	return {
		isDark: uu(e, n.$q),
		editable: Ol((() => !0 !== e.disable && !0 !== e.readonly)),
		innerLoading: yt(!1),
		focused: yt(!1),
		hasPopupOpen: !1,
		splitAttrs: Gu(t, o),
		targetUid: yt(tc(e.for)),
		rootRef: yt(null),
		targetRef: yt(null),
		controlRef: yt(null)
	}
}

function rc(e) {
	const {
		props: t,
		emit: n,
		slots: o,
		attrs: l,
		proxy: a
	} = Sl(), {
		$q: r
	} = a;
	let i = null;
	void 0 === e.hasValue && (e.hasValue = Ol((() => nc(t.modelValue)))), void 0 === e.emitValue && (e.emitValue = e => {
		n("update:modelValue", e)
	}), void 0 === e.controlEvents && (e.controlEvents = {
		onFocusin: x,
		onFocusout: C
	}), Object.assign(e, {
		clearValue: E,
		onControlFocusin: x,
		onControlFocusout: C,
		focus: S
	}), void 0 === e.computedCounter && (e.computedCounter = Ol((() => {
		if (!1 !== t.counter) {
			const e = "string" == typeof t.modelValue || "number" == typeof t.modelValue ? ("" + t.modelValue).length : !0 === Array.isArray(t.modelValue) ? t.modelValue.length : 0,
				n = void 0 !== t.maxlength ? t.maxlength : t.maxValues;
			return e + (void 0 !== n ? " / " + n : "")
		}
	})));
	const {
		isDirtyModel: s,
		hasRules: u,
		hasError: c,
		errorMessage: d,
		resetValidation: p
	} = Ku(e.focused, e.innerLoading), f = void 0 !== e.floatingLabel ? Ol((() => !0 === t.stackLabel || !0 === e.focused.value || !0 === e.floatingLabel.value)) : Ol((() => !0 === t.stackLabel || !0 === e.focused.value || !0 === e.hasValue.value)), v = Ol((() => !0 === t.bottomSlots || void 0 !== t.hint || !0 === u.value || !0 === t.counter || null !== t.error)), h = Ol((() => !0 === t.filled ? "filled" : !0 === t.outlined ? "outlined" : !0 === t.borderless ? "borderless" : t.standout ? "standout" : "standard")), m = Ol((() => `q-field row no-wrap items-start q-field--${h.value}` + (void 0 !== e.fieldClass ? ` ${e.fieldClass.value}` : "") + (!0 === t.rounded ? " q-field--rounded" : "") + (!0 === t.square ? " q-field--square" : "") + (!0 === f.value ? " q-field--float" : "") + (!0 === b.value ? " q-field--labeled" : "") + (!0 === t.dense ? " q-field--dense" : "") + (!0 === t.itemAligned ? " q-field--item-aligned q-item-type" : "") + (!0 === e.isDark.value ? " q-field--dark" : "") + (void 0 === e.getControl ? " q-field--auto-height" : "") + (!0 === e.focused.value ? " q-field--focused" : "") + (!0 === c.value ? " q-field--error" : "") + (!0 === c.value || !0 === e.focused.value ? " q-field--highlighted" : "") + (!0 !== t.hideBottomSpace && !0 === v.value ? " q-field--with-bottom" : "") + (!0 === t.disable ? " q-field--disabled" : !0 === t.readonly ? " q-field--readonly" : ""))), g = Ol((() => "q-field__control relative-position row no-wrap" + (void 0 !== t.bgColor ? ` bg-${t.bgColor}` : "") + (!0 === c.value ? " text-negative" : "string" == typeof t.standout && t.standout.length > 0 && !0 === e.focused.value ? ` ${t.standout}` : void 0 !== t.color ? ` text-${t.color}` : ""))), b = Ol((() => !0 === t.labelSlot || void 0 !== t.label)), y = Ol((() => "q-field__label no-pointer-events absolute ellipsis" + (void 0 !== t.labelColor && !0 !== c.value ? ` text-${t.labelColor}` : ""))), _ = Ol((() => ({
		id: e.targetUid.value,
		editable: e.editable.value,
		focused: e.focused.value,
		floatingLabel: f.value,
		modelValue: t.modelValue,
		emitValue: e.emitValue
	}))), w = Ol((() => {
		const n = {
			for: e.targetUid.value
		};
		return !0 === t.disable ? n["aria-disabled"] = "true" : !0 === t.readonly && (n["aria-readonly"] = "true"), n
	}));

	function k() {
		const t = document.activeElement;
		let n = void 0 !== e.targetRef && e.targetRef.value;
		!n || null !== t && t.id === e.targetUid.value || (!0 === n.hasAttribute("tabindex") || (n = n.querySelector("[tabindex]")), n && n !== t && n.focus({
			preventScroll: !0
		}))
	}

	function S() {
		ec(k)
	}

	function x(t) {
		null !== i && (clearTimeout(i), i = null), !0 === e.editable.value && !1 === e.focused.value && (e.focused.value = !0, n("focus", t))
	}

	function C(t, o) {
		null !== i && clearTimeout(i), i = setTimeout((() => {
			i = null, (!0 !== document.hasFocus() || !0 !== e.hasPopupOpen && void 0 !== e.controlRef && null !== e.controlRef.value && !1 === e.controlRef.value.contains(document.activeElement)) && (!0 === e.focused.value && (e.focused.value = !1, n("blur", t)), void 0 !== o && o())
		}))
	}

	function E(o) {
		if (er(o), !0 !== r.platform.is.mobile) {
			(void 0 !== e.targetRef && e.targetRef.value || e.rootRef.value).focus()
		} else !0 === e.rootRef.value.contains(document.activeElement) && document.activeElement.blur();
		"file" === t.type && (e.inputRef.value.value = null), n("update:modelValue", null), n("clear", t.modelValue), $t((() => {
			p(), !0 !== r.platform.is.mobile && (s.value = !1)
		}))
	}

	function q() {
		const n = [];
		return void 0 !== o.prepend && n.push(Tl("div", {
			class: "q-field__prepend q-field__marginal row no-wrap items-center",
			key: "prepend",
			onClick: Ya
		}, o.prepend())), n.push(Tl("div", {
			class: "q-field__control-container col relative-position row no-wrap q-anchor--skip"
		}, function() {
			const n = [];
			void 0 !== t.prefix && null !== t.prefix && n.push(Tl("div", {
				class: "q-field__prefix no-pointer-events row items-center"
			}, t.prefix)), void 0 !== e.getShadowControl && !0 === e.hasShadow.value && n.push(e.getShadowControl());
			void 0 !== e.getControl ? n.push(e.getControl()) : void 0 !== o.rawControl ? n.push(o.rawControl()) : void 0 !== o.control && n.push(Tl("div", {
				ref: e.targetRef,
				class: "q-field__native row",
				tabindex: -1,
				...e.splitAttrs.attributes.value,
				"data-autofocus": !0 === t.autofocus || void 0
			}, o.control(_.value)));
			return !0 === b.value && n.push(Tl("div", {
				class: y.value
			}, Ss(o.label, t.label))), void 0 !== t.suffix && null !== t.suffix && n.push(Tl("div", {
				class: "q-field__suffix no-pointer-events row items-center"
			}, t.suffix)), n.concat(Ss(o.default))
		}())), !0 === c.value && !1 === t.noErrorIcon && n.push(F("error", [Tl(iu, {
			name: r.iconSet.field.error,
			color: "negative"
		})])), !0 === t.loading || !0 === e.innerLoading.value ? n.push(F("inner-loading-append", void 0 !== o.loading ? o.loading() : [Tl(Iu, {
			color: t.color
		})])) : !0 === t.clearable && !0 === e.hasValue.value && !0 === e.editable.value && n.push(F("inner-clearable-append", [Tl(iu, {
			class: "q-field__focusable-action",
			tag: "button",
			name: t.clearIcon || r.iconSet.field.clear,
			tabindex: 0,
			type: "button",
			"aria-hidden": null,
			role: null,
			onClick: E
		})])), void 0 !== o.append && n.push(Tl("div", {
			class: "q-field__append q-field__marginal row no-wrap items-center",
			key: "append",
			onClick: Ya
		}, o.append())), void 0 !== e.getInnerAppend && n.push(F("inner-append", e.getInnerAppend())), void 0 !== e.getControlChild && n.push(e.getControlChild()), n
	}

	function L() {
		let n, l;
		!0 === c.value ? null !== d.value ? (n = [Tl("div", {
			role: "alert"
		}, d.value)], l = `q--slot-error-${d.value}`) : (n = Ss(o.error), l = "q--slot-error") : !0 === t.hideHint && !0 !== e.focused.value || (void 0 !== t.hint ? (n = [Tl("div", t.hint)], l = `q--slot-hint-${t.hint}`) : (n = Ss(o.hint), l = "q--slot-hint"));
		const a = !0 === t.counter || void 0 !== o.counter;
		if (!0 === t.hideBottomSpace && !1 === a && void 0 === n) return;
		const r = Tl("div", {
			key: l,
			class: "q-field__messages col"
		}, n);
		return Tl("div", {
			class: "q-field__bottom row items-start q-field__bottom--" + (!0 !== t.hideBottomSpace ? "animated" : "stale"),
			onClick: Ya
		}, [!0 === t.hideBottomSpace ? r : Tl(Zl, {
			name: "q-transition--field-message"
		}, (() => r)), !0 === a ? Tl("div", {
			class: "q-field__counter"
		}, void 0 !== o.counter ? o.counter() : e.computedCounter.value) : null])
	}

	function F(e, t) {
		return null === t ? null : Tl("div", {
			key: e,
			class: "q-field__append q-field__marginal row no-wrap items-center q-anchor--skip"
		}, t)
	}
	gn((() => t.for), (t => {
		e.targetUid.value = tc(t)
	}));
	let R = !1;
	return An((() => {
			R = !0
		})), Pn((() => {
			!0 === R && !0 === t.autofocus && a.focus()
		})), zn((() => {
			!0 === Na.value && void 0 === t.for && (e.targetUid.value = tc()), !0 === t.autofocus && a.focus()
		})), Dn((() => {
			null !== i && clearTimeout(i)
		})), Object.assign(a, {
			focus: S,
			blur: function() {
				var t;
				t = k, Zu = Zu.filter((e => e !== t));
				const n = document.activeElement;
				null !== n && e.rootRef.value.contains(n) && n.blur()
			}
		}),
		function() {
			const n = void 0 === e.getControl && void 0 === o.control ? {
				...e.splitAttrs.attributes.value,
				"data-autofocus": !0 === t.autofocus || void 0,
				...w.value
			} : w.value;
			return Tl("label", {
				ref: e.rootRef,
				class: [m.value, l.class],
				style: l.style,
				...n
			}, [void 0 !== o.before ? Tl("div", {
				class: "q-field__before q-field__marginal row no-wrap items-center",
				onClick: Ya
			}, o.before()) : null, Tl("div", {
				class: "q-field__inner relative-position col self-stretch"
			}, [Tl("div", {
				ref: e.controlRef,
				class: g.value,
				tabindex: -1,
				...e.controlEvents
			}, q()), !0 === v.value ? L() : null]), void 0 !== o.after ? Tl("div", {
				class: "q-field__after q-field__marginal row no-wrap items-center",
				onClick: Ya
			}, o.after()) : null])
		}
}
var ic = ys({
	name: "QField",
	inheritAttrs: !1,
	props: oc,
	emits: lc,
	setup: () => rc(ac())
});

function sc(e, t = 250) {
	let n, o = !1;
	return function() {
		return !1 === o && (o = !0, setTimeout((() => {
			o = !1
		}), t), n = e.apply(this, arguments)), n
	}
}

function uc(e, t, n, o) {
	!0 === n.modifiers.stop && Xa(e);
	const l = n.modifiers.color;
	let a = n.modifiers.center;
	a = !0 === a || !0 === o;
	const r = document.createElement("span"),
		i = document.createElement("span"),
		s = Ja(e),
		{
			left: u,
			top: c,
			width: d,
			height: p
		} = t.getBoundingClientRect(),
		f = Math.sqrt(d * d + p * p),
		v = f / 2,
		h = (d - f) / 2 + "px",
		m = a ? h : s.left - u - v + "px",
		g = (p - f) / 2 + "px",
		b = a ? g : s.top - c - v + "px";
	i.className = "q-ripple__inner", Fs(i, {
		height: `${f}px`,
		width: `${f}px`,
		transform: `translate3d(${m},${b},0) scale3d(.2,.2,1)`,
		opacity: 0
	}), r.className = "q-ripple" + (l ? " text-" + l : ""), r.setAttribute("dir", "ltr"), r.appendChild(i), t.appendChild(r);
	const y = () => {
		r.remove(), clearTimeout(_)
	};
	n.abort.push(y);
	let _ = setTimeout((() => {
		i.classList.add("q-ripple__inner--enter"), i.style.transform = `translate3d(${h},${g},0) scale3d(1,1,1)`, i.style.opacity = .2, _ = setTimeout((() => {
			i.classList.remove("q-ripple__inner--enter"), i.classList.add("q-ripple__inner--leave"), i.style.opacity = 0, _ = setTimeout((() => {
				r.remove(), n.abort.splice(n.abort.indexOf(y), 1)
			}), 275)
		}), 250)
	}), 50)
}

function cc(e, {
	modifiers: t,
	value: n,
	arg: o
}) {
	const l = Object.assign({}, e.cfg.ripple, t, n);
	e.modifiers = {
		early: !0 === l.early,
		stop: !0 === l.stop,
		center: !0 === l.center,
		color: l.color || o,
		keyCodes: [].concat(l.keyCodes || 13)
	}
}
var dc = ft({
	name: "ripple",
	beforeMount(e, t) {
		const n = t.instance.$.appContext.config.globalProperties.$q.config || {};
		if (!1 === n.ripple) return;
		const o = {
			cfg: n,
			enabled: !1 !== t.value,
			modifiers: {},
			abort: [],
			start(t) {
				!0 === o.enabled && !0 !== t.qSkipRipple && t.type === (!0 === o.modifiers.early ? "pointerdown" : "click") && uc(t, e, o, !0 === t.qKeyEvent)
			},
			keystart: sc((t => {
				!0 === o.enabled && !0 !== t.qSkipRipple && !0 === yr(t, o.modifiers.keyCodes) && t.type === "key" + (!0 === o.modifiers.early ? "down" : "up") && uc(t, e, o, !0)
			}), 300)
		};
		cc(o, t), e.__qripple = o, tr(o, "main", [
			[e, "pointerdown", "start", "passive"],
			[e, "click", "start", "passive"],
			[e, "keydown", "keystart", "passive"],
			[e, "keyup", "keystart", "passive"]
		])
	},
	updated(e, t) {
		if (t.oldValue !== t.value) {
			const n = e.__qripple;
			void 0 !== n && (n.enabled = !1 !== t.value, !0 === n.enabled && Object(t.value) === t.value && cc(n, t))
		}
	},
	beforeUnmount(e) {
		const t = e.__qripple;
		void 0 !== t && (t.abort.forEach((e => {
			e()
		})), nr(t, "main"), delete e._qripple)
	}
});
const pc = {
	xs: 8,
	sm: 10,
	md: 14,
	lg: 20,
	xl: 24
};
var fc = ys({
	name: "QChip",
	props: {
		...su,
		...Hs,
		dense: Boolean,
		icon: String,
		iconRight: String,
		iconRemove: String,
		iconSelected: String,
		label: [String, Number],
		color: String,
		textColor: String,
		modelValue: {
			type: Boolean,
			default: !0
		},
		selected: {
			type: Boolean,
			default: null
		},
		square: Boolean,
		outline: Boolean,
		clickable: Boolean,
		removable: Boolean,
		removeAriaLabel: String,
		tabindex: [String, Number],
		disable: Boolean,
		ripple: {
			type: [Boolean, Object],
			default: !0
		}
	},
	emits: ["update:modelValue", "update:selected", "remove", "click"],
	setup(e, {
		slots: t,
		emit: n
	}) {
		const {
			proxy: {
				$q: o
			}
		} = Sl(), l = uu(e, o), a = Ws(e, pc), r = Ol((() => !0 === e.selected || void 0 !== e.icon)), i = Ol((() => !0 === e.selected ? e.iconSelected || o.iconSet.chip.selected : e.icon)), s = Ol((() => e.iconRemove || o.iconSet.chip.remove)), u = Ol((() => !1 === e.disable && (!0 === e.clickable || null !== e.selected))), c = Ol((() => {
			const t = !0 === e.outline && e.color || e.textColor;
			return "q-chip row inline no-wrap items-center" + (!1 === e.outline && void 0 !== e.color ? ` bg-${e.color}` : "") + (t ? ` text-${t} q-chip--colored` : "") + (!0 === e.disable ? " disabled" : "") + (!0 === e.dense ? " q-chip--dense" : "") + (!0 === e.outline ? " q-chip--outline" : "") + (!0 === e.selected ? " q-chip--selected" : "") + (!0 === u.value ? " q-chip--clickable cursor-pointer non-selectable q-hoverable" : "") + (!0 === e.square ? " q-chip--square" : "") + (!0 === l.value ? " q-chip--dark q-dark" : "")
		})), d = Ol((() => {
			const t = !0 === e.disable ? {
				tabindex: -1,
				"aria-disabled": "true"
			} : {
				tabindex: e.tabindex || 0
			};
			return {
				chip: t,
				remove: {
					...t,
					role: "button",
					"aria-hidden": "false",
					"aria-label": e.removeAriaLabel || o.lang.label.remove
				}
			}
		}));

		function p(e) {
			13 === e.keyCode && f(e)
		}

		function f(t) {
			e.disable || (n("update:selected", !e.selected), n("click", t))
		}

		function v(t) {
			void 0 !== t.keyCode && 13 !== t.keyCode || (er(t), !1 === e.disable && (n("update:modelValue", !1), n("remove")))
		}
		return () => {
			if (!1 === e.modelValue) return;
			const n = {
				class: c.value,
				style: a.value
			};
			return !0 === u.value && Object.assign(n, d.value.chip, {
					onClick: f,
					onKeyup: p
				}),
				function(e, t, n, o, l, a) {
					t.key = o + l;
					const r = Tl(e, t, n);
					return !0 === l ? Gn(r, a()) : r
				}("div", n, function() {
					const n = [];
					!0 === u.value && n.push(Tl("div", {
						class: "q-focus-helper"
					})), !0 === r.value && n.push(Tl(iu, {
						class: "q-chip__icon q-chip__icon--left",
						name: i.value
					}));
					const o = void 0 !== e.label ? [Tl("div", {
						class: "ellipsis"
					}, [e.label])] : void 0;
					var l, a;
					return n.push(Tl("div", {
						class: "q-chip__content col row no-wrap items-center q-anchor--skip"
					}, (l = t.default, a = o, void 0 === l ? a : void 0 !== a ? a.concat(l()) : l()))), e.iconRight && n.push(Tl(iu, {
						class: "q-chip__icon q-chip__icon--right",
						name: e.iconRight
					})), !0 === e.removable && n.push(Tl(iu, {
						class: "q-chip__icon q-chip__icon--remove cursor-pointer",
						name: s.value,
						...d.value.remove,
						onClick: v,
						onKeyup: v
					})), n
				}(), "ripple", !1 !== e.ripple && !0 !== e.disable, (() => [
					[dc, e.ripple]
				]))
		}
	}
});
const vc = {
	target: {
		default: !0
	},
	noParentEvent: Boolean,
	contextMenu: Boolean
};

function hc({
	showing: e,
	avoidEmit: t,
	configureAnchorEl: n
}) {
	const {
		props: o,
		proxy: l,
		emit: a
	} = Sl(), r = yt(null);
	let i = null;

	function s(e) {
		return null !== r.value && (void 0 === e || void 0 === e.touches || e.touches.length <= 1)
	}
	const u = {};

	function c() {
		nr(u, "anchor")
	}

	function d() {
		if (!1 === o.target || "" === o.target || null === l.$el.parentNode) r.value = null;
		else if (!0 === o.target) ! function(e) {
			for (r.value = e; r.value.classList.contains("q-anchor--skip");) r.value = r.value.parentNode;
			n()
		}(l.$el.parentNode);
		else {
			let t = o.target;
			if ("string" == typeof o.target) try {
				t = document.querySelector(o.target)
			} catch (e) {
				t = void 0
			}
			null != t ? (r.value = t.$el || t, n()) : (r.value = null, console.error(`Anchor: target "${o.target}" not found`))
		}
	}
	return void 0 === n && (Object.assign(u, {
		hide(e) {
			l.hide(e)
		},
		toggle(e) {
			l.toggle(e), e.qAnchorHandled = !0
		},
		toggleKey(e) {
			!0 === yr(e, 13) && u.toggle(e)
		},
		contextClick(e) {
			l.hide(e), Ya(e), $t((() => {
				l.show(e), e.qAnchorHandled = !0
			}))
		},
		prevent: Ya,
		mobileTouch(e) {
			if (u.mobileCleanup(e), !0 !== s(e)) return;
			l.hide(e), r.value.classList.add("non-selectable");
			const t = e.target;
			tr(u, "anchor", [
				[t, "touchmove", "mobileCleanup", "passive"],
				[t, "touchend", "mobileCleanup", "passive"],
				[t, "touchcancel", "mobileCleanup", "passive"],
				[r.value, "contextmenu", "prevent", "notPassive"]
			]), i = setTimeout((() => {
				i = null, l.show(e), e.qAnchorHandled = !0
			}), 300)
		},
		mobileCleanup(t) {
			r.value.classList.remove("non-selectable"), null !== i && (clearTimeout(i), i = null), !0 === e.value && void 0 !== t && function() {
				if (void 0 !== window.getSelection) {
					const e = window.getSelection();
					void 0 !== e.empty ? e.empty() : void 0 !== e.removeAllRanges && (e.removeAllRanges(), !0 !== Ka.is.mobile && e.addRange(document.createRange()))
				} else void 0 !== document.selection && document.selection.empty()
			}()
		}
	}), n = function(e = o.contextMenu) {
		if (!0 === o.noParentEvent || null === r.value) return;
		let t;
		t = !0 === e ? !0 === l.$q.platform.is.mobile ? [
			[r.value, "touchstart", "mobileTouch", "passive"]
		] : [
			[r.value, "mousedown", "hide", "passive"],
			[r.value, "contextmenu", "contextClick", "notPassive"]
		] : [
			[r.value, "click", "toggle", "passive"],
			[r.value, "keyup", "toggleKey", "passive"]
		], tr(u, "anchor", t)
	}), gn((() => o.contextMenu), (e => {
		null !== r.value && (c(), n(e))
	})), gn((() => o.target), (() => {
		null !== r.value && c(), d()
	})), gn((() => o.noParentEvent), (e => {
		null !== r.value && (!0 === e ? c() : n())
	})), zn((() => {
		d(), !0 !== t && !0 === o.modelValue && null === r.value && a("update:modelValue", !1)
	})), Dn((() => {
		null !== i && clearTimeout(i), c()
	})), {
		anchorEl: r,
		canShow: s,
		anchorEvents: u
	}
}
const mc = {
		modelValue: {
			type: Boolean,
			default: null
		},
		"onUpdate:modelValue": [Function, Array]
	},
	gc = ["beforeShow", "show", "beforeHide", "hide"];

function bc({
	showing: e,
	canShow: t,
	hideOnRouteChange: n,
	handleShow: o,
	handleHide: l,
	processOnMount: a
}) {
	const r = Sl(),
		{
			props: i,
			emit: s,
			proxy: u
		} = r;
	let c;

	function d(e) {
		if (!0 === i.disable || void 0 !== e && !0 === e.qAnchorHandled || void 0 !== t && !0 !== t(e)) return;
		const n = void 0 !== i["onUpdate:modelValue"];
		!0 === n && (s("update:modelValue", !0), c = e, $t((() => {
			c === e && (c = void 0)
		}))), null !== i.modelValue && !1 !== n || p(e)
	}

	function p(t) {
		!0 !== e.value && (e.value = !0, s("beforeShow", t), void 0 !== o ? o(t) : s("show", t))
	}

	function f(e) {
		if (!0 === i.disable) return;
		const t = void 0 !== i["onUpdate:modelValue"];
		!0 === t && (s("update:modelValue", !1), c = e, $t((() => {
			c === e && (c = void 0)
		}))), null !== i.modelValue && !1 !== t || v(e)
	}

	function v(t) {
		!1 !== e.value && (e.value = !1, s("beforeHide", t), void 0 !== l ? l(t) : s("hide", t))
	}

	function h(t) {
		if (!0 === i.disable && !0 === t) void 0 !== i["onUpdate:modelValue"] && s("update:modelValue", !1);
		else if (!0 === t !== e.value) {
			(!0 === t ? p : v)(c)
		}
	}
	gn((() => i.modelValue), h), void 0 !== n && !0 === qu(r) && gn((() => u.$route.fullPath), (() => {
		!0 === n.value && !0 === e.value && f()
	})), !0 === a && zn((() => {
		h(i.modelValue)
	}));
	const m = {
		show: d,
		hide: f,
		toggle: function(t) {
			!0 === e.value ? f(t) : d(t)
		}
	};
	return Object.assign(u, m), m
}
let yc = 1,
	_c = document.body;
const wc = [];

function kc(e, t, n, o) {
	const l = yt(!1),
		a = yt(!1);
	let r = null;
	const i = {},
		s = "dialog" === o && function(e) {
			for (e = e.parent; null != e;) {
				if ("QGlobalDialog" === e.type.name) return !0;
				if ("QDialog" === e.type.name || "QMenu" === e.type.name) return !1;
				e = e.parent
			}
			return !1
		}(e);

	function u(t) {
		if (a.value = !1, !0 !== t) return;
		Yu(i), l.value = !1;
		const n = wc.indexOf(e.proxy); - 1 !== n && wc.splice(n, 1), null !== r && (r.remove(), r = null)
	}
	return Un((() => {
		u(!0)
	})), e.proxy.__qPortal = !0, za(e.proxy, "contentEl", (() => t.value)), {
		showPortal: function(t) {
			if (!0 === t) return Yu(i), void(a.value = !0);
			var n;
			a.value = !1, !1 === l.value && (!1 === s && null === r && (r = function(e, t) {
				const n = document.createElement("div");
				if (n.id = void 0 !== t ? `q-portal--${t}--${yc++}` : e, void 0 !== Cr.globalNodes) {
					const e = Cr.globalNodes.class;
					void 0 !== e && (n.className = e)
				}
				return _c.appendChild(n), n
			}(!1, o)), l.value = !0, wc.push(e.proxy), Xu(n = i), Ju.push(n))
		},
		hidePortal: u,
		portalIsActive: l,
		portalIsAccessible: a,
		renderPortal: () => !0 === s ? n() : !0 === l.value ? [Tl(Uo, {
			to: r
		}, n())] : void 0
	}
}
const Sc = {
	transitionShow: {
		type: String,
		default: "fade"
	},
	transitionHide: {
		type: String,
		default: "fade"
	},
	transitionDuration: {
		type: [String, Number],
		default: 300
	}
};

function xc(e, t = (() => {}), n = (() => {})) {
	return {
		transitionProps: Ol((() => {
			const o = `q-transition--${e.transitionShow||t()}`,
				l = `q-transition--${e.transitionHide||n()}`;
			return {
				appear: !0,
				enterFromClass: `${o}-enter-from`,
				enterActiveClass: `${o}-enter-active`,
				enterToClass: `${o}-enter-to`,
				leaveFromClass: `${l}-leave-from`,
				leaveActiveClass: `${l}-leave-active`,
				leaveToClass: `${l}-leave-to`
			}
		})),
		transitionStyle: Ol((() => `--q-transition-duration: ${e.transitionDuration}ms`))
	}
}

function Cc() {
	let e;
	const t = Sl();

	function n() {
		e = void 0
	}
	return An(n), Dn(n), {
		removeTick: n,
		registerTick(n) {
			e = n, $t((() => {
				e === n && (!1 === Lu(t) && e(), e = void 0)
			}))
		}
	}
}

function Ec() {
	let e = null;
	const t = Sl();

	function n() {
		null !== e && (clearTimeout(e), e = null)
	}
	return An(n), Dn(n), {
		removeTimeout: n,
		registerTimeout(o, l) {
			n(), !1 === Lu(t) && (e = setTimeout(o, l))
		}
	}
}
const qc = [];
let Lc;

function Fc(e) {
	Lc = 27 === e.keyCode
}

function Rc() {
	!0 === Lc && (Lc = !1)
}

function Oc(e) {
	!0 === Lc && (Lc = !1, !0 === yr(e, 27) && qc[qc.length - 1](e))
}

function Tc(e) {
	window[e]("keydown", Fc), window[e]("blur", Rc), window[e]("keyup", Oc), Lc = !1
}

function Pc(e) {
	!0 === Wa.is.desktop && (qc.push(e), 1 === qc.length && Tc("addEventListener"))
}

function Ac(e) {
	const t = qc.indexOf(e);
	t > -1 && (qc.splice(t, 1), 0 === qc.length && Tc("removeEventListener"))
}
const Vc = [];

function Mc(e) {
	Vc[Vc.length - 1](e)
}

function Bc(e) {
	!0 === Wa.is.desktop && (Vc.push(e), 1 === Vc.length && document.body.addEventListener("focusin", Mc))
}

function Ic(e) {
	const t = Vc.indexOf(e);
	t > -1 && (Vc.splice(t, 1), 0 === Vc.length && document.body.removeEventListener("focusin", Mc))
}
const {
	notPassiveCapture: $c
} = Ga, zc = [];

function Nc(e) {
	const t = e.target;
	if (void 0 === t || 8 === t.nodeType || !0 === t.classList.contains("no-pointer-events")) return;
	let n = wc.length - 1;
	for (; n >= 0;) {
		const e = wc[n].$;
		if ("QDialog" !== e.type.name) break;
		if (!0 !== e.props.seamless) return;
		n--
	}
	for (let o = zc.length - 1; o >= 0; o--) {
		const n = zc[o];
		if (null !== n.anchorEl.value && !1 !== n.anchorEl.value.contains(t) || t !== document.body && (null === n.innerRef.value || !1 !== n.innerRef.value.contains(t))) return;
		e.qClickOutside = !0, n.onClickOutside(e)
	}
}

function jc(e) {
	const t = zc.findIndex((t => t === e));
	t > -1 && (zc.splice(t, 1), 0 === zc.length && (document.removeEventListener("mousedown", Nc, $c), document.removeEventListener("touchstart", Nc, $c)))
}
let Dc, Uc;

function Hc(e) {
	const t = e.split(" ");
	return 2 === t.length && (!0 !== ["top", "center", "bottom"].includes(t[0]) ? (console.error("Anchor/Self position must start with one of top/center/bottom"), !1) : !0 === ["left", "middle", "right", "start", "end"].includes(t[1]) || (console.error("Anchor/Self position must end with one of left/middle/right/start/end"), !1))
}
const Wc = {
	"start#ltr": "left",
	"start#rtl": "right",
	"end#ltr": "right",
	"end#rtl": "left"
};

function Kc(e, t) {
	const n = e.split(" ");
	return {
		vertical: n[0],
		horizontal: Wc[`${n[1]}#${!0===t?"rtl":"ltr"}`]
	}
}

function Qc(e, t, n) {
	return {
		top: e[n.anchorOrigin.vertical] - t[n.selfOrigin.vertical],
		left: e[n.anchorOrigin.horizontal] - t[n.selfOrigin.horizontal]
	}
}

function Gc(e, t, n, o, l) {
	const a = n.bottom,
		r = n.right,
		i = Ms(),
		s = window.innerHeight - i,
		u = document.body.clientWidth;
	if (e.top < 0 || e.top + a > s)
		if ("center" === l.vertical) e.top = t[o.vertical] > s / 2 ? Math.max(0, s - a) : 0, e.maxHeight = Math.min(a, s);
		else if (t[o.vertical] > s / 2) {
		const n = Math.min(s, "center" === o.vertical ? t.center : o.vertical === l.vertical ? t.bottom : t.top);
		e.maxHeight = Math.min(a, n), e.top = Math.max(0, n - a)
	} else e.top = Math.max(0, "center" === o.vertical ? t.center : o.vertical === l.vertical ? t.top : t.bottom), e.maxHeight = Math.min(a, s - e.top);
	if (e.left < 0 || e.left + r > u)
		if (e.maxWidth = Math.min(r, u), "middle" === l.horizontal) e.left = t[o.horizontal] > u / 2 ? Math.max(0, u - r) : 0;
		else if (t[o.horizontal] > u / 2) {
		const n = Math.min(u, "middle" === o.horizontal ? t.middle : o.horizontal === l.horizontal ? t.right : t.left);
		e.maxWidth = Math.min(r, n), e.left = Math.max(0, n - e.maxWidth)
	} else e.left = Math.max(0, "middle" === o.horizontal ? t.middle : o.horizontal === l.horizontal ? t.left : t.right), e.maxWidth = Math.min(r, u - e.left)
} ["left", "middle", "right"].forEach((e => {
	Wc[`${e}#ltr`] = e, Wc[`${e}#rtl`] = e
}));
var Zc = ys({
	name: "QMenu",
	inheritAttrs: !1,
	props: {
		...vc,
		...mc,
		...su,
		...Sc,
		persistent: Boolean,
		autoClose: Boolean,
		separateClosePopup: Boolean,
		noRouteDismiss: Boolean,
		noRefocus: Boolean,
		noFocus: Boolean,
		fit: Boolean,
		cover: Boolean,
		square: Boolean,
		anchor: {
			type: String,
			validator: Hc
		},
		self: {
			type: String,
			validator: Hc
		},
		offset: {
			type: Array,
			validator: function(e) {
				return !e || 2 === e.length && ("number" == typeof e[0] && "number" == typeof e[1])
			}
		},
		scrollTarget: {
			default: void 0
		},
		touchPosition: Boolean,
		maxHeight: {
			type: String,
			default: null
		},
		maxWidth: {
			type: String,
			default: null
		}
	},
	emits: [...gc, "click", "escapeKey"],
	setup(e, {
		slots: t,
		emit: n,
		attrs: o
	}) {
		let l, a, r, i = null;
		const s = Sl(),
			{
				proxy: u
			} = s,
			{
				$q: c
			} = u,
			d = yt(null),
			p = yt(!1),
			f = Ol((() => !0 !== e.persistent && !0 !== e.noRouteDismiss)),
			v = uu(e, c),
			{
				registerTick: h,
				removeTick: m
			} = Cc(),
			{
				registerTimeout: g
			} = Ec(),
			{
				transitionProps: b,
				transitionStyle: y
			} = xc(e),
			{
				localScrollTarget: _,
				changeScrollEvent: w,
				unconfigureScrollTarget: k
			} = function(e, t) {
				const n = yt(null);
				let o;

				function l(e, t) {
					const n = (void 0 !== t ? "add" : "remove") + "EventListener",
						l = void 0 !== t ? t : o;
					e !== window && e[n]("scroll", l, Ga.passive), window[n]("scroll", l, Ga.passive), o = t
				}

				function a() {
					null !== n.value && (l(n.value), n.value = null)
				}
				const r = gn((() => e.noParentEvent), (() => {
					null !== n.value && (a(), t())
				}));
				return Dn(r), {
					localScrollTarget: n,
					unconfigureScrollTarget: a,
					changeScrollEvent: l
				}
			}(e, B),
			{
				anchorEl: S,
				canShow: x
			} = hc({
				showing: p
			}),
			{
				hide: C
			} = bc({
				showing: p,
				canShow: x,
				handleShow: function(t) {
					if (i = !1 === e.noRefocus ? document.activeElement : null, Bc($), E(), B(), l = void 0, void 0 !== t && (e.touchPosition || e.contextMenu)) {
						const e = Ja(t);
						if (void 0 !== e.left) {
							const {
								top: t,
								left: n
							} = S.value.getBoundingClientRect();
							l = {
								left: e.left - n,
								top: e.top - t
							}
						}
					}
					void 0 === a && (a = gn((() => c.screen.width + "|" + c.screen.height + "|" + e.self + "|" + e.anchor + "|" + c.lang.rtl), N));
					!0 !== e.noFocus && document.activeElement.blur();
					h((() => {
						N(), !0 !== e.noFocus && V()
					})), g((() => {
						!0 === c.platform.is.ios && (r = e.autoClose, d.value.click()), N(), E(!0), n("show", t)
					}), e.transitionDuration)
				},
				handleHide: function(t) {
					m(), q(), M(!0), null === i || void 0 !== t && !0 === t.qClickOutside || (((t && 0 === t.type.indexOf("key") ? i.closest('[tabindex]:not([tabindex^="-"])') : void 0) || i).focus(), i = null);
					g((() => {
						q(!0), n("hide", t)
					}), e.transitionDuration)
				},
				hideOnRouteChange: f,
				processOnMount: !0
			}),
			{
				showPortal: E,
				hidePortal: q,
				renderPortal: L
			} = kc(s, d, (function() {
				return Tl(Zl, b.value, (() => !0 === p.value ? Tl("div", {
					role: "menu",
					...o,
					ref: d,
					tabindex: -1,
					class: ["q-menu q-position-engine scroll" + T.value, o.class],
					style: [o.style, y.value],
					...P.value
				}, Ss(t.default)) : null))
			}), "menu"),
			F = {
				anchorEl: S,
				innerRef: d,
				onClickOutside(t) {
					if (!0 !== e.persistent && !0 === p.value) return C(t), ("touchstart" === t.type || t.target.classList.contains("q-dialog__backdrop")) && er(t), !0
				}
			},
			R = Ol((() => Kc(e.anchor || (!0 === e.cover ? "center middle" : "bottom start"), c.lang.rtl))),
			O = Ol((() => !0 === e.cover ? R.value : Kc(e.self || "top start", c.lang.rtl))),
			T = Ol((() => (!0 === e.square ? " q-menu--square" : "") + (!0 === v.value ? " q-menu--dark q-dark" : ""))),
			P = Ol((() => !0 === e.autoClose ? {
				onClick: I
			} : {})),
			A = Ol((() => !0 === p.value && !0 !== e.persistent));

		function V() {
			ec((() => {
				let e = d.value;
				e && !0 !== e.contains(document.activeElement) && (e = e.querySelector("[autofocus][tabindex], [data-autofocus][tabindex]") || e.querySelector("[autofocus] [tabindex], [data-autofocus] [tabindex]") || e.querySelector("[autofocus], [data-autofocus]") || e, e.focus({
					preventScroll: !0
				}))
			}))
		}

		function M(e) {
			l = void 0, void 0 !== a && (a(), a = void 0), !0 !== e && !0 !== p.value || (Ic($), k(), jc(F), Ac(z)), !0 !== e && (i = null)
		}

		function B() {
			null === S.value && void 0 === e.scrollTarget || (_.value = Ts(S.value, e.scrollTarget), w(_.value, N))
		}

		function I(e) {
			!0 !== r ? (! function(e, t) {
				do {
					if ("QMenu" === e.$options.name) {
						if (e.hide(t), !0 === e.$props.separateClosePopup) return Eu(e)
					} else if (!0 === e.__qPortal) {
						const n = Eu(e);
						return void 0 !== n && "QPopupProxy" === n.$options.name ? (e.hide(t), n) : e
					}
					e = Eu(e)
				} while (null != e)
			}(u, e), n("click", e)) : r = !1
		}

		function $(t) {
			!0 === A.value && !0 !== e.noFocus && !0 !== Rs(d.value, t.target) && V()
		}

		function z(e) {
			n("escapeKey"), C(e)
		}

		function N() {
			const t = d.value;
			null !== t && null !== S.value && function(e) {
				if (!0 === Wa.is.ios && void 0 !== window.visualViewport) {
					const e = document.body.style,
						{
							offsetLeft: t,
							offsetTop: n
						} = window.visualViewport;
					t !== Dc && (e.setProperty("--q-pe-left", t + "px"), Dc = t), n !== Uc && (e.setProperty("--q-pe-top", n + "px"), Uc = n)
				}
				const {
					scrollLeft: t,
					scrollTop: n
				} = e.el, o = void 0 === e.absoluteOffset ? function(e, t) {
					let {
						top: n,
						left: o,
						right: l,
						bottom: a,
						width: r,
						height: i
					} = e.getBoundingClientRect();
					return void 0 !== t && (n -= t[1], o -= t[0], a += t[1], l += t[0], r += t[0], i += t[1]), {
						top: n,
						bottom: a,
						height: i,
						left: o,
						right: l,
						width: r,
						middle: o + (l - o) / 2,
						center: n + (a - n) / 2
					}
				}(e.anchorEl, !0 === e.cover ? [0, 0] : e.offset) : function(e, t, n) {
					let {
						top: o,
						left: l
					} = e.getBoundingClientRect();
					return o += t.top, l += t.left, void 0 !== n && (o += n[1], l += n[0]), {
						top: o,
						bottom: o + 1,
						height: 1,
						left: l,
						right: l + 1,
						width: 1,
						middle: l,
						center: o
					}
				}(e.anchorEl, e.absoluteOffset, e.offset);
				let l = {
					maxHeight: e.maxHeight,
					maxWidth: e.maxWidth,
					visibility: "visible"
				};
				!0 !== e.fit && !0 !== e.cover || (l.minWidth = o.width + "px", !0 === e.cover && (l.minHeight = o.height + "px")), Object.assign(e.el.style, l);
				const a = {
					top: 0,
					center: (r = e.el).offsetHeight / 2,
					bottom: r.offsetHeight,
					left: 0,
					middle: r.offsetWidth / 2,
					right: r.offsetWidth
				};
				var r;
				let i = Qc(o, a, e);
				if (void 0 === e.absoluteOffset || void 0 === e.offset) Gc(i, o, a, e.anchorOrigin, e.selfOrigin);
				else {
					const {
						top: t,
						left: n
					} = i;
					Gc(i, o, a, e.anchorOrigin, e.selfOrigin);
					let l = !1;
					if (i.top !== t) {
						l = !0;
						const t = 2 * e.offset[1];
						o.center = o.top -= t, o.bottom -= t + 2
					}
					if (i.left !== n) {
						l = !0;
						const t = 2 * e.offset[0];
						o.middle = o.left -= t, o.right -= t + 2
					}!0 === l && (i = Qc(o, a, e), Gc(i, o, a, e.anchorOrigin, e.selfOrigin))
				}
				l = {
					top: i.top + "px",
					left: i.left + "px"
				}, void 0 !== i.maxHeight && (l.maxHeight = i.maxHeight + "px", o.height > i.maxHeight && (l.minHeight = l.maxHeight)), void 0 !== i.maxWidth && (l.maxWidth = i.maxWidth + "px", o.width > i.maxWidth && (l.minWidth = l.maxWidth)), Object.assign(e.el.style, l), e.el.scrollTop !== n && (e.el.scrollTop = n), e.el.scrollLeft !== t && (e.el.scrollLeft = t)
			}({
				el: t,
				offset: e.offset,
				anchorEl: S.value,
				anchorOrigin: R.value,
				selfOrigin: O.value,
				absoluteOffset: l,
				fit: e.fit,
				cover: e.cover,
				maxHeight: e.maxHeight,
				maxWidth: e.maxWidth
			})
		}
		return gn(A, (e => {
			!0 === e ? (Pc(z), function(e) {
				zc.push(e), 1 === zc.length && (document.addEventListener("mousedown", Nc, $c), document.addEventListener("touchstart", Nc, $c))
			}(F)) : (Ac(z), jc(F))
		})), Dn(M), Object.assign(u, {
			focus: V,
			updatePosition: N
		}), L
	}
});
let Jc, Xc, Yc, ed, td, nd, od = 0,
	ld = !1,
	ad = null;

function rd(e) {
	(function(e) {
		if (e.target === document.body || e.target.classList.contains("q-layout__backdrop")) return !0;
		const t = function(e) {
				if (e.path) return e.path;
				if (e.composedPath) return e.composedPath();
				const t = [];
				let n = e.target;
				for (; n;) {
					if (t.push(n), "HTML" === n.tagName) return t.push(document), t.push(window), t;
					n = n.parentElement
				}
			}(e),
			n = e.shiftKey && !e.deltaX,
			o = !n && Math.abs(e.deltaX) <= Math.abs(e.deltaY),
			l = n || o ? e.deltaY : e.deltaX;
		for (let a = 0; a < t.length; a++) {
			const e = t[a];
			if (Bs(e, o)) return o ? l < 0 && 0 === e.scrollTop || l > 0 && e.scrollTop + e.clientHeight === e.scrollHeight : l < 0 && 0 === e.scrollLeft || l > 0 && e.scrollLeft + e.clientWidth === e.scrollWidth
		}
		return !0
	})(e) && er(e)
}

function id(e) {
	e.target === document && (document.scrollingElement.scrollTop = document.scrollingElement.scrollTop)
}

function sd(e) {
	!0 !== ld && (ld = !0, requestAnimationFrame((() => {
		ld = !1;
		const {
			height: t
		} = e.target, {
			clientHeight: n,
			scrollTop: o
		} = document.scrollingElement;
		void 0 !== Yc && t === window.innerHeight || (Yc = n - t, document.scrollingElement.scrollTop = o), o > Yc && (document.scrollingElement.scrollTop -= Math.ceil((o - Yc) / 8))
	})))
}

function ud(e) {
	const t = document.body,
		n = void 0 !== window.visualViewport;
	if ("add" === e) {
		const {
			overflowY: e,
			overflowX: o
		} = window.getComputedStyle(t);
		Jc = As(window), Xc = Ps(window), ed = t.style.left, td = t.style.top, nd = window.location.href, t.style.left = `-${Jc}px`, t.style.top = `-${Xc}px`, "hidden" !== o && ("scroll" === o || t.scrollWidth > window.innerWidth) && t.classList.add("q-body--force-scrollbar-x"), "hidden" !== e && ("scroll" === e || t.scrollHeight > window.innerHeight) && t.classList.add("q-body--force-scrollbar-y"), t.classList.add("q-body--prevent-scroll"), document.qScrollPrevented = !0, !0 === Wa.is.ios && (!0 === n ? (window.scrollTo(0, 0), window.visualViewport.addEventListener("resize", sd, Ga.passiveCapture), window.visualViewport.addEventListener("scroll", sd, Ga.passiveCapture), window.scrollTo(0, 0)) : window.addEventListener("scroll", id, Ga.passiveCapture))
	}!0 === Wa.is.desktop && !0 === Wa.is.mac && window[`${e}EventListener`]("wheel", rd, Ga.notPassive), "remove" === e && (!0 === Wa.is.ios && (!0 === n ? (window.visualViewport.removeEventListener("resize", sd, Ga.passiveCapture), window.visualViewport.removeEventListener("scroll", sd, Ga.passiveCapture)) : window.removeEventListener("scroll", id, Ga.passiveCapture)), t.classList.remove("q-body--prevent-scroll"), t.classList.remove("q-body--force-scrollbar-x"), t.classList.remove("q-body--force-scrollbar-y"), document.qScrollPrevented = !1, t.style.left = ed, t.style.top = td, window.location.href === nd && window.scrollTo(Jc, Xc), Yc = void 0)
}

function cd() {
	let e;
	return {
		preventBodyScroll(t) {
			t === e || void 0 === e && !0 !== t || (e = t, function(e) {
				let t = "add";
				if (!0 === e) {
					if (od++, null !== ad) return clearTimeout(ad), void(ad = null);
					if (od > 1) return
				} else {
					if (0 === od) return;
					if (od--, od > 0) return;
					if (t = "remove", !0 === Wa.is.ios && !0 === Wa.is.nativeMobile) return null !== ad && clearTimeout(ad), void(ad = setTimeout((() => {
						ud(t), ad = null
					}), 100))
				}
				ud(t)
			}(t))
		}
	}
}
let dd = 0;
const pd = {
		standard: "fixed-full flex-center",
		top: "fixed-top justify-center",
		bottom: "fixed-bottom justify-center",
		right: "fixed-right items-center",
		left: "fixed-left items-center"
	},
	fd = {
		standard: ["scale", "scale"],
		top: ["slide-down", "slide-up"],
		bottom: ["slide-up", "slide-down"],
		right: ["slide-left", "slide-right"],
		left: ["slide-right", "slide-left"]
	};
var vd = ys({
	name: "QDialog",
	inheritAttrs: !1,
	props: {
		...mc,
		...Sc,
		transitionShow: String,
		transitionHide: String,
		persistent: Boolean,
		autoClose: Boolean,
		allowFocusOutside: Boolean,
		noEscDismiss: Boolean,
		noBackdropDismiss: Boolean,
		noRouteDismiss: Boolean,
		noRefocus: Boolean,
		noFocus: Boolean,
		noShake: Boolean,
		seamless: Boolean,
		maximized: Boolean,
		fullWidth: Boolean,
		fullHeight: Boolean,
		square: Boolean,
		position: {
			type: String,
			default: "standard",
			validator: e => "standard" === e || ["top", "bottom", "left", "right"].includes(e)
		}
	},
	emits: [...gc, "shake", "click", "escapeKey"],
	setup(e, {
		slots: t,
		emit: n,
		attrs: o
	}) {
		const l = Sl(),
			{
				proxy: {
					$q: a
				}
			} = l,
			r = yt(null),
			i = yt(!1),
			s = yt(!1);
		let u, c, d = null,
			p = null;
		const f = Ol((() => !0 !== e.persistent && !0 !== e.noRouteDismiss && !0 !== e.seamless)),
			{
				preventBodyScroll: v
			} = cd(),
			{
				registerTimeout: h
			} = Ec(),
			{
				registerTick: m,
				removeTick: g
			} = Cc(),
			{
				transitionProps: b,
				transitionStyle: y
			} = xc(e, (() => fd[e.position][0]), (() => fd[e.position][1])),
			{
				showPortal: _,
				hidePortal: w,
				portalIsAccessible: k,
				renderPortal: S
			} = kc(l, r, (function() {
				return Tl("div", {
					role: "dialog",
					"aria-modal": !0 === L.value ? "true" : "false",
					...o,
					class: R.value
				}, [Tl(Zl, {
					name: "q-transition--fade",
					appear: !0
				}, (() => !0 === L.value ? Tl("div", {
					class: "q-dialog__backdrop fixed-full",
					style: y.value,
					"aria-hidden": "true",
					tabindex: -1,
					[$]: B
				}) : null)), Tl(Zl, b.value, (() => !0 === i.value ? Tl("div", {
					ref: r,
					class: q.value,
					style: y.value,
					tabindex: -1,
					...F.value
				}, Ss(t.default)) : null))])
			}), "dialog"),
			{
				hide: x
			} = bc({
				showing: i,
				hideOnRouteChange: f,
				handleShow: function(t) {
					C(), p = !1 === e.noRefocus && null !== document.activeElement ? document.activeElement : null, V(e.maximized), _(), s.value = !0, !0 !== e.noFocus ? (null !== document.activeElement && document.activeElement.blur(), m(O)) : g();
					h((() => {
						if (!0 === l.proxy.$q.platform.is.ios) {
							if (!0 !== e.seamless && document.activeElement) {
								const {
									top: e,
									bottom: t
								} = document.activeElement.getBoundingClientRect(), {
									innerHeight: n
								} = window, o = void 0 !== window.visualViewport ? window.visualViewport.height : n;
								e > 0 && t > o / 2 && (document.scrollingElement.scrollTop = Math.min(document.scrollingElement.scrollHeight - o, t >= n ? 1 / 0 : Math.ceil(document.scrollingElement.scrollTop + t - o / 2))), document.activeElement.scrollIntoView()
							}
							c = !0, r.value.click(), c = !1
						}
						_(!0), s.value = !1, n("show", t)
					}), e.transitionDuration)
				},
				handleHide: function(t) {
					g(), E(), A(!0), s.value = !0, w(), null !== p && (((t && 0 === t.type.indexOf("key") ? p.closest('[tabindex]:not([tabindex^="-"])') : void 0) || p).focus(), p = null);
					h((() => {
						w(!0), s.value = !1, n("hide", t)
					}), e.transitionDuration)
				},
				processOnMount: !0
			}),
			{
				addToHistory: C,
				removeFromHistory: E
			} = function(e, t, n) {
				let o;

				function l() {
					void 0 !== o && (dr.remove(o), o = void 0)
				}
				return Dn((() => {
					!0 === e.value && l()
				})), {
					removeFromHistory: l,
					addToHistory() {
						o = {
							condition: () => !0 === n.value,
							handler: t
						}, dr.add(o)
					}
				}
			}(i, x, f),
			q = Ol((() => `q-dialog__inner flex no-pointer-events q-dialog__inner--${!0===e.maximized?"maximized":"minimized"} q-dialog__inner--${e.position} ${pd[e.position]}` + (!0 === s.value ? " q-dialog__inner--animating" : "") + (!0 === e.fullWidth ? " q-dialog__inner--fullwidth" : "") + (!0 === e.fullHeight ? " q-dialog__inner--fullheight" : "") + (!0 === e.square ? " q-dialog__inner--square" : ""))),
			L = Ol((() => !0 === i.value && !0 !== e.seamless)),
			F = Ol((() => !0 === e.autoClose ? {
				onClick: M
			} : {})),
			R = Ol((() => ["q-dialog fullscreen no-pointer-events q-dialog--" + (!0 === L.value ? "modal" : "seamless"), o.class]));

		function O(e) {
			ec((() => {
				let t = r.value;
				null !== t && !0 !== t.contains(document.activeElement) && (t = ("" !== e ? t.querySelector(e) : null) || t.querySelector("[autofocus][tabindex], [data-autofocus][tabindex]") || t.querySelector("[autofocus] [tabindex], [data-autofocus] [tabindex]") || t.querySelector("[autofocus], [data-autofocus]") || t, t.focus({
					preventScroll: !0
				}))
			}))
		}

		function T(e) {
			e && "function" == typeof e.focus ? e.focus({
				preventScroll: !0
			}) : O(), n("shake");
			const t = r.value;
			null !== t && (t.classList.remove("q-animate--scale"), t.classList.add("q-animate--scale"), null !== d && clearTimeout(d), d = setTimeout((() => {
				d = null, null !== r.value && (t.classList.remove("q-animate--scale"), O())
			}), 170))
		}

		function P() {
			!0 !== e.seamless && (!0 === e.persistent || !0 === e.noEscDismiss ? !0 !== e.maximized && !0 !== e.noShake && T() : (n("escapeKey"), x()))
		}

		function A(t) {
			null !== d && (clearTimeout(d), d = null), !0 !== t && !0 !== i.value || (V(!1), !0 !== e.seamless && (v(!1), Ic(I), Ac(P))), !0 !== t && (p = null)
		}

		function V(e) {
			!0 === e ? !0 !== u && (dd < 1 && document.body.classList.add("q-body--dialog"), dd++, u = !0) : !0 === u && (dd < 2 && document.body.classList.remove("q-body--dialog"), dd--, u = !1)
		}

		function M(e) {
			!0 !== c && (x(e), n("click", e))
		}

		function B(t) {
			!0 !== e.persistent && !0 !== e.noBackdropDismiss ? x(t) : !0 !== e.noShake && T(t.relatedTarget)
		}

		function I(t) {
			!0 !== e.allowFocusOutside && !0 === k.value && !0 !== Rs(r.value, t.target) && O('[tabindex]:not([tabindex="-1"])')
		}
		gn((() => e.maximized), (e => {
			!0 === i.value && V(e)
		})), gn(L, (e => {
			v(e), !0 === e ? (Bc(I), Pc(P)) : (Ic(I), Ac(P))
		})), Object.assign(l.proxy, {
			focus: O,
			shake: T,
			__updateRefocusTarget(e) {
				p = e || null
			}
		}), Dn(A);
		const $ = !0 === a.platform.is.ios || a.platform.is.safari ? "onClick" : "onFocusin";
		return S
	}
});
let hd = !1;
{
	const e = document.createElement("div");
	e.setAttribute("dir", "rtl"), Object.assign(e.style, {
		width: "1px",
		height: "1px",
		overflow: "auto"
	});
	const t = document.createElement("div");
	Object.assign(t.style, {
		width: "1000px",
		height: "1px"
	}), document.body.appendChild(e), e.appendChild(t), e.scrollLeft = -1e3, hd = e.scrollLeft >= 0, e.remove()
}
const md = ["start", "center", "end", "start-force", "center-force", "end-force"],
	gd = Array.prototype.filter,
	bd = void 0 === window.getComputedStyle(document.body).overflowAnchor ? Za : function(e, t) {
		null !== e && (void 0 !== e._qOverflowAnimationFrame && cancelAnimationFrame(e._qOverflowAnimationFrame), e._qOverflowAnimationFrame = requestAnimationFrame((() => {
			if (null === e) return;
			e._qOverflowAnimationFrame = void 0;
			const n = e.children || [];
			gd.call(n, (e => e.dataset && void 0 !== e.dataset.qVsAnchor)).forEach((e => {
				delete e.dataset.qVsAnchor
			}));
			const o = n[t];
			o && o.dataset && (o.dataset.qVsAnchor = "")
		})))
	};

function yd(e, t) {
	return e + t
}

function _d(e, t, n, o, l, a, r, i) {
	const s = e === window ? document.scrollingElement || document.documentElement : e,
		u = !0 === l ? "offsetWidth" : "offsetHeight",
		c = {
			scrollStart: 0,
			scrollViewSize: -r - i,
			scrollMaxSize: 0,
			offsetStart: -r,
			offsetEnd: -i
		};
	if (!0 === l ? (e === window ? (c.scrollStart = window.pageXOffset || window.scrollX || document.body.scrollLeft || 0, c.scrollViewSize += document.documentElement.clientWidth) : (c.scrollStart = s.scrollLeft, c.scrollViewSize += s.clientWidth), c.scrollMaxSize = s.scrollWidth, !0 === a && (c.scrollStart = (!0 === hd ? c.scrollMaxSize - c.scrollViewSize : 0) - c.scrollStart)) : (e === window ? (c.scrollStart = window.pageYOffset || window.scrollY || document.body.scrollTop || 0, c.scrollViewSize += document.documentElement.clientHeight) : (c.scrollStart = s.scrollTop, c.scrollViewSize += s.clientHeight), c.scrollMaxSize = s.scrollHeight), null !== n)
		for (let d = n.previousElementSibling; null !== d; d = d.previousElementSibling) !1 === d.classList.contains("q-virtual-scroll--skip") && (c.offsetStart += d[u]);
	if (null !== o)
		for (let d = o.nextElementSibling; null !== d; d = d.nextElementSibling) !1 === d.classList.contains("q-virtual-scroll--skip") && (c.offsetEnd += d[u]);
	if (t !== e) {
		const n = s.getBoundingClientRect(),
			o = t.getBoundingClientRect();
		!0 === l ? (c.offsetStart += o.left - n.left, c.offsetEnd -= o.width) : (c.offsetStart += o.top - n.top, c.offsetEnd -= o.height), e !== window && (c.offsetStart += c.scrollStart), c.offsetEnd += c.scrollMaxSize - c.offsetStart
	}
	return c
}

function wd(e, t, n, o) {
	"end" === t && (t = (e === window ? document.body : e)[!0 === n ? "scrollWidth" : "scrollHeight"]), e === window ? !0 === n ? (!0 === o && (t = (!0 === hd ? document.body.scrollWidth - document.documentElement.clientWidth : 0) - t), window.scrollTo(t, window.pageYOffset || window.scrollY || document.body.scrollTop || 0)) : window.scrollTo(window.pageXOffset || window.scrollX || document.body.scrollLeft || 0, t) : !0 === n ? (!0 === o && (t = (!0 === hd ? e.scrollWidth - e.offsetWidth : 0) - t), e.scrollLeft = t) : e.scrollTop = t
}

function kd(e, t, n, o) {
	if (n >= o) return 0;
	const l = t.length,
		a = Math.floor(n / 1e3),
		r = Math.floor((o - 1) / 1e3) + 1;
	let i = e.slice(a, r).reduce(yd, 0);
	return n % 1e3 != 0 && (i -= t.slice(1e3 * a, n).reduce(yd, 0)), o % 1e3 != 0 && o !== l && (i -= t.slice(o, 1e3 * r).reduce(yd, 0)), i
}
const Sd = {
		virtualScrollSliceSize: {
			type: [Number, String],
			default: null
		},
		virtualScrollSliceRatioBefore: {
			type: [Number, String],
			default: 1
		},
		virtualScrollSliceRatioAfter: {
			type: [Number, String],
			default: 1
		},
		virtualScrollItemSize: {
			type: [Number, String],
			default: 24
		},
		virtualScrollStickySizeStart: {
			type: [Number, String],
			default: 0
		},
		virtualScrollStickySizeEnd: {
			type: [Number, String],
			default: 0
		},
		tableColspan: [Number, String]
	},
	xd = Object.keys(Sd),
	Cd = {
		virtualScrollHorizontal: Boolean,
		onVirtualScroll: Function,
		...Sd
	};

function Ed({
	virtualScrollLength: e,
	getVirtualScrollTarget: t,
	getVirtualScrollEl: n,
	virtualScrollItemSizeComputed: o
}) {
	const l = Sl(),
		{
			props: a,
			emit: r,
			proxy: i
		} = l,
		{
			$q: s
		} = i;
	let u, c, d, p, f = [];
	const v = yt(0),
		h = yt(0),
		m = yt({}),
		g = yt(null),
		b = yt(null),
		y = yt(null),
		_ = yt({
			from: 0,
			to: 0
		}),
		w = Ol((() => void 0 !== a.tableColspan ? a.tableColspan : 100));
	void 0 === o && (o = Ol((() => a.virtualScrollItemSize)));
	const k = Ol((() => o.value + ";" + a.virtualScrollHorizontal));

	function S() {
		F(c, !0)
	}

	function x(e) {
		F(void 0 === e ? c : e)
	}

	function C(o, l) {
		const r = t();
		if (null == r || 8 === r.nodeType) return;
		const i = _d(r, n(), g.value, b.value, a.virtualScrollHorizontal, s.lang.rtl, a.virtualScrollStickySizeStart, a.virtualScrollStickySizeEnd);
		d !== i.scrollViewSize && R(i.scrollViewSize), E(r, i, Math.min(e.value - 1, Math.max(0, parseInt(o, 10) || 0)), 0, md.indexOf(l) > -1 ? l : c > -1 && o > c ? "end" : "start")
	}

	function E(t, n, o, l, r) {
		const i = "string" == typeof r && r.indexOf("-force") > -1,
			c = !0 === i ? r.replace("-force", "") : r,
			d = void 0 !== c ? c : "start";
		let g = Math.max(0, o - m.value[d]),
			b = g + m.value.total;
		b > e.value && (b = e.value, g = Math.max(0, b - m.value.total)), u = n.scrollStart;
		const w = g !== _.value.from || b !== _.value.to;
		if (!1 === w && void 0 === c) return void O(o);
		const {
			activeElement: k
		} = document, S = y.value;
		!0 === w && null !== S && S !== k && !0 === S.contains(k) && (S.addEventListener("focusout", L), setTimeout((() => {
			null !== S && S.removeEventListener("focusout", L)
		}))), bd(S, o - g);
		const x = void 0 !== c ? p.slice(g, o).reduce(yd, 0) : 0;
		if (!0 === w) {
			const t = b >= _.value.from && g <= _.value.to ? _.value.to : b;
			_.value = {
				from: g,
				to: t
			}, v.value = kd(f, p, 0, g), h.value = kd(f, p, b, e.value), requestAnimationFrame((() => {
				_.value.to !== b && u === n.scrollStart && (_.value = {
					from: _.value.from,
					to: b
				}, h.value = kd(f, p, b, e.value))
			}))
		}
		requestAnimationFrame((() => {
			if (u !== n.scrollStart) return;
			!0 === w && q(g);
			const e = p.slice(g, o).reduce(yd, 0),
				r = e + n.offsetStart + v.value,
				d = r + p[o];
			let f = r + l;
			if (void 0 !== c) {
				const t = e - x,
					l = n.scrollStart + t;
				f = !0 !== i && l < r && d < l + n.scrollViewSize ? l : "end" === c ? d - n.scrollViewSize : r - ("start" === c ? 0 : Math.round((n.scrollViewSize - p[o]) / 2))
			}
			u = f, wd(t, f, a.virtualScrollHorizontal, s.lang.rtl), O(o)
		}))
	}

	function q(e) {
		const t = y.value;
		if (t) {
			const n = gd.call(t.children, (e => e.classList && !1 === e.classList.contains("q-virtual-scroll--skip"))),
				o = n.length,
				l = !0 === a.virtualScrollHorizontal ? e => e.getBoundingClientRect().width : e => e.offsetHeight;
			let r, i, s = e;
			for (let e = 0; e < o;) {
				for (r = l(n[e]), e++; e < o && !0 === n[e].classList.contains("q-virtual-scroll--with-prev");) r += l(n[e]), e++;
				i = r - p[s], 0 !== i && (p[s] += i, f[Math.floor(s / 1e3)] += i), s++
			}
		}
	}

	function L() {
		null !== y.value && void 0 !== y.value && y.value.focus()
	}

	function F(t, n) {
		const l = 1 * o.value;
		!0 !== n && !1 !== Array.isArray(p) || (p = []);
		const a = p.length;
		p.length = e.value;
		for (let o = e.value - 1; o >= a; o--) p[o] = l;
		const r = Math.floor((e.value - 1) / 1e3);
		f = [];
		for (let o = 0; o <= r; o++) {
			let t = 0;
			const n = Math.min(1e3 * (o + 1), e.value);
			for (let e = 1e3 * o; e < n; e++) t += p[e];
			f.push(t)
		}
		c = -1, u = void 0, v.value = kd(f, p, 0, _.value.from), h.value = kd(f, p, _.value.to, e.value), t >= 0 ? (q(_.value.from), $t((() => {
			C(t)
		}))) : T()
	}

	function R(e) {
		if (void 0 === e && "undefined" != typeof window) {
			const o = t();
			null != o && 8 !== o.nodeType && (e = _d(o, n(), g.value, b.value, a.virtualScrollHorizontal, s.lang.rtl, a.virtualScrollStickySizeStart, a.virtualScrollStickySizeEnd).scrollViewSize)
		}
		d = e;
		const l = parseFloat(a.virtualScrollSliceRatioBefore) || 0,
			r = 1 + l + (parseFloat(a.virtualScrollSliceRatioAfter) || 0),
			i = void 0 === e || e <= 0 ? 1 : Math.ceil(e / o.value),
			u = Math.max(1, i, Math.ceil((a.virtualScrollSliceSize > 0 ? a.virtualScrollSliceSize : 10) / r));
		m.value = {
			total: Math.ceil(u * r),
			start: Math.ceil(u * l),
			center: Math.ceil(u * (.5 + l)),
			end: Math.ceil(u * (1 + l)),
			view: i
		}
	}

	function O(e) {
		c !== e && (void 0 !== a.onVirtualScroll && r("virtualScroll", {
			index: e,
			from: _.value.from,
			to: _.value.to - 1,
			direction: e < c ? "decrease" : "increase",
			ref: i
		}), c = e)
	}
	gn(Ol((() => k.value + ";" + a.virtualScrollSliceRatioBefore + ";" + a.virtualScrollSliceRatioAfter)), (() => {
		R()
	})), gn(k, S), R();
	const T = or((function() {
		const o = t();
		if (null == o || 8 === o.nodeType) return;
		const l = _d(o, n(), g.value, b.value, a.virtualScrollHorizontal, s.lang.rtl, a.virtualScrollStickySizeStart, a.virtualScrollStickySizeEnd),
			r = e.value - 1,
			i = l.scrollMaxSize - l.offsetStart - l.offsetEnd - h.value;
		if (u === l.scrollStart) return;
		if (l.scrollMaxSize <= 0) return void E(o, l, 0, 0);
		d !== l.scrollViewSize && R(l.scrollViewSize), q(_.value.from);
		const c = Math.floor(l.scrollMaxSize - Math.max(l.scrollViewSize, l.offsetEnd) - Math.min(p[r], l.scrollViewSize / 2));
		if (c > 0 && Math.ceil(l.scrollStart) >= c) return void E(o, l, r, l.scrollMaxSize - l.offsetEnd - f.reduce(yd, 0));
		let m = 0,
			y = l.scrollStart - l.offsetStart,
			w = y;
		if (y <= i && y + l.scrollViewSize >= v.value) y -= v.value, m = _.value.from, w = y;
		else
			for (let e = 0; y >= f[e] && m < r; e++) y -= f[e], m += 1e3;
		for (; y > 0 && m < r;) y -= p[m], y > -l.scrollViewSize ? (m++, w = y) : w = p[m] + y;
		E(o, l, m, w)
	}), !0 === s.platform.is.ios ? 120 : 35);
	$n((() => {
		R()
	}));
	let P = !1;
	return An((() => {
		P = !0
	})), Pn((() => {
		if (!0 !== P) return;
		const e = t();
		void 0 !== u && null != e && 8 !== e.nodeType ? wd(e, u, a.virtualScrollHorizontal, s.lang.rtl) : C(c)
	})), Dn((() => {
		T.cancel()
	})), Object.assign(i, {
		scrollTo: C,
		reset: S,
		refresh: x
	}), {
		virtualScrollSliceRange: _,
		virtualScrollSliceSizeComputed: m,
		setVirtualScrollSize: R,
		onVirtualScrollEvt: T,
		localResetVirtualScroll: F,
		padVirtualScroll: function(e, t) {
			const n = !0 === a.virtualScrollHorizontal ? "width" : "height",
				l = {
					["--q-virtual-scroll-item-" + n]: o.value + "px"
				};
			return ["tbody" === e ? Tl(e, {
				class: "q-virtual-scroll__padding",
				key: "before",
				ref: g
			}, [Tl("tr", [Tl("td", {
				style: {
					[n]: `${v.value}px`,
					...l
				},
				colspan: w.value
			})])]) : Tl(e, {
				class: "q-virtual-scroll__padding",
				key: "before",
				ref: g,
				style: {
					[n]: `${v.value}px`,
					...l
				}
			}), Tl(e, {
				class: "q-virtual-scroll__content",
				key: "content",
				ref: y,
				tabindex: -1
			}, t.flat()), "tbody" === e ? Tl(e, {
				class: "q-virtual-scroll__padding",
				key: "after",
				ref: b
			}, [Tl("tr", [Tl("td", {
				style: {
					[n]: `${h.value}px`,
					...l
				},
				colspan: w.value
			})])]) : Tl(e, {
				class: "q-virtual-scroll__padding",
				key: "after",
				ref: b,
				style: {
					[n]: `${h.value}px`,
					...l
				}
			})]
		},
		scrollTo: C,
		reset: S,
		refresh: x
	}
}
const qd = /[\u3000-\u303f\u3040-\u309f\u30a0-\u30ff\uff00-\uff9f\u4e00-\u9faf\u3400-\u4dbf]/,
	Ld = /[\u4e00-\u9fff\u3400-\u4dbf\u{20000}-\u{2a6df}\u{2a700}-\u{2b73f}\u{2b740}-\u{2b81f}\u{2b820}-\u{2ceaf}\uf900-\ufaff\u3300-\u33ff\ufe30-\ufe4f\uf900-\ufaff\u{2f800}-\u{2fa1f}]/u,
	Fd = /[\u3131-\u314e\u314f-\u3163\uac00-\ud7a3]/,
	Rd = /[a-z0-9_ -]$/i;

function Od(e) {
	return function(t) {
		if ("compositionend" === t.type || "change" === t.type) {
			if (!0 !== t.target.qComposing) return;
			t.target.qComposing = !1, e(t)
		} else if ("compositionupdate" === t.type && !0 !== t.target.qComposing && "string" == typeof t.data) {
			!0 === (!0 === Wa.is.firefox ? !1 === Rd.test(t.data) : !0 === qd.test(t.data) || !0 === Ld.test(t.data) || !0 === Fd.test(t.data)) && (t.target.qComposing = !0)
		}
	}
}

function Td(e, t, n) {
	if (n <= t) return t;
	const o = n - t + 1;
	let l = t + (e - t) % o;
	return l < t && (l = o + l), 0 === l ? 0 : l
}
const Pd = e => ["add", "add-unique", "toggle"].includes(e),
	Ad = Object.keys(oc);
var Vd = ys({
	name: "QSelect",
	inheritAttrs: !1,
	props: {
		...Cd,
		...cu,
		...oc,
		modelValue: {
			required: !0
		},
		multiple: Boolean,
		displayValue: [String, Number],
		displayValueHtml: Boolean,
		dropdownIcon: String,
		options: {
			type: Array,
			default: () => []
		},
		optionValue: [Function, String],
		optionLabel: [Function, String],
		optionDisable: [Function, String],
		hideSelected: Boolean,
		hideDropdownIcon: Boolean,
		fillInput: Boolean,
		maxValues: [Number, String],
		optionsDense: Boolean,
		optionsDark: {
			type: Boolean,
			default: null
		},
		optionsSelectedClass: String,
		optionsHtml: Boolean,
		optionsCover: Boolean,
		menuShrink: Boolean,
		menuAnchor: String,
		menuSelf: String,
		menuOffset: Array,
		popupContentClass: String,
		popupContentStyle: [String, Array, Object],
		useInput: Boolean,
		useChips: Boolean,
		newValueMode: {
			type: String,
			validator: Pd
		},
		mapOptions: Boolean,
		emitValue: Boolean,
		inputDebounce: {
			type: [Number, String],
			default: 500
		},
		inputClass: [Array, String, Object],
		inputStyle: [Array, String, Object],
		tabindex: {
			type: [String, Number],
			default: 0
		},
		autocomplete: String,
		transitionShow: String,
		transitionHide: String,
		transitionDuration: [String, Number],
		behavior: {
			type: String,
			validator: e => ["default", "menu", "dialog"].includes(e),
			default: "default"
		},
		virtualScrollItemSize: {
			type: [Number, String],
			default: void 0
		},
		onNewValue: Function,
		onFilter: Function
	},
	emits: [...lc, "add", "remove", "inputValue", "newValue", "keyup", "keypress", "keydown", "filterAbort"],
	setup(e, {
		slots: t,
		emit: n
	}) {
		const {
			proxy: o
		} = Sl(), {
			$q: l
		} = o, a = yt(!1), r = yt(!1), i = yt(-1), s = yt(""), u = yt(!1), c = yt(!1);
		let d, p, f, v, h, m, g, b = null,
			y = null;
		const _ = yt(null),
			w = yt(null),
			k = yt(null),
			S = yt(null),
			x = yt(null),
			C = du(e),
			E = Od(Se),
			q = Ol((() => Array.isArray(e.options) ? e.options.length : 0)),
			L = Ol((() => void 0 === e.virtualScrollItemSize ? !0 === e.optionsDense ? 24 : 48 : e.virtualScrollItemSize)),
			{
				virtualScrollSliceRange: F,
				virtualScrollSliceSizeComputed: R,
				localResetVirtualScroll: O,
				padVirtualScroll: T,
				onVirtualScrollEvt: P,
				scrollTo: A,
				setVirtualScrollSize: V
			} = Ed({
				virtualScrollLength: q,
				getVirtualScrollTarget: function() {
					return we()
				},
				getVirtualScrollEl: we,
				virtualScrollItemSizeComputed: L
			}),
			M = ac(),
			B = Ol((() => {
				const t = !0 === e.mapOptions && !0 !== e.multiple,
					n = void 0 === e.modelValue || null === e.modelValue && !0 !== t ? [] : !0 === e.multiple && Array.isArray(e.modelValue) ? e.modelValue : [e.modelValue];
				if (!0 === e.mapOptions && !0 === Array.isArray(e.options)) {
					const o = !0 === e.mapOptions && void 0 !== d ? d : [],
						l = n.map((t => function(t, n) {
							const o = e => qr(ne.value(e), t);
							return e.options.find(o) || n.find(o) || t
						}(t, o)));
					return null === e.modelValue && !0 === t ? l.filter((e => null !== e)) : l
				}
				return n
			})),
			I = Ol((() => {
				const t = {};
				return Ad.forEach((n => {
					const o = e[n];
					void 0 !== o && (t[n] = o)
				})), t
			})),
			$ = Ol((() => null === e.optionsDark ? M.isDark.value : e.optionsDark)),
			z = Ol((() => nc(B.value))),
			N = Ol((() => {
				let t = "q-field__input q-placeholder col";
				return !0 === e.hideSelected || 0 === B.value.length ? [t, e.inputClass] : (t += " q-field__input--padding", void 0 === e.inputClass ? t : [t, e.inputClass])
			})),
			j = Ol((() => (!0 === e.virtualScrollHorizontal ? "q-virtual-scroll--horizontal" : "") + (e.popupContentClass ? " " + e.popupContentClass : ""))),
			D = Ol((() => 0 === q.value)),
			U = Ol((() => B.value.map((e => oe.value(e))).join(", "))),
			H = Ol((() => void 0 !== e.displayValue ? e.displayValue : U.value)),
			W = Ol((() => !0 === e.optionsHtml ? () => !0 : e => null != e && !0 === e.html)),
			K = Ol((() => !0 === e.displayValueHtml || void 0 === e.displayValue && (!0 === e.optionsHtml || B.value.some(W.value)))),
			Q = Ol((() => !0 === M.focused.value ? e.tabindex : -1)),
			G = Ol((() => {
				const t = {
					tabindex: e.tabindex,
					role: "combobox",
					"aria-label": e.label,
					"aria-readonly": !0 === e.readonly ? "true" : "false",
					"aria-autocomplete": !0 === e.useInput ? "list" : "none",
					"aria-expanded": !0 === a.value ? "true" : "false",
					"aria-controls": `${M.targetUid.value}_lb`
				};
				return i.value >= 0 && (t["aria-activedescendant"] = `${M.targetUid.value}_${i.value}`), t
			})),
			Z = Ol((() => ({
				id: `${M.targetUid.value}_lb`,
				role: "listbox",
				"aria-multiselectable": !0 === e.multiple ? "true" : "false"
			}))),
			J = Ol((() => B.value.map(((e, t) => ({
				index: t,
				opt: e,
				html: W.value(e),
				selected: !0,
				removeAtIndex: ue,
				toggleOption: de,
				tabindex: Q.value
			}))))),
			X = Ol((() => {
				if (0 === q.value) return [];
				const {
					from: t,
					to: n
				} = F.value;
				return e.options.slice(t, n).map(((n, o) => {
					const r = !0 === le.value(n),
						s = t + o,
						u = {
							clickable: !0,
							active: !1,
							activeClass: te.value,
							manualFocus: !0,
							focused: !1,
							disable: r,
							tabindex: -1,
							dense: e.optionsDense,
							dark: $.value,
							role: "option",
							id: `${M.targetUid.value}_${s}`,
							onClick: () => {
								de(n)
							}
						};
					return !0 !== r && (!0 === he(n) && (u.active = !0), i.value === s && (u.focused = !0), u["aria-selected"] = !0 === u.active ? "true" : "false", !0 === l.platform.is.desktop && (u.onMousemove = () => {
						!0 === a.value && pe(s)
					})), {
						index: s,
						opt: n,
						html: W.value(n),
						label: oe.value(n),
						selected: u.active,
						focused: u.focused,
						toggleOption: de,
						setOptionIndex: pe,
						itemProps: u
					}
				}))
			})),
			Y = Ol((() => void 0 !== e.dropdownIcon ? e.dropdownIcon : l.iconSet.arrow.dropdown)),
			ee = Ol((() => !1 === e.optionsCover && !0 !== e.outlined && !0 !== e.standout && !0 !== e.borderless && !0 !== e.rounded)),
			te = Ol((() => void 0 !== e.optionsSelectedClass ? e.optionsSelectedClass : void 0 !== e.color ? `text-${e.color}` : "")),
			ne = Ol((() => ve(e.optionValue, "value"))),
			oe = Ol((() => ve(e.optionLabel, "label"))),
			le = Ol((() => ve(e.optionDisable, "disable"))),
			ae = Ol((() => B.value.map((e => ne.value(e))))),
			re = Ol((() => {
				const e = {
					onInput: Se,
					onChange: E,
					onKeydown: _e,
					onKeyup: be,
					onKeypress: ye,
					onFocus: me,
					onClick(e) {
						!0 === p && Xa(e)
					}
				};
				return e.onCompositionstart = e.onCompositionupdate = e.onCompositionend = E, e
			}));

		function ie(t) {
			return !0 === e.emitValue ? ne.value(t) : t
		}

		function se(t) {
			if (t > -1 && t < B.value.length)
				if (!0 === e.multiple) {
					const o = e.modelValue.slice();
					n("remove", {
						index: t,
						value: o.splice(t, 1)[0]
					}), n("update:modelValue", o)
				} else n("update:modelValue", null)
		}

		function ue(e) {
			se(e), M.focus()
		}

		function ce(t, o) {
			const l = ie(t);
			if (!0 !== e.multiple) return !0 === e.fillInput && Ce(oe.value(t), !0, !0), void n("update:modelValue", l);
			if (0 === B.value.length) return n("add", {
				index: 0,
				value: l
			}), void n("update:modelValue", !0 === e.multiple ? [l] : l);
			if (!0 === o && !0 === he(t)) return;
			if (void 0 !== e.maxValues && e.modelValue.length >= e.maxValues) return;
			const a = e.modelValue.slice();
			n("add", {
				index: a.length,
				value: l
			}), a.push(l), n("update:modelValue", a)
		}

		function de(t, o) {
			if (!0 !== M.editable.value || void 0 === t || !0 === le.value(t)) return;
			const l = ne.value(t);
			if (!0 !== e.multiple) return !0 !== o && (Ce(!0 === e.fillInput ? oe.value(t) : "", !0, !0), Me()), null !== w.value && w.value.focus(), void(0 !== B.value.length && !0 === qr(ne.value(B.value[0]), l) || n("update:modelValue", !0 === e.emitValue ? l : t));
			if ((!0 !== p || !0 === u.value) && M.focus(), me(), 0 === B.value.length) {
				const o = !0 === e.emitValue ? l : t;
				return n("add", {
					index: 0,
					value: o
				}), void n("update:modelValue", !0 === e.multiple ? [o] : o)
			}
			const a = e.modelValue.slice(),
				r = ae.value.findIndex((e => qr(e, l)));
			if (r > -1) n("remove", {
				index: r,
				value: a.splice(r, 1)[0]
			});
			else {
				if (void 0 !== e.maxValues && a.length >= e.maxValues) return;
				const o = !0 === e.emitValue ? l : t;
				n("add", {
					index: a.length,
					value: o
				}), a.push(o)
			}
			n("update:modelValue", a)
		}

		function pe(e) {
			if (!0 !== l.platform.is.desktop) return;
			const t = e > -1 && e < q.value ? e : -1;
			i.value !== t && (i.value = t)
		}

		function fe(t = 1, n) {
			if (!0 === a.value) {
				let o = i.value;
				do {
					o = Td(o + t, -1, q.value - 1)
				} while (-1 !== o && o !== i.value && !0 === le.value(e.options[o]));
				i.value !== o && (pe(o), A(o), !0 !== n && !0 === e.useInput && !0 === e.fillInput && xe(o >= 0 ? oe.value(e.options[o]) : v))
			}
		}

		function ve(e, t) {
			const n = void 0 !== e ? e : t;
			return "function" == typeof n ? n : e => null !== e && "object" == typeof e && n in e ? e[n] : e
		}

		function he(e) {
			const t = ne.value(e);
			return void 0 !== ae.value.find((e => qr(e, t)))
		}

		function me(t) {
			!0 === e.useInput && null !== w.value && (void 0 === t || w.value === t.target && t.target.value === U.value) && w.value.select()
		}

		function ge(e) {
			!0 === yr(e, 27) && !0 === a.value && (Xa(e), Me(), Be()), n("keyup", e)
		}

		function be(t) {
			const {
				value: n
			} = t.target;
			if (void 0 === t.keyCode)
				if (t.target.value = "", null !== b && (clearTimeout(b), b = null), Be(), "string" == typeof n && n.length > 0) {
					const t = n.toLocaleLowerCase(),
						o = n => {
							const o = e.options.find((e => n.value(e).toLocaleLowerCase() === t));
							return void 0 !== o && (-1 === B.value.indexOf(o) ? de(o) : Me(), !0)
						},
						l = e => {
							!0 !== o(ne) && !0 !== o(oe) && !0 !== e && Ee(n, !0, (() => l(!0)))
						};
					l()
				} else M.clearValue(t);
			else ge(t)
		}

		function ye(e) {
			n("keypress", e)
		}

		function _e(t) {
			if (n("keydown", t), !0 === br(t)) return;
			const o = s.value.length > 0 && (void 0 !== e.newValueMode || void 0 !== e.onNewValue),
				l = !0 !== t.shiftKey && !0 !== e.multiple && (i.value > -1 || !0 === o);
			if (27 === t.keyCode) return void Ya(t);
			if (9 === t.keyCode && !1 === l) return void Ae();
			if (void 0 === t.target || t.target.id !== M.targetUid.value) return;
			if (40 === t.keyCode && !0 !== M.innerLoading.value && !1 === a.value) return er(t), void Ve();
			if (8 === t.keyCode && !0 !== e.hideSelected && 0 === s.value.length) return void(!0 === e.multiple && !0 === Array.isArray(e.modelValue) ? se(e.modelValue.length - 1) : !0 !== e.multiple && null !== e.modelValue && n("update:modelValue", null));
			35 !== t.keyCode && 36 !== t.keyCode || "string" == typeof s.value && 0 !== s.value.length || (er(t), i.value = -1, fe(36 === t.keyCode ? 1 : -1, e.multiple)), 33 !== t.keyCode && 34 !== t.keyCode || void 0 === R.value || (er(t), i.value = Math.max(-1, Math.min(q.value, i.value + (33 === t.keyCode ? -1 : 1) * R.value.view)), fe(33 === t.keyCode ? 1 : -1, e.multiple)), 38 !== t.keyCode && 40 !== t.keyCode || (er(t), fe(38 === t.keyCode ? -1 : 1, e.multiple));
			const r = q.value;
			if ((void 0 === m || g < Date.now()) && (m = ""), r > 0 && !0 !== e.useInput && void 0 !== t.key && 1 === t.key.length && !1 === t.altKey && !1 === t.ctrlKey && !1 === t.metaKey && (32 !== t.keyCode || m.length > 0)) {
				!0 !== a.value && Ve(t);
				const n = t.key.toLocaleLowerCase(),
					o = 1 === m.length && m[0] === n;
				g = Date.now() + 1500, !1 === o && (er(t), m += n);
				const l = new RegExp("^" + m.split("").map((e => ".*+?^${}()|[]\\".indexOf(e) > -1 ? "\\" + e : e)).join(".*"), "i");
				let s = i.value;
				if (!0 === o || s < 0 || !0 !== l.test(oe.value(e.options[s])))
					do {
						s = Td(s + 1, -1, r - 1)
					} while (s !== i.value && (!0 === le.value(e.options[s]) || !0 !== l.test(oe.value(e.options[s]))));
				i.value !== s && $t((() => {
					pe(s), A(s), s >= 0 && !0 === e.useInput && !0 === e.fillInput && xe(oe.value(e.options[s]))
				}))
			} else if (13 === t.keyCode || 32 === t.keyCode && !0 !== e.useInput && "" === m || 9 === t.keyCode && !1 !== l)
				if (9 !== t.keyCode && er(t), i.value > -1 && i.value < r) de(e.options[i.value]);
				else {
					if (!0 === o) {
						const t = (t, n) => {
							if (n) {
								if (!0 !== Pd(n)) return
							} else n = e.newValueMode;
							if (null == t) return;
							Ce("", !0 !== e.multiple, !0);
							("toggle" === n ? de : ce)(t, "add-unique" === n), !0 !== e.multiple && (null !== w.value && w.value.focus(), Me())
						};
						if (void 0 !== e.onNewValue ? n("newValue", s.value, t) : t(s.value), !0 !== e.multiple) return
					}!0 === a.value ? Ae() : !0 !== M.innerLoading.value && Ve()
				}
		}

		function we() {
			return !0 === p ? x.value : null !== k.value && null !== k.value.contentEl ? k.value.contentEl : void 0
		}

		function ke() {
			if (!0 === D.value) return void 0 !== t["no-option"] ? t["no-option"]({
				inputValue: s.value
			}) : void 0;
			const e = void 0 !== t.option ? t.option : e => Tl(Vu, {
				key: e.index,
				...e.itemProps
			}, (() => Tl(xu, (() => Tl(Cu, (() => Tl("span", {
				[!0 === e.html ? "innerHTML" : "textContent"]: e.label
			})))))));
			let n = T("div", X.value.map(e));
			return void 0 !== t["before-options"] && (n = t["before-options"]().concat(n)), Cs(t["after-options"], n)
		}

		function Se(t) {
			null !== b && (clearTimeout(b), b = null), t && t.target && !0 === t.target.qComposing || (xe(t.target.value || ""), f = !0, v = s.value, !0 === M.focused.value || !0 === p && !0 !== u.value || M.focus(), void 0 !== e.onFilter && (b = setTimeout((() => {
				b = null, Ee(s.value)
			}), e.inputDebounce)))
		}

		function xe(e) {
			s.value !== e && (s.value = e, n("inputValue", e))
		}

		function Ce(t, n, o) {
			f = !0 !== o, !0 === e.useInput && (xe(t), !0 !== n && !0 === o || (v = t), !0 !== n && Ee(t))
		}

		function Ee(t, l, r) {
			if (void 0 === e.onFilter || !0 !== l && !0 !== M.focused.value) return;
			!0 === M.innerLoading.value ? n("filterAbort") : (M.innerLoading.value = !0, c.value = !0), "" !== t && !0 !== e.multiple && B.value.length > 0 && !0 !== f && t === oe.value(B.value[0]) && (t = "");
			const i = setTimeout((() => {
				!0 === a.value && (a.value = !1)
			}), 10);
			null !== y && clearTimeout(y), y = i, n("filter", t, ((e, t) => {
				!0 !== l && !0 !== M.focused.value || y !== i || (clearTimeout(y), "function" == typeof e && e(), c.value = !1, $t((() => {
					M.innerLoading.value = !1, !0 === M.editable.value && (!0 === l ? !0 === a.value && Me() : !0 === a.value ? Ie(!0) : a.value = !0), "function" == typeof t && $t((() => {
						t(o)
					})), "function" == typeof r && $t((() => {
						r(o)
					}))
				})))
			}), (() => {
				!0 === M.focused.value && y === i && (clearTimeout(y), M.innerLoading.value = !1, c.value = !1), !0 === a.value && (a.value = !1)
			}))
		}

		function qe(e) {
			Ne(e), Ae()
		}

		function Le() {
			V()
		}

		function Fe(e) {
			Xa(e), null !== w.value && w.value.focus(), u.value = !0, window.scrollTo(window.pageXOffset || window.scrollX || document.body.scrollLeft || 0, 0)
		}

		function Re(e) {
			Xa(e), $t((() => {
				u.value = !1
			}))
		}

		function Oe(e) {
			Ne(e), null !== S.value && S.value.__updateRefocusTarget(M.rootRef.value.querySelector(".q-field__native > [tabindex]:last-child")), M.focused.value = !1
		}

		function Te(e) {
			Me(), !1 === M.focused.value && n("blur", e), Be()
		}

		function Pe() {
			const e = document.activeElement;
			null !== e && e.id === M.targetUid.value || null === w.value || w.value === e || w.value.focus(), V()
		}

		function Ae() {
			!0 !== r.value && (i.value = -1, !0 === a.value && (a.value = !1), !1 === M.focused.value && (null !== y && (clearTimeout(y), y = null), !0 === M.innerLoading.value && (n("filterAbort"), M.innerLoading.value = !1, c.value = !1)))
		}

		function Ve(n) {
			!0 === M.editable.value && (!0 === p ? (M.onControlFocusin(n), r.value = !0, $t((() => {
				M.focus()
			}))) : M.focus(), void 0 !== e.onFilter ? Ee(s.value) : !0 === D.value && void 0 === t["no-option"] || (a.value = !0))
		}

		function Me() {
			r.value = !1, Ae()
		}

		function Be() {
			!0 === e.useInput && Ce(!0 !== e.multiple && !0 === e.fillInput && B.value.length > 0 && oe.value(B.value[0]) || "", !0, !0)
		}

		function Ie(t) {
			let n = -1;
			if (!0 === t) {
				if (B.value.length > 0) {
					const t = ne.value(B.value[0]);
					n = e.options.findIndex((e => qr(ne.value(e), t)))
				}
				O(n)
			}
			pe(n)
		}

		function $e() {
			!1 === r.value && null !== k.value && k.value.updatePosition()
		}

		function ze(e) {
			void 0 !== e && Xa(e), n("popupShow", e), M.hasPopupOpen = !0, M.onControlFocusin(e)
		}

		function Ne(e) {
			void 0 !== e && Xa(e), n("popupHide", e), M.hasPopupOpen = !1, M.onControlFocusout(e)
		}

		function je() {
			p = (!0 === l.platform.is.mobile || "dialog" === e.behavior) && ("menu" !== e.behavior && (!0 !== e.useInput || (void 0 !== t["no-option"] || void 0 !== e.onFilter || !1 === D.value))), h = !0 === l.platform.is.ios && !0 === p && !0 === e.useInput ? "fade" : e.transitionShow
		}
		return gn(B, (t => {
			d = t, !0 === e.useInput && !0 === e.fillInput && !0 !== e.multiple && !0 !== M.innerLoading.value && (!0 !== r.value && !0 !== a.value || !0 !== z.value) && (!0 !== f && Be(), !0 !== r.value && !0 !== a.value || Ee(""))
		}), {
			immediate: !0
		}), gn((() => e.fillInput), Be), gn(a, Ie), gn(q, (function(e, t) {
			!0 === a.value && !1 === M.innerLoading.value && (O(-1, !0), $t((() => {
				!0 === a.value && !1 === M.innerLoading.value && (e > t ? O() : Ie(!0))
			})))
		})), Nn(je), jn($e), je(), Dn((() => {
			null !== b && clearTimeout(b)
		})), Object.assign(o, {
			showPopup: Ve,
			hidePopup: Me,
			removeAtIndex: se,
			add: ce,
			toggleOption: de,
			getOptionIndex: () => i.value,
			setOptionIndex: pe,
			moveOptionSelection: fe,
			filter: Ee,
			updateMenuPosition: $e,
			updateInputValue: Ce,
			isOptionSelected: he,
			getEmittingOptionValue: ie,
			isOptionDisabled: (...e) => !0 === le.value.apply(null, e),
			getOptionValue: (...e) => ne.value.apply(null, e),
			getOptionLabel: (...e) => oe.value.apply(null, e)
		}), Object.assign(M, {
			innerValue: B,
			fieldClass: Ol((() => `q-select q-field--auto-height q-select--with${!0!==e.useInput?"out":""}-input q-select--with${!0!==e.useChips?"out":""}-chips q-select--${!0===e.multiple?"multiple":"single"}`)),
			inputRef: _,
			targetRef: w,
			hasValue: z,
			showPopup: Ve,
			floatingLabel: Ol((() => !0 !== e.hideSelected && !0 === z.value || "number" == typeof s.value || s.value.length > 0 || nc(e.displayValue))),
			getControlChild: () => {
				if (!1 !== M.editable.value && (!0 === r.value || !0 !== D.value || void 0 !== t["no-option"])) return !0 === p ? function() {
					const n = [Tl(ic, {
						class: `col-auto ${M.fieldClass.value}`,
						...I.value,
						for: M.targetUid.value,
						dark: $.value,
						square: !0,
						loading: c.value,
						itemAligned: !1,
						filled: !0,
						stackLabel: s.value.length > 0,
						...M.splitAttrs.listeners.value,
						onFocus: Fe,
						onBlur: Re
					}, {
						...t,
						rawControl: () => M.getControl(!0),
						before: void 0,
						after: void 0
					})];
					return !0 === a.value && n.push(Tl("div", {
						ref: x,
						class: j.value + " scroll",
						style: e.popupContentStyle,
						...Z.value,
						onClick: Ya,
						onScrollPassive: P
					}, ke())), Tl(vd, {
						ref: S,
						modelValue: r.value,
						position: !0 === e.useInput ? "top" : void 0,
						transitionShow: h,
						transitionHide: e.transitionHide,
						transitionDuration: e.transitionDuration,
						onBeforeShow: ze,
						onBeforeHide: Oe,
						onHide: Te,
						onShow: Pe
					}, (() => Tl("div", {
						class: "q-select__dialog" + (!0 === $.value ? " q-select__dialog--dark q-dark" : "") + (!0 === u.value ? " q-select__dialog--focused" : "")
					}, n)))
				}() : Tl(Zc, {
					ref: k,
					class: j.value,
					style: e.popupContentStyle,
					modelValue: a.value,
					fit: !0 !== e.menuShrink,
					cover: !0 === e.optionsCover && !0 !== D.value && !0 !== e.useInput,
					anchor: e.menuAnchor,
					self: e.menuSelf,
					offset: e.menuOffset,
					dark: $.value,
					noParentEvent: !0,
					noRefocus: !0,
					noFocus: !0,
					square: ee.value,
					transitionShow: e.transitionShow,
					transitionHide: e.transitionHide,
					transitionDuration: e.transitionDuration,
					separateClosePopup: !0,
					...Z.value,
					onScrollPassive: P,
					onBeforeShow: ze,
					onBeforeHide: qe,
					onShow: Le
				}, ke);
				!0 === M.hasPopupOpen && (M.hasPopupOpen = !1)
			},
			controlEvents: {
				onFocusin(e) {
					M.onControlFocusin(e)
				},
				onFocusout(e) {
					M.onControlFocusout(e, (() => {
						Be(), Ae()
					}))
				},
				onClick(e) {
					if (Ya(e), !0 !== p && !0 === a.value) return Ae(), void(null !== w.value && w.value.focus());
					Ve(e)
				}
			},
			getControl: n => {
				const o = !0 === e.hideSelected ? [] : void 0 !== t["selected-item"] ? J.value.map((e => t["selected-item"](e))).slice() : void 0 !== t.selected ? [].concat(t.selected()) : !0 === e.useChips ? J.value.map(((t, n) => Tl(fc, {
						key: "option-" + n,
						removable: !0 === M.editable.value && !0 !== le.value(t.opt),
						dense: !0,
						textColor: e.color,
						tabindex: Q.value,
						onRemove() {
							t.removeAtIndex(n)
						}
					}, (() => Tl("span", {
						class: "ellipsis",
						[!0 === t.html ? "innerHTML" : "textContent"]: oe.value(t.opt)
					}))))) : [Tl("span", {
						[!0 === K.value ? "innerHTML" : "textContent"]: H.value
					})],
					l = !0 === n || !0 !== r.value || !0 !== p;
				if (!0 === e.useInput) o.push(function(t, n) {
					const o = !0 === n ? {
							...G.value,
							...M.splitAttrs.attributes.value
						} : void 0,
						l = {
							ref: !0 === n ? w : void 0,
							key: "i_t",
							class: N.value,
							style: e.inputStyle,
							value: void 0 !== s.value ? s.value : "",
							type: "search",
							...o,
							id: !0 === n ? M.targetUid.value : void 0,
							maxlength: e.maxlength,
							autocomplete: e.autocomplete,
							"data-autofocus": !0 === t || !0 === e.autofocus || void 0,
							disabled: !0 === e.disable,
							readonly: !0 === e.readonly,
							...re.value
						};
					return !0 !== t && !0 === p && (!0 === Array.isArray(l.class) ? l.class = [...l.class, "no-pointer-events"] : l.class += " no-pointer-events"), Tl("input", l)
				}(n, l));
				else if (!0 === M.editable.value) {
					const t = !0 === l ? G.value : void 0;
					o.push(Tl("input", {
						ref: !0 === l ? w : void 0,
						key: "d_t",
						class: "q-select__focus-target",
						id: !0 === l ? M.targetUid.value : void 0,
						value: H.value,
						readonly: !0,
						"data-autofocus": !0 === n || !0 === e.autofocus || void 0,
						...t,
						onKeydown: _e,
						onKeyup: ge,
						onKeypress: ye
					})), !0 === l && "string" == typeof e.autocomplete && e.autocomplete.length > 0 && o.push(Tl("input", {
						class: "q-select__autocomplete-input",
						autocomplete: e.autocomplete,
						tabindex: -1,
						onKeyup: be
					}))
				}
				if (void 0 !== C.value && !0 !== e.disable && ae.value.length > 0) {
					const t = ae.value.map((e => Tl("option", {
						value: e,
						selected: !0
					})));
					o.push(Tl("select", {
						class: "hidden",
						name: C.value,
						multiple: e.multiple
					}, t))
				}
				return Tl("div", {
					class: "q-field__native row items-center",
					...!0 === e.useInput || !0 !== l ? void 0 : M.splitAttrs.attributes.value
				}, o)
			},
			getInnerAppend: () => !0 !== e.loading && !0 !== c.value && !0 !== e.hideDropdownIcon ? [Tl(iu, {
				class: "q-select__dropdown-icon" + (!0 === a.value ? " rotate-180" : ""),
				name: Y.value
			})] : null
		}), rc(M)
	}
});
/*!
 * shared v9.2.2
 * (c) 2022 kazuya kawaguchi
 * Released under the MIT License.
 */
const Md = "undefined" != typeof window,
	Bd = "function" == typeof Symbol && "symbol" == typeof Symbol.toStringTag,
	Id = e => Bd ? Symbol(e) : e,
	$d = e => JSON.stringify(e).replace(/\u2028/g, "\\u2028").replace(/\u2029/g, "\\u2029").replace(/\u0027/g, "\\u0027"),
	zd = e => "number" == typeof e && isFinite(e),
	Nd = e => "[object RegExp]" === ep(e),
	jd = e => tp(e) && 0 === Object.keys(e).length;

function Dd(e, t) {
	"undefined" != typeof console && (console.warn("[intlify] " + e), t && console.warn(t.stack))
}
const Ud = Object.assign;

function Hd(e) {
	return e.replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;")
}
const Wd = Object.prototype.hasOwnProperty;

function Kd(e, t) {
	return Wd.call(e, t)
}
const Qd = Array.isArray,
	Gd = e => "function" == typeof e,
	Zd = e => "string" == typeof e,
	Jd = e => "boolean" == typeof e,
	Xd = e => null !== e && "object" == typeof e,
	Yd = Object.prototype.toString,
	ep = e => Yd.call(e),
	tp = e => "[object Object]" === ep(e),
	np = 15;

function op(e, t, n = {}) {
	const {
		domain: o,
		messages: l,
		args: a
	} = n, r = new SyntaxError(String(e));
	return r.code = e, t && (r.location = t), r.domain = o, r
}
/*!
 * devtools-if v9.2.2
 * (c) 2022 kazuya kawaguchi
 * Released under the MIT License.
 */
const lp = [];
/*!
 * core-base v9.2.2
 * (c) 2022 kazuya kawaguchi
 * Released under the MIT License.
 */
lp[0] = {
	w: [0],
	i: [3, 0],
	"[": [4],
	o: [7]
}, lp[1] = {
	w: [1],
	".": [2],
	"[": [4],
	o: [7]
}, lp[2] = {
	w: [2],
	i: [3, 0],
	0: [3, 0]
}, lp[3] = {
	i: [3, 0],
	0: [3, 0],
	w: [1, 1],
	".": [2, 1],
	"[": [4, 1],
	o: [7, 1]
}, lp[4] = {
	"'": [5, 0],
	'"': [6, 0],
	"[": [4, 2],
	"]": [1, 3],
	o: 8,
	l: [4, 0]
}, lp[5] = {
	"'": [4, 0],
	o: 8,
	l: [5, 0]
}, lp[6] = {
	'"': [4, 0],
	o: 8,
	l: [6, 0]
};
const ap = /^\s?(?:true|false|-?[\d.]+|'[^']*'|"[^"]*")\s?$/;

function rp(e) {
	if (null == e) return "o";
	switch (e.charCodeAt(0)) {
		case 91:
		case 93:
		case 46:
		case 34:
		case 39:
			return e;
		case 95:
		case 36:
		case 45:
			return "i";
		case 9:
		case 10:
		case 13:
		case 160:
		case 65279:
		case 8232:
		case 8233:
			return "w"
	}
	return "i"
}

function ip(e) {
	const t = e.trim();
	return ("0" !== e.charAt(0) || !isNaN(parseInt(e))) && (n = t, ap.test(n) ? function(e) {
		const t = e.charCodeAt(0);
		return t !== e.charCodeAt(e.length - 1) || 34 !== t && 39 !== t ? e : e.slice(1, -1)
	}(t) : "*" + t);
	var n
}
const sp = new Map;

function up(e, t) {
	return Xd(e) ? e[t] : null
}
const cp = e => e,
	dp = e => "",
	pp = e => 0 === e.length ? "" : e.join(""),
	fp = e => null == e ? "" : Qd(e) || tp(e) && e.toString === Yd ? JSON.stringify(e, null, 2) : String(e);

function vp(e, t) {
	return e = Math.abs(e), 2 === t ? e ? e > 1 ? 1 : 0 : 1 : e ? Math.min(e, 2) : 0
}

function hp(e = {}) {
	const t = e.locale,
		n = function(e) {
			const t = zd(e.pluralIndex) ? e.pluralIndex : -1;
			return e.named && (zd(e.named.count) || zd(e.named.n)) ? zd(e.named.count) ? e.named.count : zd(e.named.n) ? e.named.n : t : t
		}(e),
		o = Xd(e.pluralRules) && Zd(t) && Gd(e.pluralRules[t]) ? e.pluralRules[t] : vp,
		l = Xd(e.pluralRules) && Zd(t) && Gd(e.pluralRules[t]) ? vp : void 0,
		a = e.list || [],
		r = e.named || {};
	zd(e.pluralIndex) && function(e, t) {
		t.count || (t.count = e), t.n || (t.n = e)
	}(n, r);

	function i(t) {
		const n = Gd(e.messages) ? e.messages(t) : !!Xd(e.messages) && e.messages[t];
		return n || (e.parent ? e.parent.message(t) : dp)
	}
	const s = tp(e.processor) && Gd(e.processor.normalize) ? e.processor.normalize : pp,
		u = tp(e.processor) && Gd(e.processor.interpolate) ? e.processor.interpolate : fp,
		c = {
			list: e => a[e],
			named: e => r[e],
			plural: e => e[o(n, e.length, l)],
			linked: (t, ...n) => {
				const [o, l] = n;
				let a = "text",
					r = "";
				1 === n.length ? Xd(o) ? (r = o.modifier || r, a = o.type || a) : Zd(o) && (r = o || r) : 2 === n.length && (Zd(o) && (r = o || r), Zd(l) && (a = l || a));
				let s = i(t)(c);
				return "vnode" === a && Qd(s) && r && (s = s[0]), r ? (u = r, e.modifiers ? e.modifiers[u] : cp)(s, a) : s;
				var u
			},
			message: i,
			type: tp(e.processor) && Zd(e.processor.type) ? e.processor.type : "text",
			interpolate: u,
			normalize: s
		};
	return c
}

function mp(e, t, n) {
	return [...new Set([n, ...Qd(t) ? t : Xd(t) ? Object.keys(t) : Zd(t) ? [t] : [n]])]
}

function gp(e, t, n) {
	const o = Zd(n) ? n : wp,
		l = e;
	l.__localeChainCache || (l.__localeChainCache = new Map);
	let a = l.__localeChainCache.get(o);
	if (!a) {
		a = [];
		let e = [n];
		for (; Qd(e);) e = bp(a, e, t);
		const r = Qd(t) || !tp(t) ? t : t.default ? t.default : null;
		e = Zd(r) ? [r] : r, Qd(e) && bp(a, e, !1), l.__localeChainCache.set(o, a)
	}
	return a
}

function bp(e, t, n) {
	let o = !0;
	for (let l = 0; l < t.length && Jd(o); l++) {
		const a = t[l];
		Zd(a) && (o = yp(e, t[l], n))
	}
	return o
}

function yp(e, t, n) {
	let o;
	const l = t.split("-");
	do {
		o = _p(e, l.join("-"), n), l.splice(-1, 1)
	} while (l.length && !0 === o);
	return o
}

function _p(e, t, n) {
	let o = !1;
	if (!e.includes(t) && (o = !0, t)) {
		o = "!" !== t[t.length - 1];
		const l = t.replace(/!/g, "");
		e.push(l), (Qd(n) || tp(n)) && n[l] && (o = n[l])
	}
	return o
}
const wp = "en-US",
	kp = e => `${e.charAt(0).toLocaleUpperCase()}${e.substr(1)}`;
let Sp, xp;
let Cp = 0;

function Ep(e = {}) {
	const t = Zd(e.version) ? e.version : "9.2.2",
		n = Zd(e.locale) ? e.locale : wp,
		o = Qd(e.fallbackLocale) || tp(e.fallbackLocale) || Zd(e.fallbackLocale) || !1 === e.fallbackLocale ? e.fallbackLocale : n,
		l = tp(e.messages) ? e.messages : {
			[n]: {}
		},
		a = tp(e.datetimeFormats) ? e.datetimeFormats : {
			[n]: {}
		},
		r = tp(e.numberFormats) ? e.numberFormats : {
			[n]: {}
		},
		i = Ud({}, e.modifiers || {}, {
			upper: (e, t) => "text" === t && Zd(e) ? e.toUpperCase() : "vnode" === t && Xd(e) && "__v_isVNode" in e ? e.children.toUpperCase() : e,
			lower: (e, t) => "text" === t && Zd(e) ? e.toLowerCase() : "vnode" === t && Xd(e) && "__v_isVNode" in e ? e.children.toLowerCase() : e,
			capitalize: (e, t) => "text" === t && Zd(e) ? kp(e) : "vnode" === t && Xd(e) && "__v_isVNode" in e ? kp(e.children) : e
		}),
		s = e.pluralRules || {},
		u = Gd(e.missing) ? e.missing : null,
		c = !Jd(e.missingWarn) && !Nd(e.missingWarn) || e.missingWarn,
		d = !Jd(e.fallbackWarn) && !Nd(e.fallbackWarn) || e.fallbackWarn,
		p = !!e.fallbackFormat,
		f = !!e.unresolving,
		v = Gd(e.postTranslation) ? e.postTranslation : null,
		h = tp(e.processor) ? e.processor : null,
		m = !Jd(e.warnHtmlMessage) || e.warnHtmlMessage,
		g = !!e.escapeParameter,
		b = Gd(e.messageCompiler) ? e.messageCompiler : undefined,
		y = Gd(e.messageResolver) ? e.messageResolver : Sp || up,
		_ = Gd(e.localeFallbacker) ? e.localeFallbacker : xp || mp,
		w = Xd(e.fallbackContext) ? e.fallbackContext : void 0,
		k = Gd(e.onWarn) ? e.onWarn : Dd,
		S = e,
		x = Xd(S.__datetimeFormatters) ? S.__datetimeFormatters : new Map,
		C = Xd(S.__numberFormatters) ? S.__numberFormatters : new Map,
		E = Xd(S.__meta) ? S.__meta : {};
	Cp++;
	const q = {
		version: t,
		cid: Cp,
		locale: n,
		fallbackLocale: o,
		messages: l,
		modifiers: i,
		pluralRules: s,
		missing: u,
		missingWarn: c,
		fallbackWarn: d,
		fallbackFormat: p,
		unresolving: f,
		postTranslation: v,
		processor: h,
		warnHtmlMessage: m,
		escapeParameter: g,
		messageCompiler: b,
		messageResolver: y,
		localeFallbacker: _,
		fallbackContext: w,
		onWarn: k,
		__meta: E
	};
	return q.datetimeFormats = a, q.numberFormats = r, q.__datetimeFormatters = x, q.__numberFormatters = C, q
}

function qp(e, t, n, o, l) {
	const {
		missing: a,
		onWarn: r
	} = e;
	if (null !== a) {
		const o = a(e, n, t, l);
		return Zd(o) ? o : t
	}
	return t
}

function Lp(e, t, n) {
	e.__localeChainCache = new Map, e.localeFallbacker(e, n, t)
}
let Fp = np;
const Rp = () => ++Fp,
	Op = {
		INVALID_ARGUMENT: Fp,
		INVALID_DATE_ARGUMENT: Rp(),
		INVALID_ISO_DATE_ARGUMENT: Rp(),
		__EXTEND_POINT__: Rp()
	};

function Tp(e) {
	return op(e, null, void 0)
}
const Pp = () => "",
	Ap = e => Gd(e);

function Vp(e, ...t) {
	const {
		fallbackFormat: n,
		postTranslation: o,
		unresolving: l,
		messageCompiler: a,
		fallbackLocale: r,
		messages: i
	} = e, [s, u] = Ip(...t), c = Jd(u.missingWarn) ? u.missingWarn : e.missingWarn, d = Jd(u.fallbackWarn) ? u.fallbackWarn : e.fallbackWarn, p = Jd(u.escapeParameter) ? u.escapeParameter : e.escapeParameter, f = !!u.resolvedMessage, v = Zd(u.default) || Jd(u.default) ? Jd(u.default) ? a ? s : () => s : u.default : n ? a ? s : () => s : "", h = n || "" !== v, m = Zd(u.locale) ? u.locale : e.locale;
	p && function(e) {
		Qd(e.list) ? e.list = e.list.map((e => Zd(e) ? Hd(e) : e)) : Xd(e.named) && Object.keys(e.named).forEach((t => {
			Zd(e.named[t]) && (e.named[t] = Hd(e.named[t]))
		}))
	}(u);
	let [g, b, y] = f ? [s, m, i[m] || {}] : Mp(e, s, m, r, d, c), _ = g, w = s;
	if (f || Zd(_) || Ap(_) || h && (_ = v, w = _), !(f || (Zd(_) || Ap(_)) && Zd(b))) return l ? -1 : s;
	let k = !1;
	const S = Ap(_) ? _ : Bp(e, s, b, _, w, (() => {
		k = !0
	}));
	if (k) return _;
	const x = function(e, t, n, o) {
			const {
				modifiers: l,
				pluralRules: a,
				messageResolver: r,
				fallbackLocale: i,
				fallbackWarn: s,
				missingWarn: u,
				fallbackContext: c
			} = e, d = o => {
				let l = r(n, o);
				if (null == l && c) {
					const [, , e] = Mp(c, o, t, i, s, u);
					l = r(e, o)
				}
				if (Zd(l)) {
					let n = !1;
					const a = Bp(e, o, t, l, o, (() => {
						n = !0
					}));
					return n ? Pp : a
				}
				return Ap(l) ? l : Pp
			}, p = {
				locale: t,
				modifiers: l,
				pluralRules: a,
				messages: d
			};
			e.processor && (p.processor = e.processor);
			o.list && (p.list = o.list);
			o.named && (p.named = o.named);
			zd(o.plural) && (p.pluralIndex = o.plural);
			return p
		}(e, b, y, u),
		C = function(e, t, n) {
			return t(n)
		}(0, S, hp(x));
	return o ? o(C, s) : C
}

function Mp(e, t, n, o, l, a) {
	const {
		messages: r,
		onWarn: i,
		messageResolver: s,
		localeFallbacker: u
	} = e, c = u(e, o, n);
	let d, p = {},
		f = null;
	for (let v = 0; v < c.length && (d = c[v], p = r[d] || {}, null === (f = s(p, t)) && (f = p[t]), !Zd(f) && !Gd(f)); v++) {
		const n = qp(e, t, d, 0, "translate");
		n !== t && (f = n)
	}
	return [f, d, p]
}

function Bp(e, t, n, o, l, a) {
	const {
		messageCompiler: r,
		warnHtmlMessage: i
	} = e;
	if (Ap(o)) {
		const e = o;
		return e.locale = e.locale || n, e.key = e.key || t, e
	}
	if (null == r) {
		const e = () => o;
		return e.locale = n, e.key = t, e
	}
	const s = r(o, function(e, t, n, o, l, a) {
		return {
			warnHtmlMessage: l,
			onError: e => {
				throw a && a(e), e
			},
			onCacheKey: e => ((e, t, n) => $d({
				l: e,
				k: t,
				s: n
			}))(t, n, e)
		}
	}(0, n, l, 0, i, a));
	return s.locale = n, s.key = t, s.source = o, s
}

function Ip(...e) {
	const [t, n, o] = e, l = {};
	if (!Zd(t) && !zd(t) && !Ap(t)) throw Tp(Op.INVALID_ARGUMENT);
	const a = zd(t) ? String(t) : (Ap(t), t);
	return zd(n) ? l.plural = n : Zd(n) ? l.default = n : tp(n) && !jd(n) ? l.named = n : Qd(n) && (l.list = n), zd(o) ? l.plural = o : Zd(o) ? l.default = o : tp(o) && Ud(l, o), [a, l]
}

function $p(e, ...t) {
	const {
		datetimeFormats: n,
		unresolving: o,
		fallbackLocale: l,
		onWarn: a,
		localeFallbacker: r
	} = e, {
		__datetimeFormatters: i
	} = e, [s, u, c, d] = Np(...t);
	Jd(c.missingWarn) ? c.missingWarn : e.missingWarn;
	Jd(c.fallbackWarn) ? c.fallbackWarn : e.fallbackWarn;
	const p = !!c.part,
		f = Zd(c.locale) ? c.locale : e.locale,
		v = r(e, l, f);
	if (!Zd(s) || "" === s) return new Intl.DateTimeFormat(f, d).format(u);
	let h, m = {},
		g = null;
	for (let _ = 0; _ < v.length && (h = v[_], m = n[h] || {}, g = m[s], !tp(g)); _++) qp(e, s, h, 0, "datetime format");
	if (!tp(g) || !Zd(h)) return o ? -1 : s;
	let b = `${h}__${s}`;
	jd(d) || (b = `${b}__${JSON.stringify(d)}`);
	let y = i.get(b);
	return y || (y = new Intl.DateTimeFormat(h, Ud({}, g, d)), i.set(b, y)), p ? y.formatToParts(u) : y.format(u)
}
const zp = ["localeMatcher", "weekday", "era", "year", "month", "day", "hour", "minute", "second", "timeZoneName", "formatMatcher", "hour12", "timeZone", "dateStyle", "timeStyle", "calendar", "dayPeriod", "numberingSystem", "hourCycle", "fractionalSecondDigits"];

function Np(...e) {
	const [t, n, o, l] = e, a = {};
	let r, i = {};
	if (Zd(t)) {
		const e = t.match(/(\d{4}-\d{2}-\d{2})(T|\s)?(.*)/);
		if (!e) throw Tp(Op.INVALID_ISO_DATE_ARGUMENT);
		const n = e[3] ? e[3].trim().startsWith("T") ? `${e[1].trim()}${e[3].trim()}` : `${e[1].trim()}T${e[3].trim()}` : e[1].trim();
		r = new Date(n);
		try {
			r.toISOString()
		} catch (og) {
			throw Tp(Op.INVALID_ISO_DATE_ARGUMENT)
		}
	} else if ("[object Date]" === ep(t)) {
		if (isNaN(t.getTime())) throw Tp(Op.INVALID_DATE_ARGUMENT);
		r = t
	} else {
		if (!zd(t)) throw Tp(Op.INVALID_ARGUMENT);
		r = t
	}
	return Zd(n) ? a.key = n : tp(n) && Object.keys(n).forEach((e => {
		zp.includes(e) ? i[e] = n[e] : a[e] = n[e]
	})), Zd(o) ? a.locale = o : tp(o) && (i = o), tp(l) && (i = l), [a.key || "", r, a, i]
}

function jp(e, t, n) {
	const o = e;
	for (const l in n) {
		const e = `${t}__${l}`;
		o.__datetimeFormatters.has(e) && o.__datetimeFormatters.delete(e)
	}
}

function Dp(e, ...t) {
	const {
		numberFormats: n,
		unresolving: o,
		fallbackLocale: l,
		onWarn: a,
		localeFallbacker: r
	} = e, {
		__numberFormatters: i
	} = e, [s, u, c, d] = Hp(...t);
	Jd(c.missingWarn) ? c.missingWarn : e.missingWarn;
	Jd(c.fallbackWarn) ? c.fallbackWarn : e.fallbackWarn;
	const p = !!c.part,
		f = Zd(c.locale) ? c.locale : e.locale,
		v = r(e, l, f);
	if (!Zd(s) || "" === s) return new Intl.NumberFormat(f, d).format(u);
	let h, m = {},
		g = null;
	for (let _ = 0; _ < v.length && (h = v[_], m = n[h] || {}, g = m[s], !tp(g)); _++) qp(e, s, h, 0, "number format");
	if (!tp(g) || !Zd(h)) return o ? -1 : s;
	let b = `${h}__${s}`;
	jd(d) || (b = `${b}__${JSON.stringify(d)}`);
	let y = i.get(b);
	return y || (y = new Intl.NumberFormat(h, Ud({}, g, d)), i.set(b, y)), p ? y.formatToParts(u) : y.format(u)
}
const Up = ["localeMatcher", "style", "currency", "currencyDisplay", "currencySign", "useGrouping", "minimumIntegerDigits", "minimumFractionDigits", "maximumFractionDigits", "minimumSignificantDigits", "maximumSignificantDigits", "compactDisplay", "notation", "signDisplay", "unit", "unitDisplay", "roundingMode", "roundingPriority", "roundingIncrement", "trailingZeroDisplay"];

function Hp(...e) {
	const [t, n, o, l] = e, a = {};
	let r = {};
	if (!zd(t)) throw Tp(Op.INVALID_ARGUMENT);
	const i = t;
	return Zd(n) ? a.key = n : tp(n) && Object.keys(n).forEach((e => {
		Up.includes(e) ? r[e] = n[e] : a[e] = n[e]
	})), Zd(o) ? a.locale = o : tp(o) && (r = o), tp(l) && (r = l), [a.key || "", i, a, r]
}

function Wp(e, t, n) {
	const o = e;
	for (const l in n) {
		const e = `${t}__${l}`;
		o.__numberFormatters.has(e) && o.__numberFormatters.delete(e)
	}
}
/*!
 * vue-i18n v9.2.2
 * (c) 2022 kazuya kawaguchi
 * Released under the MIT License.
 */
let Kp = np;
const Qp = () => ++Kp,
	Gp = {
		UNEXPECTED_RETURN_TYPE: Kp,
		INVALID_ARGUMENT: Qp(),
		MUST_BE_CALL_SETUP_TOP: Qp(),
		NOT_INSLALLED: Qp(),
		NOT_AVAILABLE_IN_LEGACY_MODE: Qp(),
		REQUIRED_VALUE: Qp(),
		INVALID_VALUE: Qp(),
		CANNOT_SETUP_VUE_DEVTOOLS_PLUGIN: Qp(),
		NOT_INSLALLED_WITH_PROVIDE: Qp(),
		UNEXPECTED_ERROR: Qp(),
		NOT_COMPATIBLE_LEGACY_VUE_I18N: Qp(),
		BRIDGE_SUPPORT_VUE_2_ONLY: Qp(),
		MUST_DEFINE_I18N_OPTION_IN_ALLOW_COMPOSITION: Qp(),
		NOT_AVAILABLE_COMPOSITION_IN_LEGACY: Qp(),
		__EXTEND_POINT__: Qp()
	};

function Zp(e, ...t) {
	return op(e, null, void 0)
}
const Jp = Id("__transrateVNode"),
	Xp = Id("__datetimeParts"),
	Yp = Id("__numberParts"),
	ef = Id("__setPluralRules");
Id("__intlifyMeta");
const tf = Id("__injectWithOption");

function nf(e) {
	if (!Xd(e)) return e;
	for (const t in e)
		if (Kd(e, t))
			if (t.includes(".")) {
				const n = t.split("."),
					o = n.length - 1;
				let l = e;
				for (let e = 0; e < o; e++) n[e] in l || (l[n[e]] = {}), l = l[n[e]];
				l[n[o]] = e[t], delete e[t], Xd(l[n[o]]) && nf(l[n[o]])
			} else Xd(e[t]) && nf(e[t]);
	return e
}

function of(e, t) {
	const {
		messages: n,
		__i18n: o,
		messageResolver: l,
		flatJson: a
	} = t, r = tp(n) ? n : Qd(o) ? {} : {
		[e]: {}
	};
	if (Qd(o) && o.forEach((e => {
			if ("locale" in e && "resource" in e) {
				const {
					locale: t,
					resource: n
				} = e;
				t ? (r[t] = r[t] || {}, af(n, r[t])) : af(n, r)
			} else Zd(e) && af(JSON.parse(e), r)
		})), null == l && a)
		for (const i in r) Kd(r, i) && nf(r[i]);
	return r
}
const lf = e => !Xd(e) || Qd(e);

function af(e, t) {
	if (lf(e) || lf(t)) throw Zp(Gp.INVALID_VALUE);
	for (const n in e) Kd(e, n) && (lf(e[n]) || lf(t[n]) ? t[n] = e[n] : af(e[n], t[n]))
}

function rf(e) {
	return dl(Ko, null, e, 0)
}
let sf = 0;

function uf(e) {
	return (t, n, o, l) => e(n, o, Sl() || void 0, l)
}

function cf(e = {}, t) {
	const {
		__root: n
	} = e, o = void 0 === n;
	let l = !Jd(e.inheritLocale) || e.inheritLocale;
	const a = yt(n && l ? n.locale.value : Zd(e.locale) ? e.locale : wp),
		r = yt(n && l ? n.fallbackLocale.value : Zd(e.fallbackLocale) || Qd(e.fallbackLocale) || tp(e.fallbackLocale) || !1 === e.fallbackLocale ? e.fallbackLocale : a.value),
		i = yt(of(a.value, e)),
		s = yt(tp(e.datetimeFormats) ? e.datetimeFormats : {
			[a.value]: {}
		}),
		u = yt(tp(e.numberFormats) ? e.numberFormats : {
			[a.value]: {}
		});
	let c = n ? n.missingWarn : !Jd(e.missingWarn) && !Nd(e.missingWarn) || e.missingWarn,
		d = n ? n.fallbackWarn : !Jd(e.fallbackWarn) && !Nd(e.fallbackWarn) || e.fallbackWarn,
		p = n ? n.fallbackRoot : !Jd(e.fallbackRoot) || e.fallbackRoot,
		f = !!e.fallbackFormat,
		v = Gd(e.missing) ? e.missing : null,
		h = Gd(e.missing) ? uf(e.missing) : null,
		m = Gd(e.postTranslation) ? e.postTranslation : null,
		g = n ? n.warnHtmlMessage : !Jd(e.warnHtmlMessage) || e.warnHtmlMessage,
		b = !!e.escapeParameter;
	const y = n ? n.modifiers : tp(e.modifiers) ? e.modifiers : {};
	let _, w = e.pluralRules || n && n.pluralRules;
	_ = (() => {
		const t = {
			version: "9.2.2",
			locale: a.value,
			fallbackLocale: r.value,
			messages: i.value,
			modifiers: y,
			pluralRules: w,
			missing: null === h ? void 0 : h,
			missingWarn: c,
			fallbackWarn: d,
			fallbackFormat: f,
			unresolving: !0,
			postTranslation: null === m ? void 0 : m,
			warnHtmlMessage: g,
			escapeParameter: b,
			messageResolver: e.messageResolver,
			__meta: {
				framework: "vue"
			}
		};
		t.datetimeFormats = s.value, t.numberFormats = u.value, t.__datetimeFormatters = tp(_) ? _.__datetimeFormatters : void 0, t.__numberFormatters = tp(_) ? _.__numberFormatters : void 0;
		return Ep(t)
	})(), Lp(_, a.value, r.value);
	const k = Ol({
			get: () => a.value,
			set: e => {
				a.value = e, _.locale = a.value
			}
		}),
		S = Ol({
			get: () => r.value,
			set: e => {
				r.value = e, _.fallbackLocale = r.value, Lp(_, a.value, e)
			}
		}),
		x = Ol((() => i.value)),
		C = Ol((() => s.value)),
		E = Ol((() => u.value));
	const q = (e, t, o, l, c, d) => {
		let f;
		if (a.value, r.value, i.value, s.value, u.value, f = e(_), zd(f) && -1 === f) {
			const [e, o] = t();
			return n && p ? l(n) : c(e)
		}
		if (d(f)) return f;
		throw Zp(Gp.UNEXPECTED_RETURN_TYPE)
	};

	function L(...e) {
		return q((t => Reflect.apply(Vp, null, [t, ...e])), (() => Ip(...e)), 0, (t => Reflect.apply(t.t, t, [...e])), (e => e), (e => Zd(e)))
	}
	const F = {
		normalize: function(e) {
			return e.map((e => Zd(e) || zd(e) || Jd(e) ? rf(String(e)) : e))
		},
		interpolate: e => e,
		type: "vnode"
	};

	function R(e) {
		return i.value[e] || {}
	}
	sf++, n && Md && (gn(n.locale, (e => {
		l && (a.value = e, _.locale = e, Lp(_, a.value, r.value))
	})), gn(n.fallbackLocale, (e => {
		l && (r.value = e, _.fallbackLocale = e, Lp(_, a.value, r.value))
	})));
	const O = {
		id: sf,
		locale: k,
		fallbackLocale: S,
		get inheritLocale() {
			return l
		},
		set inheritLocale(e) {
			l = e, e && n && (a.value = n.locale.value, r.value = n.fallbackLocale.value, Lp(_, a.value, r.value))
		},
		get availableLocales() {
			return Object.keys(i.value).sort()
		},
		messages: x,
		get modifiers() {
			return y
		},
		get pluralRules() {
			return w || {}
		},
		get isGlobal() {
			return o
		},
		get missingWarn() {
			return c
		},
		set missingWarn(e) {
			c = e, _.missingWarn = c
		},
		get fallbackWarn() {
			return d
		},
		set fallbackWarn(e) {
			d = e, _.fallbackWarn = d
		},
		get fallbackRoot() {
			return p
		},
		set fallbackRoot(e) {
			p = e
		},
		get fallbackFormat() {
			return f
		},
		set fallbackFormat(e) {
			f = e, _.fallbackFormat = f
		},
		get warnHtmlMessage() {
			return g
		},
		set warnHtmlMessage(e) {
			g = e, _.warnHtmlMessage = e
		},
		get escapeParameter() {
			return b
		},
		set escapeParameter(e) {
			b = e, _.escapeParameter = e
		},
		t: L,
		getLocaleMessage: R,
		setLocaleMessage: function(e, t) {
			i.value[e] = t, _.messages = i.value
		},
		mergeLocaleMessage: function(e, t) {
			i.value[e] = i.value[e] || {}, af(t, i.value[e]), _.messages = i.value
		},
		getPostTranslationHandler: function() {
			return Gd(m) ? m : null
		},
		setPostTranslationHandler: function(e) {
			m = e, _.postTranslation = e
		},
		getMissingHandler: function() {
			return v
		},
		setMissingHandler: function(e) {
			null !== e && (h = uf(e)), v = e, _.missing = h
		},
		[ef]: function(e) {
			w = e, _.pluralRules = w
		}
	};
	return O.datetimeFormats = C, O.numberFormats = E, O.rt = function(...e) {
		const [t, n, o] = e;
		if (o && !Xd(o)) throw Zp(Gp.INVALID_ARGUMENT);
		return L(t, n, Ud({
			resolvedMessage: !0
		}, o || {}))
	}, O.te = function(e, t) {
		const n = R(Zd(t) ? t : a.value);
		return null !== _.messageResolver(n, e)
	}, O.tm = function(e) {
		const t = function(e) {
			let t = null;
			const n = gp(_, r.value, a.value);
			for (let o = 0; o < n.length; o++) {
				const l = i.value[n[o]] || {},
					a = _.messageResolver(l, e);
				if (null != a) {
					t = a;
					break
				}
			}
			return t
		}(e);
		return null != t ? t : n && n.tm(e) || {}
	}, O.d = function(...e) {
		return q((t => Reflect.apply($p, null, [t, ...e])), (() => Np(...e)), 0, (t => Reflect.apply(t.d, t, [...e])), (() => ""), (e => Zd(e)))
	}, O.n = function(...e) {
		return q((t => Reflect.apply(Dp, null, [t, ...e])), (() => Hp(...e)), 0, (t => Reflect.apply(t.n, t, [...e])), (() => ""), (e => Zd(e)))
	}, O.getDateTimeFormat = function(e) {
		return s.value[e] || {}
	}, O.setDateTimeFormat = function(e, t) {
		s.value[e] = t, _.datetimeFormats = s.value, jp(_, e, t)
	}, O.mergeDateTimeFormat = function(e, t) {
		s.value[e] = Ud(s.value[e] || {}, t), _.datetimeFormats = s.value, jp(_, e, t)
	}, O.getNumberFormat = function(e) {
		return u.value[e] || {}
	}, O.setNumberFormat = function(e, t) {
		u.value[e] = t, _.numberFormats = u.value, Wp(_, e, t)
	}, O.mergeNumberFormat = function(e, t) {
		u.value[e] = Ud(u.value[e] || {}, t), _.numberFormats = u.value, Wp(_, e, t)
	}, O[tf] = e.__injectWithOption, O[Jp] = function(...e) {
		return q((t => {
			let n;
			const o = t;
			try {
				o.processor = F, n = Reflect.apply(Vp, null, [o, ...e])
			} finally {
				o.processor = null
			}
			return n
		}), (() => Ip(...e)), 0, (t => t[Jp](...e)), (e => [rf(e)]), (e => Qd(e)))
	}, O[Xp] = function(...e) {
		return q((t => Reflect.apply($p, null, [t, ...e])), (() => Np(...e)), 0, (t => t[Xp](...e)), (() => []), (e => Zd(e) || Qd(e)))
	}, O[Yp] = function(...e) {
		return q((t => Reflect.apply(Dp, null, [t, ...e])), (() => Hp(...e)), 0, (t => t[Yp](...e)), (() => []), (e => Zd(e) || Qd(e)))
	}, O
}
const df = {
	tag: {
		type: [String, Object]
	},
	locale: {
		type: String
	},
	scope: {
		type: String,
		validator: e => "parent" === e || "global" === e,
		default: "parent"
	},
	i18n: {
		type: Object
	}
};

function pf(e) {
	return Wo
}
const ff = {
	name: "i18n-t",
	props: Ud({
		keypath: {
			type: String,
			required: !0
		},
		plural: {
			type: [Number, String],
			validator: e => zd(e) || !isNaN(e)
		}
	}, df),
	setup(e, t) {
		const {
			slots: n,
			attrs: o
		} = t, l = e.i18n || kf({
			useScope: e.scope,
			__useComponent: !0
		});
		return () => {
			const a = Object.keys(n).filter((e => "_" !== e)),
				r = {};
			e.locale && (r.locale = e.locale), void 0 !== e.plural && (r.plural = Zd(e.plural) ? +e.plural : e.plural);
			const i = function({
					slots: e
				}, t) {
					if (1 === t.length && "default" === t[0]) return (e.default ? e.default() : []).reduce(((e, t) => [...e, ...Qd(t.children) ? t.children : [t]]), []);
					return t.reduce(((t, n) => {
						const o = e[n];
						return o && (t[n] = o()), t
					}), {})
				}(t, a),
				s = l[Jp](e.keypath, i, r),
				u = Ud({}, o);
			return Tl(Zd(e.tag) || Xd(e.tag) ? e.tag : pf(), u, s)
		}
	}
};

function vf(e, t, n, o) {
	const {
		slots: l,
		attrs: a
	} = t;
	return () => {
		const t = {
			part: !0
		};
		let r = {};
		e.locale && (t.locale = e.locale), Zd(e.format) ? t.key = e.format : Xd(e.format) && (Zd(e.format.key) && (t.key = e.format.key), r = Object.keys(e.format).reduce(((t, o) => n.includes(o) ? Ud({}, t, {
			[o]: e.format[o]
		}) : t), {}));
		const i = o(e.value, t, r);
		let s = [t.key];
		Qd(i) ? s = i.map(((e, t) => {
			const n = l[e.type],
				o = n ? n({
					[e.type]: e.value,
					index: t,
					parts: i
				}) : [e.value];
			var a;
			return Qd(a = o) && !Zd(a[0]) && (o[0].key = `${e.type}-${t}`), o
		})) : Zd(i) && (s = [i]);
		const u = Ud({}, a);
		return Tl(Zd(e.tag) || Xd(e.tag) ? e.tag : pf(), u, s)
	}
}
const hf = {
		name: "i18n-n",
		props: Ud({
			value: {
				type: Number,
				required: !0
			},
			format: {
				type: [String, Object]
			}
		}, df),
		setup(e, t) {
			const n = e.i18n || kf({
				useScope: "parent",
				__useComponent: !0
			});
			return vf(e, t, Up, ((...e) => n[Yp](...e)))
		}
	},
	mf = {
		name: "i18n-d",
		props: Ud({
			value: {
				type: [Number, Date],
				required: !0
			},
			format: {
				type: [String, Object]
			}
		}, df),
		setup(e, t) {
			const n = e.i18n || kf({
				useScope: "parent",
				__useComponent: !0
			});
			return vf(e, t, zp, ((...e) => n[Xp](...e)))
		}
	};

function gf(e) {
	if (Zd(e)) return {
		path: e
	};
	if (tp(e)) {
		if (!("path" in e)) throw Zp(Gp.REQUIRED_VALUE);
		return e
	}
	throw Zp(Gp.INVALID_VALUE)
}

function bf(e) {
	const {
		path: t,
		locale: n,
		args: o,
		choice: l,
		plural: a
	} = e, r = {}, i = o || {};
	return Zd(n) && (r.locale = n), zd(l) && (r.plural = l), zd(a) && (r.plural = a), [t, i, r]
}

function yf(e, t, ...n) {
	const o = tp(n[0]) ? n[0] : {},
		l = !!o.useI18nComponentName;
	(!Jd(o.globalInstall) || o.globalInstall) && (e.component(l ? "i18n" : ff.name, ff), e.component(hf.name, hf), e.component(mf.name, mf)), e.directive("t", function(e) {
		const t = t => {
			const {
				instance: n,
				modifiers: o,
				value: l
			} = t;
			if (!n || !n.$) throw Zp(Gp.UNEXPECTED_ERROR);
			const a = function(e, t) {
					const n = e;
					if ("composition" === e.mode) return n.__getInstance(t) || e.global;
					{
						const o = n.__getInstance(t);
						return null != o ? o.__composer : e.global.__composer
					}
				}(e, n.$),
				r = gf(l);
			return [Reflect.apply(a.t, a, [...bf(r)]), a]
		};
		return {
			created: (n, o) => {
				const [l, a] = t(o);
				Md && e.global === a && (n.__i18nWatcher = gn(a.locale, (() => {
					o.instance && o.instance.$forceUpdate()
				}))), n.__composer = a, n.textContent = l
			},
			unmounted: e => {
				Md && e.__i18nWatcher && (e.__i18nWatcher(), e.__i18nWatcher = void 0, delete e.__i18nWatcher), e.__composer && (e.__composer = void 0, delete e.__composer)
			},
			beforeUpdate: (e, {
				value: t
			}) => {
				if (e.__composer) {
					const n = e.__composer,
						o = gf(t);
					e.textContent = Reflect.apply(n.t, n, [...bf(o)])
				}
			},
			getSSRProps: e => {
				const [n] = t(e);
				return {
					textContent: n
				}
			}
		}
	}(t))
}
const _f = Id("global-vue-i18n");

function wf(e = {}, t) {
	const n = !Jd(e.globalInjection) || e.globalInjection,
		o = new Map,
		[l, a] = function(e, t, n) {
			const o = ee();
			{
				const t = o.run((() => cf(e)));
				if (null == t) throw Zp(Gp.UNEXPECTED_ERROR);
				return [o, t]
			}
		}(e),
		r = Id("");
	{
		const e = {
			get mode() {
				return "composition"
			},
			get allowComposition() {
				return true
			},
			async install(t, ...o) {
				t.__VUE_I18N_SYMBOL__ = r, t.provide(t.__VUE_I18N_SYMBOL__, e), n && function(e, t) {
					const n = Object.create(null);
					Sf.forEach((e => {
						const o = Object.getOwnPropertyDescriptor(t, e);
						if (!o) throw Zp(Gp.UNEXPECTED_ERROR);
						const l = bt(o.value) ? {
							get: () => o.value.value,
							set(e) {
								o.value.value = e
							}
						} : {
							get: () => o.get && o.get()
						};
						Object.defineProperty(n, e, l)
					})), e.config.globalProperties.$i18n = n, xf.forEach((n => {
						const o = Object.getOwnPropertyDescriptor(t, n);
						if (!o || !o.value) throw Zp(Gp.UNEXPECTED_ERROR);
						Object.defineProperty(e.config.globalProperties, `$${n}`, o)
					}))
				}(t, e.global), yf(t, e, ...o);
				const l = t.unmount;
				t.unmount = () => {
					e.dispose(), l()
				}
			},
			get global() {
				return a
			},
			dispose() {
				l.stop()
			},
			__instances: o,
			__getInstance: function(e) {
				return o.get(e) || null
			},
			__setInstance: function(e, t) {
				o.set(e, t)
			},
			__deleteInstance: function(e) {
				o.delete(e)
			}
		};
		return e
	}
}

function kf(e = {}) {
	const t = Sl();
	if (null == t) throw Zp(Gp.MUST_BE_CALL_SETUP_TOP);
	if (!t.isCE && null != t.appContext.app && !t.appContext.app.__VUE_I18N_SYMBOL__) throw Zp(Gp.NOT_INSLALLED);
	const n = function(e) {
			{
				const t = hn(e.isCE ? _f : e.appContext.app.__VUE_I18N_SYMBOL__);
				if (!t) throw Zp(e.isCE ? Gp.NOT_INSLALLED_WITH_PROVIDE : Gp.UNEXPECTED_ERROR);
				return t
			}
		}(t),
		o = function(e) {
			return "composition" === e.mode ? e.global : e.global.__composer
		}(n),
		l = function(e) {
			return e.type
		}(t),
		a = function(e, t) {
			return jd(e) ? "__i18n" in t ? "local" : "global" : e.useScope ? e.useScope : "local"
		}(e, l);
	if ("global" === a) return function(e, t, n) {
		let o = Xd(t.messages) ? t.messages : {};
		"__i18nGlobal" in n && (o = of(e.locale.value, {
			messages: o,
			__i18n: n.__i18nGlobal
		}));
		const l = Object.keys(o);
		if (l.length && l.forEach((t => {
				e.mergeLocaleMessage(t, o[t])
			})), Xd(t.datetimeFormats)) {
			const n = Object.keys(t.datetimeFormats);
			n.length && n.forEach((n => {
				e.mergeDateTimeFormat(n, t.datetimeFormats[n])
			}))
		}
		if (Xd(t.numberFormats)) {
			const n = Object.keys(t.numberFormats);
			n.length && n.forEach((n => {
				e.mergeNumberFormat(n, t.numberFormats[n])
			}))
		}
	}(o, e, l), o;
	if ("parent" === a) {
		let l = function(e, t, n = !1) {
			let o = null;
			const l = t.root;
			let a = t.parent;
			for (; null != a;) {
				const t = e;
				if ("composition" === e.mode && (o = t.__getInstance(a)), null != o) break;
				if (l === a) break;
				a = a.parent
			}
			return o
		}(n, t, e.__useComponent);
		return null == l && (l = o), l
	}
	const r = n;
	let i = r.__getInstance(t);
	if (null == i) {
		const n = Ud({}, e);
		"__i18n" in l && (n.__i18n = l.__i18n), o && (n.__root = o), i = cf(n),
			function(e, t, n) {
				zn((() => {}), t), Un((() => {
					e.__deleteInstance(t)
				}), t)
			}(r, t), r.__setInstance(t, i)
	}
	return i
}
const Sf = ["locale", "fallbackLocale", "availableLocales"],
	xf = ["t", "rt", "d", "n", "tm"];
Sp = function(e, t) {
	if (!Xd(e)) return null;
	let n = sp.get(t);
	if (n || (n = function(e) {
			const t = [];
			let n, o, l, a, r, i, s, u = -1,
				c = 0,
				d = 0;
			const p = [];

			function f() {
				const t = e[u + 1];
				if (5 === c && "'" === t || 6 === c && '"' === t) return u++, l = "\\" + t, p[0](), !0
			}
			for (p[0] = () => {
					void 0 === o ? o = l : o += l
				}, p[1] = () => {
					void 0 !== o && (t.push(o), o = void 0)
				}, p[2] = () => {
					p[0](), d++
				}, p[3] = () => {
					if (d > 0) d--, c = 4, p[0]();
					else {
						if (d = 0, void 0 === o) return !1;
						if (o = ip(o), !1 === o) return !1;
						p[1]()
					}
				}; null !== c;)
				if (u++, n = e[u], "\\" !== n || !f()) {
					if (a = rp(n), s = lp[c], r = s[a] || s.l || 8, 8 === r) return;
					if (c = r[0], void 0 !== r[1] && (i = p[r[1]], i && (l = n, !1 === i()))) return;
					if (7 === c) return t
				}
		}(t), n && sp.set(t, n)), !n) return null;
	const o = n.length;
	let l = e,
		a = 0;
	for (; a < o;) {
		const e = l[n[a]];
		if (void 0 === e) return null;
		l = e, a++
	}
	return l
}, xp = gp;
var Cf = {
	"en-US": {
		balance: e => {
			const {
				normalize: t
			} = e;
			return t(["Balance"])
		},
		apiKey: e => {
			const {
				normalize: t
			} = e;
			return t(["Api Key"])
		},
		getKey: e => {
			const {
				normalize: t
			} = e;
			return t(["Get a key"])
		},
		inputKey: e => {
			const {
				normalize: t
			} = e;
			return t(["Please input your API key"])
		},
		addFounds: e => {
			const {
				normalize: t
			} = e;
			return t(["Add Funds"])
		},
		enabled: e => {
			const {
				normalize: t
			} = e;
			return t(["Enabled / Solve automatically"])
		},
		setting: e => {
			const {
				normalize: t
			} = e;
			return t(["Settings"])
		},
		proxy: e => {
			const {
				normalize: t
			} = e;
			return t(["Proxy"])
		},
		proxyType: e => {
			const {
				normalize: t
			} = e;
			return t(["Proxy Type"])
		},
		port: e => {
			const {
				normalize: t
			} = e;
			return t(["Port"])
		},
		login: e => {
			const {
				normalize: t
			} = e;
			return t(["Login"])
		},
		password: e => {
			const {
				normalize: t
			} = e;
			return t(["Password"])
		},
		loginName: e => {
			const {
				normalize: t
			} = e;
			return t(["Password Name"])
		},
		blackControl: e => {
			const {
				normalize: t
			} = e;
			return t(["Blacklist control"])
		},
		blackTip: e => {
			const {
				normalize: t
			} = e;
			return t(["Captcha solving on added websites will be disabled"])
		},
		add: e => {
			const {
				normalize: t
			} = e;
			return t(["Add"])
		},
		guide: e => {
			const {
				normalize: t
			} = e;
			return t(["Guide"])
		},
		close: e => {
			const {
				normalize: t
			} = e;
			return t(["Close"])
		},
		delay: e => {
			const {
				normalize: t
			} = e;
			return t(["Delay between start solve captcha(ms):"])
		},
		repeat: e => {
			const {
				normalize: t
			} = e;
			return t(["Repeat captcha solving in case of an error:"])
		},
		copySuccess: e => {
			const {
				normalize: t
			} = e;
			return t(["Copy Succeed!"])
		},
		manualSolving: e => {
			const {
				normalize: t
			} = e;
			return t(["Manual Solving"])
		},
		solvedCallback: e => {
			const {
				normalize: t
			} = e;
			return t(["Solved Callback"])
		},
		solvedCallbackPlaceholder: e => {
			const {
				normalize: t
			} = e;
			return t(["Solved success callback"])
		}
	},
	"zh-CN": {
		balance: e => {
			const {
				normalize: t
			} = e;
			return t(["余额"])
		},
		apiKey: e => {
			const {
				normalize: t
			} = e;
			return t(["API密钥"])
		},
		getKey: e => {
			const {
				normalize: t
			} = e;
			return t(["获取Key"])
		},
		inputKey: e => {
			const {
				normalize: t
			} = e;
			return t(["请输入您的API密钥"])
		},
		addFounds: e => {
			const {
				normalize: t
			} = e;
			return t(["添加资金"])
		},
		enabled: e => {
			const {
				normalize: t
			} = e;
			return t(["启用 / 自动解决"])
		},
		setting: e => {
			const {
				normalize: t
			} = e;
			return t(["设置"])
		},
		proxy: e => {
			const {
				normalize: t
			} = e;
			return t(["代理"])
		},
		proxyType: e => {
			const {
				normalize: t
			} = e;
			return t(["代理类型"])
		},
		port: e => {
			const {
				normalize: t
			} = e;
			return t(["端口"])
		},
		login: e => {
			const {
				normalize: t
			} = e;
			return t(["账号"])
		},
		password: e => {
			const {
				normalize: t
			} = e;
			return t(["密码"])
		},
		loginName: e => {
			const {
				normalize: t
			} = e;
			return t(["账号名称"])
		},
		blackControl: e => {
			const {
				normalize: t
			} = e;
			return t(["黑名单控制"])
		},
		blackTip: e => {
			const {
				normalize: t
			} = e;
			return t(["CapSolver将在添加的网站中被禁用"])
		},
		add: e => {
			const {
				normalize: t
			} = e;
			return t(["添加"])
		},
		guide: e => {
			const {
				normalize: t
			} = e;
			return t(["指南"])
		},
		close: e => {
			const {
				normalize: t
			} = e;
			return t(["关闭"])
		},
		delay: e => {
			const {
				normalize: t
			} = e;
			return t(["开始解决验证码的延迟时间（ms）："])
		},
		repeat: e => {
			const {
				normalize: t
			} = e;
			return t(["验证失败重试次数："])
		},
		copySuccess: e => {
			const {
				normalize: t
			} = e;
			return t(["复制成功！"])
		},
		manualSolving: e => {
			const {
				normalize: t
			} = e;
			return t(["手动触发"])
		},
		solvedCallback: e => {
			const {
				normalize: t
			} = e;
			return t(["回调名称"])
		},
		solvedCallbackPlaceholder: e => {
			const {
				normalize: t
			} = e;
			return t(["成功回调函数名"])
		}
	},
	es: {
		balance: e => {
			const {
				normalize: t
			} = e;
			return t(["Saldo"])
		},
		apiKey: e => {
			const {
				normalize: t
			} = e;
			return t(["Clave API"])
		},
		getKey: e => {
			const {
				normalize: t
			} = e;
			return t(["Obtener una clave"])
		},
		inputKey: e => {
			const {
				normalize: t
			} = e;
			return t(["Por favor ingrese su clave API"])
		},
		addFounds: e => {
			const {
				normalize: t
			} = e;
			return t(["Agregar fondos"])
		},
		enabled: e => {
			const {
				normalize: t
			} = e;
			return t(["Habilitado / Resolver automáticamente"])
		},
		setting: e => {
			const {
				normalize: t
			} = e;
			return t(["Configuración"])
		},
		proxy: e => {
			const {
				normalize: t
			} = e;
			return t(["Proxy"])
		},
		proxyType: e => {
			const {
				normalize: t
			} = e;
			return t(["Tipo de proxy"])
		},
		port: e => {
			const {
				normalize: t
			} = e;
			return t(["Puerto"])
		},
		login: e => {
			const {
				normalize: t
			} = e;
			return t(["Iniciar sesión"])
		},
		password: e => {
			const {
				normalize: t
			} = e;
			return t(["Contraseña"])
		},
		loginName: e => {
			const {
				normalize: t
			} = e;
			return t(["Nombre de usuario"])
		},
		blackControl: e => {
			const {
				normalize: t
			} = e;
			return t(["Control de lista negra"])
		},
		blackTip: e => {
			const {
				normalize: t
			} = e;
			return t(["Se desactivará la resolución de captchas en los sitios web agregados"])
		},
		add: e => {
			const {
				normalize: t
			} = e;
			return t(["Agregar"])
		},
		guide: e => {
			const {
				normalize: t
			} = e;
			return t(["Guía"])
		},
		close: e => {
			const {
				normalize: t
			} = e;
			return t(["Cerrar"])
		},
		delay: e => {
			const {
				normalize: t
			} = e;
			return t(["Retraso entre el inicio de la resolución del captcha(ms):"])
		},
		repeat: e => {
			const {
				normalize: t
			} = e;
			return t(["Repetir la resolución del captcha en caso de un error:"])
		},
		copySuccess: e => {
			const {
				normalize: t
			} = e;
			return t(["Replicar el éxito!"])
		},
		manualSolving: e => {
			const {
				normalize: t
			} = e;
			return t(["Solución manual"])
		},
		solvedCallback: e => {
			const {
				normalize: t
			} = e;
			return t(["Llamar de vuelta"])
		},
		solvedCallbackPlaceholder: e => {
			const {
				normalize: t
			} = e;
			return t(["Llamar de vuelta"])
		}
	},
	ru: {
		balance: e => {
			const {
				normalize: t
			} = e;
			return t(["Баланс"])
		},
		apiKey: e => {
			const {
				normalize: t
			} = e;
			return t(["Ключ API"])
		},
		getKey: e => {
			const {
				normalize: t
			} = e;
			return t(["Получить ключ"])
		},
		inputKey: e => {
			const {
				normalize: t
			} = e;
			return t(["Пожалуйста"])
		},
		addFounds: e => {
			const {
				normalize: t
			} = e;
			return t(["Добавить средства"])
		},
		enabled: e => {
			const {
				normalize: t
			} = e;
			return t(["Включено / Автоматически решать"])
		},
		setting: e => {
			const {
				normalize: t
			} = e;
			return t(["Настройки"])
		},
		proxy: e => {
			const {
				normalize: t
			} = e;
			return t(["Прокси"])
		},
		proxyType: e => {
			const {
				normalize: t
			} = e;
			return t(["Тип прокси"])
		},
		port: e => {
			const {
				normalize: t
			} = e;
			return t(["Порт"])
		},
		login: e => {
			const {
				normalize: t
			} = e;
			return t(["Войти"])
		},
		password: e => {
			const {
				normalize: t
			} = e;
			return t(["Пароль"])
		},
		loginName: e => {
			const {
				normalize: t
			} = e;
			return t(["Имя пользователя"])
		},
		blackControl: e => {
			const {
				normalize: t
			} = e;
			return t(["Управление черным списком"])
		},
		blackTip: e => {
			const {
				normalize: t
			} = e;
			return t(["Решение капчи на добавленных сайтах будет отключено"])
		},
		add: e => {
			const {
				normalize: t
			} = e;
			return t(["Добавить"])
		},
		guide: e => {
			const {
				normalize: t
			} = e;
			return t(["Руководство"])
		},
		close: e => {
			const {
				normalize: t
			} = e;
			return t(["Закрыть"])
		},
		delay: e => {
			const {
				normalize: t
			} = e;
			return t(["Задержка между началом решения капчи (мс):"])
		},
		repeat: e => {
			const {
				normalize: t
			} = e;
			return t(["Repetir la resolución del captcha en caso de un error:"])
		},
		copySuccess: e => {
			const {
				normalize: t
			} = e;
			return t(["Копировать успешно!"])
		},
		manualSolving: e => {
			const {
				normalize: t
			} = e;
			return t(["Вручную"])
		},
		solvedCallback: e => {
			const {
				normalize: t
			} = e;
			return t(["Перезвонить"])
		},
		solvedCallbackPlaceholder: e => {
			const {
				normalize: t
			} = e;
			return t(["Перезвонить"])
		}
	}
};
const Ef = [{
	value: "en-US",
	label: "English",
	flag: "us"
}, {
	value: "zh-CN",
	label: "简体中文",
	flag: "cn"
}, {
	value: "es",
	label: "España",
	flag: "es"
}, {
	value: "ru",
	label: "Россия",
	flag: "ru"
}];
let qf;

function Lf(e) {
	Ef.some((t => t.value === e)) && chrome.storage.local.set({
		i18n: {
			locale: e
		}
	})
}
var Ff = async ({
	app: e
}) => {
	var t, n;
	const o = await chrome.storage.local.get("i18n"),
		l = (a = null == (t = null == o ? void 0 : o.i18n) ? void 0 : t.locale, qf = wf({
			locale: null != a ? a : "en-US",
			legacy: !1,
			messages: {
				"en-US": Cf["en-US"],
				"zh-CN": Cf["zh-CN"],
				es: Cf.es,
				ru: Cf.ru
			}
		}), qf);
	var a;
	document.documentElement.setAttribute("lang", null == (n = null == o ? void 0 : o.i18n) ? void 0 : n.locale), e.use(l)
}, Rf = Object.freeze(Object.defineProperty({
	__proto__: null,
	cacheLang: Lf,
	default: Ff
}, Symbol.toStringTag, {
	value: "Module"
}));
const Of = ["src"],
	Tf = ["src"];
var Pf = Ar(Rn({
	__name: "I18nTrigger",
	setup(e) {
		const {
			locale: t
		} = kf(), n = yt("en-US"), o = [{
			value: "en-US",
			label: "English",
			icon: "assets/en-US.553867d3.svg"
		}, {
			value: "zh-CN",
			label: "简体中文",
			icon: "assets/zh-CN.c1f22841.svg"
		}, {
			value: "es",
			label: "España",
			icon: "assets/es.6fe80291.svg"
		}, {
			value: "ru",
			label: "Россия",
			icon: "assets/ru.6c62f886.svg"
		}];

		function l() {
			t.value = n.value, Lf(n.value)
		}
		const a = Ol((() => o.find((e => e.value === n.value)).icon));
		return zn((async () => {
			var e;
			const t = await chrome.storage.local.get("i18n");
			n.value = (null == (e = null == t ? void 0 : t.i18n) ? void 0 : e.locale) || "en-US"
		})), (e, t) => (Xo(), ll(Vd, {
			outlined: "",
			modelValue: n.value,
			"onUpdate:modelValue": [t[0] || (t[0] = e => n.value = e), l],
			options: o,
			"option-value": "value",
			"emit-value": "",
			"map-options": ""
		}, {
			prepend: nn((() => [cl("img", {
				src: kt(a),
				alt: ""
			}, null, 8, Of)])),
			option: nn((e => [dl(Vu, bl({
				class: "cap-option"
			}, e.itemProps), {
				default: nn((() => [dl(xu, null, {
					default: nn((() => [cl("img", {
						src: e.opt.icon,
						alt: ""
					}, null, 8, Tf)])),
					_: 2
				}, 1024), dl(xu, null, {
					default: nn((() => [dl(Cu, null, {
						default: nn((() => [fl(v(e.opt.label), 1)])),
						_: 2
					}, 1024)])),
					_: 2
				}, 1024)])),
				_: 2
			}, 1040)])),
			_: 1
		}, 8, ["modelValue"]))
	}
}), [
	["__scopeId", "data-v-9303f99a"]
]);
const Af = {
		class: "header-box"
	},
	Vf = ["src"];
var Mf = Ar(Rn({
	__name: "Header",
	setup(e) {
		const t = yt({});
		async function n() {
			await Su.set(pt(t.value))
		}
		return zn((async () => {
			const e = await Su.getAll();
			t.value = e
		})), (e, o) => (Xo(), ol("div", Af, [dl(gu, {
			class: "toolbar"
		}, {
			default: nn((() => [cl("img", {
				src: kt("assets/dark-logo.png"),
				alt: ""
			}, null, 8, Vf), dl(Ds), dl(Pf), dl(mu, {
				modelValue: t.value.useCapsolver,
				"onUpdate:modelValue": [o[0] || (o[0] = e => t.value.useCapsolver = e), n],
				size: "36px"
			}, null, 8, ["modelValue"])])),
			_: 1
		})]))
	}
}), [
	["__scopeId", "data-v-0b05d9d3"]
]);
var Bf = Ar(Rn({
	__name: "PopupLayout",
	setup: e => (e, t) => {
		const n = Jn("router-view");
		return Xo(), ll(Ns, {
			view: "hhh Lpr fff",
			class: "popup-layout"
		}, {
			default: nn((() => [dl(Es, {
				class: "bg-white"
			}, {
				default: nn((() => [dl(Mf)])),
				_: 1
			}), dl(Ls, null, {
				default: nn((() => [dl(qs, null, {
					default: nn((() => [dl(n)])),
					_: 1
				})])),
				_: 1
			})])),
			_: 1
		})
	}
}), [
	["__scopeId", "data-v-77b8ca20"]
]);
const If = {
		date: "####/##/##",
		datetime: "####/##/## ##:##",
		time: "##:##",
		fulltime: "##:##:##",
		phone: "(###) ### - ####",
		card: "#### #### #### ####"
	},
	$f = {
		"#": {
			pattern: "[\\d]",
			negate: "[^\\d]"
		},
		S: {
			pattern: "[a-zA-Z]",
			negate: "[^a-zA-Z]"
		},
		N: {
			pattern: "[0-9a-zA-Z]",
			negate: "[^0-9a-zA-Z]"
		},
		A: {
			pattern: "[a-zA-Z]",
			negate: "[^a-zA-Z]",
			transform: e => e.toLocaleUpperCase()
		},
		a: {
			pattern: "[a-zA-Z]",
			negate: "[^a-zA-Z]",
			transform: e => e.toLocaleLowerCase()
		},
		X: {
			pattern: "[0-9a-zA-Z]",
			negate: "[^0-9a-zA-Z]",
			transform: e => e.toLocaleUpperCase()
		},
		x: {
			pattern: "[0-9a-zA-Z]",
			negate: "[^0-9a-zA-Z]",
			transform: e => e.toLocaleLowerCase()
		}
	},
	zf = Object.keys($f);
zf.forEach((e => {
	$f[e].regex = new RegExp($f[e].pattern)
}));
const Nf = new RegExp("\\\\([^.*+?^${}()|([\\]])|([.*+?^${}()|[\\]])|([" + zf.join("") + "])|(.)", "g"),
	jf = /[.*+?^${}()|[\]\\]/g,
	Df = String.fromCharCode(1),
	Uf = {
		mask: String,
		reverseFillMask: Boolean,
		fillMask: [Boolean, String],
		unmaskedValue: Boolean
	};

function Hf(e, t, n, o) {
	let l, a, r, i;
	const s = yt(null),
		u = yt(function() {
			if (d(), !0 === s.value) {
				const t = v(h(e.modelValue));
				return !1 !== e.fillMask ? m(t) : t
			}
			return e.modelValue
		}());

	function c(e) {
		if (e < l.length) return l.slice(-e);
		let t = "",
			n = l;
		const o = n.indexOf(Df);
		if (o > -1) {
			for (let o = e - n.length; o > 0; o--) t += Df;
			n = n.slice(0, o) + t + n.slice(o)
		}
		return n
	}

	function d() {
		if (s.value = void 0 !== e.mask && e.mask.length > 0 && (!0 === e.autogrow || ["textarea", "text", "search", "url", "tel", "password"].includes(e.type)), !1 === s.value) return i = void 0, l = "", void(a = "");
		const t = void 0 === If[e.mask] ? e.mask : If[e.mask],
			n = "string" == typeof e.fillMask && e.fillMask.length > 0 ? e.fillMask.slice(0, 1) : "_",
			o = n.replace(jf, "\\$&"),
			u = [],
			c = [],
			d = [];
		let p = !0 === e.reverseFillMask,
			f = "",
			v = "";
		t.replace(Nf, ((e, t, n, o, l) => {
			if (void 0 !== o) {
				const e = $f[o];
				d.push(e), v = e.negate, !0 === p && (c.push("(?:" + v + "+)?(" + e.pattern + "+)?(?:" + v + "+)?(" + e.pattern + "+)?"), p = !1), c.push("(?:" + v + "+)?(" + e.pattern + ")?")
			} else if (void 0 !== n) f = "\\" + ("\\" === n ? "" : n), d.push(n), u.push("([^" + f + "]+)?" + f + "?");
			else {
				const e = void 0 !== t ? t : l;
				f = "\\" === e ? "\\\\\\\\" : e.replace(jf, "\\\\$&"), d.push(e), u.push("([^" + f + "]+)?" + f + "?")
			}
		}));
		const h = new RegExp("^" + u.join("") + "(" + ("" === f ? "." : "[^" + f + "]") + "+)?" + ("" === f ? "" : "[" + f + "]*") + "$"),
			m = c.length - 1,
			g = c.map(((t, n) => 0 === n && !0 === e.reverseFillMask ? new RegExp("^" + o + "*" + t) : n === m ? new RegExp("^" + t + "(" + ("" === v ? "." : v) + "+)?" + (!0 === e.reverseFillMask ? "$" : o + "*")) : new RegExp("^" + t)));
		r = d, i = t => {
			const n = h.exec(!0 === e.reverseFillMask ? t : t.slice(0, d.length));
			null !== n && (t = n.slice(1).join(""));
			const o = [],
				l = g.length;
			for (let e = 0, a = t; e < l; e++) {
				const t = g[e].exec(a);
				if (null === t) break;
				a = a.slice(t.shift().length), o.push(...t)
			}
			return o.length > 0 ? o.join("") : t
		}, l = d.map((e => "string" == typeof e ? e : Df)).join(""), a = l.split(Df).join(n)
	}

	function p(t, r, i) {
		const s = o.value,
			c = s.selectionEnd,
			p = s.value.length - c,
			g = h(t);
		!0 === r && d();
		const b = v(g),
			y = !1 !== e.fillMask ? m(b) : b,
			_ = u.value !== y;
		s.value !== y && (s.value = y), !0 === _ && (u.value = y), document.activeElement === s && $t((() => {
			if (y !== a)
				if ("insertFromPaste" !== i || !0 === e.reverseFillMask)
					if (["deleteContentBackward", "deleteContentForward"].indexOf(i) > -1) {
						const t = !0 === e.reverseFillMask ? 0 === c ? y.length > b.length ? 1 : 0 : Math.max(0, y.length - (y === a ? 0 : Math.min(b.length, p) + 1)) + 1 : c;
						s.setSelectionRange(t, t, "forward")
					} else if (!0 === e.reverseFillMask)
				if (!0 === _) {
					const e = Math.max(0, y.length - (y === a ? 0 : Math.min(b.length, p + 1)));
					1 === e && 1 === c ? s.setSelectionRange(e, e, "forward") : f.rightReverse(s, e, e)
				} else {
					const e = y.length - p;
					s.setSelectionRange(e, e, "backward")
				}
			else if (!0 === _) {
				const e = Math.max(0, l.indexOf(Df), Math.min(b.length, c) - 1);
				f.right(s, e, e)
			} else {
				const e = c - 1;
				f.right(s, e, e)
			} else {
				const e = c - 1;
				f.right(s, e, e)
			} else {
				const t = !0 === e.reverseFillMask ? a.length : 0;
				s.setSelectionRange(t, t, "forward")
			}
		}));
		const w = !0 === e.unmaskedValue ? h(y) : y;
		String(e.modelValue) !== w && n(w, !0)
	}
	gn((() => e.type + e.autogrow), d), gn((() => e.mask), (n => {
		if (void 0 !== n) p(u.value, !0);
		else {
			const n = h(u.value);
			d(), e.modelValue !== n && t("update:modelValue", n)
		}
	})), gn((() => e.fillMask + e.reverseFillMask), (() => {
		!0 === s.value && p(u.value, !0)
	})), gn((() => e.unmaskedValue), (() => {
		!0 === s.value && p(u.value)
	}));
	const f = {
		left(e, t, n, o) {
			const a = -1 === l.slice(t - 1).indexOf(Df);
			let r = Math.max(0, t - 1);
			for (; r >= 0; r--)
				if (l[r] === Df) {
					t = r, !0 === a && t++;
					break
				} if (r < 0 && void 0 !== l[t] && l[t] !== Df) return f.right(e, 0, 0);
			t >= 0 && e.setSelectionRange(t, !0 === o ? n : t, "backward")
		},
		right(e, t, n, o) {
			const a = e.value.length;
			let r = Math.min(a, n + 1);
			for (; r <= a; r++) {
				if (l[r] === Df) {
					n = r;
					break
				}
				l[r - 1] === Df && (n = r)
			}
			if (r > a && void 0 !== l[n - 1] && l[n - 1] !== Df) return f.left(e, a, a);
			e.setSelectionRange(o ? t : n, n, "forward")
		},
		leftReverse(e, t, n, o) {
			const l = c(e.value.length);
			let a = Math.max(0, t - 1);
			for (; a >= 0; a--) {
				if (l[a - 1] === Df) {
					t = a;
					break
				}
				if (l[a] === Df && (t = a, 0 === a)) break
			}
			if (a < 0 && void 0 !== l[t] && l[t] !== Df) return f.rightReverse(e, 0, 0);
			t >= 0 && e.setSelectionRange(t, !0 === o ? n : t, "backward")
		},
		rightReverse(e, t, n, o) {
			const l = e.value.length,
				a = c(l),
				r = -1 === a.slice(0, n + 1).indexOf(Df);
			let i = Math.min(l, n + 1);
			for (; i <= l; i++)
				if (a[i - 1] === Df) {
					(n = i) > 0 && !0 === r && n--;
					break
				} if (i > l && void 0 !== a[n - 1] && a[n - 1] !== Df) return f.leftReverse(e, l, l);
			e.setSelectionRange(!0 === o ? t : n, n, "forward")
		}
	};

	function v(t) {
		if (null == t || "" === t) return "";
		if (!0 === e.reverseFillMask) return function(e) {
			const t = r,
				n = l.indexOf(Df);
			let o = e.length - 1,
				a = "";
			for (let l = t.length - 1; l >= 0 && o > -1; l--) {
				const r = t[l];
				let i = e[o];
				if ("string" == typeof r) a = r + a, i === r && o--;
				else {
					if (void 0 === i || !r.regex.test(i)) return a;
					do {
						a = (void 0 !== r.transform ? r.transform(i) : i) + a, o--, i = e[o]
					} while (n === l && void 0 !== i && r.regex.test(i))
				}
			}
			return a
		}(t);
		const n = r;
		let o = 0,
			a = "";
		for (let e = 0; e < n.length; e++) {
			const l = t[o],
				r = n[e];
			if ("string" == typeof r) a += r, l === r && o++;
			else {
				if (void 0 === l || !r.regex.test(l)) return a;
				a += void 0 !== r.transform ? r.transform(l) : l, o++
			}
		}
		return a
	}

	function h(e) {
		return "string" != typeof e || void 0 === i ? "number" == typeof e ? i("" + e) : e : i(e)
	}

	function m(t) {
		return a.length - t.length <= 0 ? t : !0 === e.reverseFillMask && t.length > 0 ? a.slice(0, -t.length) + t : t + a.slice(t.length)
	}
	return {
		innerValue: u,
		hasMask: s,
		moveCursorForPaste: function(e, t, n) {
			const o = v(h(e.value));
			t = Math.max(0, l.indexOf(Df), Math.min(o.length, t)), e.setSelectionRange(t, n, "forward")
		},
		updateMaskValue: p,
		onMaskedKeydown: function(n) {
			if (t("keydown", n), !0 === br(n)) return;
			const l = o.value,
				a = l.selectionStart,
				r = l.selectionEnd;
			if (37 === n.keyCode || 39 === n.keyCode) {
				const t = f[(39 === n.keyCode ? "right" : "left") + (!0 === e.reverseFillMask ? "Reverse" : "")];
				n.preventDefault(), t(l, a, r, n.shiftKey)
			} else 8 === n.keyCode && !0 !== e.reverseFillMask && a === r ? f.left(l, a, r, !0) : 46 === n.keyCode && !0 === e.reverseFillMask && a === r && f.rightReverse(l, a, r, !0)
		}
	}
}
var Wf = ys({
	name: "QInput",
	inheritAttrs: !1,
	props: {
		...oc,
		...Uf,
		...cu,
		modelValue: {
			required: !1
		},
		shadowText: String,
		type: {
			type: String,
			default: "text"
		},
		debounce: [String, Number],
		autogrow: Boolean,
		inputClass: [Array, String, Object],
		inputStyle: [Array, String, Object]
	},
	emits: [...lc, "paste", "change", "keydown", "animationend"],
	setup(e, {
		emit: t,
		attrs: n
	}) {
		const {
			proxy: o
		} = Sl(), {
			$q: l
		} = o, a = {};
		let r, i, s, u = NaN,
			c = null;
		const d = yt(null),
			p = du(e),
			{
				innerValue: f,
				hasMask: v,
				moveCursorForPaste: h,
				updateMaskValue: m,
				onMaskedKeydown: g
			} = Hf(e, t, F, d),
			b = function(e, t) {
				function n() {
					const t = e.modelValue;
					try {
						const e = "DataTransfer" in window ? new DataTransfer : "ClipboardEvent" in window ? new ClipboardEvent("").clipboardData : void 0;
						return Object(t) === t && ("length" in t ? Array.from(t) : [t]).forEach((t => {
							e.items.add(t)
						})), {
							files: e.files
						}
					} catch (og) {
						return {
							files: void 0
						}
					}
				}
				return Ol(!0 === t ? () => {
					if ("file" === e.type) return n()
				} : n)
			}(e, !0),
			y = Ol((() => nc(f.value))),
			_ = Od(q),
			w = ac(),
			k = Ol((() => "textarea" === e.type || !0 === e.autogrow)),
			S = Ol((() => !0 === k.value || ["text", "search", "url", "tel", "password"].includes(e.type))),
			x = Ol((() => {
				const t = {
					...w.splitAttrs.listeners.value,
					onInput: q,
					onPaste: E,
					onChange: O,
					onBlur: T,
					onFocus: Xa
				};
				return t.onCompositionstart = t.onCompositionupdate = t.onCompositionend = _, !0 === v.value && (t.onKeydown = g), !0 === e.autogrow && (t.onAnimationend = L), t
			})),
			C = Ol((() => {
				const t = {
					tabindex: 0,
					"data-autofocus": !0 === e.autofocus || void 0,
					rows: "textarea" === e.type ? 6 : void 0,
					"aria-label": e.label,
					name: p.value,
					...w.splitAttrs.attributes.value,
					id: w.targetUid.value,
					maxlength: e.maxlength,
					disabled: !0 === e.disable,
					readonly: !0 === e.readonly
				};
				return !1 === k.value && (t.type = e.type), !0 === e.autogrow && (t.rows = 1), t
			}));

		function E(n) {
			if (!0 === v.value && !0 !== e.reverseFillMask) {
				const e = n.target;
				h(e, e.selectionStart, e.selectionEnd)
			}
			t("paste", n)
		}

		function q(n) {
			if (!n || !n.target) return;
			if ("file" === e.type) return void t("update:modelValue", n.target.files);
			const o = n.target.value;
			if (!0 !== n.target.qComposing) {
				if (!0 === v.value) m(o, !1, n.inputType);
				else if (F(o), !0 === S.value && n.target === document.activeElement) {
					const {
						selectionStart: e,
						selectionEnd: t
					} = n.target;
					void 0 !== e && void 0 !== t && $t((() => {
						n.target === document.activeElement && 0 === o.indexOf(n.target.value) && n.target.setSelectionRange(e, t)
					}))
				}!0 === e.autogrow && R()
			} else a.value = o
		}

		function L(e) {
			t("animationend", e), R()
		}

		function F(n, o) {
			s = () => {
				c = null, "number" !== e.type && !0 === a.hasOwnProperty("value") && delete a.value, e.modelValue !== n && u !== n && (u = n, !0 === o && (i = !0), t("update:modelValue", n), $t((() => {
					u === n && (u = NaN)
				}))), s = void 0
			}, "number" === e.type && (r = !0, a.value = n), void 0 !== e.debounce ? (null !== c && clearTimeout(c), a.value = n, c = setTimeout(s, e.debounce)) : s()
		}

		function R() {
			requestAnimationFrame((() => {
				const e = d.value;
				if (null !== e) {
					const t = e.parentNode.style,
						{
							overflow: n
						} = e.style;
					!0 !== l.platform.is.firefox && (e.style.overflow = "hidden"), t.marginBottom = e.scrollHeight - 1 + "px", e.style.height = "1px", e.style.height = e.scrollHeight + "px", e.style.overflow = n, t.marginBottom = ""
				}
			}))
		}

		function O(e) {
			_(e), null !== c && (clearTimeout(c), c = null), void 0 !== s && s(), t("change", e.target.value)
		}

		function T(t) {
			void 0 !== t && Xa(t), null !== c && (clearTimeout(c), c = null), void 0 !== s && s(), r = !1, i = !1, delete a.value, "file" !== e.type && setTimeout((() => {
				null !== d.value && (d.value.value = void 0 !== f.value ? f.value : "")
			}))
		}

		function P() {
			return !0 === a.hasOwnProperty("value") ? a.value : void 0 !== f.value ? f.value : ""
		}
		gn((() => e.type), (() => {
			d.value && (d.value.value = e.modelValue)
		})), gn((() => e.modelValue), (t => {
			if (!0 === v.value) {
				if (!0 === i && (i = !1, String(t) === u)) return;
				m(t)
			} else f.value !== t && (f.value = t, "number" === e.type && !0 === a.hasOwnProperty("value") && (!0 === r ? r = !1 : delete a.value));
			!0 === e.autogrow && $t(R)
		})), gn((() => e.autogrow), (e => {
			!0 === e ? $t(R) : null !== d.value && n.rows > 0 && (d.value.style.height = "auto")
		})), gn((() => e.dense), (() => {
			!0 === e.autogrow && $t(R)
		})), Dn((() => {
			T()
		})), zn((() => {
			!0 === e.autogrow && R()
		})), Object.assign(w, {
			innerValue: f,
			fieldClass: Ol((() => "q-" + (!0 === k.value ? "textarea" : "input") + (!0 === e.autogrow ? " q-textarea--autogrow" : ""))),
			hasShadow: Ol((() => "file" !== e.type && "string" == typeof e.shadowText && e.shadowText.length > 0)),
			inputRef: d,
			emitValue: F,
			hasValue: y,
			floatingLabel: Ol((() => !0 === y.value || nc(e.displayValue))),
			getControl: () => Tl(!0 === k.value ? "textarea" : "input", {
				ref: d,
				class: ["q-field__native q-placeholder", e.inputClass],
				style: e.inputStyle,
				...C.value,
				...x.value,
				..."file" !== e.type ? {
					value: P()
				} : b.value
			}),
			getShadowControl: () => Tl("div", {
				class: "q-field__native q-field__shadow absolute-bottom no-pointer-events" + (!0 === k.value ? "" : " text-no-wrap")
			}, [Tl("span", {
				class: "invisible"
			}, P()), Tl("span", e.shadowText)])
		});
		const A = rc(w);
		return Object.assign(o, {
			focus: function() {
				ec((() => {
					const e = document.activeElement;
					null === d.value || d.value === e || null !== e && e.id === w.targetUid.value || d.value.focus({
						preventScroll: !0
					})
				}))
			},
			select: function() {
				null !== d.value && d.value.select()
			},
			getNativeElement: () => d.value
		}), za(o, "nativeEl", (() => d.value)), A
	}
});
const Kf = [Tl("g", {
	"stroke-width": "4",
	"stroke-linecap": "round"
}, [Tl("line", {
	y1: "17",
	y2: "29",
	transform: "translate(32,32) rotate(180)"
}, [Tl("animate", {
	attributeName: "stroke-opacity",
	dur: "750ms",
	values: "1;.85;.7;.65;.55;.45;.35;.25;.15;.1;0;1",
	repeatCount: "indefinite"
})]), Tl("line", {
	y1: "17",
	y2: "29",
	transform: "translate(32,32) rotate(210)"
}, [Tl("animate", {
	attributeName: "stroke-opacity",
	dur: "750ms",
	values: "0;1;.85;.7;.65;.55;.45;.35;.25;.15;.1;0",
	repeatCount: "indefinite"
})]), Tl("line", {
	y1: "17",
	y2: "29",
	transform: "translate(32,32) rotate(240)"
}, [Tl("animate", {
	attributeName: "stroke-opacity",
	dur: "750ms",
	values: ".1;0;1;.85;.7;.65;.55;.45;.35;.25;.15;.1",
	repeatCount: "indefinite"
})]), Tl("line", {
	y1: "17",
	y2: "29",
	transform: "translate(32,32) rotate(270)"
}, [Tl("animate", {
	attributeName: "stroke-opacity",
	dur: "750ms",
	values: ".15;.1;0;1;.85;.7;.65;.55;.45;.35;.25;.15",
	repeatCount: "indefinite"
})]), Tl("line", {
	y1: "17",
	y2: "29",
	transform: "translate(32,32) rotate(300)"
}, [Tl("animate", {
	attributeName: "stroke-opacity",
	dur: "750ms",
	values: ".25;.15;.1;0;1;.85;.7;.65;.55;.45;.35;.25",
	repeatCount: "indefinite"
})]), Tl("line", {
	y1: "17",
	y2: "29",
	transform: "translate(32,32) rotate(330)"
}, [Tl("animate", {
	attributeName: "stroke-opacity",
	dur: "750ms",
	values: ".35;.25;.15;.1;0;1;.85;.7;.65;.55;.45;.35",
	repeatCount: "indefinite"
})]), Tl("line", {
	y1: "17",
	y2: "29",
	transform: "translate(32,32) rotate(0)"
}, [Tl("animate", {
	attributeName: "stroke-opacity",
	dur: "750ms",
	values: ".45;.35;.25;.15;.1;0;1;.85;.7;.65;.55;.45",
	repeatCount: "indefinite"
})]), Tl("line", {
	y1: "17",
	y2: "29",
	transform: "translate(32,32) rotate(30)"
}, [Tl("animate", {
	attributeName: "stroke-opacity",
	dur: "750ms",
	values: ".55;.45;.35;.25;.15;.1;0;1;.85;.7;.65;.55",
	repeatCount: "indefinite"
})]), Tl("line", {
	y1: "17",
	y2: "29",
	transform: "translate(32,32) rotate(60)"
}, [Tl("animate", {
	attributeName: "stroke-opacity",
	dur: "750ms",
	values: ".65;.55;.45;.35;.25;.15;.1;0;1;.85;.7;.65",
	repeatCount: "indefinite"
})]), Tl("line", {
	y1: "17",
	y2: "29",
	transform: "translate(32,32) rotate(90)"
}, [Tl("animate", {
	attributeName: "stroke-opacity",
	dur: "750ms",
	values: ".7;.65;.55;.45;.35;.25;.15;.1;0;1;.85;.7",
	repeatCount: "indefinite"
})]), Tl("line", {
	y1: "17",
	y2: "29",
	transform: "translate(32,32) rotate(120)"
}, [Tl("animate", {
	attributeName: "stroke-opacity",
	dur: "750ms",
	values: ".85;.7;.65;.55;.45;.35;.25;.15;.1;0;1;.85",
	repeatCount: "indefinite"
})]), Tl("line", {
	y1: "17",
	y2: "29",
	transform: "translate(32,32) rotate(150)"
}, [Tl("animate", {
	attributeName: "stroke-opacity",
	dur: "750ms",
	values: "1;.85;.7;.65;.55;.45;.35;.25;.15;.1;0;1",
	repeatCount: "indefinite"
})])])];
var Qf = ys({
	name: "QSpinnerIos",
	props: Mu,
	setup(e) {
		const {
			cSize: t,
			classes: n
		} = Bu(e);
		return () => Tl("svg", {
			class: n.value,
			width: t.value,
			height: t.value,
			stroke: "currentColor",
			fill: "currentColor",
			viewBox: "0 0 64 64"
		}, Kf)
	}
});
const Gf = {
		left: "start",
		center: "center",
		right: "end",
		between: "between",
		around: "around",
		evenly: "evenly",
		stretch: "stretch"
	},
	Zf = Object.keys(Gf),
	Jf = {
		type: String,
		validator: e => Zf.includes(e)
	};
const Xf = {
		none: 0,
		xs: 4,
		sm: 8,
		md: 16,
		lg: 24,
		xl: 32
	},
	Yf = {
		xs: 8,
		sm: 10,
		md: 14,
		lg: 20,
		xl: 24
	},
	ev = ["button", "submit", "reset"],
	tv = /[^\s]\/[^\s]/,
	nv = {
		...Hs,
		...Pu,
		type: {
			type: String,
			default: "button"
		},
		label: [Number, String],
		icon: String,
		iconRight: String,
		...["flat", "outline", "push", "unelevated"].reduce(((e, t) => (e[t] = Boolean) && e), {}),
		square: Boolean,
		round: Boolean,
		rounded: Boolean,
		glossy: Boolean,
		size: String,
		fab: Boolean,
		fabMini: Boolean,
		padding: String,
		color: String,
		textColor: String,
		noCaps: Boolean,
		noWrap: Boolean,
		dense: Boolean,
		tabindex: [Number, String],
		ripple: {
			type: [Boolean, Object],
			default: !0
		},
		align: {
			...Jf,
			default: "center"
		},
		stack: Boolean,
		stretch: Boolean,
		loading: {
			type: Boolean,
			default: null
		},
		disable: Boolean
	};

function ov(e) {
	const t = Ws(e, Yf),
		n = function(e) {
			return Ol((() => {
				const t = void 0 === e.align ? !0 === e.vertical ? "stretch" : "left" : e.align;
				return `${!0===e.vertical?"items":"justify"}-${Gf[t]}`
			}))
		}(e),
		{
			hasRouterLink: o,
			hasLink: l,
			linkTag: a,
			linkAttrs: r,
			navigateOnClick: i
		} = Au({
			fallbackTag: "button"
		}),
		s = Ol((() => {
			const n = !1 === e.fab && !1 === e.fabMini ? t.value : {};
			return void 0 !== e.padding ? Object.assign({}, n, {
				padding: e.padding.split(/\s+/).map((e => e in Xf ? Xf[e] + "px" : e)).join(" "),
				minWidth: "0",
				minHeight: "0"
			}) : n
		})),
		u = Ol((() => !0 === e.rounded || !0 === e.fab || !0 === e.fabMini)),
		c = Ol((() => !0 !== e.disable && !0 !== e.loading)),
		d = Ol((() => !0 === c.value ? e.tabindex || 0 : -1)),
		p = Ol((() => ((e, t) => !0 === e.flat ? "flat" : !0 === e.outline ? "outline" : !0 === e.push ? "push" : !0 === e.unelevated ? "unelevated" : t)(e, "standard"))),
		f = Ol((() => {
			const t = {
				tabindex: d.value
			};
			return !0 === l.value ? Object.assign(t, r.value) : !0 === ev.includes(e.type) && (t.type = e.type), "a" === a.value ? (!0 === e.disable ? t["aria-disabled"] = "true" : void 0 === t.href && (t.role = "button"), !0 !== o.value && !0 === tv.test(e.type) && (t.type = e.type)) : !0 === e.disable && (t.disabled = "", t["aria-disabled"] = "true"), !0 === e.loading && void 0 !== e.percentage && Object.assign(t, {
				role: "progressbar",
				"aria-valuemin": 0,
				"aria-valuemax": 100,
				"aria-valuenow": e.percentage
			}), t
		}));
	return {
		classes: Ol((() => {
			let t;
			void 0 !== e.color ? t = !0 === e.flat || !0 === e.outline ? `text-${e.textColor||e.color}` : `bg-${e.color} text-${e.textColor||"white"}` : e.textColor && (t = `text-${e.textColor}`);
			const n = !0 === e.round ? "round" : "rectangle" + (!0 === u.value ? " q-btn--rounded" : !0 === e.square ? " q-btn--square" : "");
			return `q-btn--${p.value} q-btn--${n}` + (void 0 !== t ? " " + t : "") + (!0 === c.value ? " q-btn--actionable q-focusable q-hoverable" : !0 === e.disable ? " disabled" : "") + (!0 === e.fab ? " q-btn--fab" : !0 === e.fabMini ? " q-btn--fab-mini" : "") + (!0 === e.noCaps ? " q-btn--no-uppercase" : "") + (!0 === e.dense ? " q-btn--dense" : "") + (!0 === e.stretch ? " no-border-radius self-stretch" : "") + (!0 === e.glossy ? " glossy" : "") + (e.square ? " q-btn--square" : "")
		})),
		style: s,
		innerClasses: Ol((() => n.value + (!0 === e.stack ? " column" : " row") + (!0 === e.noWrap ? " no-wrap text-no-wrap" : "") + (!0 === e.loading ? " q-btn__content--hidden" : ""))),
		attributes: f,
		hasLink: l,
		linkTag: a,
		navigateOnClick: i,
		isActionable: c
	}
}
const {
	passiveCapture: lv
} = Ga;
let av = null,
	rv = null,
	iv = null;
var sv, uv = ys({
		name: "QBtn",
		props: {
			...nv,
			percentage: Number,
			darkPercentage: Boolean,
			onTouchstart: [Function, Array]
		},
		emits: ["click", "keydown", "mousedown", "keyup"],
		setup(e, {
			slots: t,
			emit: n
		}) {
			const {
				proxy: o
			} = Sl(), {
				classes: l,
				style: a,
				innerClasses: r,
				attributes: i,
				hasLink: s,
				linkTag: u,
				navigateOnClick: c,
				isActionable: d
			} = ov(e), p = yt(null), f = yt(null);
			let v, h = null,
				m = null;
			const g = Ol((() => void 0 !== e.label && null !== e.label && "" !== e.label)),
				b = Ol((() => !0 !== e.disable && !1 !== e.ripple && {
					keyCodes: !0 === s.value ? [13, 32] : [13],
					...!0 === e.ripple ? {} : e.ripple
				})),
				y = Ol((() => ({
					center: e.round
				}))),
				_ = Ol((() => {
					const t = Math.max(0, Math.min(100, e.percentage));
					return t > 0 ? {
						transition: "transform 0.6s",
						transform: `translateX(${t-100}%)`
					} : {}
				})),
				w = Ol((() => {
					if (!0 === e.loading) return {
						onMousedown: F,
						onTouchstart: F,
						onClick: F,
						onKeydown: F,
						onKeyup: F
					};
					if (!0 === d.value) {
						const t = {
							onClick: S,
							onKeydown: x,
							onMousedown: E
						};
						if (!0 === o.$q.platform.has.touch) {
							t[`onTouchstart${void 0!==e.onTouchstart?"":"Passive"}`] = C
						}
						return t
					}
					return {
						onClick: er
					}
				})),
				k = Ol((() => ({
					ref: p,
					class: "q-btn q-btn-item non-selectable no-outline " + l.value,
					style: a.value,
					...i.value,
					...w.value
				})));

			function S(t) {
				if (null !== p.value) {
					if (void 0 !== t) {
						if (!0 === t.defaultPrevented) return;
						const n = document.activeElement;
						if ("submit" === e.type && n !== document.body && !1 === p.value.contains(n) && !1 === n.contains(p.value)) {
							p.value.focus();
							const e = () => {
								document.removeEventListener("keydown", er, !0), document.removeEventListener("keyup", e, lv), null !== p.value && p.value.removeEventListener("blur", e, lv)
							};
							document.addEventListener("keydown", er, !0), document.addEventListener("keyup", e, lv), p.value.addEventListener("blur", e, lv)
						}
					}
					c(t)
				}
			}

			function x(e) {
				null !== p.value && (n("keydown", e), !0 === yr(e, [13, 32]) && rv !== p.value && (null !== rv && L(), !0 !== e.defaultPrevented && (p.value.focus(), rv = p.value, p.value.classList.add("q-btn--active"), document.addEventListener("keyup", q, !0), p.value.addEventListener("blur", q, lv)), er(e)))
			}

			function C(e) {
				null !== p.value && (n("touchstart", e), !0 !== e.defaultPrevented && (av !== p.value && (null !== av && L(), av = p.value, h = e.target, h.addEventListener("touchcancel", q, lv), h.addEventListener("touchend", q, lv)), v = !0, null !== m && clearTimeout(m), m = setTimeout((() => {
					m = null, v = !1
				}), 200)))
			}

			function E(e) {
				null !== p.value && (e.qSkipRipple = !0 === v, n("mousedown", e), !0 !== e.defaultPrevented && iv !== p.value && (null !== iv && L(), iv = p.value, p.value.classList.add("q-btn--active"), document.addEventListener("mouseup", q, lv)))
			}

			function q(e) {
				if (null !== p.value && (void 0 === e || "blur" !== e.type || document.activeElement !== p.value)) {
					if (void 0 !== e && "keyup" === e.type) {
						if (rv === p.value && !0 === yr(e, [13, 32])) {
							const t = new MouseEvent("click", e);
							t.qKeyEvent = !0, !0 === e.defaultPrevented && Ya(t), !0 === e.cancelBubble && Xa(t), p.value.dispatchEvent(t), er(e), e.qKeyEvent = !0
						}
						n("keyup", e)
					}
					L()
				}
			}

			function L(e) {
				const t = f.value;
				!0 === e || av !== p.value && iv !== p.value || null === t || t === document.activeElement || (t.setAttribute("tabindex", -1), t.focus()), av === p.value && (null !== h && (h.removeEventListener("touchcancel", q, lv), h.removeEventListener("touchend", q, lv)), av = h = null), iv === p.value && (document.removeEventListener("mouseup", q, lv), iv = null), rv === p.value && (document.removeEventListener("keyup", q, !0), null !== p.value && p.value.removeEventListener("blur", q, lv), rv = null), null !== p.value && p.value.classList.remove("q-btn--active")
			}

			function F(e) {
				er(e), e.qSkipRipple = !0
			}
			return Dn((() => {
				L(!0)
			})), Object.assign(o, {
				click: S
			}), () => {
				let n = [];
				void 0 !== e.icon && n.push(Tl(iu, {
					name: e.icon,
					left: !1 === e.stack && !0 === g.value,
					role: "img",
					"aria-hidden": "true"
				})), !0 === g.value && n.push(Tl("span", {
					class: "block"
				}, [e.label])), n = Cs(t.default, n), void 0 !== e.iconRight && !1 === e.round && n.push(Tl(iu, {
					name: e.iconRight,
					right: !1 === e.stack && !0 === g.value,
					role: "img",
					"aria-hidden": "true"
				}));
				const o = [Tl("span", {
					class: "q-focus-helper",
					ref: f
				})];
				return !0 === e.loading && void 0 !== e.percentage && o.push(Tl("span", {
					class: "q-btn__progress absolute-full overflow-hidden" + (!0 === e.darkPercentage ? " q-btn__progress--dark" : "")
				}, [Tl("span", {
					class: "q-btn__progress-indicator fit block",
					style: _.value
				})])), o.push(Tl("span", {
					class: "q-btn__content text-center col items-center q-anchor--skip " + r.value
				}, n)), null !== e.loading && o.push(Tl(Zl, {
					name: "q-transition--fade"
				}, (() => !0 === e.loading ? [Tl("span", {
					key: "loading",
					class: "absolute-full flex flex-center"
				}, void 0 !== t.loading ? t.loading() : [Tl(Iu)])] : null))), Gn(Tl(u.value, k.value, o), [
					[dc, b.value, void 0, y.value]
				])
			}
		}
	}),
	cv = ys({
		name: "QList",
		props: {
			...su,
			bordered: Boolean,
			dense: Boolean,
			separator: Boolean,
			padding: Boolean,
			tag: {
				type: String,
				default: "div"
			}
		},
		setup(e, {
			slots: t
		}) {
			const n = Sl(),
				o = uu(e, n.proxy.$q),
				l = Ol((() => "q-list" + (!0 === e.bordered ? " q-list--bordered" : "") + (!0 === e.dense ? " q-list--dense" : "") + (!0 === e.separator ? " q-list--separator" : "") + (!0 === o.value ? " q-list--dark" : "") + (!0 === e.padding ? " q-list--padding" : "")));
			return () => Tl(e.tag, {
				class: l.value
			}, Ss(t.default))
		}
	}),
	dv = {
		exports: {}
	};
/*!
 * js-logger - http://github.com/jonnyreeves/js-logger
 * Jonny Reeves, http://jonnyreeves.co.uk/
 * js-logger may be freely distributed under the MIT license.
 */
sv = dv,
	function(e) {
		var t, n = {
				VERSION: "1.6.1"
			},
			o = {},
			l = function(e, t) {
				return function() {
					return t.apply(e, arguments)
				}
			},
			a = function() {
				var e, t, n = arguments,
					o = n[0];
				for (t = 1; t < n.length; t++)
					for (e in n[t]) !(e in o) && n[t].hasOwnProperty(e) && (o[e] = n[t][e]);
				return o
			},
			r = function(e, t) {
				return {
					value: e,
					name: t
				}
			};
		n.TRACE = r(1, "TRACE"), n.DEBUG = r(2, "DEBUG"), n.INFO = r(3, "INFO"), n.TIME = r(4, "TIME"), n.WARN = r(5, "WARN"), n.ERROR = r(8, "ERROR"), n.OFF = r(99, "OFF");
		var i = function(e) {
			this.context = e, this.setLevel(e.filterLevel), this.log = this.info
		};
		i.prototype = {
			setLevel: function(e) {
				e && "value" in e && (this.context.filterLevel = e)
			},
			getLevel: function() {
				return this.context.filterLevel
			},
			enabledFor: function(e) {
				var t = this.context.filterLevel;
				return e.value >= t.value
			},
			trace: function() {
				this.invoke(n.TRACE, arguments)
			},
			debug: function() {
				this.invoke(n.DEBUG, arguments)
			},
			info: function() {
				this.invoke(n.INFO, arguments)
			},
			warn: function() {
				this.invoke(n.WARN, arguments)
			},
			error: function() {
				this.invoke(n.ERROR, arguments)
			},
			time: function(e) {
				"string" == typeof e && e.length > 0 && this.invoke(n.TIME, [e, "start"])
			},
			timeEnd: function(e) {
				"string" == typeof e && e.length > 0 && this.invoke(n.TIME, [e, "end"])
			},
			invoke: function(e, n) {
				t && this.enabledFor(e) && t(n, a({
					level: e
				}, this.context))
			}
		};
		var s, u = new i({
			filterLevel: n.OFF
		});
		(s = n).enabledFor = l(u, u.enabledFor), s.trace = l(u, u.trace), s.debug = l(u, u.debug), s.time = l(u, u.time), s.timeEnd = l(u, u.timeEnd), s.info = l(u, u.info), s.warn = l(u, u.warn), s.error = l(u, u.error), s.log = s.info, n.setHandler = function(e) {
			t = e
		}, n.setLevel = function(e) {
			for (var t in u.setLevel(e), o) o.hasOwnProperty(t) && o[t].setLevel(e)
		}, n.getLevel = function() {
			return u.getLevel()
		}, n.get = function(e) {
			return o[e] || (o[e] = new i(a({
				name: e
			}, u.context)))
		}, n.createDefaultHandler = function(e) {
			(e = e || {}).formatter = e.formatter || function(e, t) {
				t.name && e.unshift("[" + t.name + "]")
			};
			var t = {},
				o = function(e, t) {
					Function.prototype.apply.call(e, console, t)
				};
			return "undefined" == typeof console ? function() {} : function(l, a) {
				l = Array.prototype.slice.call(l);
				var r, i = console.log;
				a.level === n.TIME ? (r = (a.name ? "[" + a.name + "] " : "") + l[0], "start" === l[1] ? console.time ? console.time(r) : t[r] = (new Date).getTime() : console.timeEnd ? console.timeEnd(r) : o(i, [r + ": " + ((new Date).getTime() - t[r]) + "ms"])) : (a.level === n.WARN && console.warn ? i = console.warn : a.level === n.ERROR && console.error ? i = console.error : a.level === n.INFO && console.info ? i = console.info : a.level === n.DEBUG && console.debug ? i = console.debug : a.level === n.TRACE && console.trace && (i = console.trace), e.formatter(l, a), o(i, l))
			}
		}, n.useDefaults = function(e) {
			n.setLevel(e && e.defaultLevel || n.DEBUG), n.setHandler(n.createDefaultHandler(e))
		}, n.setDefaults = n.useDefaults, sv.exports ? sv.exports = n : (n._prevLogger = e.Logger, n.noConflict = function() {
			return e.Logger = n._prevLogger, n
		}, e.Logger = n)
	}(wa);
var pv = dv.exports;
const fv = {
	telegram: "https://t.me/SimpleCaptcha",
	discord: "",
	dashboard: "https://simplecaptcha.org",
	addFunds: "https://simplecaptcha.org/money",
	policy: "",
	getKey: "https://simplecaptcha.org/profile_info",
	guide: "https://simplecaptcha.org",
	callbackInstructions: "https://simplecaptcha.org",
	img2textIntroduce: "https://simplecaptcha.org",
	funCaptchaUnsolved: "https://simplecaptcha.org"
	
};
class vv {
	constructor(e) {
		t(this, "baseURL"), this.baseURL = e
	}
	async post(e, t, n) {
		const o = await fetch(this.getURL(e), {
			method: "POST",
			body: JSON.stringify(t),
			headers: {
				"Content-Type": "application/json"
			},
			...n
		});
		return {
			status: o.status,
			statusText: o.statusText,
			data: await o.json(),
			headers: o.headers
		}
	}
	getURL(e) {
		return this.baseURL + e
	}
}
class hv {
	constructor(e) {
		t(this, "options", {
			apiKey: "",
			service: "https://api.simplecaptcha.org",
			defaultTimeout: 120,
			pollingInterval: 5,
			recaptchaTimeout: 600
		}), t(this, "http");
		for (let t in this.options) this.options[t] = void 0 === e[t] ? this.options[t] : e[t];
		this.http = new vv(this.options.service)
	}
	static async API(e) {
		const t = await Su.getAll();
		if (!(null == e ? void 0 : e.apiKey) && !(null == t ? void 0 : t.apiKey)) throw new Error("Capsover: No API Kye set up yet!");
		return new hv({
			apiKey: t.apiKey,
			...e
		})
	}
	async getProxyParams(e) {
		const t = await Su.getAll();
		return {
			proxyType: t.proxyType,
			proxyAddress: t.hostOrIp,
			proxyPort: t.port,
			proxyLogin: t.proxyLogin,
			proxyPassword: t.proxyPassword,
			type: e.type.replace("ProxyLess", "")
		}
	}
	async getBalance() {
		var e, t, n;
		const o = await this.http.post("/getBalance", {
			clientKey: this.options.apiKey
		});
		if (200 !== o.status || (null == (e = o.data) ? void 0 : e.errorCode) || (null == (t = o.data) ? void 0 : t.errorId)) throw new Error((null == (n = o.data) ? void 0 : n.errorDescription) || "createTask fail！");
		return o.data
	}
	async createTaskResult(e, t) {
		t || (t = {
			timeout: this.options.defaultTimeout,
			pollingInterval: this.options.pollingInterval
		});
		const n = await Su.getAll();
		if (n.appId && (e.appId = n.appId), n.useProxy) {
			const t = await this.getProxyParams(e.task);
			Object.assign(e.task, t)
		}
		const o = await this.createTask(e),
			{
				taskId: l
			} = o;
		let a = this.getTime(),
			r = void 0 === t.timeout ? this.options.defaultTimeout : t.timeout,
			i = void 0 === t.pollingInterval ? this.options.pollingInterval : t.pollingInterval;
		for (; !(this.getTime() - a > r);) {
			await new Promise((e => setTimeout(e, 1e3 * i)));
			const e = await this.getTaskSolution({
				taskId: l
			});
			if ("ready" === e.status) return e
		}
		throw new Error("Timeout " + r + " seconds reached")
	}
	async createTask(e) {
		var t, n, o;
		const l = await this.http.post("/createTask", {
			clientKey: this.options.apiKey,
			...e
		});
		if (200 !== l.status || (null == (t = l.data) ? void 0 : t.errorCode) || (null == (n = l.data) ? void 0 : n.errorId)) throw new Error((null == (o = l.data) ? void 0 : o.errorCode) || "createTask fail！");
		if (!l.data.taskId) throw new Error("taskIs is empty!");
		return l.data
	}
	async getTaskSolution({
		taskId: e
	}) {
		var t, n, o;
		const l = await this.http.post("/getTaskResult", {
			clientKey: this.options.apiKey,
			taskId: e
		});
		if (200 !== l.status || (null == (t = l.data) ? void 0 : t.errorCode) || (null == (n = l.data) ? void 0 : n.errorId)) throw new Error((null == (o = l.data) ? void 0 : o.errorCode) || "getTaskResult fail！");
		return l.data
	}
	async createRecognitionTask(e) {
		var t, n, o;
		const l = await Su.getAll();
		l.appId && (e.appId = l.appId);
		const a = await this.http.post("/createTask", {
			clientKey: this.options.apiKey,
			...e
		});
		if (200 !== a.status || (null == (t = a.data) ? void 0 : t.errorCode) || 0 !== (null == (n = a.data) ? void 0 : n.errorId)) throw new Error((null == (o = a.data) ? void 0 : o.errorDescription) || "createTask fail！");
		if (!a.data.taskId) throw new Error("taskIs is empty!");
		return a.data
	}
	getTime() {
		return parseInt(String(Date.now() / 1e3))
	}
}
const mv = [{
	label: "ReCaptcha v2",
	key: "reCaptcha",
	enabledName: "enabledForRecaptcha",
	disabled: !1,
	captchaMode: "onlyClick"
}, {
	label: "ReCaptcha v3",
	key: "reCaptcha3",
	enabledName: "enabledForRecaptchaV3",
	disabled: !0,
	captchaMode: "onlyToken"
}, {
	label: "HCaptcha",
	key: "hCaptcha",
	enabledName: "enabledForHCaptcha",
	disabled: !1,
	captchaMode: "onlyClick"
}, {
	label: "FunCaptcha",
	key: "funCaptcha",
	enabledName: "enabledForFunCaptcha",
	disabled: !1,
	captchaMode: "onlyClick",
	isBeta: !1,
	unsolved: !0,
	questionIntroduceLink: fv.funCaptchaUnsolved
}, {
	label: "Text Captcha",
	key: "textCaptcha",
	enabledName: "enabledForImageToText",
	disabled: !1,
	captchaMode: "onlyClick",
	questionIntroduce: !0,
	questionIntroduceLink: fv.img2textIntroduce
}, {
	label: "AWS Captcha",
	key: "aws",
	enabledName: "enabledForAwsCaptcha",
	disabled: !1,
	isCollapse: !1,
	captchaMode: "onlyClick"
}, {
	label: "Cloudflare",
	key: "cloudflare",
	enabledName: "enabledForCloudflare",
	disabled: !1,
	captchaMode: "onlyClick"
}, {
	label: "GeeTest",
	key: "geetest",
	enabledName: "enabledForGeetestV4",
	disabled: !0,
	isCollapse: !1,
	captchaMode: "comingSoon"
}, {
	label: "Datadome",
	key: "datadome",
	enabledName: "enabledForDataDome",
	disabled: !0,
	isCollapse: !1,
	captchaMode: "comingSoon"
}];
const gv = (e => (en("data-v-d6001888"), e = e(), tn(), e))((() => cl("img", {
	src: "assets/success.42815aad.svg",
	alt: ""
}, null, -1)));
var bv = Ar(Rn({
	__name: "Message",
	props: {
		type: null,
		message: null,
		duration: null
	},
	setup(e, {
		expose: t
	}) {
		const n = e,
			o = yt(!0);
		return t({
			close: function(e, t) {
				let l = setTimeout((() => {
					o.value = !1;
					let n = setTimeout((() => {
						e.removeChild(t), clearTimeout(l), clearTimeout(n), l = null, n = null
					}), 500)
				}), n.duration)
			}
		}), (t, n) => (Xo(), ol("div", {
			class: d(["capsolver-message", {
				"capsolver-message--close": !o.value
			}])
		}, [gv, cl("span", null, v(e.message), 1)], 2))
	}
}), [
	["__scopeId", "data-v-d6001888"]
]);

function yv(e, t) {
	const n = Tl(bv, e);
	return ((...e) => {
		va().render(...e)
	})(n, t), n
}

function _v(e) {
	const t = document.body,
		n = function() {
			const e = document.createElement("div");
			return e.classList.add("capsolver-message-container"), e
		}(),
		o = {
			vNode: yv(e, n),
			container: n
		};
	t.appendChild(n), o.vNode.component.exposed.close(t, n)
}
const wv = {
		class: "link"
	},
	kv = ["href", "target", "onClick"];
var Sv = Ar(Rn({
	__name: "Link",
	props: {
		href: null,
		target: {
			default: "_blank"
		},
		refresh: {
			type: Boolean
		}
	},
	setup(e) {
		const t = e,
			n = Ol((() => {
				var e, n;
				return (null == (e = t.href) ? void 0 : e.toLowerCase().includes("http://")) || (null == (n = t.href) ? void 0 : n.toLowerCase().includes("https://"))
			})),
			o = hn(as);

		function l(e) {
			t.refresh && (e.preventDefault(), o.go(0))
		}
		return (t, o) => {
			const a = Jn("router-link");
			return Xo(), ol("div", wv, [e.href ? (Xo(), ol(Wo, {
				key: 0
			}, [kt(n) || e.refresh ? (Xo(), ol("a", {
				key: 0,
				class: "row items-center",
				href: e.href,
				target: e.target,
				onClick: (r = l, i = ["stop"], (e, ...t) => {
					for (let n = 0; n < i.length; n++) {
						const t = ua[i[n]];
						if (t && t(e, i)) return
					}
					return r(e, ...t)
				})
			}, [to(t.$slots, "default", {}, void 0, !0)], 8, kv)) : (Xo(), ll(a, {
				key: 1,
				to: e.href
			}, {
				default: nn((() => [to(t.$slots, "default", {}, void 0, !0)])),
				_: 3
			}, 8, ["to"]))], 64)) : to(t.$slots, "default", {
				key: 1
			}, void 0, !0)]);
			var r, i
		}
	}
}), [
	["__scopeId", "data-v-a62aa848"]
]);
const xv = {
		class: "cap-collapse"
	},
	Cv = Rn({
		__name: "CapsolverCollapse",
		props: {
			collapse: {
				type: Boolean
			}
		},
		setup: e => (t, n) => Gn((Xo(), ol("div", xv, [to(t.$slots, "default")], 512)), [
			[ca, e.collapse]
		])
	}),
	Ev = Tl("div", {
		key: "svg",
		class: "q-checkbox__bg absolute"
	}, [Tl("svg", {
		class: "q-checkbox__svg fit absolute-full",
		viewBox: "0 0 24 24"
	}, [Tl("path", {
		class: "q-checkbox__truthy",
		fill: "none",
		d: "M1.73,12.91 8.1,19.28 22.79,4.59"
	}), Tl("path", {
		class: "q-checkbox__indet",
		d: "M4,14H20V10H4"
	})])]);
var qv = ys({
	name: "QCheckbox",
	props: fu,
	emits: vu,
	setup: e => hu("checkbox", (function(t, n) {
		const o = Ol((() => (!0 === t.value ? e.checkedIcon : !0 === n.value ? e.indeterminateIcon : e.uncheckedIcon) || null));
		return () => null !== o.value ? [Tl("div", {
			key: "icon",
			class: "q-checkbox__icon-container absolute-full flex flex-center no-wrap"
		}, [Tl(iu, {
			class: "q-checkbox__icon",
			name: o.value
		})])] : [Ev]
	}))
});
const Lv = e => (en("data-v-0efae70a"), e = e(), tn(), e),
	Fv = {
		class: "cap-radio"
	},
	Rv = [Lv((() => cl("span", null, "Token", -1)))],
	Ov = [Lv((() => cl("span", null, "Click", -1)))];
var Tv = Ar(Rn({
	__name: "CapsolverRadio",
	props: {
		mode: null
	},
	emits: ["update:mode", "modeChange"],
	setup(e, {
		emit: t
	}) {
		function n(e) {
			t("update:mode", e), t("modeChange")
		}
		return (t, o) => (Xo(), ol("div", Fv, [cl("div", {
			class: d(["cap-radio--item", {
				active: "token" === e.mode
			}]),
			onClick: o[0] || (o[0] = e => n("token"))
		}, Rv, 2), cl("div", {
			class: d(["cap-radio--item", {
				active: "click" === e.mode
			}]),
			onClick: o[1] || (o[1] = e => n("click"))
		}, Ov, 2)]))
	}
}), [
	["__scopeId", "data-v-0efae70a"]
]);
const Pv = ["src"];
var Av = Ar(Rn({
		__name: "CapsolverArrow",
		props: {
			up: {
				type: Boolean
			}
		},
		emits: ["update:up"],
		setup(e, {
			emit: t
		}) {
			const n = e;

			function o() {
				t("update:up", !n.up)
			}
			return (t, n) => (Xo(), ol("div", {
				class: d(["captcha-arrow", {
					"captcha-arrow--up": e.up
				}]),
				onClick: o
			}, [cl("img", {
				src: kt("assets/arrow.1ab57550.svg"),
				alt: ""
			}, null, 8, Pv)], 2))
		}
	}), [
		["__scopeId", "data-v-3ffd6706"]
	]),
	Vv = "assets/reCaptcha.63436d93.svg";
const Mv = {
		class: "captcha-checkbox"
	},
	Bv = ["src"],
	Iv = {
		class: "captcha-name"
	},
	$v = {
		class: "row items-center justify-end"
	},
	zv = {
		key: 0,
		class: "only-click"
	},
	Nv = {
		key: 1,
		class: "row items-center"
	},
	jv = {
		key: 1,
		class: "w-placeholder"
	},
	Dv = {
		key: 0,
		class: "captcha-collapse-item"
	},
	Uv = {
		key: 1,
		class: "captcha-collapse-item"
	};
var Hv = Ar(Rn({
	__name: "CaptchaItem",
	props: {
		captcha: null,
		captchaName: null,
		enabledForCaptcha: null,
		label: null,
		disabled: {
			type: Boolean,
			default: !1
		},
		repeatTimes: {
			type: Boolean,
			default: !0
		},
		delayTime: {
			type: Boolean,
			default: !0
		},
		isCollapse: {
			type: Boolean,
			default: !0
		},
		onlyClick: {
			type: Boolean,
			default: !1
		},
		onlyToken: {
			type: Boolean,
			default: !1
		},
		comingSoon: {
			type: Boolean,
			default: !1
		},
		captchaMode: {
			default: "radio"
		}
	},
	emits: ["update:captcha", "captchaChange"],
	setup(e, {
		emit: t
	}) {
		const n = e,
			{
				t: o
			} = kf(),
			l = at({
				geetest: "assets/geetest.5dfc422c.svg",
				reCaptcha: Vv,
				hCaptcha: "assets/hCaptcha.0406a4eb.svg",
				funCaptcha: "assets/funCaptcha.4f6d4ba4.svg",
				textCaptcha: "assets/textToImage.8dbe0bf9.svg",
				reCaptcha3: Vv,
				cloudflare: "assets/cloudflare.a164bb78.svg",
				datadome: "assets/dataDome.047813e4.svg",
				aws: "assets/aws.08ef8f27.svg"
			}),
			a = yt(),
			r = yt(!1);
		var i;
		bn((() => {
			a.value = n.captcha
		}), null, i);
		const s = Ol((() => {
			let e = "";
			switch (n.captchaMode) {
				case "radio":
				default:
					e = "";
					break;
				case "onlyClick":
					e = "Only Click";
					break;
				case "onlyToken":
					e = "Only Token";
					break;
				case "comingSoon":
					e = "Coming Soon"
			}
			return e
		}));

		function u() {
			t("update:captcha", a.value), t("captchaChange")
		}

		function c(e) {
			a.value[e] = Math.floor(a.value[e]), Number(a.value[e]) < 0 && (a.value[e] = 0), u(), t("captchaChange")
		}
		return (t, n) => (Xo(), ol("div", {
			class: d(["captcha-container", {
				"captcha-coming-soon": "comingSoon" === e.captchaMode
			}])
		}, [dl(Vu, null, {
			default: nn((() => [cl("div", Mv, [dl(qv, {
				modelValue: a.value[e.enabledForCaptcha],
				"onUpdate:modelValue": [n[0] || (n[0] = t => a.value[e.enabledForCaptcha] = t), u],
				disable: e.disabled
			}, null, 8, ["modelValue", "disable"])]), dl(xu, null, {
				default: nn((() => [dl(Cu, {
					class: "captcha-label-item"
				}, {
					default: nn((() => [cl("img", {
						class: "captcha-logo",
						src: l[e.captchaName],
						alt: ""
					}, null, 8, Bv), cl("span", Iv, v(e.label), 1), to(t.$slots, "tip", {}, void 0, !0)])),
					_: 3
				})])),
				_: 3
			}), cl("div", $v, [
				["onlyClick", "onlyToken", "comingSoon"].includes(e.captchaMode) ? (Xo(), ol("div", zv, [cl("span", null, v(kt(s)), 1)])) : (Xo(), ol("div", Nv, [dl(Tv, {
					mode: a.value[`${e.captchaName}Mode`],
					"onUpdate:mode": n[1] || (n[1] = t => a.value[`${e.captchaName}Mode`] = t),
					onModeChange: u
				}, null, 8, ["mode"]), e.isCollapse ? (Xo(), ll(Av, {
					key: 0,
					up: r.value,
					"onUpdate:up": n[2] || (n[2] = e => r.value = e)
				}, null, 8, ["up"])) : (Xo(), ol("div", jv))]))
			])])),
			_: 3
		}), e.isCollapse ? (Xo(), ll(Cv, {
			key: 0,
			collapse: r.value
		}, {
			default: nn((() => [e.delayTime ? (Xo(), ol("div", Dv, [cl("span", null, v(kt(o)("delay")), 1), dl(Wf, {
				modelValue: a.value[`${e.captchaName}DelayTime`],
				"onUpdate:modelValue": n[3] || (n[3] = t => a.value[`${e.captchaName}DelayTime`] = t),
				outlined: "",
				type: "number",
				onBlur: n[4] || (n[4] = () => {
					c(`${e.captchaName}DelayTime`)
				})
			}, null, 8, ["modelValue"])])) : vl("", !0), e.repeatTimes ? (Xo(), ol("div", Uv, [cl("span", null, v(kt(o)("repeat")), 1), dl(Wf, {
				modelValue: a.value[`${e.captchaName}RepeatTimes`],
				"onUpdate:modelValue": n[5] || (n[5] = t => a.value[`${e.captchaName}RepeatTimes`] = t),
				outlined: "",
				type: "number",
				onBlur: n[6] || (n[6] = () => {
					c(`${e.captchaName}RepeatTimes`)
				})
			}, null, 8, ["modelValue"])])) : vl("", !0), to(t.$slots, "collapse", {}, void 0, !0)])),
			_: 3
		}, 8, ["collapse"])) : vl("", !0)], 2))
	}
}), [
	["__scopeId", "data-v-2117a99a"]
]);
const Wv = e => (en("data-v-6b176276"), e = e(), tn(), e),
	Kv = {
		class: "mt12 capsolver-card"
	},
	Qv = {
		class: "api-title"
	},
	Gv = Wv((() => cl("div", {
		class: "text-title"
	}, [cl("img", {
		src: "assets/key.201fc3f4.svg",
		alt: ""
	}), cl("span", null, "API Key")], -1))),
	Zv = {
		class: "text-primary"
	},
	Jv = {
		class: "row items-center mt16"
	},
	Xv = {
		class: "text-title"
	},
	Yv = Wv((() => cl("img", {
		src: "assets/balance.ec909fe5.svg",
		alt: ""
	}, null, -1))),
	eh = {
		key: 1,
		class: "text-balance ml12"
	},
	th = {
		class: "mt12 capsolver-card"
	},
	nh = {
		class: "text-title"
	},
	oh = Wv((() => cl("img", {
		src: "assets/lock.8b188c3a.svg",
		alt: ""
	}, null, -1))),
	lh = Wv((() => cl("img", {
		src: "assets/question.6085c9ed.svg",
		alt: ""
	}, null, -1))),
	ah = {
		key: 1,
		class: "captcha-beta"
	},
	rh = Wv((() => cl("span", {
		class: "captcha-unsolved"
	}, "Unsolved Solution", -1))),
	ih = {
		class: "mt12 captcha-settings capsolver-card"
	},
	sh = {
		class: "text-title"
	},
	uh = Wv((() => cl("img", {
		src: "assets/settings.8bf367a7.svg",
		alt: ""
	}, null, -1))),
	ch = {
		class: "setting-item"
	},
	dh = {
		class: "setting-item"
	},
	ph = {
		class: "captcha-collapse-item"
	},
	fh = {
		class: "captcha-proxy-type"
	},
	vh = {
		class: "captcha-proxy-host"
	},
	hh = Wv((() => cl("span", null, "IP/Host", -1))),
	mh = {
		class: "captcha-proxy-port"
	},
	gh = {
		class: "captcha-collapse-item"
	},
	bh = {
		class: "captcha-proxy-login"
	},
	yh = {
		class: "captcha-proxy-password"
	},
	_h = {
		class: "setting-item"
	},
	wh = {
		class: "captcha-collapse-item"
	},
	kh = {
		style: {
			color: "#999"
		}
	},
	Sh = {
		class: "captcha-black-list mb16"
	},
	xh = {
		class: "captcha-black-url"
	},
	Ch = ["onClick"],
	Eh = [Wv((() => cl("img", {
		src: "assets/Union.e4f5e32d.svg",
		alt: ""
	}, null, -1)))],
	qh = {
		class: "setting-item callback-fn"
	},
	Lh = Wv((() => cl("img", {
		src: "assets/question.6085c9ed.svg",
		alt: ""
	}, null, -1))),
	Fh = {
		class: "mt12 captcha-footer"
	},
	Rh = {
		class: "captcha-support"
	},
	Oh = Wv((() => cl("img", {
		src: "assets/tips.e99d9ebe.svg",
		alt: ""
	}, null, -1))),
	Th = {
		class: "guide"
	};
var Ph = Ar(Rn({
	__name: "Config",
	async setup(e) {
		let t, n;
		const {
			t: o,
			locale: l
		} = kf(), a = ([t, n] = function(e) {
			const t = Sl();
			let n = e();
			return Cl(), A(n) && (n = n.catch((e => {
				throw xl(t), e
			}))), [n, () => xl(t)]
		}((() => Su.getAll())), t = await t, n(), t), r = yt(a), {
			captchaList: i
		} = {
			captchaList: mv
		};
		async function s() {
			await Su.set(pt(r.value))
		}
		const u = yt((null == a ? void 0 : a.apiKey) || ""),
			c = yt(!1),
			p = yt(""),
			f = yt({
				balance: 0,
				packages: []
			});
		async function h() {
			if (r.value.apiKey !== u.value) {
				if (r.value.apiKey = u.value, c.value = !0, await s(), !r.value.apiKey) return f.value = {
					balance: 0,
					packages: []
				}, r.value = ku, void(c.value = !1);
				await m(), c.value = !1
			}
		}
		async function m() {
			c.value = !0;
			try {
				const e = await hv.API();
				f.value = await e.getBalance(), pv.info("balance: ", f.value)
			} catch (og) {
				pv.error(og)
			} finally {
				c.value = !1
			}
		}
		async function g() {
			p.value && (r.value.blackUrlList.unshift(p.value), await s(), p.value = "")
		}

		function b() {
			window.close()
		}

		function y() {
			0 !== u.value.length && (navigator.clipboard.writeText(u.value), _v({
				type: "success",
				message: o("copySuccess"),
				duration: 2e3
			}))
		}
		return zn((() => {
			m()
		})), (e, t) => {
			var n;
			return Xo(), ol(Wo, null, [cl("div", Kv, [cl("div", Qv, [Gv, dl(Sv, {
				href: kt(fv).getKey
			}, {
				default: nn((() => [cl("span", Zv, v(kt(o)("getKey")), 1)])),
				_: 1
			}, 8, ["href"])]), dl(Wf, {
				modelValue: u.value,
				"onUpdate:modelValue": t[0] || (t[0] = e => u.value = e),
				outlined: "",
				class: "mt8 api-key",
				placeholder: kt(o)("inputKey"),
				onBlur: t[1] || (t[1] = () => {
					h()
				})
			}, {
				append: nn((() => [cl("img", {
					src: "assets/copy.b3d46815.svg",
					class: d(["copy-key", {
						"copy-key--drop": 0 === u.value.length
					}]),
					onClick: y,
					alt: ""
				}, null, 2)])),
				_: 1
			}, 8, ["modelValue", "placeholder"]), cl("div", Jv, [cl("div", Xv, [Yv, cl("span", null, v(kt(o)("balance")) + ":", 1), c.value ? (Xo(), ll(Qf, {
				key: 0,
				color: "primary",
				class: "ml12"
			})) : (Xo(), ol("span", eh, "$" + v(((null == (n = f.value) ? void 0 : n.balance) || 0).toFixed(4)), 1))]), dl(Ds), dl(Sv, {
				href: kt(fv).addFunds
			}, {
				default: nn((() => [dl(uv, {
					class: "btn-primary",
					"no-caps": "",
					unelevated: ""
				}, {
					default: nn((() => [fl("+ " + v(kt(o)("addFounds")), 1)])),
					_: 1
				})])),
				_: 1
			}, 8, ["href"])])]), cl("div", th, [cl("div", nh, [oh, cl("span", null, v(kt(o)("enabled")), 1)]), dl(cv, {
				dense: "",
				class: "m-list"
			}, {
				default: nn((() => [(Xo(!0), ol(Wo, null, eo(kt(i), (e => (Xo(), ll(Hv, {
					key: e.key,
					captcha: r.value,
					"onUpdate:captcha": t[2] || (t[2] = e => r.value = e),
					label: e.label,
					"captcha-name": e.key,
					"enabled-for-captcha": e.enabledName,
					disabled: e.disabled,
					"is-collapse": e.isCollapse,
					"captcha-mode": e.captchaMode,
					onCaptchaChange: s
				}, {
					tip: nn((() => [e.questionIntroduce ? (Xo(), ll(Sv, {
						key: 0,
						href: e.questionIntroduceLink
					}, {
						default: nn((() => [lh])),
						_: 2
					}, 1032, ["href"])) : vl("", !0), e.isBeta ? (Xo(), ol("span", ah, "Beta")) : vl("", !0), e.unsolved ? (Xo(), ll(Sv, {
						key: 2,
						href: e.questionIntroduceLink
					}, {
						default: nn((() => [rh])),
						_: 2
					}, 1032, ["href"])) : vl("", !0)])),
					_: 2
				}, 1032, ["captcha", "label", "captcha-name", "enabled-for-captcha", "disabled", "is-collapse", "captcha-mode"])))), 128))])),
				_: 1
			})]), cl("div", ih, [cl("div", sh, [uh, cl("span", null, v(kt(o)("setting")), 1)]), dl(cv, {
				dense: "",
				class: "m-list"
			}, {
				default: nn((() => [cl("div", ch, [dl(Vu, null, {
					default: nn((() => [dl(xu, null, {
						default: nn((() => [dl(Cu, null, {
							default: nn((() => [fl(v(kt(o)("manualSolving")), 1)])),
							_: 1
						})])),
						_: 1
					}), dl(xu, {
						side: ""
					}, {
						default: nn((() => [dl(mu, {
							modelValue: r.value.manualSolving,
							"onUpdate:modelValue": [t[3] || (t[3] = e => r.value.manualSolving = e), s]
						}, null, 8, ["modelValue"])])),
						_: 1
					})])),
					_: 1
				})]), cl("div", dh, [dl(Vu, null, {
					default: nn((() => [dl(xu, null, {
						default: nn((() => [dl(Cu, null, {
							default: nn((() => [fl(v(kt(o)("proxy")), 1)])),
							_: 1
						})])),
						_: 1
					}), dl(xu, {
						side: ""
					}, {
						default: nn((() => [dl(mu, {
							modelValue: r.value.useProxy,
							"onUpdate:modelValue": [t[4] || (t[4] = e => r.value.useProxy = e), s]
						}, null, 8, ["modelValue"])])),
						_: 1
					})])),
					_: 1
				}), dl(Cv, {
					collapse: r.value.useProxy
				}, {
					default: nn((() => [cl("div", ph, [cl("div", fh, [cl("span", null, v(kt(o)("proxyType")), 1), dl(Vd, {
						outlined: "",
						modelValue: r.value.proxyType,
						"onUpdate:modelValue": [t[5] || (t[5] = e => r.value.proxyType = e), s],
						options: ["http", "https", "socks4", "socks5"]
					}, null, 8, ["modelValue"])]), cl("div", vh, [hh, dl(Wf, {
						modelValue: r.value.hostOrIp,
						"onUpdate:modelValue": t[6] || (t[6] = e => r.value.hostOrIp = e),
						outlined: "",
						placeholder: "Ip/Host",
						onBlur: t[7] || (t[7] = () => {
							s()
						})
					}, null, 8, ["modelValue"])]), cl("div", mh, [cl("span", null, v(kt(o)("port")), 1), dl(Wf, {
						modelValue: r.value.port,
						"onUpdate:modelValue": t[8] || (t[8] = e => r.value.port = e),
						outlined: "",
						type: "number",
						placeholder: kt(o)("port"),
						onBlur: t[9] || (t[9] = () => {
							!async function(e) {
								r.value[e] = Math.floor(r.value[e]), Number(r.value[e]) < 0 && (r.value[e] = "port" === e ? "" : 0), await s()
							}("port")
						})
					}, null, 8, ["modelValue", "placeholder"])])]), cl("div", gh, [cl("div", bh, [cl("span", null, v(kt(o)("login")), 1), dl(Wf, {
						modelValue: r.value.proxyLogin,
						"onUpdate:modelValue": t[10] || (t[10] = e => r.value.proxyLogin = e),
						outlined: "",
						placeholder: kt(o)("loginName"),
						onBlur: t[11] || (t[11] = () => {
							s()
						})
					}, null, 8, ["modelValue", "placeholder"])]), cl("div", yh, [cl("span", null, v(kt(o)("password")), 1), dl(Wf, {
						modelValue: r.value.proxyPassword,
						"onUpdate:modelValue": t[12] || (t[12] = e => r.value.proxyPassword = e),
						outlined: "",
						placeholder: kt(o)("password"),
						onBlur: t[13] || (t[13] = () => {
							s()
						})
					}, null, 8, ["modelValue", "placeholder"])])])])),
					_: 1
				}, 8, ["collapse"])]), cl("div", _h, [dl(Vu, null, {
					default: nn((() => [dl(xu, null, {
						default: nn((() => [dl(Cu, null, {
							default: nn((() => [fl(v(kt(o)("blackControl")), 1)])),
							_: 1
						})])),
						_: 1
					}), dl(xu, {
						side: ""
					}, {
						default: nn((() => [dl(mu, {
							modelValue: r.value.enabledForBlacklistControl,
							"onUpdate:modelValue": [t[14] || (t[14] = e => r.value.enabledForBlacklistControl = e), s]
						}, null, 8, ["modelValue"])])),
						_: 1
					})])),
					_: 1
				}), dl(Cv, {
					collapse: r.value.enabledForBlacklistControl
				}, {
					default: nn((() => [cl("div", wh, [cl("span", kh, v(kt(o)("blackTip")), 1)]), cl("div", {
						class: d(["captcha-collapse-item captcha-black", `captcha-black--${kt(l)}`])
					}, [dl(Wf, {
						modelValue: p.value,
						"onUpdate:modelValue": t[15] || (t[15] = e => p.value = e),
						outlined: "",
						placeholder: "https://*.example.com"
					}, null, 8, ["modelValue"]), dl(uv, {
						class: "btn-primary",
						"no-caps": "",
						unelevated: "",
						onClick: g
					}, {
						default: nn((() => [fl(v(kt(o)("add")), 1)])),
						_: 1
					})], 2), cl("div", Sh, [(Xo(!0), ol(Wo, null, eo(r.value.blackUrlList, ((e, t) => (Xo(), ol("div", {
						class: "captcha-black-urls",
						key: e + Date.now()
					}, [cl("div", xh, v(e), 1), cl("div", {
						class: "delete",
						onClick: e => async function(e) {
							r.value.blackUrlList.splice(e, 1), await s()
						}(t)
					}, Eh, 8, Ch)])))), 128))])])),
					_: 1
				}, 8, ["collapse"])]), cl("div", qh, [dl(Vu, null, {
					default: nn((() => [dl(xu, null, {
						default: nn((() => [dl(Cu, null, {
							default: nn((() => [fl(v(kt(o)("solvedCallback")), 1)])),
							_: 1
						}), dl(Sv, {
							href: kt(fv).callbackInstructions
						}, {
							default: nn((() => [Lh])),
							_: 1
						}, 8, ["href"])])),
						_: 1
					}), dl(xu, {
						side: ""
					}, {
						default: nn((() => [dl(Wf, {
							modelValue: r.value.solvedCallback,
							"onUpdate:modelValue": t[16] || (t[16] = e => r.value.solvedCallback = e),
							outlined: "",
							placeholder: kt(o)("solvedCallbackPlaceholder"),
							onBlur: t[17] || (t[17] = () => {
								s()
							})
						}, null, 8, ["modelValue", "placeholder"])])),
						_: 1
					})])),
					_: 1
				})])])),
				_: 1
			})]), cl("div", Fh, [cl("div", Rh, [Oh, dl(Sv, {
				href: kt(fv).getKey
			}, {
				default: nn((() => [cl("span", Th, v(kt(o)("guide")), 1)])),
				_: 1
			}, 8, ["href"])]), cl("div", null, [dl(uv, {
				class: "btn-primary",
				"no-caps": "",
				unelevated: "",
				style: {
					"background-color": "#fff",
					border: "none"
				},
				onClick: b
			}, {
				default: nn((() => [cl("span", null, v(kt(o)("close")), 1)])),
				_: 1
			})])])], 64)
		}
	}
}), [
	["__scopeId", "data-v-6b176276"]
]);
const Ah = Rn({
	__name: "index",
	setup: e => (Qn((e => {
		console.error("configError: ", e)
	})), (e, t) => (Xo(), ll(un, null, {
		fallback: nn((() => [fl(" Loading... ")])),
		default: nn((() => [dl(Ph)])),
		_: 1
	})))
});
var Vh = ys({
		name: "QTd",
		props: {
			props: Object,
			autoWidth: Boolean,
			noHover: Boolean
		},
		setup(e, {
			slots: t
		}) {
			const n = Sl(),
				o = Ol((() => "q-td" + (!0 === e.autoWidth ? " q-table--col-auto-width" : "") + (!0 === e.noHover ? " q-td--no-hover" : "") + " "));
			return () => {
				if (void 0 === e.props) return Tl("td", {
					class: o.value
				}, Ss(t.default));
				const l = n.vnode.key,
					a = (void 0 !== e.props.colsMap ? e.props.colsMap[l] : null) || e.props.col;
				if (void 0 === a) return;
				const {
					row: r
				} = e.props;
				return Tl("td", {
					class: o.value + a.__tdClass(r),
					style: a.__tdStyle(r)
				}, Ss(t.default))
			}
		}
	}),
	Mh = ys({
		name: "QTh",
		props: {
			props: Object,
			autoWidth: Boolean
		},
		emits: ["click"],
		setup(e, {
			slots: t,
			emit: n
		}) {
			const o = Sl(),
				{
					proxy: {
						$q: l
					}
				} = o,
				a = e => {
					n("click", e)
				};
			return () => {
				if (void 0 === e.props) return Tl("th", {
					class: !0 === e.autoWidth ? "q-table--col-auto-width" : "",
					onClick: a
				}, Ss(t.default));
				let n, r;
				const i = o.vnode.key;
				if (i) {
					if (n = e.props.colsMap[i], void 0 === n) return
				} else n = e.props.col;
				if (!0 === n.sortable) {
					const e = "right" === n.align ? "unshift" : "push";
					r = xs(t.default, []), r[e](Tl(iu, {
						class: n.__iconClass,
						name: l.iconSet.table.arrowUp
					}))
				} else r = Ss(t.default);
				return Tl("th", {
					class: n.__thClass + (!0 === e.autoWidth ? " q-table--col-auto-width" : ""),
					style: n.headerStyle,
					onClick: t => {
						!0 === n.sortable && e.props.sort(n), a(t)
					}
				}, r)
			}
		}
	});
const Bh = {
		true: "inset",
		item: "item-inset",
		"item-thumbnail": "item-thumbnail-inset"
	},
	Ih = {
		xs: 2,
		sm: 4,
		md: 8,
		lg: 16,
		xl: 24
	};
var $h = ys({
	name: "QSeparator",
	props: {
		...su,
		spaced: [Boolean, String],
		inset: [Boolean, String],
		vertical: Boolean,
		color: String,
		size: String
	},
	setup(e) {
		const t = Sl(),
			n = uu(e, t.proxy.$q),
			o = Ol((() => !0 === e.vertical ? "vertical" : "horizontal")),
			l = Ol((() => ` q-separator--${o.value}`)),
			a = Ol((() => !1 !== e.inset ? `${l.value}-${Bh[e.inset]}` : "")),
			r = Ol((() => `q-separator${l.value}${a.value}` + (void 0 !== e.color ? ` bg-${e.color}` : "") + (!0 === n.value ? " q-separator--dark" : ""))),
			i = Ol((() => {
				const t = {};
				if (void 0 !== e.size && (t[!0 === e.vertical ? "width" : "height"] = e.size), !1 !== e.spaced) {
					const n = !0 === e.spaced ? `${Ih.md}px` : e.spaced in Ih ? `${Ih[e.spaced]}px` : e.spaced,
						o = !0 === e.vertical ? ["Left", "Right"] : ["Top", "Bottom"];
					t[`margin${o[0]}`] = t[`margin${o[1]}`] = n
				}
				return t
			}));
		return () => Tl("hr", {
			class: r.value,
			style: i.value,
			"aria-orientation": o.value
		})
	}
});
const zh = ["horizontal", "vertical", "cell", "none"];
var Nh = ys({
	name: "QMarkupTable",
	props: {
		...su,
		dense: Boolean,
		flat: Boolean,
		bordered: Boolean,
		square: Boolean,
		wrapCells: Boolean,
		separator: {
			type: String,
			default: "horizontal",
			validator: e => zh.includes(e)
		}
	},
	setup(e, {
		slots: t
	}) {
		const n = Sl(),
			o = uu(e, n.proxy.$q),
			l = Ol((() => `q-markup-table q-table__container q-table__card q-table--${e.separator}-separator` + (!0 === o.value ? " q-table--dark q-table__card--dark q-dark" : "") + (!0 === e.dense ? " q-table--dense" : "") + (!0 === e.flat ? " q-table--flat" : "") + (!0 === e.bordered ? " q-table--bordered" : "") + (!0 === e.square ? " q-table--square" : "") + (!1 === e.wrapCells ? " q-table--no-wrap" : "")));
		return () => Tl("div", {
			class: l.value
		}, [Tl("table", {
			class: "q-table"
		}, Ss(t.default))])
	}
});

function jh(e, t) {
	return Tl("div", e, [Tl("table", {
		class: "q-table"
	}, t)])
}
const Dh = {
		list: cv,
		table: Nh
	},
	Uh = ["list", "table", "__qtable"];
var Hh = ys({
	name: "QVirtualScroll",
	props: {
		...Cd,
		type: {
			type: String,
			default: "list",
			validator: e => Uh.includes(e)
		},
		items: {
			type: Array,
			default: () => []
		},
		itemsFn: Function,
		itemsSize: Number,
		scrollTarget: {
			default: void 0
		}
	},
	setup(e, {
		slots: t,
		attrs: n
	}) {
		let o;
		const l = yt(null),
			a = Ol((() => e.itemsSize >= 0 && void 0 !== e.itemsFn ? parseInt(e.itemsSize, 10) : Array.isArray(e.items) ? e.items.length : 0)),
			{
				virtualScrollSliceRange: r,
				localResetVirtualScroll: i,
				padVirtualScroll: s,
				onVirtualScrollEvt: u
			} = Ed({
				virtualScrollLength: a,
				getVirtualScrollTarget: function() {
					return o
				},
				getVirtualScrollEl: f
			}),
			c = Ol((() => {
				if (0 === a.value) return [];
				const t = (e, t) => ({
					index: r.value.from + t,
					item: e
				});
				return void 0 === e.itemsFn ? e.items.slice(r.value.from, r.value.to).map(t) : e.itemsFn(r.value.from, r.value.to - r.value.from).map(t)
			})),
			d = Ol((() => "q-virtual-scroll q-virtual-scroll" + (!0 === e.virtualScrollHorizontal ? "--horizontal" : "--vertical") + (void 0 !== e.scrollTarget ? "" : " scroll"))),
			p = Ol((() => void 0 !== e.scrollTarget ? {} : {
				tabindex: 0
			}));

		function f() {
			return l.value.$el || l.value
		}

		function v() {
			o = Ts(f(), e.scrollTarget), o.addEventListener("scroll", u, Ga.passive)
		}

		function h() {
			void 0 !== o && (o.removeEventListener("scroll", u, Ga.passive), o = void 0)
		}

		function m() {
			let n = s("list" === e.type ? "div" : "tbody", c.value.map(t.default));
			return void 0 !== t.before && (n = t.before().concat(n)), Cs(t.after, n)
		}
		return gn(a, (() => {
			i()
		})), gn((() => e.scrollTarget), (() => {
			h(), v()
		})), $n((() => {
			i()
		})), zn((() => {
			v()
		})), Pn((() => {
			v()
		})), An((() => {
			h()
		})), Dn((() => {
			h()
		})), () => {
			if (void 0 !== t.default) return "__qtable" === e.type ? jh({
				ref: l,
				class: "q-table__middle " + d.value
			}, m()) : Tl(Dh[e.type], {
				...n,
				ref: l,
				class: [n.class, d.value],
				...p.value
			}, m);
			console.error("QVirtualScroll: default scoped slot is required for rendering")
		}
	}
});
const Wh = {
	xs: 2,
	sm: 4,
	md: 6,
	lg: 10,
	xl: 14
};

function Kh(e, t, n) {
	return {
		transform: !0 === t ? `translateX(${!0===n.lang.rtl?"-":""}100%) scale3d(${-e},1,1)` : `scale3d(${e},1,1)`
	}
}
var Qh = ys({
	name: "QLinearProgress",
	props: {
		...su,
		...Hs,
		value: {
			type: Number,
			default: 0
		},
		buffer: Number,
		color: String,
		trackColor: String,
		reverse: Boolean,
		stripe: Boolean,
		indeterminate: Boolean,
		query: Boolean,
		rounded: Boolean,
		animationSpeed: {
			type: [String, Number],
			default: 2100
		},
		instantFeedback: Boolean
	},
	setup(e, {
		slots: t
	}) {
		const {
			proxy: n
		} = Sl(), o = uu(e, n.$q), l = Ws(e, Wh), a = Ol((() => !0 === e.indeterminate || !0 === e.query)), r = Ol((() => e.reverse !== e.query)), i = Ol((() => ({
			...null !== l.value ? l.value : {},
			"--q-linear-progress-speed": `${e.animationSpeed}ms`
		}))), s = Ol((() => "q-linear-progress" + (void 0 !== e.color ? ` text-${e.color}` : "") + (!0 === e.reverse || !0 === e.query ? " q-linear-progress--reverse" : "") + (!0 === e.rounded ? " rounded-borders" : ""))), u = Ol((() => Kh(void 0 !== e.buffer ? e.buffer : 1, r.value, n.$q))), c = Ol((() => `with${!0===e.instantFeedback?"out":""}-transition`)), d = Ol((() => `q-linear-progress__track absolute-full q-linear-progress__track--${c.value} q-linear-progress__track--${!0===o.value?"dark":"light"}` + (void 0 !== e.trackColor ? ` bg-${e.trackColor}` : ""))), p = Ol((() => Kh(!0 === a.value ? 1 : e.value, r.value, n.$q))), f = Ol((() => `q-linear-progress__model absolute-full q-linear-progress__model--${c.value} q-linear-progress__model--${!0===a.value?"in":""}determinate`)), v = Ol((() => ({
			width: 100 * e.value + "%"
		}))), h = Ol((() => `q-linear-progress__stripe absolute-${!0===e.reverse?"right":"left"} q-linear-progress__stripe--${c.value}`));
		return () => {
			const n = [Tl("div", {
				class: d.value,
				style: u.value
			}), Tl("div", {
				class: f.value,
				style: p.value
			})];
			return !0 === e.stripe && !1 === a.value && n.push(Tl("div", {
				class: h.value,
				style: v.value
			})), Tl("div", {
				class: s.value,
				style: i.value,
				role: "progressbar",
				"aria-valuemin": 0,
				"aria-valuemax": 1,
				"aria-valuenow": !0 === e.indeterminate ? void 0 : e.value
			}, Cs(t.default, n))
		}
	}
});
let Gh = 0;
const Zh = {
	fullscreen: Boolean,
	noRouteFullscreenExit: Boolean
};
const Jh = {
	sortMethod: Function,
	binaryStateSort: Boolean,
	columnSortOrder: {
		type: String,
		validator: e => "ad" === e || "da" === e,
		default: "ad"
	}
};

function Xh(e, t, n, o) {
	return {
		columnToSort: Ol((() => {
			const {
				sortBy: e
			} = t.value;
			return e && n.value.find((t => t.name === e)) || null
		})),
		computedSortMethod: Ol((() => void 0 !== e.sortMethod ? e.sortMethod : (e, t, o) => {
			const l = n.value.find((e => e.name === t));
			if (void 0 === l || void 0 === l.field) return e;
			const a = !0 === o ? -1 : 1,
				r = "function" == typeof l.field ? e => l.field(e) : e => e[l.field];
			return e.sort(((e, t) => {
				let n = r(e),
					o = r(t);
				return null == n ? -1 * a : null == o ? 1 * a : void 0 !== l.sort ? l.sort(n, o, e, t) * a : !0 === Rr(n) && !0 === Rr(o) ? (n - o) * a : !0 === Fr(n) && !0 === Fr(o) ? function(e, t) {
					return new Date(e) - new Date(t)
				}(n, o) * a : "boolean" == typeof n && "boolean" == typeof o ? (n - o) * a : ([n, o] = [n, o].map((e => (e + "").toLocaleString().toLowerCase())), n < o ? -1 * a : n === o ? 0 : a)
			}))
		})),
		sort: function(l) {
			let a = e.columnSortOrder;
			if (!0 === Lr(l)) l.sortOrder && (a = l.sortOrder), l = l.name;
			else {
				const e = n.value.find((e => e.name === l));
				void 0 !== e && e.sortOrder && (a = e.sortOrder)
			}
			let {
				sortBy: r,
				descending: i
			} = t.value;
			r !== l ? (r = l, i = "da" === a) : !0 === e.binaryStateSort ? i = !i : !0 === i ? "ad" === a ? r = null : i = !1 : "ad" === a ? i = !0 : r = null, o({
				sortBy: r,
				descending: i,
				page: 1
			})
		}
	}
}
const Yh = {
	filter: [String, Object],
	filterMethod: Function
};

function em(e) {
	return e.page < 1 && (e.page = 1), void 0 !== e.rowsPerPage && e.rowsPerPage < 1 && (e.rowsPerPage = 0), e
}
const tm = {
	pagination: Object,
	rowsPerPageOptions: {
		type: Array,
		default: () => [5, 7, 10, 15, 20, 25, 50, 0]
	},
	"onUpdate:pagination": [Function, Array]
};
const nm = {
	selection: {
		type: String,
		default: "none",
		validator: e => ["single", "multiple", "none"].includes(e)
	},
	selected: {
		type: Array,
		default: () => []
	}
};

function om(e) {
	return Array.isArray(e) ? e.slice() : []
}
const lm = {
	expanded: Array
};
const am = {
	visibleColumns: Array
};
const rm = "q-table__bottom row items-center",
	im = {};
xd.forEach((e => {
	im[e] = {}
}));
var sm = ys({
	name: "QTable",
	props: {
		rows: {
			type: Array,
			default: () => []
		},
		rowKey: {
			type: [String, Function],
			default: "id"
		},
		columns: Array,
		loading: Boolean,
		iconFirstPage: String,
		iconPrevPage: String,
		iconNextPage: String,
		iconLastPage: String,
		title: String,
		hideHeader: Boolean,
		grid: Boolean,
		gridHeader: Boolean,
		dense: Boolean,
		flat: Boolean,
		bordered: Boolean,
		square: Boolean,
		separator: {
			type: String,
			default: "horizontal",
			validator: e => ["horizontal", "vertical", "cell", "none"].includes(e)
		},
		wrapCells: Boolean,
		virtualScroll: Boolean,
		virtualScrollTarget: {
			default: void 0
		},
		...im,
		noDataLabel: String,
		noResultsLabel: String,
		loadingLabel: String,
		selectedRowsLabel: Function,
		rowsPerPageLabel: String,
		paginationLabel: Function,
		color: {
			type: String,
			default: "grey-8"
		},
		titleClass: [String, Array, Object],
		tableStyle: [String, Array, Object],
		tableClass: [String, Array, Object],
		tableHeaderStyle: [String, Array, Object],
		tableHeaderClass: [String, Array, Object],
		cardContainerClass: [String, Array, Object],
		cardContainerStyle: [String, Array, Object],
		cardStyle: [String, Array, Object],
		cardClass: [String, Array, Object],
		hideBottom: Boolean,
		hideSelectedBanner: Boolean,
		hideNoData: Boolean,
		hidePagination: Boolean,
		onRowClick: Function,
		onRowDblclick: Function,
		onRowContextmenu: Function,
		...su,
		...Zh,
		...am,
		...Yh,
		...tm,
		...lm,
		...nm,
		...Jh
	},
	emits: ["request", "virtualScroll", "update:fullscreen", "fullscreen", "update:expanded", "update:selected", "selection"],
	setup(e, {
		slots: t,
		emit: n
	}) {
		const o = Sl(),
			{
				proxy: {
					$q: l
				}
			} = o,
			a = uu(e, l),
			{
				inFullscreen: r,
				toggleFullscreen: i
			} = function() {
				const e = Sl(),
					{
						props: t,
						emit: n,
						proxy: o
					} = e;
				let l, a, r;
				const i = yt(!1);

				function s() {
					!0 === i.value ? c() : u()
				}

				function u() {
					!0 !== i.value && (i.value = !0, r = o.$el.parentNode, r.replaceChild(a, o.$el), document.body.appendChild(o.$el), Gh++, 1 === Gh && document.body.classList.add("q-body--fullscreen-mixin"), l = {
						handler: c
					}, dr.add(l))
				}

				function c() {
					!0 === i.value && (void 0 !== l && (dr.remove(l), l = void 0), r.replaceChild(o.$el, a), i.value = !1, Gh = Math.max(0, Gh - 1), 0 === Gh && (document.body.classList.remove("q-body--fullscreen-mixin"), void 0 !== o.$el.scrollIntoView && setTimeout((() => {
						o.$el.scrollIntoView()
					}))))
				}
				return !0 === qu(e) && gn((() => o.$route.fullPath), (() => {
					!0 !== t.noRouteFullscreenExit && c()
				})), gn((() => t.fullscreen), (e => {
					i.value !== e && s()
				})), gn(i, (e => {
					n("update:fullscreen", e), n("fullscreen", e)
				})), $n((() => {
					a = document.createElement("span")
				})), zn((() => {
					!0 === t.fullscreen && u()
				})), Dn(c), Object.assign(o, {
					toggleFullscreen: s,
					setFullscreen: u,
					exitFullscreen: c
				}), {
					inFullscreen: i,
					toggleFullscreen: s
				}
			}(),
			s = Ol((() => "function" == typeof e.rowKey ? e.rowKey : t => t[e.rowKey])),
			u = yt(null),
			c = yt(null),
			d = Ol((() => !0 !== e.grid && !0 === e.virtualScroll)),
			p = Ol((() => " q-table__card" + (!0 === a.value ? " q-table__card--dark q-dark" : "") + (!0 === e.square ? " q-table--square" : "") + (!0 === e.flat ? " q-table--flat" : "") + (!0 === e.bordered ? " q-table--bordered" : ""))),
			f = Ol((() => `q-table__container q-table--${e.separator}-separator column no-wrap` + (!0 === e.grid ? " q-table--grid" : p.value) + (!0 === a.value ? " q-table--dark" : "") + (!0 === e.dense ? " q-table--dense" : "") + (!1 === e.wrapCells ? " q-table--no-wrap" : "") + (!0 === r.value ? " fullscreen scroll" : ""))),
			v = Ol((() => f.value + (!0 === e.loading ? " q-table--loading" : "")));
		gn((() => e.tableStyle + e.tableClass + e.tableHeaderStyle + e.tableHeaderClass + f.value), (() => {
			!0 === d.value && null !== c.value && c.value.reset()
		}));
		const {
			innerPagination: h,
			computedPagination: m,
			isServerSide: g,
			requestServerInteraction: b,
			setPagination: y
		} = function(e, t) {
			const {
				props: n,
				emit: o
			} = e, l = yt(Object.assign({
				sortBy: null,
				descending: !1,
				page: 1,
				rowsPerPage: n.rowsPerPageOptions.length > 0 ? n.rowsPerPageOptions[0] : 5
			}, n.pagination)), a = Ol((() => em(void 0 !== n["onUpdate:pagination"] ? {
				...l.value,
				...n.pagination
			} : l.value))), r = Ol((() => void 0 !== a.value.rowsNumber));

			function i(e) {
				s({
					pagination: e,
					filter: n.filter
				})
			}

			function s(e = {}) {
				$t((() => {
					o("request", {
						pagination: e.pagination || a.value,
						filter: e.filter || n.filter,
						getCellValue: t
					})
				}))
			}
			return {
				innerPagination: l,
				computedPagination: a,
				isServerSide: r,
				requestServerInteraction: s,
				setPagination: function(e, t) {
					const s = em({
						...a.value,
						...e
					});
					!0 !== function(e, t) {
						for (const n in t)
							if (t[n] !== e[n]) return !1;
						return !0
					}(a.value, s) ? !0 !== r.value ? void 0 !== n.pagination && void 0 !== n["onUpdate:pagination"] ? o("update:pagination", s) : l.value = s : i(s) : !0 === r.value && !0 === t && i(s)
				}
			}
		}(o, ue), {
			computedFilterMethod: _
		} = function(e, t) {
			const n = Ol((() => void 0 !== e.filterMethod ? e.filterMethod : (e, t, n, o) => {
				const l = t ? t.toLowerCase() : "";
				return e.filter((e => n.some((t => {
					const n = o(t, e) + "";
					return -1 !== ("undefined" === n || "null" === n ? "" : n.toLowerCase()).indexOf(l)
				}))))
			}));
			return gn((() => e.filter), (() => {
				$t((() => {
					t({
						page: 1
					}, !0)
				}))
			}), {
				deep: !0
			}), {
				computedFilterMethod: n
			}
		}(e, y), {
			isRowExpanded: w,
			setExpanded: k,
			updateExpanded: S
		} = function(e, t) {
			const n = yt(om(e.expanded));

			function o(o) {
				void 0 !== e.expanded ? t("update:expanded", o) : n.value = o
			}
			return gn((() => e.expanded), (e => {
				n.value = om(e)
			})), {
				isRowExpanded: function(e) {
					return n.value.includes(e)
				},
				setExpanded: o,
				updateExpanded: function(e, t) {
					const l = n.value.slice(),
						a = l.indexOf(e);
					!0 === t ? -1 === a && (l.push(e), o(l)) : -1 !== a && (l.splice(a, 1), o(l))
				}
			}
		}(e, n), x = Ol((() => {
			let t = e.rows;
			if (!0 === g.value || 0 === t.length) return t;
			const {
				sortBy: n,
				descending: o
			} = m.value;
			return e.filter && (t = _.value(t, e.filter, B.value, ue)), null !== z.value && (t = N.value(e.rows === t ? t.slice() : t, n, o)), t
		})), C = Ol((() => x.value.length)), E = Ol((() => {
			let t = x.value;
			if (!0 === g.value) return t;
			const {
				rowsPerPage: n
			} = m.value;
			return 0 !== n && (0 === D.value && e.rows !== t ? t.length > U.value && (t = t.slice(0, U.value)) : t = t.slice(D.value, U.value)), t
		})), {
			hasSelectionMode: q,
			singleSelection: L,
			multipleSelection: F,
			allRowsSelected: R,
			someRowsSelected: O,
			rowsSelectedNumber: T,
			isRowSelected: P,
			clearSelection: A,
			updateSelection: V
		} = function(e, t, n, o) {
			const l = Ol((() => {
					const t = {};
					return e.selected.map(o.value).forEach((e => {
						t[e] = !0
					})), t
				})),
				a = Ol((() => "none" !== e.selection)),
				r = Ol((() => "single" === e.selection)),
				i = Ol((() => "multiple" === e.selection)),
				s = Ol((() => n.value.length > 0 && n.value.every((e => !0 === l.value[o.value(e)])))),
				u = Ol((() => !0 !== s.value && n.value.some((e => !0 === l.value[o.value(e)])))),
				c = Ol((() => e.selected.length));
			return {
				hasSelectionMode: a,
				singleSelection: r,
				multipleSelection: i,
				allRowsSelected: s,
				someRowsSelected: u,
				rowsSelectedNumber: c,
				isRowSelected: function(e) {
					return !0 === l.value[e]
				},
				clearSelection: function() {
					t("update:selected", [])
				},
				updateSelection: function(n, l, a, i) {
					t("selection", {
						rows: l,
						added: a,
						keys: n,
						evt: i
					});
					const s = !0 === r.value ? !0 === a ? l : [] : !0 === a ? e.selected.concat(l) : e.selected.filter((e => !1 === n.includes(o.value(e))));
					t("update:selected", s)
				}
			}
		}(e, n, E, s), {
			colList: M,
			computedCols: B,
			computedColsMap: I,
			computedColspan: $
		} = function(e, t, n) {
			const o = Ol((() => {
					if (void 0 !== e.columns) return e.columns;
					const t = e.rows[0];
					return void 0 !== t ? Object.keys(t).map((e => ({
						name: e,
						label: e.toUpperCase(),
						field: e,
						align: Rr(t[e]) ? "right" : "left",
						sortable: !0
					}))) : []
				})),
				l = Ol((() => {
					const {
						sortBy: n,
						descending: l
					} = t.value;
					return (void 0 !== e.visibleColumns ? o.value.filter((t => !0 === t.required || !0 === e.visibleColumns.includes(t.name))) : o.value).map((e => {
						const t = e.align || "right",
							o = `text-${t}`;
						return {
							...e,
							align: t,
							__iconClass: `q-table__sort-icon q-table__sort-icon--${t}`,
							__thClass: o + (void 0 !== e.headerClasses ? " " + e.headerClasses : "") + (!0 === e.sortable ? " sortable" : "") + (e.name === n ? " sorted " + (!0 === l ? "sort-desc" : "") : ""),
							__tdStyle: void 0 !== e.style ? "function" != typeof e.style ? () => e.style : e.style : () => null,
							__tdClass: void 0 !== e.classes ? "function" != typeof e.classes ? () => o + " " + e.classes : t => o + " " + e.classes(t) : () => o
						}
					}))
				})),
				a = Ol((() => {
					const e = {};
					return l.value.forEach((t => {
						e[t.name] = t
					})), e
				})),
				r = Ol((() => void 0 !== e.tableColspan ? e.tableColspan : l.value.length + (!0 === n.value ? 1 : 0)));
			return {
				colList: o,
				computedCols: l,
				computedColsMap: a,
				computedColspan: r
			}
		}(e, m, q), {
			columnToSort: z,
			computedSortMethod: N,
			sort: j
		} = Xh(e, m, M, y), {
			firstRowIndex: D,
			lastRowIndex: U,
			isFirstPage: H,
			isLastPage: W,
			pagesNumber: K,
			computedRowsPerPageOptions: Q,
			computedRowsNumber: G,
			firstPage: Z,
			prevPage: J,
			nextPage: X,
			lastPage: Y
		} = function(e, t, n, o, l, a) {
			const {
				props: r,
				emit: i,
				proxy: {
					$q: s
				}
			} = e, u = Ol((() => !0 === o.value ? n.value.rowsNumber || 0 : a.value)), c = Ol((() => {
				const {
					page: e,
					rowsPerPage: t
				} = n.value;
				return (e - 1) * t
			})), d = Ol((() => {
				const {
					page: e,
					rowsPerPage: t
				} = n.value;
				return e * t
			})), p = Ol((() => 1 === n.value.page)), f = Ol((() => 0 === n.value.rowsPerPage ? 1 : Math.max(1, Math.ceil(u.value / n.value.rowsPerPage)))), v = Ol((() => 0 === d.value || n.value.page >= f.value)), h = Ol((() => (r.rowsPerPageOptions.includes(t.value.rowsPerPage) ? r.rowsPerPageOptions : [t.value.rowsPerPage].concat(r.rowsPerPageOptions)).map((e => ({
				label: 0 === e ? s.lang.table.allRows : "" + e,
				value: e
			})))));
			return gn(f, ((e, t) => {
				if (e === t) return;
				const o = n.value.page;
				e && !o ? l({
					page: 1
				}) : e < o && l({
					page: e
				})
			})), void 0 !== r["onUpdate:pagination"] && i("update:pagination", {
				...n.value
			}), {
				firstRowIndex: c,
				lastRowIndex: d,
				isFirstPage: p,
				isLastPage: v,
				pagesNumber: f,
				computedRowsPerPageOptions: h,
				computedRowsNumber: u,
				firstPage: function() {
					l({
						page: 1
					})
				},
				prevPage: function() {
					const {
						page: e
					} = n.value;
					e > 1 && l({
						page: e - 1
					})
				},
				nextPage: function() {
					const {
						page: e,
						rowsPerPage: t
					} = n.value;
					d.value > 0 && e * t < u.value && l({
						page: e + 1
					})
				},
				lastPage: function() {
					l({
						page: f.value
					})
				}
			}
		}(o, h, m, g, y, C), ee = Ol((() => 0 === E.value.length)), te = Ol((() => {
			const t = {};
			return xd.forEach((n => {
				t[n] = e[n]
			})), void 0 === t.virtualScrollItemSize && (t.virtualScrollItemSize = !0 === e.dense ? 28 : 48), t
		}));

		function ne() {
			if (!0 === e.grid) return function() {
				const o = void 0 !== t.item ? t.item : o => {
					const l = o.cols.map((e => Tl("div", {
						class: "q-table__grid-item-row"
					}, [Tl("div", {
						class: "q-table__grid-item-title"
					}, [e.label]), Tl("div", {
						class: "q-table__grid-item-value"
					}, [e.value])])));
					if (!0 === q.value) {
						const n = t["body-selection"],
							r = void 0 !== n ? n(o) : [Tl(qv, {
								modelValue: o.selected,
								color: e.color,
								dark: a.value,
								dense: e.dense,
								"onUpdate:modelValue": (e, t) => {
									V([o.key], [o.row], e, t)
								}
							})];
						l.unshift(Tl("div", {
							class: "q-table__grid-item-row"
						}, r), Tl($h, {
							dark: a.value
						}))
					}
					const r = {
						class: ["q-table__grid-item-card" + p.value, e.cardClass],
						style: e.cardStyle
					};
					return void 0 === e.onRowClick && void 0 === e.onRowDblclick || (r.class[0] += " cursor-pointer", void 0 !== e.onRowClick && (r.onClick = e => {
						n("RowClick", e, o.row, o.pageIndex)
					}), void 0 !== e.onRowDblclick && (r.onDblclick = e => {
						n("RowDblclick", e, o.row, o.pageIndex)
					})), Tl("div", {
						class: "q-table__grid-item col-xs-12 col-sm-6 col-md-4 col-lg-3" + (!0 === o.selected ? " q-table__grid-item--selected" : "")
					}, [Tl("div", r, l)])
				};
				return Tl("div", {
					class: ["q-table__grid-content row", e.cardContainerClass],
					style: e.cardContainerStyle
				}, E.value.map(((e, t) => o(ie({
					key: s.value(e),
					row: e,
					pageIndex: t
				})))))
			}();
			const o = !0 !== e.hideHeader ? fe : null;
			if (!0 === d.value) {
				const n = t["top-row"],
					l = t["bottom-row"],
					a = {
						default: e => ae(e.item, t.body, e.index)
					};
				if (void 0 !== n) {
					const e = Tl("tbody", n({
						cols: B.value
					}));
					a.before = null === o ? () => e : () => [o()].concat(e)
				} else null !== o && (a.before = o);
				return void 0 !== l && (a.after = () => Tl("tbody", l({
					cols: B.value
				}))), Tl(Hh, {
					ref: c,
					class: e.tableClass,
					style: e.tableStyle,
					...te.value,
					scrollTarget: e.virtualScrollTarget,
					items: E.value,
					type: "__qtable",
					tableColspan: $.value,
					onVirtualScroll: oe
				}, a)
			}
			const l = [re()];
			return null !== o && l.unshift(o()), jh({
				class: ["q-table__middle scroll", e.tableClass],
				style: e.tableStyle
			}, l)
		}

		function oe(e) {
			n("virtualScroll", e)
		}

		function le() {
			return [Tl(Qh, {
				class: "q-table__linear-progress",
				color: e.color,
				dark: a.value,
				indeterminate: !0,
				trackColor: "transparent"
			})]
		}

		function ae(o, l, r) {
			const i = s.value(o),
				u = P(i);
			if (void 0 !== l) return l(ie({
				key: i,
				row: o,
				pageIndex: r,
				__trClass: u ? "selected" : ""
			}));
			const c = t["body-cell"],
				d = B.value.map((e => {
					const n = t[`body-cell-${e.name}`],
						l = void 0 !== n ? n : c;
					return void 0 !== l ? l(function(e) {
						return se(e), za(e, "value", (() => ue(e.col, e.row))), e
					}({
						key: i,
						row: o,
						pageIndex: r,
						col: e
					})) : Tl("td", {
						class: e.__tdClass(o),
						style: e.__tdStyle(o)
					}, ue(e, o))
				}));
			if (!0 === q.value) {
				const n = t["body-selection"],
					l = void 0 !== n ? n(function(e) {
						return se(e), e
					}({
						key: i,
						row: o,
						pageIndex: r
					})) : [Tl(qv, {
						modelValue: u,
						color: e.color,
						dark: a.value,
						dense: e.dense,
						"onUpdate:modelValue": (e, t) => {
							V([i], [o], e, t)
						}
					})];
				d.unshift(Tl("td", {
					class: "q-table--col-auto-width"
				}, l))
			}
			const p = {
				key: i,
				class: {
					selected: u
				}
			};
			return void 0 !== e.onRowClick && (p.class["cursor-pointer"] = !0, p.onClick = e => {
				n("RowClick", e, o, r)
			}), void 0 !== e.onRowDblclick && (p.class["cursor-pointer"] = !0, p.onDblclick = e => {
				n("RowDblclick", e, o, r)
			}), void 0 !== e.onRowContextmenu && (p.class["cursor-pointer"] = !0, p.onContextmenu = e => {
				n("RowContextmenu", e, o, r)
			}), Tl("tr", p, d)
		}

		function re() {
			const e = t.body,
				n = t["top-row"],
				o = t["bottom-row"];
			let l = E.value.map(((t, n) => ae(t, e, n)));
			return void 0 !== n && (l = n({
				cols: B.value
			}).concat(l)), void 0 !== o && (l = l.concat(o({
				cols: B.value
			}))), Tl("tbody", l)
		}

		function ie(e) {
			return se(e), e.cols = e.cols.map((t => za({
				...t
			}, "value", (() => ue(t, e.row))))), e
		}

		function se(t) {
			Object.assign(t, {
				cols: B.value,
				colsMap: I.value,
				sort: j,
				rowIndex: D.value + t.pageIndex,
				color: e.color,
				dark: a.value,
				dense: e.dense
			}), !0 === q.value && za(t, "selected", (() => P(t.key)), ((e, n) => {
				V([t.key], [t.row], e, n)
			})), za(t, "expand", (() => w(t.key)), (e => {
				S(t.key, e)
			}))
		}

		function ue(e, t) {
			const n = "function" == typeof e.field ? e.field(t) : t[e.field];
			return void 0 !== e.format ? e.format(n, t) : n
		}
		const ce = Ol((() => ({
			pagination: m.value,
			pagesNumber: K.value,
			isFirstPage: H.value,
			isLastPage: W.value,
			firstPage: Z,
			prevPage: J,
			nextPage: X,
			lastPage: Y,
			inFullscreen: r.value,
			toggleFullscreen: i
		})));

		function de() {
			const n = t.top,
				o = t["top-left"],
				l = t["top-right"],
				a = t["top-selection"],
				r = !0 === q.value && void 0 !== a && T.value > 0,
				i = "q-table__top relative-position row items-center";
			if (void 0 !== n) return Tl("div", {
				class: i
			}, [n(ce.value)]);
			let s;
			return !0 === r ? s = a(ce.value).slice() : (s = [], void 0 !== o ? s.push(Tl("div", {
				class: "q-table-control"
			}, [o(ce.value)])) : e.title && s.push(Tl("div", {
				class: "q-table__control"
			}, [Tl("div", {
				class: ["q-table__title", e.titleClass]
			}, e.title)]))), void 0 !== l && (s.push(Tl("div", {
				class: "q-table__separator col"
			})), s.push(Tl("div", {
				class: "q-table__control"
			}, [l(ce.value)]))), 0 !== s.length ? Tl("div", {
				class: i
			}, s) : void 0
		}
		const pe = Ol((() => !0 === O.value ? null : R.value));

		function fe() {
			const n = function() {
				const n = t.header,
					o = t["header-cell"];
				if (void 0 !== n) return n(ve({
					header: !0
				})).slice();
				const l = B.value.map((e => {
					const n = t[`header-cell-${e.name}`],
						l = void 0 !== n ? n : o,
						a = ve({
							col: e
						});
					return void 0 !== l ? l(a) : Tl(Mh, {
						key: e.name,
						props: a
					}, (() => e.label))
				}));
				if (!0 === L.value && !0 !== e.grid) l.unshift(Tl("th", {
					class: "q-table--col-auto-width"
				}, " "));
				else if (!0 === F.value) {
					const n = t["header-selection"],
						o = void 0 !== n ? n(ve({})) : [Tl(qv, {
							color: e.color,
							modelValue: pe.value,
							dark: a.value,
							dense: e.dense,
							"onUpdate:modelValue": he
						})];
					l.unshift(Tl("th", {
						class: "q-table--col-auto-width"
					}, o))
				}
				return [Tl("tr", {
					class: e.tableHeaderClass,
					style: e.tableHeaderStyle
				}, l)]
			}();
			return !0 === e.loading && void 0 === t.loading && n.push(Tl("tr", {
				class: "q-table__progress"
			}, [Tl("th", {
				class: "relative-position",
				colspan: $.value
			}, le())])), Tl("thead", n)
		}

		function ve(t) {
			return Object.assign(t, {
				cols: B.value,
				sort: j,
				colsMap: I.value,
				color: e.color,
				dark: a.value,
				dense: e.dense
			}), !0 === F.value && za(t, "selected", (() => pe.value), he), t
		}

		function he(e) {
			!0 === O.value && (e = !1), V(E.value.map(s.value), E.value, e)
		}
		const me = Ol((() => {
			const t = [e.iconFirstPage || l.iconSet.table.firstPage, e.iconPrevPage || l.iconSet.table.prevPage, e.iconNextPage || l.iconSet.table.nextPage, e.iconLastPage || l.iconSet.table.lastPage];
			return !0 === l.lang.rtl ? t.reverse() : t
		}));

		function ge() {
			if (!0 === e.hideBottom) return;
			if (!0 === ee.value) {
				if (!0 === e.hideNoData) return;
				const n = !0 === e.loading ? e.loadingLabel || l.lang.table.loading : e.filter ? e.noResultsLabel || l.lang.table.noResults : e.noDataLabel || l.lang.table.noData,
					o = t["no-data"],
					a = void 0 !== o ? [o({
						message: n,
						icon: l.iconSet.table.warning,
						filter: e.filter
					})] : [Tl(iu, {
						class: "q-table__bottom-nodata-icon",
						name: l.iconSet.table.warning
					}), n];
				return Tl("div", {
					class: rm + " q-table__bottom--nodata"
				}, a)
			}
			const n = t.bottom;
			if (void 0 !== n) return Tl("div", {
				class: rm
			}, [n(ce.value)]);
			const o = !0 !== e.hideSelectedBanner && !0 === q.value && T.value > 0 ? [Tl("div", {
				class: "q-table__control"
			}, [Tl("div", [(e.selectedRowsLabel || l.lang.table.selectedRecords)(T.value)])])] : [];
			return !0 !== e.hidePagination ? Tl("div", {
				class: rm + " justify-end"
			}, function(n) {
				let o;
				const {
					rowsPerPage: r
				} = m.value, i = e.paginationLabel || l.lang.table.pagination, s = t.pagination, u = e.rowsPerPageOptions.length > 1;
				n.push(Tl("div", {
					class: "q-table__separator col"
				})), !0 === u && n.push(Tl("div", {
					class: "q-table__control"
				}, [Tl("span", {
					class: "q-table__bottom-item"
				}, [e.rowsPerPageLabel || l.lang.table.recordsPerPage]), Tl(Vd, {
					class: "q-table__select inline q-table__bottom-item",
					color: e.color,
					modelValue: r,
					options: Q.value,
					displayValue: 0 === r ? l.lang.table.allRows : r,
					dark: a.value,
					borderless: !0,
					dense: !0,
					optionsDense: !0,
					optionsCover: !0,
					"onUpdate:modelValue": be
				})]));
				if (void 0 !== s) o = s(ce.value);
				else if (o = [Tl("span", 0 !== r ? {
						class: "q-table__bottom-item"
					} : {}, [r ? i(D.value + 1, Math.min(U.value, G.value), G.value) : i(1, C.value, G.value)])], 0 !== r && K.value > 1) {
					const t = {
						color: e.color,
						round: !0,
						dense: !0,
						flat: !0
					};
					!0 === e.dense && (t.size = "sm"), K.value > 2 && o.push(Tl(uv, {
						key: "pgFirst",
						...t,
						icon: me.value[0],
						disable: H.value,
						onClick: Z
					})), o.push(Tl(uv, {
						key: "pgPrev",
						...t,
						icon: me.value[1],
						disable: H.value,
						onClick: J
					}), Tl(uv, {
						key: "pgNext",
						...t,
						icon: me.value[2],
						disable: W.value,
						onClick: X
					})), K.value > 2 && o.push(Tl(uv, {
						key: "pgLast",
						...t,
						icon: me.value[3],
						disable: W.value,
						onClick: Y
					}))
				}
				return n.push(Tl("div", {
					class: "q-table__control"
				}, o)), n
			}(o)) : o.length > 0 ? Tl("div", {
				class: rm
			}, o) : void 0
		}

		function be(e) {
			y({
				page: 1,
				rowsPerPage: e.value
			})
		}
		return Object.assign(o.proxy, {
				requestServerInteraction: b,
				setPagination: y,
				firstPage: Z,
				prevPage: J,
				nextPage: X,
				lastPage: Y,
				isRowSelected: P,
				clearSelection: A,
				isRowExpanded: w,
				setExpanded: k,
				sort: j,
				resetVirtualScroll: function() {
					!0 === d.value && c.value.reset()
				},
				scrollTo: function(t, o) {
					if (null !== c.value) return void c.value.scrollTo(t, o);
					t = parseInt(t, 10);
					const l = u.value.querySelector(`tbody tr:nth-of-type(${t+1})`);
					if (null !== l) {
						const o = u.value.querySelector(".q-table__middle.scroll"),
							a = l.offsetTop - e.virtualScrollStickySizeStart,
							r = a < o.scrollTop ? "decrease" : "increase";
						o.scrollTop = a, n("virtualScroll", {
							index: t,
							from: 0,
							to: h.value.rowsPerPage - 1,
							direction: r
						})
					}
				},
				getCellValue: ue
			}),
			function(e, t) {
				for (const n in t) za(e, n, t[n])
			}(o.proxy, {
				filteredSortedRows: () => x.value,
				computedRows: () => E.value,
				computedRowsNumber: () => G.value
			}), () => {
				const n = [de()],
					o = {
						ref: u,
						class: v.value
					};
				return !0 === e.grid ? n.push(function() {
					const n = !0 === e.gridHeader ? [Tl("table", {
						class: "q-table"
					}, [fe()])] : !0 === e.loading && void 0 === t.loading ? le() : void 0;
					return Tl("div", {
						class: "q-table__middle"
					}, n)
				}()) : Object.assign(o, {
					class: [o.class, e.cardClass],
					style: e.cardStyle
				}), n.push(ne(), ge()), !0 === e.loading && void 0 !== t.loading && n.push(t.loading()), Tl("div", o, n)
			}
	}
});

function um(e) {
	return e ? "✅" : "❌"
}
const cm = [{
		name: "website",
		label: "website url",
		align: "left",
		field: "website"
	}, {
		name: "sitekey",
		label: "sitekey",
		align: "left",
		field: "sitekey"
	}, {
		name: "isEnterprise",
		label: "Enterprise",
		align: "left",
		field: e => um(e.isEnterprise)
	}, {
		name: "isRqDataRequired",
		label: "rqdata required",
		align: "left",
		field: e => um(e.isRqDataRequired)
	}, {
		name: "jsonValue",
		label: "Capsolver json",
		align: "left",
		field: "jsonValue"
	}],
	dm = yt([]),
	pm = {
		websiteURL: "",
		websiteKey: "",
		version: "",
		isEnterprise: !1,
		getCaptcha: ""
	};

function fm() {
	return chrome.devtools.network.onRequestFinished.addListener((e => {
		const t = e.request.url;
		/https:\/\/newassets\.([a-zA-Z0-9\-]+\.)?[a-zA-Z0-9\-]+\.[a-zA-Z]{2,}\/captcha\/v1\/[a-z0-9]+\/static\/hcaptcha\.html/gm.test(t) ? (e => {
			pm.isEnterprise = !1, e.getContent((e => {
				pm.getCaptcha = btoa(unescape(encodeURIComponent(e)))
			}))
		})(e) : /https:\/\/js\.([a-zA-Z0-9\-]+\.)?[a-zA-Z0-9\-]+\.[a-zA-Z]{2,}\/1\/api\.js/gm.test(t) ? (e => {
			const t = ["sentry", "custom", "apiEndpoint", "endpoint", "reportapi", "assethost", "imghost"];
			for (let n of t)
				if (e.request.url.includes(n)) {
					pm.isEnterprise = !0;
					break
				}
		})(e) : /https:\/\/([a-zA-Z0-9\-]+\.)?[a-zA-Z0-9\-]+\.[a-zA-Z]{2,}\/checksiteconfig\?.+/gm.test(t) ? (e => {
			const t = new URL(e.request.url);
			pm.version = t.searchParams.get("v"), pm.websiteURL = t.searchParams.get("host"), pm.websiteKey = t.searchParams.get("sitekey"), e.getContent((e => {
				e.includes('"features":{}') || (pm.isEnterprise = !0)
			}))
		})(e) : /https:\/\/([a-zA-Z0-9\-]+\.)?[a-zA-Z0-9\-]+\.[a-zA-Z]{2,}\/getcaptcha\/[a-z0-9\-]+/gm.test(t) && (e => {
			console.log("request", e);
			let t = null;
			e.request.postData.params.forEach((e => {
				"sitekey" === e.name && (pm.websiteKey = e.value), "host" === e.name && (pm.websiteURL = e.value), "v" === e.name && (pm.version = e.value)
			})), e.getContent((e => {
				e.includes("request_config") || (pm.isEnterprise = !0)
			})), e.request.postData && e.request.postData.text.includes("rqdata") && (pm.isEnterprise = !0, t = e.request.postData.text.match(/rqdata=([^&]*)/)[1]);
			const n = {
					site_url: pm.websiteURL,
					is_enterprise: pm.isEnterprise,
					is_rqdata_required: !!t,
					key: pm.websiteKey,
					anchor: pm.getCaptcha
				},
				{
					site_url: o,
					is_enterprise: l,
					is_rqdata_required: a,
					key: r
				} = n,
				i = JSON.stringify(function(e, t, n, o = null) {
					const l = {
						clientKey: "YOUR_API_KEY",
						task: {
							type: "HCaptchaTask",
							websiteURL: e,
							websiteKey: t,
							getCaptcha: n,
							proxy: "Your proxy here"
						}
					};
					return o && (l.task.enterprisePayload = {
						rqdata: "Obtain this value, as it's required and changes dynamically"
					}), l
				}(pm.websiteURL, pm.websiteKey, pm.getCaptcha, t), null, 4);
			dm.value.push({
				website: o,
				sitekey: r,
				isEnterprise: l,
				isRqDataRequired: a,
				jsonValue: i
			})
		})(e)
	})), {
		hCaptchaInfo: dm,
		columns: cm
	}
}
const vm = [{
		name: "website",
		label: "website url",
		align: "left",
		field: "website"
	}, {
		name: "publicKey",
		label: "site key",
		align: "left",
		field: "publicKey"
	}, {
		name: "isFunction",
		label: "funcaptcha",
		align: "left",
		field: e => gm(e.isFunction)
	}, {
		name: "funcaptchaApiJsSubdomain",
		label: "funcaptcha api js subdomain",
		align: "left",
		field: e => e.funcaptchaApiJsSubdomain
	}, {
		name: "dataBlob",
		label: "data blob",
		align: "left",
		field: e => gm(e.dataBlob)
	}, {
		name: "bda",
		label: "bda",
		align: "left",
		field: "bda"
	}, {
		name: "userAgent",
		label: "user agent",
		align: "left",
		field: "userAgent"
	}, {
		name: "jsonValue",
		label: "Capsolver json",
		align: "left",
		field: "jsonValue"
	}],
	hm = yt([]),
	mm = {
		websiteURL: "",
		websitePublicKey: "",
		data: null,
		bda: "",
		userAgent: "",
		isFunCaptcha: !1,
		funcaptchaApiJSSubdomain: ""
	};

function gm(e) {
	return e ? "✅" : "❌"
}
const bm = e => {
	const t = new URL(e.request.url),
		n = e.request.postData.text,
		o = new URLSearchParams(n);
	mm.websiteURL = o.get("site"), mm.websitePublicKey = o.get("public_key"), mm.data = o.get("data[blob]"), mm.bda = o.get("bda"), mm.userAgent = o.get("userbrowser"), mm.funcaptchaApiJSSubdomain = "https://" + function(e) {
		return new URL(e).hostname
	}(t);
	const l = {
			site_url: mm.websiteURL,
			is_funCaptcha: mm.isFunCaptcha,
			key: mm.websitePublicKey,
			data: mm.data,
			userAgent: mm.userAgent,
			bda: mm.bda,
			funcaptchaApiJSSubdomain: mm.funcaptchaApiJSSubdomain
		},
		{
			site_url: a,
			is_funCaptcha: r,
			key: i,
			data: s,
			funcaptchaApiJSSubdomain: u,
			bda: c,
			userAgent: d
		} = l,
		p = JSON.stringify(function(e, t, n, o = null) {
			if (!n) throw new Error("Failed to extract subdomain from website URL");
			const l = {
				clientKey: "YOUR_API_KEY_HERE",
				task: {
					type: "FunCaptchaTaskProxyLess",
					websiteURL: e,
					websitePublicKey: t,
					funcaptchaApiJSSubdomain: n
				}
			};
			return o && (l.task.data = JSON.stringify({
				blob: "Obtain this value, it's required and it's different each time."
			})), l
		}(mm.websiteURL, mm.websitePublicKey, mm.funcaptchaApiJSSubdomain, mm.data), null, 4);
	hm.value.push({
		website: a,
		publicKey: i,
		isFunction: r,
		funcaptchaApiJsSubdomain: u,
		dataBlob: !!s,
		jsonValue: p,
		bda: c,
		userAgent: d
	})
};
var ym = {
		/*! ieee754. BSD-3-Clause License. Feross Aboukhadijeh <https://feross.org/opensource> */
		read: function(e, t, n, o, l) {
			var a, r, i = 8 * l - o - 1,
				s = (1 << i) - 1,
				u = s >> 1,
				c = -7,
				d = n ? l - 1 : 0,
				p = n ? -1 : 1,
				f = e[t + d];
			for (d += p, a = f & (1 << -c) - 1, f >>= -c, c += i; c > 0; a = 256 * a + e[t + d], d += p, c -= 8);
			for (r = a & (1 << -c) - 1, a >>= -c, c += o; c > 0; r = 256 * r + e[t + d], d += p, c -= 8);
			if (0 === a) a = 1 - u;
			else {
				if (a === s) return r ? NaN : 1 / 0 * (f ? -1 : 1);
				r += Math.pow(2, o), a -= u
			}
			return (f ? -1 : 1) * r * Math.pow(2, a - o)
		},
		write: function(e, t, n, o, l, a) {
			var r, i, s, u = 8 * a - l - 1,
				c = (1 << u) - 1,
				d = c >> 1,
				p = 23 === l ? Math.pow(2, -24) - Math.pow(2, -77) : 0,
				f = o ? 0 : a - 1,
				v = o ? 1 : -1,
				h = t < 0 || 0 === t && 1 / t < 0 ? 1 : 0;
			for (t = Math.abs(t), isNaN(t) || t === 1 / 0 ? (i = isNaN(t) ? 1 : 0, r = c) : (r = Math.floor(Math.log(t) / Math.LN2), t * (s = Math.pow(2, -r)) < 1 && (r--, s *= 2), (t += r + d >= 1 ? p / s : p * Math.pow(2, 1 - d)) * s >= 2 && (r++, s /= 2), r + d >= c ? (i = 0, r = c) : r + d >= 1 ? (i = (t * s - 1) * Math.pow(2, l), r += d) : (i = t * Math.pow(2, d - 1) * Math.pow(2, l), r = 0)); l >= 8; e[n + f] = 255 & i, f += v, i /= 256, l -= 8);
			for (r = r << l | i, u += l; u > 0; e[n + f] = 255 & r, f += v, r /= 256, u -= 8);
			e[n + f - v] |= 128 * h
		}
	},
	_m = km,
	wm = ym;

function km(e) {
	this.buf = ArrayBuffer.isView && ArrayBuffer.isView(e) ? e : new Uint8Array(e || 0), this.pos = 0, this.type = 0, this.length = this.buf.length
}
km.Varint = 0, km.Fixed64 = 1, km.Bytes = 2, km.Fixed32 = 5;
var Sm = "undefined" == typeof TextDecoder ? null : new TextDecoder("utf8");

function xm(e) {
	return e.type === km.Bytes ? e.readVarint() + e.pos : e.pos + 1
}

function Cm(e, t, n) {
	return n ? 4294967296 * t + (e >>> 0) : 4294967296 * (t >>> 0) + (e >>> 0)
}

function Em(e, t, n) {
	var o = t <= 16383 ? 1 : t <= 2097151 ? 2 : t <= 268435455 ? 3 : Math.floor(Math.log(t) / (7 * Math.LN2));
	n.realloc(o);
	for (var l = n.pos - 1; l >= e; l--) n.buf[l + o] = n.buf[l]
}

function qm(e, t) {
	for (var n = 0; n < e.length; n++) t.writeVarint(e[n])
}

function Lm(e, t) {
	for (var n = 0; n < e.length; n++) t.writeSVarint(e[n])
}

function Fm(e, t) {
	for (var n = 0; n < e.length; n++) t.writeFloat(e[n])
}

function Rm(e, t) {
	for (var n = 0; n < e.length; n++) t.writeDouble(e[n])
}

function Om(e, t) {
	for (var n = 0; n < e.length; n++) t.writeBoolean(e[n])
}

function Tm(e, t) {
	for (var n = 0; n < e.length; n++) t.writeFixed32(e[n])
}

function Pm(e, t) {
	for (var n = 0; n < e.length; n++) t.writeSFixed32(e[n])
}

function Am(e, t) {
	for (var n = 0; n < e.length; n++) t.writeFixed64(e[n])
}

function Vm(e, t) {
	for (var n = 0; n < e.length; n++) t.writeSFixed64(e[n])
}

function Mm(e, t) {
	return (e[t] | e[t + 1] << 8 | e[t + 2] << 16) + 16777216 * e[t + 3]
}

function Bm(e, t, n) {
	e[n] = t, e[n + 1] = t >>> 8, e[n + 2] = t >>> 16, e[n + 3] = t >>> 24
}

function Im(e, t) {
	return (e[t] | e[t + 1] << 8 | e[t + 2] << 16) + (e[t + 3] << 24)
}
km.prototype = {
	destroy: function() {
		this.buf = null
	},
	readFields: function(e, t, n) {
		for (n = n || this.length; this.pos < n;) {
			var o = this.readVarint(),
				l = o >> 3,
				a = this.pos;
			this.type = 7 & o, e(l, t, this), this.pos === a && this.skip(o)
		}
		return t
	},
	readMessage: function(e, t) {
		return this.readFields(e, t, this.readVarint() + this.pos)
	},
	readFixed32: function() {
		var e = Mm(this.buf, this.pos);
		return this.pos += 4, e
	},
	readSFixed32: function() {
		var e = Im(this.buf, this.pos);
		return this.pos += 4, e
	},
	readFixed64: function() {
		var e = Mm(this.buf, this.pos) + 4294967296 * Mm(this.buf, this.pos + 4);
		return this.pos += 8, e
	},
	readSFixed64: function() {
		var e = Mm(this.buf, this.pos) + 4294967296 * Im(this.buf, this.pos + 4);
		return this.pos += 8, e
	},
	readFloat: function() {
		var e = wm.read(this.buf, this.pos, !0, 23, 4);
		return this.pos += 4, e
	},
	readDouble: function() {
		var e = wm.read(this.buf, this.pos, !0, 52, 8);
		return this.pos += 8, e
	},
	readVarint: function(e) {
		var t, n, o = this.buf;
		return t = 127 & (n = o[this.pos++]), n < 128 ? t : (t |= (127 & (n = o[this.pos++])) << 7, n < 128 ? t : (t |= (127 & (n = o[this.pos++])) << 14, n < 128 ? t : (t |= (127 & (n = o[this.pos++])) << 21, n < 128 ? t : function(e, t, n) {
			var o, l, a = n.buf;
			if (l = a[n.pos++], o = (112 & l) >> 4, l < 128) return Cm(e, o, t);
			if (l = a[n.pos++], o |= (127 & l) << 3, l < 128) return Cm(e, o, t);
			if (l = a[n.pos++], o |= (127 & l) << 10, l < 128) return Cm(e, o, t);
			if (l = a[n.pos++], o |= (127 & l) << 17, l < 128) return Cm(e, o, t);
			if (l = a[n.pos++], o |= (127 & l) << 24, l < 128) return Cm(e, o, t);
			if (l = a[n.pos++], o |= (1 & l) << 31, l < 128) return Cm(e, o, t);
			throw new Error("Expected varint not more than 10 bytes")
		}(t |= (15 & (n = o[this.pos])) << 28, e, this))))
	},
	readVarint64: function() {
		return this.readVarint(!0)
	},
	readSVarint: function() {
		var e = this.readVarint();
		return e % 2 == 1 ? (e + 1) / -2 : e / 2
	},
	readBoolean: function() {
		return Boolean(this.readVarint())
	},
	readString: function() {
		var e = this.readVarint() + this.pos,
			t = this.pos;
		return this.pos = e, e - t >= 12 && Sm ? function(e, t, n) {
			return Sm.decode(e.subarray(t, n))
		}(this.buf, t, e) : function(e, t, n) {
			var o = "",
				l = t;
			for (; l < n;) {
				var a, r, i, s = e[l],
					u = null,
					c = s > 239 ? 4 : s > 223 ? 3 : s > 191 ? 2 : 1;
				if (l + c > n) break;
				1 === c ? s < 128 && (u = s) : 2 === c ? 128 == (192 & (a = e[l + 1])) && (u = (31 & s) << 6 | 63 & a) <= 127 && (u = null) : 3 === c ? (a = e[l + 1], r = e[l + 2], 128 == (192 & a) && 128 == (192 & r) && ((u = (15 & s) << 12 | (63 & a) << 6 | 63 & r) <= 2047 || u >= 55296 && u <= 57343) && (u = null)) : 4 === c && (a = e[l + 1], r = e[l + 2], i = e[l + 3], 128 == (192 & a) && 128 == (192 & r) && 128 == (192 & i) && ((u = (15 & s) << 18 | (63 & a) << 12 | (63 & r) << 6 | 63 & i) <= 65535 || u >= 1114112) && (u = null)), null === u ? (u = 65533, c = 1) : u > 65535 && (u -= 65536, o += String.fromCharCode(u >>> 10 & 1023 | 55296), u = 56320 | 1023 & u), o += String.fromCharCode(u), l += c
			}
			return o
		}(this.buf, t, e)
	},
	readBytes: function() {
		var e = this.readVarint() + this.pos,
			t = this.buf.subarray(this.pos, e);
		return this.pos = e, t
	},
	readPackedVarint: function(e, t) {
		if (this.type !== km.Bytes) return e.push(this.readVarint(t));
		var n = xm(this);
		for (e = e || []; this.pos < n;) e.push(this.readVarint(t));
		return e
	},
	readPackedSVarint: function(e) {
		if (this.type !== km.Bytes) return e.push(this.readSVarint());
		var t = xm(this);
		for (e = e || []; this.pos < t;) e.push(this.readSVarint());
		return e
	},
	readPackedBoolean: function(e) {
		if (this.type !== km.Bytes) return e.push(this.readBoolean());
		var t = xm(this);
		for (e = e || []; this.pos < t;) e.push(this.readBoolean());
		return e
	},
	readPackedFloat: function(e) {
		if (this.type !== km.Bytes) return e.push(this.readFloat());
		var t = xm(this);
		for (e = e || []; this.pos < t;) e.push(this.readFloat());
		return e
	},
	readPackedDouble: function(e) {
		if (this.type !== km.Bytes) return e.push(this.readDouble());
		var t = xm(this);
		for (e = e || []; this.pos < t;) e.push(this.readDouble());
		return e
	},
	readPackedFixed32: function(e) {
		if (this.type !== km.Bytes) return e.push(this.readFixed32());
		var t = xm(this);
		for (e = e || []; this.pos < t;) e.push(this.readFixed32());
		return e
	},
	readPackedSFixed32: function(e) {
		if (this.type !== km.Bytes) return e.push(this.readSFixed32());
		var t = xm(this);
		for (e = e || []; this.pos < t;) e.push(this.readSFixed32());
		return e
	},
	readPackedFixed64: function(e) {
		if (this.type !== km.Bytes) return e.push(this.readFixed64());
		var t = xm(this);
		for (e = e || []; this.pos < t;) e.push(this.readFixed64());
		return e
	},
	readPackedSFixed64: function(e) {
		if (this.type !== km.Bytes) return e.push(this.readSFixed64());
		var t = xm(this);
		for (e = e || []; this.pos < t;) e.push(this.readSFixed64());
		return e
	},
	skip: function(e) {
		var t = 7 & e;
		if (t === km.Varint)
			for (; this.buf[this.pos++] > 127;);
		else if (t === km.Bytes) this.pos = this.readVarint() + this.pos;
		else if (t === km.Fixed32) this.pos += 4;
		else {
			if (t !== km.Fixed64) throw new Error("Unimplemented type: " + t);
			this.pos += 8
		}
	},
	writeTag: function(e, t) {
		this.writeVarint(e << 3 | t)
	},
	realloc: function(e) {
		for (var t = this.length || 16; t < this.pos + e;) t *= 2;
		if (t !== this.length) {
			var n = new Uint8Array(t);
			n.set(this.buf), this.buf = n, this.length = t
		}
	},
	finish: function() {
		return this.length = this.pos, this.pos = 0, this.buf.subarray(0, this.length)
	},
	writeFixed32: function(e) {
		this.realloc(4), Bm(this.buf, e, this.pos), this.pos += 4
	},
	writeSFixed32: function(e) {
		this.realloc(4), Bm(this.buf, e, this.pos), this.pos += 4
	},
	writeFixed64: function(e) {
		this.realloc(8), Bm(this.buf, -1 & e, this.pos), Bm(this.buf, Math.floor(2.3283064365386963e-10 * e), this.pos + 4), this.pos += 8
	},
	writeSFixed64: function(e) {
		this.realloc(8), Bm(this.buf, -1 & e, this.pos), Bm(this.buf, Math.floor(2.3283064365386963e-10 * e), this.pos + 4), this.pos += 8
	},
	writeVarint: function(e) {
		(e = +e || 0) > 268435455 || e < 0 ? function(e, t) {
			var n, o;
			e >= 0 ? (n = e % 4294967296 | 0, o = e / 4294967296 | 0) : (o = ~(-e / 4294967296), 4294967295 ^ (n = ~(-e % 4294967296)) ? n = n + 1 | 0 : (n = 0, o = o + 1 | 0));
			if (e >= 0x10000000000000000 || e < -0x10000000000000000) throw new Error("Given varint doesn't fit into 10 bytes");
			t.realloc(10),
				function(e, t, n) {
					n.buf[n.pos++] = 127 & e | 128, e >>>= 7, n.buf[n.pos++] = 127 & e | 128, e >>>= 7, n.buf[n.pos++] = 127 & e | 128, e >>>= 7, n.buf[n.pos++] = 127 & e | 128, e >>>= 7, n.buf[n.pos] = 127 & e
				}(n, 0, t),
				function(e, t) {
					var n = (7 & e) << 4;
					if (t.buf[t.pos++] |= n | ((e >>>= 3) ? 128 : 0), !e) return;
					if (t.buf[t.pos++] = 127 & e | ((e >>>= 7) ? 128 : 0), !e) return;
					if (t.buf[t.pos++] = 127 & e | ((e >>>= 7) ? 128 : 0), !e) return;
					if (t.buf[t.pos++] = 127 & e | ((e >>>= 7) ? 128 : 0), !e) return;
					if (t.buf[t.pos++] = 127 & e | ((e >>>= 7) ? 128 : 0), !e) return;
					t.buf[t.pos++] = 127 & e
				}(o, t)
		}(e, this) : (this.realloc(4), this.buf[this.pos++] = 127 & e | (e > 127 ? 128 : 0), e <= 127 || (this.buf[this.pos++] = 127 & (e >>>= 7) | (e > 127 ? 128 : 0), e <= 127 || (this.buf[this.pos++] = 127 & (e >>>= 7) | (e > 127 ? 128 : 0), e <= 127 || (this.buf[this.pos++] = e >>> 7 & 127))))
	},
	writeSVarint: function(e) {
		this.writeVarint(e < 0 ? 2 * -e - 1 : 2 * e)
	},
	writeBoolean: function(e) {
		this.writeVarint(Boolean(e))
	},
	writeString: function(e) {
		e = String(e), this.realloc(4 * e.length), this.pos++;
		var t = this.pos;
		this.pos = function(e, t, n) {
			for (var o, l, a = 0; a < t.length; a++) {
				if ((o = t.charCodeAt(a)) > 55295 && o < 57344) {
					if (!l) {
						o > 56319 || a + 1 === t.length ? (e[n++] = 239, e[n++] = 191, e[n++] = 189) : l = o;
						continue
					}
					if (o < 56320) {
						e[n++] = 239, e[n++] = 191, e[n++] = 189, l = o;
						continue
					}
					o = l - 55296 << 10 | o - 56320 | 65536, l = null
				} else l && (e[n++] = 239, e[n++] = 191, e[n++] = 189, l = null);
				o < 128 ? e[n++] = o : (o < 2048 ? e[n++] = o >> 6 | 192 : (o < 65536 ? e[n++] = o >> 12 | 224 : (e[n++] = o >> 18 | 240, e[n++] = o >> 12 & 63 | 128), e[n++] = o >> 6 & 63 | 128), e[n++] = 63 & o | 128)
			}
			return n
		}(this.buf, e, this.pos);
		var n = this.pos - t;
		n >= 128 && Em(t, n, this), this.pos = t - 1, this.writeVarint(n), this.pos += n
	},
	writeFloat: function(e) {
		this.realloc(4), wm.write(this.buf, e, this.pos, !0, 23, 4), this.pos += 4
	},
	writeDouble: function(e) {
		this.realloc(8), wm.write(this.buf, e, this.pos, !0, 52, 8), this.pos += 8
	},
	writeBytes: function(e) {
		var t = e.length;
		this.writeVarint(t), this.realloc(t);
		for (var n = 0; n < t; n++) this.buf[this.pos++] = e[n]
	},
	writeRawMessage: function(e, t) {
		this.pos++;
		var n = this.pos;
		e(t, this);
		var o = this.pos - n;
		o >= 128 && Em(n, o, this), this.pos = n - 1, this.writeVarint(o), this.pos += o
	},
	writeMessage: function(e, t, n) {
		this.writeTag(e, km.Bytes), this.writeRawMessage(t, n)
	},
	writePackedVarint: function(e, t) {
		t.length && this.writeMessage(e, qm, t)
	},
	writePackedSVarint: function(e, t) {
		t.length && this.writeMessage(e, Lm, t)
	},
	writePackedBoolean: function(e, t) {
		t.length && this.writeMessage(e, Om, t)
	},
	writePackedFloat: function(e, t) {
		t.length && this.writeMessage(e, Fm, t)
	},
	writePackedDouble: function(e, t) {
		t.length && this.writeMessage(e, Rm, t)
	},
	writePackedFixed32: function(e, t) {
		t.length && this.writeMessage(e, Tm, t)
	},
	writePackedSFixed32: function(e, t) {
		t.length && this.writeMessage(e, Pm, t)
	},
	writePackedFixed64: function(e, t) {
		t.length && this.writeMessage(e, Am, t)
	},
	writePackedSFixed64: function(e, t) {
		t.length && this.writeMessage(e, Vm, t)
	},
	writeBytesField: function(e, t) {
		this.writeTag(e, km.Bytes), this.writeBytes(t)
	},
	writeFixed32Field: function(e, t) {
		this.writeTag(e, km.Fixed32), this.writeFixed32(t)
	},
	writeSFixed32Field: function(e, t) {
		this.writeTag(e, km.Fixed32), this.writeSFixed32(t)
	},
	writeFixed64Field: function(e, t) {
		this.writeTag(e, km.Fixed64), this.writeFixed64(t)
	},
	writeSFixed64Field: function(e, t) {
		this.writeTag(e, km.Fixed64), this.writeSFixed64(t)
	},
	writeVarintField: function(e, t) {
		this.writeTag(e, km.Varint), this.writeVarint(t)
	},
	writeSVarintField: function(e, t) {
		this.writeTag(e, km.Varint), this.writeSVarint(t)
	},
	writeStringField: function(e, t) {
		this.writeTag(e, km.Bytes), this.writeString(t)
	},
	writeFloatField: function(e, t) {
		this.writeTag(e, km.Fixed32), this.writeFloat(t)
	},
	writeDoubleField: function(e, t) {
		this.writeTag(e, km.Fixed64), this.writeDouble(t)
	},
	writeBooleanField: function(e, t) {
		this.writeVarintField(e, Boolean(t))
	}
};
var $m = {
	read: null,
	_readField: null,
	write: null
};
$m.read = function(e, t) {
	return e.readFields($m._readField, {
		field_01: "",
		field_02: "",
		field_03: "",
		field_04: "",
		field_05: "",
		field_06: "",
		field_07: "",
		field_08: "",
		field_09: "",
		field_10: "",
		field_11: "",
		field_12: "",
		field_13: "",
		field_14: "",
		field_15: "",
		field_16: "",
		field_17: "",
		field_18: "",
		field_19: "",
		field_20: "",
		field_21: "",
		field_22: "",
		field_23: "",
		field_24: ""
	}, t)
}, $m._readField = function(e, t, n) {
	1 === e ? t.field_01 = n.readString() : 2 === e ? t.field_02 = n.readString() : 3 === e ? t.field_03 = n.readString() : 4 === e ? t.field_04 = n.readString() : 5 === e ? t.field_05 = n.readString() : 6 === e ? t.field_06 = n.readString() : 7 === e ? t.field_07 = n.readString() : 8 === e ? t.field_08 = n.readString() : 9 === e ? t.field_09 = n.readString() : 10 === e ? t.field_10 = n.readString() : 11 === e ? t.field_11 = n.readString() : 12 === e ? t.field_12 = n.readString() : 13 === e ? t.field_13 = n.readString() : 14 === e ? t.field_14 = n.readString() : 15 === e ? t.field_15 = n.readString() : 16 === e ? t.field_16 = n.readString() : 17 === e ? t.field_17 = n.readString() : 18 === e ? t.field_18 = n.readString() : 19 === e ? t.field_19 = n.readString() : 20 === e ? t.field_20 = n.readString() : 21 === e ? t.field_21 = n.readString() : 22 === e ? t.field_22 = n.readString() : 23 === e ? t.field_23 = n.readString() : 24 === e && (t.field_24 = n.readString())
}, $m.write = function(e, t) {
	e.field_01 && t.writeStringField(1, e.field_01), e.field_02 && t.writeStringField(2, e.field_02), e.field_03 && t.writeStringField(3, e.field_03), e.field_04 && t.writeStringField(4, e.field_04), e.field_05 && t.writeStringField(5, e.field_05), e.field_06 && t.writeStringField(6, e.field_06), e.field_07 && t.writeStringField(7, e.field_07), e.field_08 && t.writeStringField(8, e.field_08), e.field_09 && t.writeStringField(9, e.field_09), e.field_10 && t.writeStringField(10, e.field_10), e.field_11 && t.writeStringField(11, e.field_11), e.field_12 && t.writeStringField(12, e.field_12), e.field_13 && t.writeStringField(13, e.field_13), e.field_14 && t.writeStringField(14, e.field_14), e.field_15 && t.writeStringField(15, e.field_15), e.field_16 && t.writeStringField(16, e.field_16), e.field_17 && t.writeStringField(17, e.field_17), e.field_18 && t.writeStringField(18, e.field_18), e.field_19 && t.writeStringField(19, e.field_19), e.field_20 && t.writeStringField(20, e.field_20), e.field_21 && t.writeStringField(21, e.field_21), e.field_22 && t.writeStringField(22, e.field_22), e.field_23 && t.writeStringField(23, e.field_23), e.field_24 && t.writeStringField(24, e.field_24)
};
const zm = [{
		name: "website",
		label: "website url",
		align: "left",
		field: "website"
	}, {
		name: "sitekey",
		label: "sitekey",
		align: "left",
		field: e => e.siteKey
	}, {
		name: "action",
		label: "action",
		align: "left",
		field: "action"
	}, {
		name: "isInvisible",
		label: "isInvisible",
		align: "left",
		field: e => Dm(e.isInvisible)
	}, {
		name: "recaptchaV2Normal",
		label: "recaptchaV2Normal",
		align: "left",
		field: e => Dm(e.recaptchaV2Normal)
	}, {
		name: "isReCaptchaV3",
		label: "isReCaptchaV3",
		align: "left",
		field: e => Dm(e.isReCaptchaV3)
	}, {
		name: "isEnterprise",
		label: "isEnterprise",
		align: "left",
		field: e => Dm(e.isEnterprise)
	}, {
		name: "isSRequired",
		label: "isSRequired",
		align: "left",
		field: e => Dm(e.isSRequired)
	}, {
		name: "apiDomain",
		label: "api domain",
		align: "left",
		field: "apiDomain"
	}, {
		name: "jsonValue",
		label: "Capsolver json",
		align: "left",
		field: "jsonValue"
	}],
	Nm = {},
	jm = e => {
		const t = new URL(e);
		return atob(t.searchParams.get("co").replaceAll(".", "=")).replace(":443", "")
	};

function Dm(e) {
	return e ? "✅" : "❌"
}
const Um = yt([]);
const Hm = (e, t) => {
	const n = Uint8Array.from(e, (e => e.charCodeAt(0))),
		o = new _m(n),
		l = $m.read(o),
		{
			field_14: a,
			field_08: r = ""
		} = l;
	if (Nm[a]) {
		const {
			site_url: n,
			is_enterprise: o,
			is_invisible: l,
			is_s_required: i,
			apiDomain: s,
			anchor: u
		} = Nm[a], c = r.length > 0, d = !l && !c, p = !(!l || c), f = ["accept", "accept-language", "content-type", "sec-ch-ua", "sec-ch-ua-mobile", "sec-ch-ua-platform", "sec-fetch-dest", "sec-fetch-mode", "sec-fetch-site", "x-client-data"];
		let v = "";
		const h = {};
		t.request.headers.forEach((e => {
			"referer" === e.name && (v = e.value), f.includes(e.name) && (h[e.name] = e.value)
		}));
		const m = `\n            fetch("${t.request.url}", {\n                "headers": ${JSON.stringify(h)},\n                "referrer": "${v}",\n                "referrerPolicy": "strict-origin-when-cross-origin",\n                "body": "${e}",\n                "method": "${t.request.method}",\n                "mode": "cors",\n                "credentials": "include" \n            });\n        `,
			g = btoa(unescape(encodeURIComponent(m))),
			b = JSON.stringify(JSON.parse(function(e, t, n, o, l, a, r, i, s, u) {
				let c;
				c = o ? a ? "ReCaptchaV3EnterpriseTaskProxyless" : "ReCaptchaV3TaskProxyLess" : a ? "ReCaptchaV2EnterpriseTaskProxyLess" : "ReCaptchaV2TaskProxyLess";
				const d = {
					clientKey: "YOUR_API_KEY",
					task: {
						type: c,
						websiteURL: e,
						websiteKey: t,
						anchor: s,
						reload: u
					}
				};
				return i.includes("recaptcha.net") && (d.task.apiDomain = i), o && (d.task.pageAction = n), l && (d.task.isInvisible = !0), r && (d.task.enterprisePayload = {
					s: "SOME_ADDITIONAL_TOKEN"
				}), JSON.stringify(d, null, 4)
			}(n, a, r, c, p, o, i, s, u, g)), null, 4);
		Um.value.push({
			website: n,
			siteKey: a,
			action: r,
			isInvisible: p,
			recaptchaV2Normal: d,
			isReCaptchaV3: c,
			isEnterprise: o,
			isSRequired: i,
			apiDomain: s,
			jsonValue: b
		})
	}
};

function Wm() {
	return chrome.devtools.network.onRequestFinished.addListener((e => {
		/https:\/\/(www\.)*(google\.com|recaptcha\.net)\/recaptcha\/(api2|enterprise)\/anchor/gm.test(e.request.url) ? (e => {
			const t = new URL(e.request.url),
				n = t.searchParams.get("k"),
				o = t.searchParams.get("size"),
				l = t.searchParams.get("s"),
				a = {
					site_url: jm(e.request.url),
					is_enterprise: e.request.url.includes("enterprise"),
					is_invisible: o.includes("invisible"),
					is_s_required: null != l,
					apiDomain: t.host.includes("recaptcha.net") ? "www.recaptcha.net" : ""
				};
			e.getContent((e => {
				a.anchor = btoa(unescape(encodeURIComponent(e))), Nm[n] = a
			}))
		})(e) : /https:\/\/(www\.)*(google\.com|recaptcha\.net)\/recaptcha\/(api2|enterprise)\/reload/gm.test(e.request.url) && Hm(e.request.postData.text, e)
	})), {
		reCaptchaInfo: Um,
		recaptchaColumns: zm
	}
}
const Km = {
		class: "detector"
	},
	Qm = {
		class: "logo"
	},
	Gm = ["src"],
	Zm = ["src"],
	Jm = {
		class: "content"
	},
	Xm = {
		class: "empty"
	},
	Ym = [(e => (en("data-v-f3cf53dc"), e = e(), tn(), e))((() => cl("span", null, "if you want to get captcha info, please reload page.", -1)))];
const eg = [{
	path: "/:catchAll(.*)*",
	component: () => l((() => import("./ErrorNotFound.3ced0048.js")), [])
}, {
	path: "/popup",
	component: Bf,
	redirect: {
		name: "popup"
	},
	children: [{
		path: "",
		name: "popup",
		component: Ah
	}]
}, {
	path: "/devtools",
	component: Ar(Rn({
		__name: "devtool",
		setup(e) {
			chrome.devtools.panels.create("Capsolver Captcha Detector", null, "www/index.html#/devtools");
			const {
				hCaptchaInfo: t,
				columns: n
			} = fm(), {
				funcaptchaInfo: o,
				funcaptchaColumns: l
			} = (chrome.devtools.network.onRequestFinished.addListener((e => {
				const t = e.request.url;
				/^https:\/\/[^\/]+\/fc\/[a-zA-Z0-9-]+\/public_key\/[A-Fa-f0-9\-]+$/gm.test(t) && (mm.isFunCaptcha = !0, bm(e))
			})), {
				funcaptchaInfo: hm,
				funcaptchaColumns: vm
			}), {
				reCaptchaInfo: a,
				recaptchaColumns: r
			} = Wm(), i = Ol((() => t.value.length > 0)), s = Ol((() => o.value.length > 0)), u = Ol((() => a.value.length > 0)), c = Ol((() => !i.value && !s.value && !u.value));
			return (e, d) => (Xo(), ol("div", Km, [cl("div", Qm, [cl("img", {
				class: "logo-img",
				src: kt("assets/logo.png"),
				alt: ""
			}, null, 8, Gm), cl("img", {
				class: "logo-img--text",
				src: kt("assets/dark-logo.png"),
				alt: ""
			}, null, 8, Zm)]), cl("div", Jm, [Gn(dl(sm, {
				title: "hcaptcha",
				rows: kt(t),
				columns: kt(n),
				"row-key": "name"
			}, {
				"body-cell-jsonValue": nn((e => [dl(Vh, {
					props: e
				}, {
					default: nn((() => [dl(Wf, {
						type: "textarea",
						outlined: "",
						readonly: "",
						"model-value": e.row.jsonValue,
						"onUpdate:model-value": t => e.row.jsonValue = t
					}, null, 8, ["model-value", "onUpdate:model-value"])])),
					_: 2
				}, 1032, ["props"])])),
				_: 1
			}, 8, ["rows", "columns"]), [
				[ca, kt(i)]
			]), Gn(dl(sm, {
				title: "funcaptcha",
				rows: kt(o),
				columns: kt(l),
				"row-key": "name"
			}, {
				"body-cell-jsonValue": nn((e => [dl(Vh, {
					props: e
				}, {
					default: nn((() => [dl(Wf, {
						type: "textarea",
						outlined: "",
						readonly: "",
						"model-value": e.row.jsonValue,
						"onUpdate:model-value": t => e.row.jsonValue = t
					}, null, 8, ["model-value", "onUpdate:model-value"])])),
					_: 2
				}, 1032, ["props"])])),
				"body-cell-bda": nn((e => [dl(Vh, {
					props: e
				}, {
					default: nn((() => [dl(Wf, {
						type: "textarea",
						outlined: "",
						readonly: "",
						"model-value": e.row.bda,
						"onUpdate:model-value": t => e.row.bda = t
					}, null, 8, ["model-value", "onUpdate:model-value"])])),
					_: 2
				}, 1032, ["props"])])),
				"body-cell-userAgent": nn((e => [dl(Vh, {
					props: e
				}, {
					default: nn((() => [dl(Wf, {
						type: "textarea",
						outlined: "",
						readonly: "",
						"model-value": e.row.userAgent,
						"onUpdate:model-value": t => e.row.userAgent = t
					}, null, 8, ["model-value", "onUpdate:model-value"])])),
					_: 2
				}, 1032, ["props"])])),
				_: 1
			}, 8, ["rows", "columns"]), [
				[ca, kt(s)]
			]), Gn(dl(sm, {
				title: "recaptcha",
				rows: kt(a),
				columns: kt(r),
				"row-key": "name"
			}, {
				"body-cell-jsonValue": nn((e => [dl(Vh, {
					props: e
				}, {
					default: nn((() => [dl(Wf, {
						type: "textarea",
						outlined: "",
						readonly: "",
						"model-value": e.row.jsonValue,
						"onUpdate:model-value": t => e.row.jsonValue = t
					}, null, 8, ["model-value", "onUpdate:model-value"])])),
					_: 2
				}, 1032, ["props"])])),
				_: 1
			}, 8, ["rows", "columns"]), [
				[ca, kt(u)]
			]), Gn(cl("div", Xm, Ym, 512), [
				[ca, kt(c)]
			])])]))
		}
	}), [
		["__scopeId", "data-v-f3cf53dc"]
	])
}];
var tg = function() {
	return gs({
		scrollBehavior: () => ({
			left: 0,
			top: 0
		}),
		routes: eg,
		history: fi("")
	})
};
async function ng({
	app: e,
	router: t,
	store: n
}, o) {
	let l = !1;
	const a = e => {
			if (l = !0, "string" == typeof e && /^https?:\/\//.test(e)) return void(window.location.href = e);
			const n = (e => {
				try {
					return t.resolve(e).href
				} catch (n) {}
				return Object(e) === e ? null : e
			})(e);
			null !== n && (window.location.href = n, window.location.reload())
		},
		r = window.location.href.replace(window.location.origin, "");
	for (let s = 0; !1 === l && s < o.length; s++) try {
		await o[s]({
			app: e,
			router: t,
			store: n,
			ssrContext: null,
			redirect: a,
			urlPath: r,
			publicPath: ""
		})
	} catch (i) {
		return i && i.url ? void a(i.url) : void console.error("[Quasar] boot error:", i)
	}!0 !== l && (e.use(t), chrome.runtime.id && setTimeout((() => {
		! function() {
			const t = (e, t) => {
					const n = chrome.runtime.connect({
						name: "app:" + e
					});
					let o = !1;
					n.onDisconnect.addListener((() => {
						o = !0
					})), t(new $a({
						listen(e) {
							n.onMessage.addListener(e)
						},
						send(e) {
							o || n.postMessage(e)
						}
					}))
				},
				n = e => {
					const n = chrome.devtools ? chrome.devtools.inspectedWindow.tabId : ya();
					t(n, e)
				};
			var o;
			o = t => {
				window.QBexBridge = t, e.config.globalProperties.$q.bex = window.QBexBridge, e.mount("#q-app")
			}, chrome.tabs && !chrome.devtools ? chrome.tabs.getCurrent((e => {
				e && e.id ? t(e.id, o) : n(o)
			})) : n(o)
		}()
	}), 300))
}(async function(e, t) {
	const n = e(Vr);
	n.use(Pr, t);
	const o = "function" == typeof $r ? await $r({}) : $r;
	n.use(o);
	const l = ft("function" == typeof tg ? await tg({
		store: o
	}) : tg);
	return o.use((({
		store: e
	}) => {
		e.router = l
	})), {
		app: n,
		store: o,
		router: l
	}
})(((...e) => {
	const t = va().createApp(...e),
		{
			mount: n
		} = t;
	return t.mount = e => {
		const o = function(e) {
			if (O(e)) {
				return document.querySelector(e)
			}
			return e
		}(e);
		if (!o) return;
		const l = t._component;
		R(l) || l.render || l.template || (l.template = o.innerHTML), o.innerHTML = "";
		const a = n(o, !1, o instanceof SVGElement);
		return o instanceof Element && (o.removeAttribute("v-cloak"), o.setAttribute("data-v-app", "")), a
	}, t
}), {
	config: {
		dark: !1
	}
}).then((e => {
	const [t, n] = void 0 !== Promise.allSettled ? ["allSettled", e => e.map((e => {
		if ("rejected" !== e.status) return e.value.default;
		console.error("[Quasar] boot error:", e.reason)
	}))] : ["all", e => e.map((e => e.default))];
	return Promise[t]([l((() => Promise.resolve().then((function() {
		return Rf
	}))), void 0)]).then((t => {
		const o = n(t).filter((e => "function" == typeof e));
		ng(e, o)
	}))
}));
export {
	uv as Q, Ar as _, cl as a, dl as b, ol as c, Xo as o
};
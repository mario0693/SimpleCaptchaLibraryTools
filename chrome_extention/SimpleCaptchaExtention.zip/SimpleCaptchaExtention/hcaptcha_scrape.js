(async () => {
    var e = IS_DEVELOPMENT;
    const o = "lazy";
    
    window.SimpleCaptcha = [];
    var a = {};
    var n = window.addEventListener ? "addEventListener" : "attachEvent";
    for (window[n]("attachEvent" == n ? "onmessage" : "message", async e => {
            e = e[e.message ? "message" : "data"];
            e && !0 === e.SimpleCaptcha && ("append" === e.action ? window.SimpleCaptcha.push(e.data) : "clear" === e.action ? window.SimpleCaptcha = [] : "reload" === e.action && (window.parent.postMessage({
                SimpleCaptcha: !0,
                action: "reload"
            }, "*"), window.location.reload(!0)))
        }, !1);;) {
        await Time.sleep(1e3);
        try {
            var checkboxElement = document.querySelector('#checkbox');
            if(checkboxElement)
            {
                var taskGridElement = document.querySelector('.image');
                if (taskGridElement === null) {
                    console.log("click hcaptcha checkbox")
                    checkboxElement.click();
                    await delay(3000);
                }
                else{
                    console.log("taskgrid found")
                }

            }
            //Check Block connection
            "block" === document.querySelector("#timeout_widget")?.style?.display && (window.parent.postMessage({
                SimpleCaptcha: !0,
                action: "reload"
            }, "*"), window.location.reload(!0));
            var r = document.querySelectorAll("#game_children_challenge ul > li > a");
            for (const l in r) {
                var d = r[l];
                l in a && d.removeEventListener("click", a[l]), a[l] = t.bind(this, parseInt(l)), d.addEventListener("click", a[l])
            }
        } catch (e) {}
    }
})();